package com.getjar.sdk.rewards;

import android.content.Context;
import android.os.Message;
import android.util.Log;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.GetJarConfig;
import com.getjar.sdk.rewards.GetJarWebViewActivity;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.net.MalformedURLException;
import java.net.URL;

public class GetJarWebViewClient extends WebViewClient {
    Logger log = new Logger(this);
    CommContext mCommContext;
    Context mContext;

    public GetJarWebViewClient(GetJarWebViewActivity getJarWebViewActivity, CommContext commContext) {
        this.mContext = getJarWebViewActivity;
        this.mCommContext = commContext;
    }

    public static void saveUrl(String str, CommContext commContext, Context context) {
        try {
            if (!shouldFilterUrl(str) && Utility.convertMillSec(Long.parseLong(GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_WEBVIEW_SAVED_URL_TTL))) > 0) {
                RewardUtility.saveWebUrlData(context, str);
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, String.format("saveUrl(%1$s) failed", str), e);
        }
    }

    private static boolean shouldFilterUrl(String str) {
        try {
            URL url = new URL(str);
            String query = url.getQuery();
            Log.d(Constants.TAG, String.format("shouldFilterUrl(%1$s)", String.format("%1$s://%2$s%3$s", url.getProtocol(), url.getAuthority(), url.getPath())));
            if (!StringUtility.isNullOrEmpty(query)) {
                for (String str2 : query.split(Utility.QUERY_APPENDIX)) {
                    String[] split = str2.split("=");
                    if (split.length >= 2 && split[0].equalsIgnoreCase("override.header.Cache-Control") && split[1].equalsIgnoreCase("no-cache")) {
                        return true;
                    }
                }
            }
            return false;
        } catch (MalformedURLException e) {
            Log.e(Constants.TAG, String.format("shouldFilterUrl(%1$s) failed", str), e);
            return false;
        }
    }

    public void onFormResubmission(WebView webView, Message message, Message message2) {
        message2.sendToTarget();
    }

    public void onLoadResource(WebView webView, String str) {
        this.log.verbose(String.format("Loading Resource '%1$s'", str));
    }

    public void onPageFinished(WebView webView, String str) {
        this.log.debug("OnPageFinished:" + str);
        CookieSyncManager.getInstance().sync();
        if (!str.equals(Constants.DEFAULT_ERROR_PAGE)) {
            return;
        }
        if (GetJarWebViewActivity.sErrorSource.mErrorType == GetJarWebViewActivity.ErrorType.NETWORK) {
            GetJarWebViewActivity.loadUrlInWebView(webView, "javascript:GJ.onError(\"NETWORK\",\"" + GetJarWebViewActivity.sErrorSource.mSubCode + "\")");
        } else if (GetJarWebViewActivity.sErrorSource.mErrorType == GetJarWebViewActivity.ErrorType.AUTH) {
            GetJarWebViewActivity.loadUrlInWebView(webView, "javascript:GJ.onError(\"AUTH\",\"" + GetJarWebViewActivity.sErrorSource.mSubCode + "\")");
        } else if (GetJarWebViewActivity.sErrorSource.mErrorType == GetJarWebViewActivity.ErrorType.SERVICE) {
            GetJarWebViewActivity.loadUrlInWebView(webView, "javascript:GJ.onError(\"SERVICE\",\"" + GetJarWebViewActivity.sErrorSource.mSubCode + "\")");
        }
    }

    public void onReceivedError(WebView webView, int i, String str, String str2) {
        this.log.debug(String.format("Error while loading URL '%1$s' [errorCode:%2$d description:%3$s]", str2, Integer.valueOf(i), str));
        this.log.debug("error code:" + i);
        this.log.debug("error message:" + str);
        super.onReceivedError(webView, i, str, str2);
        GetJarWebViewActivity.loadUrlInWebView(webView, Constants.DEFAULT_ERROR_PAGE);
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(WebView webView, String str) {
        this.log.debug("OverrideURl:" + str);
        if (!str.equals(Constants.DEFAULT_ERROR_PAGE)) {
            saveUrl(str, this.mCommContext, this.mContext);
        }
        GetJarWebViewActivity.loadUrlInWebView(webView, str);
        return true;
    }
}

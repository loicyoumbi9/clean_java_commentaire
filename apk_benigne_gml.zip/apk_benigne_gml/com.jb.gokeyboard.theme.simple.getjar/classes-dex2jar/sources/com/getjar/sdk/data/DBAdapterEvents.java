package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import com.getjar.sdk.events.Event;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import java.util.ArrayList;
import java.util.List;

public class DBAdapterEvents extends SQLiteOpenHelper {
    private static final String DATABASE_CREATE = "CREATE TABLE IF NOT EXISTS eventsData (id INTEGER PRIMARY KEY AUTOINCREMENT, packageName TEXT NOT NULL, eventType TEXT NOT NULL, eventTime INTEGER NOT NULL DEFAULT 0, synced INTEGER NOT NULL DEFAULT 0);";
    private static final String DATABASE_NAME = "GetJarDBEvents";
    private static final String DATABASE_TABLE = "eventsData";
    private static final int DATABASE_VERSION = 2;
    private static final int EVENT_DATABASE_CAPACITY = 1000;
    private Logger log = new Logger(this);
    private SQLiteDatabase mDatabase = getWritableDatabase();

    public DBAdapterEvents(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean addEvent(Event event) {
        try {
            if (numofdata(DATABASE_TABLE) >= EVENT_DATABASE_CAPACITY && !removeTask((long) getoldest(DATABASE_TABLE), DATABASE_TABLE)) {
                return false;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("packageName", event.getPackageName());
            contentValues.put("eventType", event.getEventType().name());
            contentValues.put("eventTime", Long.valueOf(System.currentTimeMillis()));
            contentValues.put("synced", (Integer) 0);
            return this.mDatabase.insert(DATABASE_TABLE, null, contentValues) != -1;
        } catch (SQLiteException e) {
            return false;
        }
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this.mDatabase.close();
    }

    public int getoldest(String str) {
        try {
            Cursor query = this.mDatabase.query(str, new String[]{Constants.APP_ID}, null, null, null, null, "id ASC");
            if (query == null) {
                return 0;
            }
            query.moveToFirst();
            int i = query.getInt(0);
            query.deactivate();
            query.close();
            return i;
        } catch (SQLiteException e) {
            return -1;
        }
    }

    public List<Event> loadNonSyncedEvents() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE, null, "synced = 0", null, null, null, "eventTime");
        while (query.moveToNext()) {
            try {
                Event event = new Event();
                event.setId(query.getInt(0));
                event.setPackageName(query.getString(1));
                event.setEventType(Event.EventTypes.valueOf(query.getString(2)));
                event.setEventTime(query.getLong(3));
                event.setSynced(query.getInt(4) == 1);
                arrayList.add(event);
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    public int numofdata(String str) {
        try {
            Cursor query = this.mDatabase.query(str, null, null, null, null, null, null);
            if (query == null) {
                return 0;
            }
            int count = query.getCount();
            query.deactivate();
            query.close();
            return count;
        } catch (SQLiteException e) {
            return -1;
        }
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(DATABASE_CREATE);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        this.log.info("Upgrading database from version " + i + " to " + i2 + ", which will destroy all old data");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS eventsData");
        onCreate(sQLiteDatabase);
    }

    public void purgeSyncedEvents() {
        this.mDatabase.delete(DATABASE_TABLE, "synced = 1", null);
    }

    public boolean removeTask(long j, String str) {
        try {
            return this.mDatabase.delete(str, new StringBuilder().append("id = ").append(j).toString(), null) > 0;
        } catch (SQLiteException e) {
            return false;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean updateEventAsSynced(long j) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("synced", (Integer) 1);
        return this.mDatabase.update(DATABASE_TABLE, contentValues, new StringBuilder().append("id = ").append(Long.toString(j)).toString(), null) > 0;
    }
}

package com.getjar.sdk.rewards;

import org.json.JSONException;
import org.json.JSONObject;

public class AppData {
    private String mAppLabel;
    private Integer mDbId;
    private int mFlags;
    private int mLaunchCount;
    private String mPackageName;
    private AppStatus mStatus;
    private String mTargetSDKVer;
    private long mUsageTime;
    private Integer mVersionCode;
    private String mVersionName;
    private boolean mWasRunning;

    public enum AppStatus {
        DOWNLOADED,
        INSTALLED,
        UNINSTALLED
    }

    public AppData() {
    }

    public AppData(String str, AppStatus appStatus, Integer num, String str2, String str3, int i, String str4, byte[] bArr) {
        this.mPackageName = str;
        this.mStatus = appStatus;
        this.mVersionCode = num;
        this.mVersionName = str2;
        this.mTargetSDKVer = str3;
        this.mFlags = i;
        this.mAppLabel = str4;
    }

    public boolean equals(Object obj) {
        return this.mPackageName.equals(((AppData) obj).mPackageName);
    }

    public String getAppName() {
        return this.mAppLabel;
    }

    public Integer getDBID() {
        return this.mDbId;
    }

    public int getFlags() {
        return this.mFlags;
    }

    public JSONObject getJSON() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("packageName", this.mPackageName);
        jSONObject.put("appLabel", this.mAppLabel);
        jSONObject.put("status", this.mStatus.name());
        jSONObject.put("versionCode", this.mVersionCode.intValue());
        jSONObject.put("versionName", this.mVersionName);
        jSONObject.put("targetSDKVer", this.mTargetSDKVer);
        jSONObject.put("launchCount", this.mLaunchCount);
        jSONObject.put("usageTime", this.mUsageTime);
        return jSONObject;
    }

    public int getLaunchCount() {
        return this.mLaunchCount;
    }

    public String getPackageName() {
        return this.mPackageName;
    }

    public AppStatus getStatus() {
        return this.mStatus;
    }

    public String getTargetSDKVer() {
        return this.mTargetSDKVer;
    }

    public long getUsageTime() {
        return this.mUsageTime;
    }

    public Integer getVersionCode() {
        return this.mVersionCode;
    }

    public String getVersionName() {
        return this.mVersionName;
    }

    public boolean getWasRunning() {
        return this.mWasRunning;
    }

    public int hashCode() {
        return this.mPackageName.hashCode();
    }

    public void setAppName(String str) {
        this.mAppLabel = str;
    }

    public void setDBID(Integer num) {
        this.mDbId = num;
    }

    public void setFlags(int i) {
        this.mFlags = i;
    }

    public void setLaunchCount(int i) {
        this.mLaunchCount = i;
    }

    public void setPackageName(String str) {
        this.mPackageName = str;
    }

    public void setStatus(AppStatus appStatus) {
        this.mStatus = appStatus;
    }

    public void setTargetSDKVer(String str) {
        this.mTargetSDKVer = str;
    }

    public void setUsageTime(long j) {
        this.mUsageTime = j;
    }

    public void setVersionCode(Integer num) {
        this.mVersionCode = num;
    }

    public void setVersionName(String str) {
        this.mVersionName = str;
    }

    public void setWasRunning(boolean z) {
        this.mWasRunning = z;
    }
}

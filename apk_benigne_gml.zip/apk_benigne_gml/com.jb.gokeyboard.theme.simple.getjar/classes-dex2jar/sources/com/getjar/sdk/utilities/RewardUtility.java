package com.getjar.sdk.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import com.getjar.sdk.data.DBPurchaseData;
import com.getjar.sdk.data.SalesRecord;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.utilities.Constants;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RewardUtility {
    public static final String DEVELOPER_REFERENCES = "GetJarDeveloperReferences";
    private static final String INSTALLED_APP = "AppPackageName";
    private static final String INSTALLED_APPS = "installedApps";
    public static final int INSTALL_APP_CAP = 500;
    public static final String REWARD_URL = "http://rewards.getjar.com/";
    public static final String _PreferencesInstalledAppFileName = "GetJarSDKInstalledAppPrefs";
    public static final String _PreferencesWebSettingName = "GetJarSDKWebSettingPrefs";

    public static boolean checkPermission(Context context, String str) {
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be null");
        } else if (!StringUtility.isNullOrEmpty(str)) {
            return context.checkCallingOrSelfPermission(str) == 0;
        } else {
            throw new IllegalArgumentException("'permission' can not be null or empty");
        }
    }

    public static byte[] compress(byte[] bArr) {
        if (bArr == null) {
            throw new IllegalArgumentException("compressData must have a valid context.");
        }
        Deflater deflater = new Deflater();
        deflater.setLevel(9);
        deflater.setInput(bArr);
        deflater.finish();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length);
        byte[] bArr2 = new byte[1024];
        while (!deflater.finished()) {
            byteArrayOutputStream.write(bArr2, 0, deflater.deflate(bArr2));
        }
        try {
            byteArrayOutputStream.close();
        } catch (IOException e) {
        }
        return byteArrayOutputStream.toByteArray();
    }

    public static byte[] decompress(byte[] bArr) {
        if (bArr == null) {
            throw new IllegalArgumentException("compressData must have a valid context.");
        }
        Inflater inflater = new Inflater();
        inflater.setInput(bArr);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length);
        byte[] bArr2 = new byte[1024];
        while (!inflater.finished()) {
            try {
                byteArrayOutputStream.write(bArr2, 0, inflater.inflate(bArr2));
            } catch (DataFormatException e) {
            }
        }
        try {
            byteArrayOutputStream.close();
        } catch (IOException e2) {
        }
        return byteArrayOutputStream.toByteArray();
    }

    public static HashMap<String, String> getAppMetadata(Context context, String str) throws JSONException {
        if (context != null) {
            return Utility.jsonArrayStringToMapUnchange(getAppMetadataString(context, str));
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static String getAppMetadataString(Context context, String str) {
        if (context != null) {
            return context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).getString(str + Constants.APPDATA_SUFFIX, null);
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static Map<String, ?> getDefaultSharedPrefsMap(Context context) {
        return context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).getAll();
    }

    public static Long getGetJarTimestamp(Context context) {
        if (context != null) {
            return Long.valueOf(context.getSharedPreferences(DEVELOPER_REFERENCES, 0).getLong(Constants.TIMESTAMP, 0));
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static JSONObject getInstalltedAppFromDevice(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context Object must have a valid context.");
        }
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        try {
            List<ApplicationInfo> installedApplications = context.getPackageManager().getInstalledApplications(128);
            for (int i = 0; i < installedApplications.size(); i++) {
                AppData applicationInfo = Utility.getApplicationInfo(context, installedApplications.get(i).packageName, AppData.AppStatus.INSTALLED);
                if (!Utility.shouldFilterApp(applicationInfo)) {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put(INSTALLED_APP, applicationInfo.getPackageName());
                    jSONArray.put(jSONObject2);
                }
            }
            jSONObject.put(INSTALLED_APPS, jSONArray);
            return jSONObject;
        } catch (Exception e) {
            Logger.sLog(e);
            return jSONObject;
        }
    }

    public static String getRequestInstallType(Context context, String str) {
        if (context != null) {
            return context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).getString(str + Constants.RequestInstallType.SUFFIX_DEFAULT, null);
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static int getRewardPrizeRewardApplication(Context context, String str) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else {
            SharedPreferences sharedPreferences = context.getSharedPreferences(_PreferencesInstalledAppFileName, 0);
            if (sharedPreferences.contains(str)) {
                return sharedPreferences.getInt(str, 0);
            }
            return 0;
        }
    }

    public static List<SalesRecord> getSalesRecord(Context context) {
        new ArrayList();
        DBPurchaseData dBPurchaseData = new DBPurchaseData(context);
        try {
            return dBPurchaseData.getSalesRecords();
        } finally {
            dBPurchaseData.close();
        }
    }

    public static String getSharedPrefsStringValue(Context context, String str, String str2) {
        if (context != null) {
            return context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).getString(str2, null);
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static HashMap<String, String> getTrackingMetadata(Context context, String str) throws JSONException {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        String trackingMetadataString = getTrackingMetadataString(context, str);
        Logger.sLog("tracking data" + trackingMetadataString);
        return Utility.jsonArrayStringToMapUnchange(trackingMetadataString);
    }

    public static String getTrackingMetadataString(Context context, String str) {
        if (context != null) {
            return context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).getString(str + Constants.TRACKING_SUFFIX, null);
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    public static Map<String, ?> getWebSharedPrefsMap(Context context) {
        return context.getSharedPreferences(_PreferencesWebSettingName, 0).getAll();
    }

    public static boolean isPreInstallRewardApplication(Context context, String str) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else {
            SharedPreferences sharedPreferences = context.getSharedPreferences(_PreferencesInstalledAppFileName, 0);
            return sharedPreferences.contains(new StringBuilder().append(str).append(Constants.RequestInstallType.SUFFIX_STATE).toString()) && sharedPreferences.getString(new StringBuilder().append(str).append(Constants.RequestInstallType.SUFFIX_STATE).toString(), Constants.RequestInstallState.UNKNOWN.toString()).equals(Constants.RequestInstallState.UNKNOWN.toString());
        }
    }

    private static void maintainLimit(SharedPreferences sharedPreferences, int i) {
        if (sharedPreferences == null) {
            throw new IllegalArgumentException("'sharedPreferences' can not be null");
        }
        Map<String, ?> all = sharedPreferences.getAll();
        Logger.sLog("Number of entry:" + all.size());
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            if (i < all.size()) {
                sharedPreferences.edit().remove(entry.getKey()).commit();
                i++;
                Logger.sLog("SharedPreference Entry name:" + entry.getKey());
            } else {
                return;
            }
        }
    }

    public static void removePreInstallRewardApplication(Context context, String str) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else {
            SharedPreferences sharedPreferences = context.getSharedPreferences(_PreferencesInstalledAppFileName, 0);
            if (sharedPreferences.contains(str)) {
                sharedPreferences.edit().remove(str).commit();
            }
            if (sharedPreferences.contains(new StringBuffer(str).append(".blob").toString())) {
                sharedPreferences.edit().remove(new StringBuffer(str).append(".blob").toString()).commit();
            }
        }
    }

    public static void removeSPEntry(SharedPreferences.Editor editor, String str) {
        editor.remove(str + Constants.RequestInstallType.SUFFIX_DEFAULT);
        editor.remove(str + Constants.RequestInstallType.SUFFIX_STATE);
        editor.remove(str + Constants.RequestInstallType.SUFFIX_SUBSTATE);
        editor.remove(str + Constants.APPDATA_FRIENDLY_SUFFIX);
        editor.remove(str + Constants.RequestInstallType.SUFFIX_APP_ID);
        editor.remove(str + Constants.RequestInstallType.SUFFIX_AMOUNT);
        editor.remove(str + Constants.APPDATA_TIMESTAMP_SUFFIX);
        editor.remove(str + Constants.RequestInstallType.SUFFIX_NOTIFICATION);
        editor.commit();
    }

    public static void saveGetJarTimestamp(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        context.getSharedPreferences(DEVELOPER_REFERENCES, 0).edit().putLong(Constants.TIMESTAMP, System.currentTimeMillis()).commit();
    }

    public static void savePreInstallRewardApplication(Context context, String str, int i) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else if (i < 0) {
            throw new IllegalArgumentException("Must provide a non negative cost. " + i);
        } else {
            SharedPreferences sharedPreferences = context.getSharedPreferences(_PreferencesInstalledAppFileName, 0);
            maintainLimit(sharedPreferences, 500);
            sharedPreferences.edit().putInt(str, i).commit();
        }
    }

    public static void savePreInstallRewardApplicationMetadata(Context context, String str, String str2) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty App Id.");
        } else {
            context.getSharedPreferences(_PreferencesInstalledAppFileName, 0).edit().putString(str, str2).commit();
        }
    }

    public static void saveSalesRecord(Context context, String str, String str2) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty product id.");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty transaction Id.");
        } else {
            DBPurchaseData dBPurchaseData = new DBPurchaseData(context);
            try {
                dBPurchaseData.insertPurchase(new SalesRecord(str, str2));
            } finally {
                dBPurchaseData.close();
            }
        }
    }

    public static void saveWebUrlData(Context context, String str) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty url.");
        } else {
            SharedPreferences.Editor edit = context.getSharedPreferences(_PreferencesWebSettingName, 0).edit();
            edit.putLong(Constants.WEB_TIMESTAMP, new Date().getTime()).commit();
            edit.putString(Constants.WEB_LAST_KNOWN, str).commit();
            edit.commit();
            Log.v(Constants.TAG, String.format("Last known URL updated to '%1$s'", str));
        }
    }

    public static String sdkUUID() {
        UUID randomUUID = UUID.randomUUID();
        Logger.sLog("Random UUID String = " + randomUUID.toString());
        Logger.sLog("UUID version       = " + randomUUID.version());
        Logger.sLog("UUID variant       = " + randomUUID.variant());
        return randomUUID.toString();
    }
}

package com.getjar.sdk.comm.persistence;

import com.getjar.sdk.comm.persistence.DBTransactions;
import com.getjar.sdk.utilities.Base64;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.Serializable;

public class PurchaseUnmanagedBucket extends TransactionBucket {
    public PurchaseUnmanagedBucket() {
        setType(DBTransactions.TransactionType.PURCHASE);
    }

    public PurchaseUnmanagedBucket(String str, Serializable serializable) throws IOException {
        super(str, DBTransactions.TransactionType.PURCHASE, serializable);
    }

    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public RelatedPurchaseData getRelatedObject() throws IOException, ClassNotFoundException {
        if (StringUtility.isNullOrEmpty(this._relatedObject)) {
            return null;
        }
        return (RelatedPurchaseData) Base64.decodeToObject(this._relatedObject);
    }

    public DBTransactions.PurchaseState getState() {
        return (DBTransactions.PurchaseState) Enum.valueOf(DBTransactions.PurchaseState.class, super.getStateString());
    }

    public void setState(DBTransactions.PurchaseState purchaseState) {
        setStateString(purchaseState.name());
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setStateString(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'state' can not be NULL or empty");
        }
        try {
            Enum.valueOf(DBTransactions.PurchaseState.class, str);
            super.setStateString(str);
        } catch (Exception e) {
            throw new IllegalArgumentException(String.format("Can not set the state for PurchaseBucket to '%1$s'", str), e);
        }
    }

    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setType(DBTransactions.TransactionType transactionType) {
        if (!DBTransactions.TransactionType.PURCHASE.equals(transactionType)) {
            throw new IllegalArgumentException(String.format("Can not set the TransactionType for PurchaseBucket to '%1$s'", transactionType.name()));
        } else {
            super.setTypeString(DBTransactions.TransactionType.PURCHASE.name());
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setTypeString(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'type' can not be NULL or empty");
        }
        if (!DBTransactions.TransactionType.PURCHASE.equals((DBTransactions.TransactionType) Enum.valueOf(DBTransactions.TransactionType.class, str))) {
            throw new IllegalArgumentException(String.format("Can not set the TransactionType for PurchaseBucket to '%1$s'", str));
        } else {
            super.setTypeString(DBTransactions.TransactionType.PURCHASE.name());
        }
    }
}

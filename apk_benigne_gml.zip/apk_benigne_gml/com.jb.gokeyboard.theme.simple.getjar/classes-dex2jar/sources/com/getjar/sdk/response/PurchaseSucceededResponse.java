package com.getjar.sdk.response;

import android.os.Parcel;
import android.os.Parcelable;

public class PurchaseSucceededResponse extends PurchaseResponse {
    public static final Parcelable.Creator<PurchaseSucceededResponse> CREATOR = new Parcelable.Creator<PurchaseSucceededResponse>() {
        /* class com.getjar.sdk.response.PurchaseSucceededResponse.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public PurchaseSucceededResponse createFromParcel(Parcel parcel) {
            return new PurchaseSucceededResponse(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public PurchaseSucceededResponse[] newArray(int i) {
            return new PurchaseSucceededResponse[i];
        }
    };

    public PurchaseSucceededResponse(Parcel parcel) {
        super(parcel);
    }

    public PurchaseSucceededResponse(String str, long j, String str2, String str3) {
        super(str, j, str2, str3);
    }
}

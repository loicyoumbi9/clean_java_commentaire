package com.getjar.sdk.data;

public class TransactionItem {
    private String mClientTransactionID;
    private String mItemId;
    private String mItemMetaData;
    private String mPackageName;
    private String mTrackingData;

    public TransactionItem(String str, String str2, String str3, String str4, String str5) {
        this.mPackageName = str;
        this.mItemId = str2;
        this.mClientTransactionID = str3;
        this.mItemMetaData = str4;
        this.mTrackingData = str5;
    }

    public String getItemId() {
        return this.mItemId;
    }

    public String getMetaData() {
        return this.mItemMetaData;
    }

    public String getPackageName() {
        return this.mPackageName;
    }

    public String getTrackingData() {
        return this.mTrackingData;
    }

    public String getTransactionId() {
        return this.mClientTransactionID;
    }
}

package com.getjar.sdk.comm;

import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

public class LocalizationServiceProxy extends AuthorizedServiceProxyBase {
    private static final String _CONTRACT_VERSION = "20120810";
    private static LocalizationServiceProxy _Instance = null;
    private static final String _URL_TEMPLATE_PRICING_RATIOS = String.format("%1$s%2$s", "%1$slocalization/pricing_ratios/%2$s?version=", _CONTRACT_VERSION);

    private LocalizationServiceProxy() {
    }

    public static LocalizationServiceProxy getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    private static void makeTheInstance() {
        synchronized (LocalizationServiceProxy.class) {
            try {
                if (_Instance == null) {
                    _Instance = new LocalizationServiceProxy();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public Operation getPricingRatio(CommContext commContext, CallbackInterface callbackInterface) throws UnsupportedEncodingException, JSONException, InterruptedException, TimeoutException, Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            String country = commContext.getApplicationContext().getResources().getConfiguration().locale.getCountry();
            return makeAsyncGETRequestForJson("getPricingRatio", Operation.Priority.MEDIUM, commContext, String.format(_URL_TEMPLATE_PRICING_RATIOS, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_LOCALIZATION_SERVICE_ENDPOINT), URLEncoder.encode(country, Constants.ENCODING_CHARSET)), callbackInterface, true);
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase, com.getjar.sdk.comm.AuthorizedServiceProxyBase
    public Request.ServiceName getServiceName() {
        return Request.ServiceName.LOCALIZATION;
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase, com.getjar.sdk.comm.AuthorizedServiceProxyBase
    public void preRequestWork(Operation operation) throws Exception {
        operation.getCommContext().waitForAuthorization();
    }
}

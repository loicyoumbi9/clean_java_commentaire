package com.getjar.sdk.utilities;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class Base64 {
    static final /* synthetic */ boolean $assertionsDisabled = (!Base64.class.desiredAssertionStatus());
    public static final int DECODE = 0;
    public static final int DONT_GUNZIP = 4;
    public static final int DO_BREAK_LINES = 8;
    public static final int ENCODE = 1;
    private static final byte EQUALS_SIGN = 61;
    private static final byte EQUALS_SIGN_ENC = -1;
    public static final int GZIP = 2;
    private static final int MAX_LINE_LENGTH = 76;
    private static final byte NEW_LINE = 10;
    public static final int NO_OPTIONS = 0;
    public static final int ORDERED = 32;
    private static final String PREFERRED_ENCODING = "US-ASCII";
    public static final int URL_SAFE = 16;
    private static final byte WHITE_SPACE_ENC = -5;
    private static final byte[] _ORDERED_ALPHABET = {45, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122};
    private static final byte[] _ORDERED_DECODABET = {-9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 0, -9, -9, 1, 2, 3, 4, 5, 6, 7, 8, 9, NEW_LINE, -9, -9, -9, EQUALS_SIGN_ENC, -9, -9, -9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, -9, -9, -9, -9, 37, -9, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, EQUALS_SIGN, 62, 63, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9};
    private static final byte[] _STANDARD_ALPHABET = {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
    private static final byte[] _STANDARD_DECODABET = {-9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, EQUALS_SIGN, -9, -9, -9, EQUALS_SIGN_ENC, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, NEW_LINE, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9};
    private static final byte[] _URL_SAFE_ALPHABET = {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
    private static final byte[] _URL_SAFE_DECODABET = {-9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, WHITE_SPACE_ENC, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, EQUALS_SIGN, -9, -9, -9, EQUALS_SIGN_ENC, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, NEW_LINE, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9};

    public static class InputStream extends FilterInputStream {
        private boolean breakLines;
        private byte[] buffer;
        private int bufferLength;
        private byte[] decodabet;
        private boolean encode;
        private int lineLength;
        private int numSigBytes;
        private int options;
        private int position;

        public InputStream(java.io.InputStream inputStream) {
            this(inputStream, 0);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public InputStream(java.io.InputStream inputStream, int i) {
            super(inputStream);
            boolean z = true;
            this.options = i;
            this.breakLines = (i & 8) > 0;
            this.encode = (i & 1) <= 0 ? false : z;
            this.bufferLength = this.encode ? 4 : 3;
            this.buffer = new byte[this.bufferLength];
            this.position = -1;
            this.lineLength = 0;
            this.decodabet = Base64.getDecodabet(i);
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read() throws IOException {
            int read;
            if (this.position < 0) {
                if (this.encode) {
                    byte[] bArr = new byte[3];
                    int i = 0;
                    for (int i2 = 0; i2 < 3; i2++) {
                        int read2 = this.in.read();
                        if (read2 < 0) {
                            break;
                        }
                        bArr[i2] = (byte) read2;
                        i++;
                    }
                    if (i <= 0) {
                        return -1;
                    }
                    byte[] unused = Base64.encode3to4(bArr, 0, i, this.buffer, 0, this.options);
                    this.position = 0;
                    this.numSigBytes = 4;
                } else {
                    byte[] bArr2 = new byte[4];
                    int i3 = 0;
                    while (i3 < 4) {
                        do {
                            read = this.in.read();
                            if (read < 0) {
                                break;
                            }
                        } while (this.decodabet[read & 127] <= -5);
                        if (read < 0) {
                            break;
                        }
                        bArr2[i3] = (byte) read;
                        i3++;
                    }
                    if (i3 == 4) {
                        this.numSigBytes = Base64.decode4to3(bArr2, 0, this.buffer, 0, this.options);
                        this.position = 0;
                    } else if (i3 == 0) {
                        return -1;
                    } else {
                        throw new IOException("Improperly padded Base64 input.");
                    }
                }
            }
            if (this.position < 0) {
                throw new IOException("Error in Base64 code reading stream.");
            } else if (this.position >= this.numSigBytes) {
                return -1;
            } else {
                if (!this.encode || !this.breakLines || this.lineLength < Base64.MAX_LINE_LENGTH) {
                    this.lineLength++;
                    byte[] bArr3 = this.buffer;
                    int i4 = this.position;
                    this.position = i4 + 1;
                    byte b = bArr3[i4];
                    if (this.position >= this.bufferLength) {
                        this.position = -1;
                    }
                    return b & Base64.EQUALS_SIGN_ENC;
                }
                this.lineLength = 0;
                return 10;
            }
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read(byte[] bArr, int i, int i2) throws IOException {
            int i3 = 0;
            while (i3 < i2) {
                int read = read();
                if (read >= 0) {
                    bArr[i + i3] = (byte) read;
                    i3++;
                } else if (i3 == 0) {
                    return -1;
                } else {
                    return i3;
                }
            }
            return i3;
        }
    }

    public static class OutputStream extends FilterOutputStream {
        private byte[] b4;
        private boolean breakLines;
        private byte[] buffer;
        private int bufferLength;
        private byte[] decodabet;
        private boolean encode;
        private int lineLength;
        private int options;
        private int position;
        private boolean suspendEncoding;

        public OutputStream(java.io.OutputStream outputStream) {
            this(outputStream, 1);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public OutputStream(java.io.OutputStream outputStream, int i) {
            super(outputStream);
            boolean z = true;
            this.breakLines = (i & 8) != 0;
            this.encode = (i & 1) == 0 ? false : z;
            this.bufferLength = this.encode ? 3 : 4;
            this.buffer = new byte[this.bufferLength];
            this.position = 0;
            this.lineLength = 0;
            this.suspendEncoding = false;
            this.b4 = new byte[4];
            this.options = i;
            this.decodabet = Base64.getDecodabet(i);
        }

        @Override // java.io.OutputStream, java.io.Closeable, java.io.FilterOutputStream, java.lang.AutoCloseable
        public void close() throws IOException {
            flushBase64();
            super.close();
            this.buffer = null;
            this.out = null;
        }

        public void flushBase64() throws IOException {
            if (this.position <= 0) {
                return;
            }
            if (this.encode) {
                this.out.write(Base64.encode3to4(this.b4, this.buffer, this.position, this.options));
                this.position = 0;
                return;
            }
            throw new IOException("Base64 input not properly padded.");
        }

        public void resumeEncoding() {
            this.suspendEncoding = false;
        }

        public void suspendEncoding() throws IOException {
            flushBase64();
            this.suspendEncoding = true;
        }

        @Override // java.io.OutputStream, java.io.FilterOutputStream
        public void write(int i) throws IOException {
            if (this.suspendEncoding) {
                this.out.write(i);
            } else if (this.encode) {
                byte[] bArr = this.buffer;
                int i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) i;
                if (this.position >= this.bufferLength) {
                    this.out.write(Base64.encode3to4(this.b4, this.buffer, this.bufferLength, this.options));
                    this.lineLength += 4;
                    if (this.breakLines && this.lineLength >= Base64.MAX_LINE_LENGTH) {
                        this.out.write(10);
                        this.lineLength = 0;
                    }
                    this.position = 0;
                }
            } else if (this.decodabet[i & 127] > -5) {
                byte[] bArr2 = this.buffer;
                int i3 = this.position;
                this.position = i3 + 1;
                bArr2[i3] = (byte) i;
                if (this.position >= this.bufferLength) {
                    this.out.write(this.b4, 0, Base64.decode4to3(this.buffer, 0, this.b4, 0, this.options));
                    this.position = 0;
                }
            } else if (this.decodabet[i & 127] != -5) {
                throw new IOException("Invalid character in Base64 data.");
            }
        }

        @Override // java.io.OutputStream, java.io.FilterOutputStream
        public void write(byte[] bArr, int i, int i2) throws IOException {
            if (this.suspendEncoding) {
                this.out.write(bArr, i, i2);
                return;
            }
            for (int i3 = 0; i3 < i2; i3++) {
                write(bArr[i + i3]);
            }
        }
    }

    private Base64() {
    }

    public static byte[] decode(String str) throws IOException {
        return decode(str, 0);
    }

    public static byte[] decode(String str, int i) throws IOException {
        byte[] bytes;
        Throwable th;
        GZIPInputStream gZIPInputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        ByteArrayInputStream byteArrayInputStream;
        GZIPInputStream gZIPInputStream2;
        if (str == null) {
            throw new NullPointerException("Input string was null.");
        }
        try {
            bytes = str.getBytes(PREFERRED_ENCODING);
        } catch (UnsupportedEncodingException e) {
            bytes = str.getBytes();
        }
        byte[] decode = decode(bytes, 0, bytes.length, i);
        boolean z = (i & 4) != 0;
        if (decode != null && decode.length >= 4 && !z) {
            if (35615 == (((decode[1] << 8) & 65280) | (decode[0] & EQUALS_SIGN_ENC))) {
                byte[] bArr = new byte[2048];
                try {
                    byteArrayOutputStream = new ByteArrayOutputStream();
                } catch (IOException e2) {
                    e = e2;
                    gZIPInputStream2 = null;
                    byteArrayInputStream = null;
                    byteArrayOutputStream = null;
                    try {
                        e.printStackTrace();
                        try {
                            byteArrayOutputStream.close();
                        } catch (Exception e3) {
                        }
                        try {
                            gZIPInputStream2.close();
                        } catch (Exception e4) {
                        }
                        try {
                            byteArrayInputStream.close();
                            return decode;
                        } catch (Exception e5) {
                            return decode;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        gZIPInputStream = gZIPInputStream2;
                        try {
                            byteArrayOutputStream.close();
                        } catch (Exception e6) {
                        }
                        try {
                            gZIPInputStream.close();
                        } catch (Exception e7) {
                        }
                        try {
                            byteArrayInputStream.close();
                        } catch (Exception e8) {
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    gZIPInputStream = null;
                    byteArrayOutputStream = null;
                    byteArrayInputStream = null;
                    byteArrayOutputStream.close();
                    gZIPInputStream.close();
                    byteArrayInputStream.close();
                    throw th;
                }
                try {
                    byteArrayInputStream = new ByteArrayInputStream(decode);
                    try {
                        gZIPInputStream2 = new GZIPInputStream(byteArrayInputStream);
                        while (true) {
                            try {
                                int read = gZIPInputStream2.read(bArr);
                                if (read < 0) {
                                    break;
                                }
                                byteArrayOutputStream.write(bArr, 0, read);
                            } catch (IOException e9) {
                                e = e9;
                            } catch (Throwable th4) {
                                gZIPInputStream = gZIPInputStream2;
                                th = th4;
                                byteArrayOutputStream.close();
                                gZIPInputStream.close();
                                byteArrayInputStream.close();
                                throw th;
                            }
                        }
                        byte[] byteArray = byteArrayOutputStream.toByteArray();
                        try {
                            byteArrayOutputStream.close();
                        } catch (Exception e10) {
                        }
                        try {
                            gZIPInputStream2.close();
                        } catch (Exception e11) {
                        }
                        try {
                            byteArrayInputStream.close();
                            return byteArray;
                        } catch (Exception e12) {
                            return byteArray;
                        }
                    } catch (IOException e13) {
                        e = e13;
                        gZIPInputStream2 = null;
                        e.printStackTrace();
                        byteArrayOutputStream.close();
                        gZIPInputStream2.close();
                        byteArrayInputStream.close();
                        return decode;
                    } catch (Throwable th5) {
                        gZIPInputStream = null;
                        th = th5;
                        byteArrayOutputStream.close();
                        gZIPInputStream.close();
                        byteArrayInputStream.close();
                        throw th;
                    }
                } catch (IOException e14) {
                    e = e14;
                    gZIPInputStream2 = null;
                    byteArrayInputStream = null;
                    e.printStackTrace();
                    byteArrayOutputStream.close();
                    gZIPInputStream2.close();
                    byteArrayInputStream.close();
                    return decode;
                } catch (Throwable th6) {
                    gZIPInputStream = null;
                    th = th6;
                    byteArrayInputStream = null;
                    byteArrayOutputStream.close();
                    gZIPInputStream.close();
                    byteArrayInputStream.close();
                    throw th;
                }
            }
        }
        return decode;
    }

    public static byte[] decode(byte[] bArr) throws IOException {
        return decode(bArr, 0, bArr.length, 0);
    }

    public static byte[] decode(byte[] bArr, int i, int i2, int i3) throws IOException {
        int i4;
        if (bArr == null) {
            throw new NullPointerException("Cannot decode null source array.");
        } else if (i < 0 || i + i2 > bArr.length) {
            throw new IllegalArgumentException(String.format("Source array with length %d cannot have offset of %d and process %d bytes.", Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i2)));
        } else if (i2 == 0) {
            return new byte[0];
        } else {
            if (i2 < 4) {
                throw new IllegalArgumentException("Base64-encoded string must have at least four characters, but length specified was " + i2);
            }
            byte[] decodabet = getDecodabet(i3);
            byte[] bArr2 = new byte[((i2 * 3) / 4)];
            byte[] bArr3 = new byte[4];
            int i5 = i;
            int i6 = 0;
            int i7 = 0;
            while (i5 < i + i2) {
                byte b = decodabet[bArr[i5] & EQUALS_SIGN_ENC];
                if (b >= -5) {
                    if (b >= -1) {
                        i4 = i7 + 1;
                        bArr3[i7] = bArr[i5];
                        if (i4 > 3) {
                            i6 += decode4to3(bArr3, 0, bArr2, i6, i3);
                            if (bArr[i5] == 61) {
                                break;
                            }
                            i4 = 0;
                        } else {
                            continue;
                        }
                    } else {
                        i4 = i7;
                    }
                    i5++;
                    i7 = i4;
                } else {
                    throw new IOException(String.format("Bad Base64 input character decimal %d in array position %d", Integer.valueOf(bArr[i5] & EQUALS_SIGN_ENC), Integer.valueOf(i5)));
                }
            }
            byte[] bArr4 = new byte[i6];
            System.arraycopy(bArr2, 0, bArr4, 0, i6);
            return bArr4;
        }
    }

    /* access modifiers changed from: private */
    public static int decode4to3(byte[] bArr, int i, byte[] bArr2, int i2, int i3) {
        if (bArr == null) {
            throw new NullPointerException("Source array was null.");
        } else if (bArr2 == null) {
            throw new NullPointerException("Destination array was null.");
        } else if (i < 0 || i + 3 >= bArr.length) {
            throw new IllegalArgumentException(String.format("Source array with length %d cannot have offset of %d and still process four bytes.", Integer.valueOf(bArr.length), Integer.valueOf(i)));
        } else if (i2 < 0 || i2 + 2 >= bArr2.length) {
            throw new IllegalArgumentException(String.format("Destination array with length %d cannot have offset of %d and still store three bytes.", Integer.valueOf(bArr2.length), Integer.valueOf(i2)));
        } else {
            byte[] decodabet = getDecodabet(i3);
            if (bArr[i + 2] == 61) {
                bArr2[i2] = (byte) ((((decodabet[bArr[i]] & EQUALS_SIGN_ENC) << 18) | ((decodabet[bArr[i + 1]] & EQUALS_SIGN_ENC) << 12)) >>> 16);
                return 1;
            } else if (bArr[i + 3] == 61) {
                int i4 = ((decodabet[bArr[i]] & EQUALS_SIGN_ENC) << 18) | ((decodabet[bArr[i + 1]] & EQUALS_SIGN_ENC) << 12) | ((decodabet[bArr[i + 2]] & EQUALS_SIGN_ENC) << 6);
                bArr2[i2] = (byte) (i4 >>> 16);
                bArr2[i2 + 1] = (byte) (i4 >>> 8);
                return 2;
            } else {
                byte b = ((decodabet[bArr[i]] & EQUALS_SIGN_ENC) << 18) | ((decodabet[bArr[i + 1]] & EQUALS_SIGN_ENC) << 12) | ((decodabet[bArr[i + 2]] & EQUALS_SIGN_ENC) << 6) | (decodabet[bArr[i + 3]] & EQUALS_SIGN_ENC);
                bArr2[i2] = (byte) (b >> 16);
                bArr2[i2 + 1] = (byte) (b >> 8);
                bArr2[i2 + 2] = (byte) b;
                return 3;
            }
        }
    }

    public static void decodeFileToFile(String str, String str2) throws IOException {
        BufferedOutputStream bufferedOutputStream;
        BufferedOutputStream bufferedOutputStream2 = null;
        byte[] decodeFromFile = decodeFromFile(str);
        try {
            bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(str2));
            try {
                bufferedOutputStream.write(decodeFromFile);
                try {
                    bufferedOutputStream.close();
                } catch (Exception e) {
                }
            } catch (IOException e2) {
                e = e2;
                try {
                    throw e;
                } catch (Throwable th) {
                    th = th;
                    bufferedOutputStream2 = bufferedOutputStream;
                }
            } catch (Throwable th2) {
                th = th2;
                try {
                    bufferedOutputStream.close();
                } catch (Exception e3) {
                }
                throw th;
            }
        } catch (IOException e4) {
            e = e4;
            bufferedOutputStream = null;
            throw e;
        } catch (Throwable th3) {
            th = th3;
            bufferedOutputStream = bufferedOutputStream2;
            bufferedOutputStream.close();
            throw th;
        }
    }

    public static byte[] decodeFromFile(String str) throws IOException {
        Throwable th;
        InputStream inputStream;
        Throwable th2;
        InputStream inputStream2;
        int i = 0;
        try {
            File file = new File(str);
            if (file.length() > 2147483647L) {
                throw new IOException("File is too big for this convenience method (" + file.length() + " bytes).");
            }
            byte[] bArr = new byte[((int) file.length())];
            inputStream2 = new InputStream(new BufferedInputStream(new FileInputStream(file)), 0);
            while (true) {
                try {
                    int read = inputStream2.read(bArr, i, 4096);
                    if (read >= 0) {
                        i = read + i;
                    } else {
                        byte[] bArr2 = new byte[i];
                        System.arraycopy(bArr, 0, bArr2, 0, i);
                        try {
                            inputStream2.close();
                            return bArr2;
                        } catch (Exception e) {
                            return bArr2;
                        }
                    }
                } catch (IOException e2) {
                    e = e2;
                    try {
                        throw e;
                    } catch (Throwable th3) {
                        th = th3;
                        inputStream = inputStream2;
                    }
                } catch (Throwable th4) {
                    th2 = th4;
                    try {
                        inputStream2.close();
                    } catch (Exception e3) {
                    }
                    throw th2;
                }
            }
        } catch (IOException e4) {
            e = e4;
            inputStream2 = null;
            throw e;
        } catch (Throwable th5) {
            th = th5;
            inputStream = null;
            inputStream2 = inputStream;
            th2 = th;
            inputStream2.close();
            throw th2;
        }
    }

    public static void decodeToFile(String str, String str2) throws IOException {
        Throwable th;
        OutputStream outputStream;
        Throwable th2;
        OutputStream outputStream2;
        try {
            outputStream2 = new OutputStream(new FileOutputStream(str2), 0);
            try {
                outputStream2.write(str.getBytes(PREFERRED_ENCODING));
                try {
                    outputStream2.close();
                } catch (Exception e) {
                }
            } catch (IOException e2) {
                e = e2;
                try {
                    throw e;
                } catch (Throwable th3) {
                    th = th3;
                    outputStream = outputStream2;
                }
            } catch (Throwable th4) {
                th2 = th4;
                try {
                    outputStream2.close();
                } catch (Exception e3) {
                }
                throw th2;
            }
        } catch (IOException e4) {
            e = e4;
            outputStream2 = null;
            throw e;
        } catch (Throwable th5) {
            th = th5;
            outputStream = null;
            outputStream2 = outputStream;
            th2 = th;
            outputStream2.close();
            throw th2;
        }
    }

    public static Object decodeToObject(String str) throws IOException, ClassNotFoundException {
        return decodeToObject(str, 0, null);
    }

    /* JADX WARNING: Unknown top exception splitter block from list: {B:17:0x0025=Splitter:B:17:0x0025, B:30:0x0037=Splitter:B:30:0x0037} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object decodeToObject(java.lang.String r5, int r6, final java.lang.ClassLoader r7) throws java.io.IOException, java.lang.ClassNotFoundException {
        /*
            r1 = 0
            byte[] r0 = decode(r5, r6)
            java.io.ByteArrayInputStream r3 = new java.io.ByteArrayInputStream     // Catch:{ IOException -> 0x0030, ClassNotFoundException -> 0x0034, all -> 0x0051 }
            r3.<init>(r0)     // Catch:{ IOException -> 0x0030, ClassNotFoundException -> 0x0034, all -> 0x0051 }
            if (r7 != 0) goto L_0x001d
            java.io.ObjectInputStream r0 = new java.io.ObjectInputStream     // Catch:{ IOException -> 0x0023, ClassNotFoundException -> 0x0044, all -> 0x0049 }
            r0.<init>(r3)     // Catch:{ IOException -> 0x0023, ClassNotFoundException -> 0x0044, all -> 0x0049 }
        L_0x0011:
            java.lang.Object r1 = r0.readObject()     // Catch:{ IOException -> 0x0041, ClassNotFoundException -> 0x0047, all -> 0x004d }
            r3.close()     // Catch:{ Exception -> 0x003b }
        L_0x0018:
            r0.close()     // Catch:{ Exception -> 0x0038 }
            r0 = r1
        L_0x001c:
            return r0
        L_0x001d:
            com.getjar.sdk.utilities.Base64$1 r0 = new com.getjar.sdk.utilities.Base64$1     // Catch:{ IOException -> 0x0023, ClassNotFoundException -> 0x0044, all -> 0x0049 }
            r0.<init>(r3, r7)     // Catch:{ IOException -> 0x0023, ClassNotFoundException -> 0x0044, all -> 0x0049 }
            goto L_0x0011
        L_0x0023:
            r2 = move-exception
        L_0x0024:
            r0 = r1
        L_0x0025:
            throw r2     // Catch:{ all -> 0x0026 }
        L_0x0026:
            r1 = move-exception
            r2 = r1
            r4 = r0
        L_0x0029:
            r3.close()     // Catch:{ Exception -> 0x003d }
        L_0x002c:
            r4.close()     // Catch:{ Exception -> 0x003f }
        L_0x002f:
            throw r2
        L_0x0030:
            r2 = move-exception
            r0 = r1
            r3 = r1
            goto L_0x0025
        L_0x0034:
            r2 = move-exception
            r0 = r1
            r3 = r1
        L_0x0037:
            throw r2     // Catch:{ all -> 0x0026 }
        L_0x0038:
            r0 = move-exception
            r0 = r1
            goto L_0x001c
        L_0x003b:
            r2 = move-exception
            goto L_0x0018
        L_0x003d:
            r0 = move-exception
            goto L_0x002c
        L_0x003f:
            r0 = move-exception
            goto L_0x002f
        L_0x0041:
            r2 = move-exception
            r1 = r0
            goto L_0x0024
        L_0x0044:
            r2 = move-exception
            r0 = r1
            goto L_0x0037
        L_0x0047:
            r2 = move-exception
            goto L_0x0037
        L_0x0049:
            r0 = move-exception
            r2 = r0
            r4 = r1
            goto L_0x0029
        L_0x004d:
            r1 = move-exception
            r2 = r1
            r4 = r0
            goto L_0x0029
        L_0x0051:
            r0 = move-exception
            r2 = r0
            r4 = r1
            r3 = r1
            goto L_0x0029
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.utilities.Base64.decodeToObject(java.lang.String, int, java.lang.ClassLoader):java.lang.Object");
    }

    public static void encode(ByteBuffer byteBuffer, ByteBuffer byteBuffer2) {
        byte[] bArr = new byte[3];
        byte[] bArr2 = new byte[4];
        while (byteBuffer.hasRemaining()) {
            int min = Math.min(3, byteBuffer.remaining());
            byteBuffer.get(bArr, 0, min);
            encode3to4(bArr2, bArr, min, 0);
            byteBuffer2.put(bArr2);
        }
    }

    public static void encode(ByteBuffer byteBuffer, CharBuffer charBuffer) {
        byte[] bArr = new byte[3];
        byte[] bArr2 = new byte[4];
        while (byteBuffer.hasRemaining()) {
            int min = Math.min(3, byteBuffer.remaining());
            byteBuffer.get(bArr, 0, min);
            encode3to4(bArr2, bArr, min, 0);
            for (int i = 0; i < 4; i++) {
                charBuffer.put((char) (bArr2[i] & EQUALS_SIGN_ENC));
            }
        }
    }

    /* access modifiers changed from: private */
    public static byte[] encode3to4(byte[] bArr, int i, int i2, byte[] bArr2, int i3, int i4) {
        int i5 = 0;
        byte[] alphabet = getAlphabet(i4);
        int i6 = i2 > 0 ? (bArr[i] << 24) >>> 8 : 0;
        int i7 = i2 > 1 ? (bArr[i + 1] << 24) >>> 16 : 0;
        if (i2 > 2) {
            i5 = (bArr[i + 2] << 24) >>> 24;
        }
        int i8 = i5 | i7 | i6;
        switch (i2) {
            case 1:
                bArr2[i3] = alphabet[i8 >>> 18];
                bArr2[i3 + 1] = alphabet[(i8 >>> 12) & 63];
                bArr2[i3 + 2] = EQUALS_SIGN;
                bArr2[i3 + 3] = EQUALS_SIGN;
                break;
            case 2:
                bArr2[i3] = alphabet[i8 >>> 18];
                bArr2[i3 + 1] = alphabet[(i8 >>> 12) & 63];
                bArr2[i3 + 2] = alphabet[(i8 >>> 6) & 63];
                bArr2[i3 + 3] = EQUALS_SIGN;
                break;
            case 3:
                bArr2[i3] = alphabet[i8 >>> 18];
                bArr2[i3 + 1] = alphabet[(i8 >>> 12) & 63];
                bArr2[i3 + 2] = alphabet[(i8 >>> 6) & 63];
                bArr2[i3 + 3] = alphabet[i8 & 63];
                break;
        }
        return bArr2;
    }

    /* access modifiers changed from: private */
    public static byte[] encode3to4(byte[] bArr, byte[] bArr2, int i, int i2) {
        encode3to4(bArr2, 0, i, bArr, 0, i2);
        return bArr;
    }

    public static String encodeBytes(byte[] bArr) {
        String str = null;
        try {
            str = encodeBytes(bArr, 0, bArr.length, 0);
        } catch (IOException e) {
            if (!$assertionsDisabled) {
                throw new AssertionError(e.getMessage());
            }
        }
        if ($assertionsDisabled || str != null) {
            return str;
        }
        throw new AssertionError();
    }

    public static String encodeBytes(byte[] bArr, int i) throws IOException {
        return encodeBytes(bArr, 0, bArr.length, i);
    }

    public static String encodeBytes(byte[] bArr, int i, int i2) {
        String str = null;
        try {
            str = encodeBytes(bArr, i, i2, 0);
        } catch (IOException e) {
            if (!$assertionsDisabled) {
                throw new AssertionError(e.getMessage());
            }
        }
        if ($assertionsDisabled || str != null) {
            return str;
        }
        throw new AssertionError();
    }

    public static String encodeBytes(byte[] bArr, int i, int i2, int i3) throws IOException {
        byte[] encodeBytesToBytes = encodeBytesToBytes(bArr, i, i2, i3);
        try {
            return new String(encodeBytesToBytes, PREFERRED_ENCODING);
        } catch (UnsupportedEncodingException e) {
            return new String(encodeBytesToBytes);
        }
    }

    public static byte[] encodeBytesToBytes(byte[] bArr) {
        try {
            return encodeBytesToBytes(bArr, 0, bArr.length, 0);
        } catch (IOException e) {
            if ($assertionsDisabled) {
                return null;
            }
            throw new AssertionError("IOExceptions only come from GZipping, which is turned off: " + e.getMessage());
        }
    }

    public static byte[] encodeBytesToBytes(byte[] bArr, int i, int i2, int i3) throws IOException {
        Throwable th;
        GZIPOutputStream gZIPOutputStream;
        OutputStream outputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        GZIPOutputStream gZIPOutputStream2;
        if (bArr == null) {
            throw new NullPointerException("Cannot serialize a null array.");
        } else if (i < 0) {
            throw new IllegalArgumentException("Cannot have negative offset: " + i);
        } else if (i2 < 0) {
            throw new IllegalArgumentException("Cannot have length offset: " + i2);
        } else if (i + i2 > bArr.length) {
            throw new IllegalArgumentException(String.format("Cannot have offset of %d and length of %d with array of length %d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(bArr.length)));
        } else if ((i3 & 2) != 0) {
            try {
                byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    outputStream = new OutputStream(byteArrayOutputStream, i3 | 1);
                    try {
                        gZIPOutputStream2 = new GZIPOutputStream(outputStream);
                    } catch (IOException e) {
                        e = e;
                        gZIPOutputStream2 = null;
                        try {
                            throw e;
                        } catch (Throwable th2) {
                            th = th2;
                            gZIPOutputStream = gZIPOutputStream2;
                        }
                    } catch (Throwable th3) {
                        gZIPOutputStream = null;
                        th = th3;
                        try {
                            gZIPOutputStream.close();
                        } catch (Exception e2) {
                        }
                        try {
                            outputStream.close();
                        } catch (Exception e3) {
                        }
                        try {
                            byteArrayOutputStream.close();
                        } catch (Exception e4) {
                        }
                        throw th;
                    }
                } catch (IOException e5) {
                    e = e5;
                    gZIPOutputStream2 = null;
                    outputStream = null;
                    throw e;
                } catch (Throwable th4) {
                    gZIPOutputStream = null;
                    outputStream = null;
                    th = th4;
                    gZIPOutputStream.close();
                    outputStream.close();
                    byteArrayOutputStream.close();
                    throw th;
                }
                try {
                    gZIPOutputStream2.write(bArr, i, i2);
                    gZIPOutputStream2.close();
                    try {
                        gZIPOutputStream2.close();
                    } catch (Exception e6) {
                    }
                    try {
                        outputStream.close();
                    } catch (Exception e7) {
                    }
                    try {
                        byteArrayOutputStream.close();
                    } catch (Exception e8) {
                    }
                    return byteArrayOutputStream.toByteArray();
                } catch (IOException e9) {
                    e = e9;
                    throw e;
                } catch (Throwable th5) {
                    gZIPOutputStream = gZIPOutputStream2;
                    th = th5;
                    gZIPOutputStream.close();
                    outputStream.close();
                    byteArrayOutputStream.close();
                    throw th;
                }
            } catch (IOException e10) {
                e = e10;
                gZIPOutputStream2 = null;
                outputStream = null;
                byteArrayOutputStream = null;
                throw e;
            } catch (Throwable th6) {
                th = th6;
                gZIPOutputStream = null;
                outputStream = null;
                byteArrayOutputStream = null;
                gZIPOutputStream.close();
                outputStream.close();
                byteArrayOutputStream.close();
                throw th;
            }
        } else {
            boolean z = (i3 & 8) != 0;
            int i4 = (i2 % 3 > 0 ? 4 : 0) + ((i2 / 3) * 4);
            if (z) {
                i4 += i4 / MAX_LINE_LENGTH;
            }
            byte[] bArr2 = new byte[i4];
            int i5 = 0;
            int i6 = 0;
            int i7 = 0;
            while (i5 < i2 - 2) {
                encode3to4(bArr, i5 + i, 3, bArr2, i7, i3);
                int i8 = i6 + 4;
                if (z && i8 >= MAX_LINE_LENGTH) {
                    bArr2[i7 + 4] = NEW_LINE;
                    i7++;
                    i8 = 0;
                }
                i7 += 4;
                i5 += 3;
                i6 = i8;
            }
            if (i5 < i2) {
                encode3to4(bArr, i5 + i, i2 - i5, bArr2, i7, i3);
                i7 += 4;
            }
            if (i7 > bArr2.length - 1) {
                return bArr2;
            }
            byte[] bArr3 = new byte[i7];
            System.arraycopy(bArr2, 0, bArr3, 0, i7);
            return bArr3;
        }
    }

    public static void encodeFileToFile(String str, String str2) throws IOException {
        BufferedOutputStream bufferedOutputStream;
        BufferedOutputStream bufferedOutputStream2 = null;
        String encodeFromFile = encodeFromFile(str);
        try {
            bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(str2));
            try {
                bufferedOutputStream.write(encodeFromFile.getBytes(PREFERRED_ENCODING));
                try {
                    bufferedOutputStream.close();
                } catch (Exception e) {
                }
            } catch (IOException e2) {
                e = e2;
                try {
                    throw e;
                } catch (Throwable th) {
                    th = th;
                    bufferedOutputStream2 = bufferedOutputStream;
                }
            } catch (Throwable th2) {
                th = th2;
                try {
                    bufferedOutputStream.close();
                } catch (Exception e3) {
                }
                throw th;
            }
        } catch (IOException e4) {
            e = e4;
            bufferedOutputStream = null;
            throw e;
        } catch (Throwable th3) {
            th = th3;
            bufferedOutputStream = bufferedOutputStream2;
            bufferedOutputStream.close();
            throw th;
        }
    }

    public static String encodeFromFile(String str) throws IOException {
        Throwable th;
        InputStream inputStream;
        Throwable th2;
        InputStream inputStream2;
        int i = 0;
        try {
            File file = new File(str);
            byte[] bArr = new byte[Math.max((int) ((((double) file.length()) * 1.4d) + 1.0d), 40)];
            inputStream2 = new InputStream(new BufferedInputStream(new FileInputStream(file)), 1);
            while (true) {
                try {
                    int read = inputStream2.read(bArr, i, 4096);
                    if (read >= 0) {
                        i = read + i;
                    } else {
                        String str2 = new String(bArr, 0, i, PREFERRED_ENCODING);
                        try {
                            inputStream2.close();
                            return str2;
                        } catch (Exception e) {
                            return str2;
                        }
                    }
                } catch (IOException e2) {
                    e = e2;
                    try {
                        throw e;
                    } catch (Throwable th3) {
                        th = th3;
                        inputStream = inputStream2;
                    }
                } catch (Throwable th4) {
                    th2 = th4;
                    try {
                        inputStream2.close();
                    } catch (Exception e3) {
                    }
                    throw th2;
                }
            }
        } catch (IOException e4) {
            e = e4;
            inputStream2 = null;
            throw e;
        } catch (Throwable th5) {
            th = th5;
            inputStream = null;
            inputStream2 = inputStream;
            th2 = th;
            inputStream2.close();
            throw th2;
        }
    }

    public static String encodeObject(Serializable serializable) throws IOException {
        return encodeObject(serializable, 0);
    }

    public static String encodeObject(Serializable serializable, int i) throws IOException {
        Throwable th;
        ObjectOutputStream objectOutputStream;
        GZIPOutputStream gZIPOutputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        OutputStream outputStream;
        ObjectOutputStream objectOutputStream2;
        Throwable th2;
        ObjectOutputStream objectOutputStream3;
        Throwable th3;
        if (serializable == null) {
            throw new NullPointerException("Cannot serialize a null object.");
        }
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                outputStream = new OutputStream(byteArrayOutputStream, i | 1);
                if ((i & 2) != 0) {
                    try {
                        gZIPOutputStream = new GZIPOutputStream(outputStream);
                    } catch (IOException e) {
                        e = e;
                        objectOutputStream3 = null;
                        gZIPOutputStream = null;
                        try {
                            throw e;
                        } catch (Throwable th4) {
                            th = th4;
                            objectOutputStream = objectOutputStream3;
                        }
                    } catch (Throwable th5) {
                        th3 = th5;
                        objectOutputStream2 = null;
                        gZIPOutputStream = null;
                        th2 = th3;
                        try {
                            objectOutputStream2.close();
                        } catch (Exception e2) {
                        }
                        try {
                            gZIPOutputStream.close();
                        } catch (Exception e3) {
                        }
                        try {
                            outputStream.close();
                        } catch (Exception e4) {
                        }
                        try {
                            byteArrayOutputStream.close();
                        } catch (Exception e5) {
                        }
                        throw th2;
                    }
                    try {
                        objectOutputStream3 = new ObjectOutputStream(gZIPOutputStream);
                    } catch (IOException e6) {
                        e = e6;
                        objectOutputStream3 = null;
                        throw e;
                    } catch (Throwable th6) {
                        th2 = th6;
                        objectOutputStream2 = null;
                        objectOutputStream2.close();
                        gZIPOutputStream.close();
                        outputStream.close();
                        byteArrayOutputStream.close();
                        throw th2;
                    }
                } else {
                    objectOutputStream3 = new ObjectOutputStream(outputStream);
                    gZIPOutputStream = null;
                }
            } catch (IOException e7) {
                e = e7;
                objectOutputStream3 = null;
                gZIPOutputStream = null;
                outputStream = null;
                throw e;
            } catch (Throwable th7) {
                th2 = th7;
                objectOutputStream2 = null;
                gZIPOutputStream = null;
                outputStream = null;
                objectOutputStream2.close();
                gZIPOutputStream.close();
                outputStream.close();
                byteArrayOutputStream.close();
                throw th2;
            }
            try {
                objectOutputStream3.writeObject(serializable);
                try {
                    objectOutputStream3.close();
                } catch (Exception e8) {
                }
                try {
                    gZIPOutputStream.close();
                } catch (Exception e9) {
                }
                try {
                    outputStream.close();
                } catch (Exception e10) {
                }
                try {
                    byteArrayOutputStream.close();
                } catch (Exception e11) {
                }
                try {
                    return new String(byteArrayOutputStream.toByteArray(), PREFERRED_ENCODING);
                } catch (UnsupportedEncodingException e12) {
                    return new String(byteArrayOutputStream.toByteArray());
                }
            } catch (IOException e13) {
                e = e13;
                throw e;
            } catch (Throwable th8) {
                th3 = th8;
                objectOutputStream2 = objectOutputStream3;
                th2 = th3;
                objectOutputStream2.close();
                gZIPOutputStream.close();
                outputStream.close();
                byteArrayOutputStream.close();
                throw th2;
            }
        } catch (IOException e14) {
            e = e14;
            objectOutputStream3 = null;
            gZIPOutputStream = null;
            outputStream = null;
            byteArrayOutputStream = null;
            throw e;
        } catch (Throwable th9) {
            th = th9;
            objectOutputStream = null;
            gZIPOutputStream = null;
            byteArrayOutputStream = null;
            outputStream = null;
            th2 = th;
            objectOutputStream2.close();
            gZIPOutputStream.close();
            outputStream.close();
            byteArrayOutputStream.close();
            throw th2;
        }
    }

    public static void encodeToFile(byte[] bArr, String str) throws IOException {
        Throwable th;
        OutputStream outputStream;
        OutputStream outputStream2;
        if (bArr == null) {
            throw new NullPointerException("Data to encode was null.");
        }
        try {
            outputStream2 = new OutputStream(new FileOutputStream(str), 1);
            try {
                outputStream2.write(bArr);
                try {
                    outputStream2.close();
                } catch (Exception e) {
                }
            } catch (IOException e2) {
                e = e2;
                try {
                    throw e;
                } catch (Throwable th2) {
                    th = th2;
                    outputStream = outputStream2;
                }
            } catch (Throwable th3) {
                th = th3;
                try {
                    outputStream2.close();
                } catch (Exception e3) {
                }
                throw th;
            }
        } catch (IOException e4) {
            e = e4;
            outputStream2 = null;
            throw e;
        } catch (Throwable th4) {
            th = th4;
            outputStream = null;
            outputStream2 = outputStream;
            outputStream2.close();
            throw th;
        }
    }

    private static final byte[] getAlphabet(int i) {
        return (i & 16) == 16 ? _URL_SAFE_ALPHABET : (i & 32) == 32 ? _ORDERED_ALPHABET : _STANDARD_ALPHABET;
    }

    /* access modifiers changed from: private */
    public static final byte[] getDecodabet(int i) {
        return (i & 16) == 16 ? _URL_SAFE_DECODABET : (i & 32) == 32 ? _ORDERED_DECODABET : _STANDARD_DECODABET;
    }
}

package com.getjar.sdk.comm;

public class ServicesException extends Exception {
    private Result _requestResult = null;

    public ServicesException(String str, Result result) {
        super(str);
        this._requestResult = result;
    }

    public Result getRequestResult() {
        return this._requestResult;
    }
}

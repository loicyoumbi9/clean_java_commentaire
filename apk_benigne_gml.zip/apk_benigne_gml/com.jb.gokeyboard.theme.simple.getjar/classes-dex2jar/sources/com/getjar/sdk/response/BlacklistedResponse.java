package com.getjar.sdk.response;

import android.os.Parcel;
import android.os.Parcelable;

public class BlacklistedResponse extends Response {
    public static final Parcelable.Creator<BlacklistedResponse> CREATOR = new Parcelable.Creator<BlacklistedResponse>() {
        /* class com.getjar.sdk.response.BlacklistedResponse.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public BlacklistedResponse createFromParcel(Parcel parcel) {
            return new BlacklistedResponse(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public BlacklistedResponse[] newArray(int i) {
            return new BlacklistedResponse[i];
        }
    };
    private BlacklistType _blacklistType;

    public enum BlacklistType {
        DEVICE,
        USER,
        APP
    }

    public BlacklistedResponse(Parcel parcel) {
        super(parcel);
        this._blacklistType = BlacklistType.valueOf(parcel.readString());
    }

    public BlacklistedResponse(BlacklistType blacklistType) {
        this._blacklistType = blacklistType;
    }

    public BlacklistType getBlacklistType() {
        return this._blacklistType;
    }

    @Override // com.getjar.sdk.response.Response
    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeString(this._blacklistType.name());
    }
}

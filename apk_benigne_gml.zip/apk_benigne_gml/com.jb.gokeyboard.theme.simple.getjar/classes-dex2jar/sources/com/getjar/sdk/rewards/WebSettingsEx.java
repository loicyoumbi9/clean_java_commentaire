package com.getjar.sdk.rewards;

import android.util.Log;
import android.webkit.WebSettings;
import com.getjar.sdk.utilities.Constants;

public abstract class WebSettingsEx {
    /* access modifiers changed from: private */
    public static Class _ZoomDensityClass;

    public static class ZoomDensity {
        public static Object CLOSE;
        public static Object FAR;
        public static Object MEDIUM;

        static {
            FAR = null;
            MEDIUM = null;
            CLOSE = null;
            try {
                if (WebSettingsEx._ZoomDensityClass != null) {
                    Object[] enumConstants = WebSettingsEx._ZoomDensityClass.getEnumConstants();
                    for (Object obj : enumConstants) {
                        obj.getClass().getDeclaredField("value").setAccessible(true);
                        if ("FAR".equals(obj.toString())) {
                            FAR = obj;
                        } else if ("MEDIUM".equals(obj.toString())) {
                            MEDIUM = obj;
                        } else if ("CLOSE".equals(obj.toString())) {
                            CLOSE = obj;
                        }
                    }
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    static {
        _ZoomDensityClass = null;
        _ZoomDensityClass = null;
        Class<?>[] declaredClasses = WebSettings.class.getDeclaredClasses();
        for (Class<?> cls : declaredClasses) {
            if ("ZoomDensity".equals(cls.getSimpleName())) {
                _ZoomDensityClass = cls;
                return;
            }
        }
    }

    public static void setDefaultZoom(WebSettings webSettings, Object obj) {
        try {
            if (_ZoomDensityClass == null) {
                return;
            }
            if (obj == null) {
                throw new IllegalArgumentException("'value' can not be NULL");
            } else if (!_ZoomDensityClass.isInstance(obj)) {
                throw new IllegalArgumentException(String.format("'value' must be an instance of %1$s", _ZoomDensityClass.getName()));
            } else {
                webSettings.getClass().getMethod("setDefaultZoom", _ZoomDensityClass).invoke(webSettings, obj);
                Log.v(Constants.TAG, String.format("WebSettings.setDefaultZoom(ZoomDensity.%1$s) successfully called", obj));
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.w(Constants.TAG, String.format("Unable to call WebSettings.setDefaultZoom(ZoomDensity.%1$s)", obj));
        }
    }
}

package com.getjar.sdk.listener;

public interface RecommendedPriceListener {
    void recommendedPriceEvent(long j);
}

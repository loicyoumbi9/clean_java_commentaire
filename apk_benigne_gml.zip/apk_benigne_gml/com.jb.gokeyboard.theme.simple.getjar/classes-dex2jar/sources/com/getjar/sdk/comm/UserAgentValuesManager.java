package com.getjar.sdk.comm;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.webkit.WebView;
import com.getjar.sdk.utilities.BuildVersion;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.OverridesUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;

public class UserAgentValuesManager {
    private static UserAgentValuesManager _Instance = null;
    private static final String _PrefsKeyUserAgent = "UserAgent";
    private Object _asyncWebKitWorkMonitorObject = new Object();
    private boolean _asyncWebKitWorkWasSignalled = false;
    private volatile String _sdkUserAgent = null;
    private Object _sdkUserAgentLock = new Object();
    /* access modifiers changed from: private */
    public volatile String _webKitUserAgent = null;
    private Object _webKitUserAgentLock = new Object();

    private UserAgentValuesManager() {
    }

    /* access modifiers changed from: private */
    public void asyncWebKitWorkNotify() {
        synchronized (this._asyncWebKitWorkMonitorObject) {
            this._asyncWebKitWorkWasSignalled = true;
            this._asyncWebKitWorkMonitorObject.notify();
        }
    }

    private void asyncWebKitWorkWait() throws InterruptedException {
        synchronized (this._asyncWebKitWorkMonitorObject) {
            while (!this._asyncWebKitWorkWasSignalled) {
                try {
                    this._asyncWebKitWorkMonitorObject.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            this._asyncWebKitWorkWasSignalled = false;
        }
    }

    public static UserAgentValuesManager getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    /* access modifiers changed from: private */
    public String getWebKitUserAgentInternal(Context context) {
        if (context != null) {
            return new WebView(context).getSettings().getUserAgentString();
        }
        throw new IllegalArgumentException("Must have a valid context.");
    }

    private static void makeTheInstance() {
        synchronized (UserAgentValuesManager.class) {
            try {
                if (_Instance == null) {
                    _Instance = new UserAgentValuesManager();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public String getSdkUserAgent(Context context, String str) {
        if (StringUtility.isNullOrEmpty(this._sdkUserAgent)) {
            synchronized (this._sdkUserAgentLock) {
                if (StringUtility.isNullOrEmpty(this._sdkUserAgent)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(Constants.USER_AGENT_APP);
                    sb.append(BuildVersion.BUILD_VERSION);
                    sb.append(" ");
                    try {
                        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0);
                        sb.append(packageInfo.packageName).append("/").append(packageInfo.versionCode);
                    } catch (Exception e) {
                        sb.append(Constants.USER_AGENT_UNKOWN_APP);
                    }
                    sb.append(" ").append("android").append("/").append(Build.VERSION.RELEASE).append(" (").append(Build.BRAND).append("; ").append(Build.PRODUCT).append("; ").append(Build.MODEL).append(")");
                    this._sdkUserAgent = sb.toString();
                    Log.d(Constants.TAG, String.format("SDK User Agent value: '%1$s'", this._sdkUserAgent));
                }
            }
        }
        return this._sdkUserAgent;
    }

    public String getWebKitUserAgent(final Context context) throws InterruptedException {
        if (StringUtility.isNullOrEmpty(this._webKitUserAgent)) {
            synchronized (this._webKitUserAgentLock) {
                if (StringUtility.isNullOrEmpty(this._webKitUserAgent)) {
                    String value = OverridesUtility.getValue("webkit.user.agent");
                    if (!StringUtility.isNullOrEmpty(value)) {
                        Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'webkit.user.agent' = '%1$s'", value));
                        return value;
                    }
                    SharedPreferences sharedPreferences = context.getSharedPreferences("GetJarClientPrefs", 0);
                    if (sharedPreferences.contains(_PrefsKeyUserAgent)) {
                        this._webKitUserAgent = sharedPreferences.getString(_PrefsKeyUserAgent, "");
                    }
                    if (StringUtility.isNullOrEmpty(this._webKitUserAgent)) {
                        if (!Utility.isCurrentThreadTheUIThread()) {
                            new Handler(context.getMainLooper()).post(new Runnable() {
                                /* class com.getjar.sdk.comm.UserAgentValuesManager.AnonymousClass1 */

                                public void run() {
                                    try {
                                        String unused = UserAgentValuesManager.this._webKitUserAgent = UserAgentValuesManager.this.getWebKitUserAgentInternal(context);
                                    } finally {
                                        UserAgentValuesManager.this.asyncWebKitWorkNotify();
                                    }
                                }
                            });
                            asyncWebKitWorkWait();
                        } else {
                            this._webKitUserAgent = getWebKitUserAgentInternal(context);
                        }
                        sharedPreferences.edit().putString(_PrefsKeyUserAgent, this._webKitUserAgent).commit();
                    }
                    Log.d(Constants.TAG, String.format("WebKit User Agent value: '%1$s'", this._webKitUserAgent));
                }
            }
        }
        return this._webKitUserAgent;
    }
}

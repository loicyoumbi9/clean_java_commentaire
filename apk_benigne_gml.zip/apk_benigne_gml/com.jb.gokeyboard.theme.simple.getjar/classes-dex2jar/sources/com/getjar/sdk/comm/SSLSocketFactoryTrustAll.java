package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;

public class SSLSocketFactoryTrustAll extends SSLSocketFactory {
    private static final X509HostnameVerifier _HostnameVerifier = new X509HostnameVerifier() {
        /* class com.getjar.sdk.comm.SSLSocketFactoryTrustAll.AnonymousClass2 */

        @Override // org.apache.http.conn.ssl.X509HostnameVerifier
        public void verify(String str, X509Certificate x509Certificate) throws SSLException {
        }

        @Override // org.apache.http.conn.ssl.X509HostnameVerifier
        public void verify(String str, SSLSocket sSLSocket) throws IOException {
        }

        @Override // org.apache.http.conn.ssl.X509HostnameVerifier
        public void verify(String str, String[] strArr, String[] strArr2) throws SSLException {
        }

        @Override // org.apache.http.conn.ssl.X509HostnameVerifier
        public boolean verify(String str, SSLSession sSLSession) {
            return true;
        }
    };
    private static final TrustManager[] _TrustAllCerts = {new X509TrustManager() {
        /* class com.getjar.sdk.comm.SSLSocketFactoryTrustAll.AnonymousClass1 */

        @Override // javax.net.ssl.X509TrustManager
        public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
        }

        @Override // javax.net.ssl.X509TrustManager
        public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    }};
    private SSLContext _sslContext = SSLContext.getInstance("TLS");

    public SSLSocketFactoryTrustAll(KeyStore keyStore) throws Exception {
        super(keyStore);
        try {
            this._sslContext.init(null, _TrustAllCerts, null);
            setHostnameVerifier(_HostnameVerifier);
        } catch (Exception e) {
            Log.e(Constants.TAG, "SSLSocketFactoryTrustAll constructor failed", e);
            throw e;
        }
    }

    @Override // org.apache.http.conn.scheme.SocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
    public Socket createSocket() throws IOException {
        return this._sslContext.getSocketFactory().createSocket();
    }

    @Override // org.apache.http.conn.scheme.LayeredSocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
    public Socket createSocket(Socket socket, String str, int i, boolean z) throws IOException, UnknownHostException {
        return this._sslContext.getSocketFactory().createSocket(socket, str, i, z);
    }
}

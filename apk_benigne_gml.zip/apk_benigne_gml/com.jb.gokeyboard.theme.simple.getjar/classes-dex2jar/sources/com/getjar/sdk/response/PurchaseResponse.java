package com.getjar.sdk.response;

import android.os.Parcel;

public abstract class PurchaseResponse extends Response {
    private long _amount;
    private String _productId;
    private String _productName;
    private String _transactionId;

    public PurchaseResponse(Parcel parcel) {
        super(parcel);
        this._productId = parcel.readString();
        this._amount = parcel.readLong();
        this._productName = parcel.readString();
        this._transactionId = parcel.readString();
    }

    public PurchaseResponse(String str, long j, String str2, String str3) {
        this._productId = str;
        this._amount = j;
        this._productName = str2;
        this._transactionId = str3;
    }

    public long getAmount() {
        return this._amount;
    }

    public String getProductId() {
        return this._productId;
    }

    public String getProductName() {
        return this._productName;
    }

    public String getTransactionId() {
        return this._transactionId;
    }

    @Override // com.getjar.sdk.response.Response
    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeString(this._productId);
        parcel.writeLong(this._amount);
        parcel.writeString(this._productName);
        parcel.writeString(this._transactionId);
    }
}

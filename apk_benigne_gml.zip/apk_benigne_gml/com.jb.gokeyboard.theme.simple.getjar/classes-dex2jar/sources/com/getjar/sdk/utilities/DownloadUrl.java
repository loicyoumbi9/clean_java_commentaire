package com.getjar.sdk.utilities;

import android.graphics.Bitmap;

public class DownloadUrl {
    private Bitmap mAppIcon;
    private String mAppLink;
    private String mAppName;
    private String mAppPackageName;
    private Bitmap mGetIcon;
    private String mGetJarLink;
    private String mGetJarName;
    private String mGetJarPackageName;

    public DownloadUrl(String str, String str2, String str3, String str4, String str5, String str6, Bitmap bitmap, Bitmap bitmap2) {
        this.mAppName = str;
        this.mAppLink = str3;
        this.mGetJarLink = str6;
        this.mGetIcon = bitmap2;
        this.mAppIcon = bitmap;
        this.mAppPackageName = str2;
        this.mGetJarName = str4;
        this.mGetJarPackageName = str5;
    }

    public Bitmap getAppIcon() {
        return this.mAppIcon;
    }

    public String getAppLink() {
        return this.mAppLink;
    }

    public String getAppName() {
        return this.mAppName;
    }

    public String getAppPackageName() {
        return this.mAppPackageName;
    }

    public Bitmap getGetJarIcon() {
        return this.mGetIcon;
    }

    public String getGetJarLink() {
        return this.mGetJarLink;
    }

    public String getGetJarName() {
        return this.mGetJarName;
    }

    public String getGetPackageName() {
        return this.mGetJarPackageName;
    }
}

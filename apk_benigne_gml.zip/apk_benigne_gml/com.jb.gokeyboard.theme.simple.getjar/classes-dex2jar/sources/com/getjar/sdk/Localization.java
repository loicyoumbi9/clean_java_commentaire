package com.getjar.sdk;

import android.util.Log;
import com.getjar.sdk.data.LocalizationEngine;
import com.getjar.sdk.listener.PricingRatioListener;
import com.getjar.sdk.listener.RecommendedPriceListener;
import com.getjar.sdk.utilities.Constants;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class Localization {
    private static final ExecutorService _ExecutorService = Executors.newCachedThreadPool();
    private LocalizationEngine _localizationEngine = null;

    private class PricingRatioCallable implements Callable<Float> {
        private PricingRatioListener _callback = null;
        private Future<Float> _pricingRatioFuture = null;

        PricingRatioCallable(Future<Float> future, PricingRatioListener pricingRatioListener) {
            if (future == null) {
                throw new IllegalArgumentException("'pricingRatioFuture', can not be NULL");
            } else if (pricingRatioListener == null) {
                throw new IllegalArgumentException("'callback', can not be NULL");
            } else {
                this._pricingRatioFuture = future;
                this._callback = pricingRatioListener;
            }
        }

        @Override // java.util.concurrent.Callable
        public Float call() {
            Float f;
            try {
                f = this._pricingRatioFuture.get();
                try {
                    this._callback.pricingRatioEvent(f.floatValue());
                } catch (Exception e) {
                    e = e;
                    Log.e(Constants.TAG, "PricingRatioCallbackCallable failed", e);
                    return f;
                }
            } catch (Exception e2) {
                e = e2;
                f = null;
                Log.e(Constants.TAG, "PricingRatioCallbackCallable failed", e);
                return f;
            }
            return f;
        }
    }

    private class RecommendedPriceCallable implements Callable<Long> {
        private RecommendedPriceListener _callback;
        private Future<Float> _pricingRatioFuture;
        private long _sourcePrice;

        RecommendedPriceCallable(Future<Float> future, long j) {
            this._pricingRatioFuture = null;
            this._callback = null;
            if (future == null) {
                throw new IllegalArgumentException("'pricingRatioFuture', can not be NULL");
            } else if (j <= 0) {
                throw new IllegalArgumentException("'sourcePrice' must be greater than zero");
            } else {
                this._pricingRatioFuture = future;
                this._sourcePrice = j;
            }
        }

        RecommendedPriceCallable(Localization localization, Future<Float> future, long j, RecommendedPriceListener recommendedPriceListener) {
            this(future, j);
            if (recommendedPriceListener == null) {
                throw new IllegalArgumentException("'callback', can not be NULL");
            }
            this._callback = recommendedPriceListener;
        }

        @Override // java.util.concurrent.Callable
        public Long call() {
            Long l;
            try {
                l = Long.valueOf(Localization.this.getRecommendedPriceInternal(this._sourcePrice, this._pricingRatioFuture.get().floatValue()));
                try {
                    if (this._callback != null) {
                        this._callback.recommendedPriceEvent(l.longValue());
                    }
                } catch (Exception e) {
                    e = e;
                    Log.e(Constants.TAG, "PricingRatioCallbackCallable failed", e);
                    return l;
                }
            } catch (Exception e2) {
                e = e2;
                l = null;
            }
            return l;
        }
    }

    public Localization(GetJarContext getJarContext) {
        if (getJarContext == null) {
            throw new IllegalArgumentException("'getJarContext' can not be NULL");
        }
        this._localizationEngine = new LocalizationEngine(getJarContext.getCommContext());
    }

    /* access modifiers changed from: private */
    public long getRecommendedPriceInternal(long j, float f) {
        float f2 = 1.0f;
        if (j <= 0) {
            throw new IllegalArgumentException("'sourcePrice' must be greater than zero");
        } else if (f <= 0.0f) {
            throw new IllegalArgumentException("'pricingRatio' must be greater than zero");
        } else if (f > 2.0f) {
            throw new IllegalArgumentException("'pricingRatio' must be less than or equal to two");
        } else {
            float f3 = ((float) j) * f;
            Log.v(Constants.TAG, String.format("getRecommendedPrice() theAmount:%1$d  pricingRatio:%2$f  price:%3$f", Long.valueOf(j), Float.valueOf(f), Float.valueOf(f3)));
            float floor = (float) Math.floor((double) f3);
            Log.v(Constants.TAG, String.format("getRecommendedPrice() price_floor:%1$f", Float.valueOf(floor)));
            float f4 = floor - (floor % 5.0f);
            Log.v(Constants.TAG, String.format("getRecommendedPrice() price_to_multiple:%1$f", Float.valueOf(f4)));
            if (f4 >= 1.0f) {
                f2 = f4;
            }
            Log.v(Constants.TAG, String.format("getRecommendedPrice() price_returned:%1$f", Float.valueOf(f2)));
            return (long) f2;
        }
    }

    public float getPricingRatio() {
        try {
            return this._localizationEngine.getPricingRatio(false);
        } catch (Exception e) {
            Log.e(Constants.TAG, "getPricingRatio() failed", e);
            return 1.0f;
        }
    }

    public Future<Float> getPricingRatioAsync() {
        return this._localizationEngine.getPricingRatioAsync();
    }

    public Future<Float> getPricingRatioAsync(PricingRatioListener pricingRatioListener) {
        if (pricingRatioListener == null) {
            throw new IllegalArgumentException("'callback', can not be NULL");
        }
        FutureTask futureTask = new FutureTask(new PricingRatioCallable(getPricingRatioAsync(), pricingRatioListener));
        _ExecutorService.execute(futureTask);
        return futureTask;
    }

    public long getRecommendedPrice(long j) {
        if (j <= 0) {
            throw new IllegalArgumentException("Prices must always be greater than zero");
        }
        try {
            return getRecommendedPriceInternal(j, getPricingRatio());
        } catch (Exception e) {
            Log.e(Constants.TAG, "getRecommendedPrice() failed", e);
            return j;
        }
    }

    public Future<Long> getRecommendedPriceAsync(long j) {
        if (j <= 0) {
            throw new IllegalArgumentException("Prices must always be greater than zero");
        }
        FutureTask futureTask = new FutureTask(new RecommendedPriceCallable(getPricingRatioAsync(), j));
        _ExecutorService.execute(futureTask);
        return futureTask;
    }

    public Future<Long> getRecommendedPriceAsync(long j, RecommendedPriceListener recommendedPriceListener) {
        if (j <= 0) {
            throw new IllegalArgumentException("Prices must always be greater than zero");
        } else if (recommendedPriceListener == null) {
            throw new IllegalArgumentException("'callback', can not be NULL");
        } else {
            FutureTask futureTask = new FutureTask(new RecommendedPriceCallable(this, getPricingRatioAsync(), j, recommendedPriceListener));
            _ExecutorService.execute(futureTask);
            return futureTask;
        }
    }
}

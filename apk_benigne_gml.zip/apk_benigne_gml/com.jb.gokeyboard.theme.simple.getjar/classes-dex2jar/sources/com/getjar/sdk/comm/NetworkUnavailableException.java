package com.getjar.sdk.comm;

public class NetworkUnavailableException extends Exception {
    public NetworkUnavailableException() {
    }

    public NetworkUnavailableException(String str) {
        super(str);
    }
}

package com.getjar.sdk.data;

import android.util.Log;
import com.getjar.sdk.GetJarException;
import com.getjar.sdk.comm.CallbackInterface;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.LocalizationServiceProxy;
import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.utilities.Constants;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import org.json.JSONObject;

public class LocalizationEngine {
    private static final ExecutorService _ExecutorService = Executors.newCachedThreadPool();
    private CommContext _commContext = null;

    private class PricingRatioCallable implements Callable<Float> {
        private PricingRatioCallable() {
        }

        @Override // java.util.concurrent.Callable
        public Float call() throws Exception {
            return Float.valueOf(LocalizationEngine.this.getPricingRatio(true));
        }
    }

    private class PricingRatioCallback implements CallbackInterface {
        private PricingRatioCallback() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
        }
    }

    public LocalizationEngine(CommContext commContext) {
        if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        }
        this._commContext = commContext;
    }

    private Float getRatioFromResult(Result result) {
        JSONObject responseJson;
        if (result == null || (responseJson = result.getResponseJson()) == null || responseJson.length() <= 0) {
            return null;
        }
        try {
            return Float.valueOf((float) responseJson.getJSONObject("return").getDouble("ratio"));
        } catch (Exception e) {
            Log.e(Constants.TAG, "getRatioFromResult() JSON parsing failed", e);
            return null;
        }
    }

    public float getPricingRatio(boolean z) {
        Float ratioFromResult;
        try {
            Operation pricingRatio = LocalizationServiceProxy.getInstance().getPricingRatio(this._commContext, new PricingRatioCallback());
            Float ratioFromResult2 = getRatioFromResult(pricingRatio.getResult());
            if (ratioFromResult2 != null) {
                Log.v(Constants.TAG, String.format("getPricingRatio() returning %1$f (cache)", ratioFromResult2));
                return ratioFromResult2.floatValue();
            }
            if (z && (ratioFromResult = getRatioFromResult(pricingRatio.get())) != null) {
                Log.v(Constants.TAG, String.format("getPricingRatio() returning %1$f (post-blocking)", ratioFromResult));
                return ratioFromResult.floatValue();
            }
            Log.v(Constants.TAG, "getPricingRatio() returning 1.0 (default)");
            return 1.0f;
        } catch (Exception e) {
            Log.e(Constants.TAG, "getPricingRatio() failed", e);
        }
    }

    public Future<Float> getPricingRatioAsync() {
        try {
            FutureTask futureTask = new FutureTask(new PricingRatioCallable());
            _ExecutorService.execute(futureTask);
            return futureTask;
        } catch (Exception e) {
            throw new GetJarException(e);
        }
    }
}

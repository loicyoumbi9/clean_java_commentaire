package com.getjar.sdk.comm;

public interface ServiceContextInterface {
    boolean checkIfOperationShouldBeRetried(CommContext commContext, Result result, int i, int i2) throws Exception;

    void preRequestWork(Operation operation) throws Exception;
}

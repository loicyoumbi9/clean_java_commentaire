package com.getjar.sdk.comm;

import java.security.KeyStore;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

public class GetJarHttpClient extends DefaultHttpClient {
    private GetJarHttpClient(ClientConnectionManager clientConnectionManager, HttpParams httpParams) {
        super(clientConnectionManager, httpParams);
    }

    public static GetJarHttpClient newInstance(String str, int i, int i2) throws Exception {
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setStaleCheckingEnabled(basicHttpParams, false);
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, i);
        HttpConnectionParams.setSoTimeout(basicHttpParams, i2);
        HttpConnectionParams.setSocketBufferSize(basicHttpParams, 8192);
        HttpClientParams.setRedirecting(basicHttpParams, false);
        HttpProtocolParams.setUserAgent(basicHttpParams, str);
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        SSLSocketFactoryTrustAll newSSLSocketFactoryInstance = newSSLSocketFactoryInstance();
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 8080));
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        schemeRegistry.register(new Scheme("https", newSSLSocketFactoryInstance, 8443));
        schemeRegistry.register(new Scheme("https", newSSLSocketFactoryInstance, 443));
        return new GetJarHttpClient(new ThreadSafeClientConnManager(basicHttpParams, schemeRegistry), basicHttpParams);
    }

    private static SSLSocketFactoryTrustAll newSSLSocketFactoryInstance() throws Exception {
        KeyStore instance = KeyStore.getInstance("BKS");
        instance.load(null, null);
        SSLSocketFactoryTrustAll sSLSocketFactoryTrustAll = new SSLSocketFactoryTrustAll(instance);
        sSLSocketFactoryTrustAll.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        return sSLSocketFactoryTrustAll;
    }
}

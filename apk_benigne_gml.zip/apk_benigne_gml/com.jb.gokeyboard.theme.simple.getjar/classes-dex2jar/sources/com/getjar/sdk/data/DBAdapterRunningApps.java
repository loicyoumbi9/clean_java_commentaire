package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.Utility;
import com.getjar.vending.GetJarUtils;
import java.util.ArrayList;
import java.util.List;

public class DBAdapterRunningApps extends SQLiteOpenHelper {
    private static final String DATABASE_CREATE = "CREATE TABLE IF NOT EXISTS runningAppData (id INTEGER PRIMARY KEY AUTOINCREMENT, packageName TEXT NOT NULL UNIQUE, versionCode INTEGER, versionName TEXT, targetSDK TEXT, flags INTEGER, appLabel TEXT, wasRunning INTEGER);";
    private static final String DATABASE_NAME = "GetJarDBRunning";
    private static final String DATABASE_TABLE = "runningAppData";
    private static final int DATABASE_VERSION = 2;
    private Logger log = new Logger(this);
    private SQLiteDatabase mDatabase = getWritableDatabase();

    public DBAdapterRunningApps(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 2);
    }

    public boolean addAppData(AppData appData) {
        if (!Utility.shouldFilterApp(appData) && !checkForRecord(appData.getPackageName())) {
            int i = appData.getWasRunning() ? 1 : 0;
            ContentValues contentValues = new ContentValues();
            contentValues.put("packageName", appData.getPackageName());
            contentValues.put("versionCode", appData.getVersionCode());
            contentValues.put("versionName", appData.getVersionName());
            contentValues.put("targetSDK", appData.getTargetSDKVer());
            contentValues.put("flags", Integer.valueOf(appData.getFlags()));
            contentValues.put("appLabel", appData.getAppName());
            contentValues.put("wasRunning", Integer.valueOf(i));
            if (this.mDatabase.insert(DATABASE_TABLE, null, contentValues) != -1) {
                return true;
            }
        }
        return false;
    }

    public boolean checkForRecord(String str) {
        boolean z = false;
        Cursor rawQuery = this.mDatabase.rawQuery("SELECT count(*) FROM runningAppData WHERE packageName = '" + str + "'", null);
        try {
            rawQuery.moveToFirst();
            if (rawQuery.getInt(0) > 0) {
                z = true;
            }
            try {
                rawQuery.close();
            } catch (Throwable th) {
            }
            return z;
        } catch (Throwable th2) {
        }
        throw th;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this.mDatabase.close();
    }

    public boolean deleteAppData() {
        return this.mDatabase.delete(DATABASE_TABLE, GetJarUtils.PVERSION, null) > 0;
    }

    public List<AppData> loadAll() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE, null, null, null, null, null, null);
        while (query.moveToNext()) {
            try {
                AppData appData = new AppData();
                appData.setPackageName(query.getString(1));
                appData.setVersionCode(Integer.valueOf(query.getInt(2)));
                appData.setVersionName(query.getString(3));
                appData.setTargetSDKVer(query.getString(4));
                appData.setFlags(query.getInt(5));
                appData.setAppName(query.getString(6));
                appData.setWasRunning(query.getInt(7) == 1);
                arrayList.add(appData);
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(DATABASE_CREATE);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        this.log.info("Upgrading database from version " + i + " to " + i2 + ", which will destroy all old data");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS runningAppData");
        onCreate(sQLiteDatabase);
    }
}

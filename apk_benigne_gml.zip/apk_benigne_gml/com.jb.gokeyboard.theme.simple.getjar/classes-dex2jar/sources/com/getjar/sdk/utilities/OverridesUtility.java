package com.getjar.sdk.utilities;

import java.util.Map;
import java.util.UUID;

public final class OverridesUtility {
    public static final boolean DEBUG_BUILD = false;

    public static Map<?, ?> getOverridesMap() {
        return null;
    }

    public static String getValue(String str) {
        return null;
    }

    public static String getValue(String str, String str2) {
        return str2;
    }

    public static Boolean getValueBool(String str) {
        return null;
    }

    public static Boolean getValueBool(String str, Boolean bool) {
        return bool;
    }

    public static String getValueFakeID(String str) {
        return null;
    }

    public static String getValueFakeID(String str, String str2) {
        return str2;
    }

    public static Integer getValueInt(String str) {
        return null;
    }

    public static Integer getValueInt(String str, Integer num) {
        return num;
    }

    public static Long getValueLong(String str) {
        return null;
    }

    public static Long getValueLong(String str, Long l) {
        return l;
    }

    public static UUID getValueUUID(String str) {
        return null;
    }

    public static UUID getValueUUID(String str, UUID uuid) {
        return uuid;
    }
}

package com.getjar.sdk.data;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.getjar.sdk.comm.MetadataValue;
import com.getjar.sdk.comm.ServiceProxyBase;
import com.getjar.sdk.comm.UserAgentValuesManager;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.OverridesUtility;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;

public class DeviceMetadata {
    public static String KEY_ANDROID_DEVICE_ANDROID_ID = "android.device.android_id";
    public static String KEY_ANDROID_DEVICE_BOARD = "android.device.board";
    public static String KEY_ANDROID_DEVICE_BRAND = "android.device.brand";
    public static String KEY_ANDROID_DEVICE_DEVICE_ID = "android.device.device_id";
    public static String KEY_ANDROID_DEVICE_HARDWARE = "android.device.hardware";
    public static String KEY_ANDROID_DEVICE_MANUFACTURER = "android.device.manufacturer";
    public static String KEY_ANDROID_DEVICE_MODEL = "android.device.model";
    public static String KEY_ANDROID_DEVICE_PRODUCT = "android.device.product";
    public static String KEY_ANDROID_DEVICE_SERIAL_NUMBER = "android.device.serial_number";
    public static String KEY_ANDROID_OS_INCREMENTAL = "android.os.incremental";
    public static String KEY_ANDROID_OS_RELEASE = "android.os.release";
    public static String KEY_ANDROID_OS_SDK_INT = "android.os.sdk_int";
    public static String KEY_DEVICE_PLATFORM = Constants.META_DEVICE_PLATFORM;
    public static String KEY_DEVICE_PLATFORM_VERSION = Constants.META_DEVICE_PLATFORM_VERSION;
    private Map<String, String> _deviceMetadata = null;
    private Map<String, MetadataValue> _deviceMetadataWithReliability = null;

    public DeviceMetadata(Context context) {
        int findSdkInt = findSdkInt(context);
        String findHardware = findHardware(context);
        String findManufacturer = findManufacturer(context);
        String findSerialNo = findSerialNo(context, findSdkInt);
        if (StringUtility.isNullOrEmpty(findSerialNo)) {
            Log.w(Constants.TAG, "Failed to get a serial number");
        }
        String findAndroidId = findAndroidId(context);
        if (StringUtility.isNullOrEmpty(findAndroidId)) {
            Log.w(Constants.TAG, "Failed to get the Android ID");
        }
        String findDeviceId = findDeviceId(context);
        if (StringUtility.isNullOrEmpty(findAndroidId)) {
            Log.w(Constants.TAG, "Failed to get the device ID [TelephonyManager.getDeviceId()]");
        }
        this._deviceMetadata = new HashMap(14);
        this._deviceMetadata.put(KEY_DEVICE_PLATFORM, "android");
        this._deviceMetadata.put(KEY_DEVICE_PLATFORM_VERSION, Build.VERSION.RELEASE);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_ANDROID_ID, findAndroidId);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_BOARD, Build.BOARD);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_BRAND, Build.BRAND);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_DEVICE_ID, findDeviceId);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_HARDWARE, findHardware);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_MANUFACTURER, findManufacturer);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_MODEL, Build.MODEL);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_PRODUCT, Build.PRODUCT);
        this._deviceMetadata.put(KEY_ANDROID_DEVICE_SERIAL_NUMBER, findSerialNo);
        this._deviceMetadata.put(KEY_ANDROID_OS_INCREMENTAL, Build.VERSION.INCREMENTAL);
        this._deviceMetadata.put(KEY_ANDROID_OS_RELEASE, Build.VERSION.RELEASE);
        this._deviceMetadata.put(KEY_ANDROID_OS_SDK_INT, Integer.toString(findSdkInt));
        try {
            this._deviceMetadata.put(Constants.META_LEGACY_UA, UserAgentValuesManager.getInstance().getWebKitUserAgent(context));
        } catch (InterruptedException e) {
        }
        this._deviceMetadataWithReliability = new HashMap(14);
        this._deviceMetadataWithReliability.put(KEY_DEVICE_PLATFORM, getMetadataValueInstance("android"));
        this._deviceMetadataWithReliability.put(KEY_DEVICE_PLATFORM_VERSION, getMetadataValueInstance(Build.VERSION.RELEASE));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_ANDROID_ID, getMetadataValueInstance(findAndroidId));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_BOARD, getMetadataValueInstance(Build.BOARD));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_BRAND, getMetadataValueInstance(Build.BRAND));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_DEVICE_ID, getMetadataValueInstance(findDeviceId));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_HARDWARE, getMetadataValueInstance(findHardware));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_MANUFACTURER, getMetadataValueInstance(findManufacturer));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_MODEL, getMetadataValueInstance(Build.MODEL));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_PRODUCT, getMetadataValueInstance(Build.PRODUCT));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_DEVICE_SERIAL_NUMBER, getMetadataValueInstance(findSerialNo));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_OS_INCREMENTAL, getMetadataValueInstance(Build.VERSION.INCREMENTAL));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_OS_RELEASE, getMetadataValueInstance(Build.VERSION.RELEASE));
        this._deviceMetadataWithReliability.put(KEY_ANDROID_OS_SDK_INT, getMetadataValueInstance(Integer.toString(findSdkInt)));
        try {
            this._deviceMetadataWithReliability.put(Constants.META_LEGACY_UA, getMetadataValueInstance(UserAgentValuesManager.getInstance().getWebKitUserAgent(context)));
        } catch (InterruptedException e2) {
        }
    }

    private String findAndroidId(Context context) {
        String valueFakeID = OverridesUtility.getValueFakeID("identity.android.id");
        if (!StringUtility.isNullOrEmpty(valueFakeID)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.android.id' = '%1$s'", valueFakeID));
            return valueFakeID;
        }
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        return (string == null || string.length() <= 1) ? "" : string;
    }

    private String findDeviceId(Context context) {
        String valueFakeID = OverridesUtility.getValueFakeID("identity.device.id");
        if (StringUtility.isNullOrEmpty(valueFakeID)) {
            return RewardUtility.checkPermission(context, Utility.READ_PHONE_STATE_PERMISSION) ? ((TelephonyManager) context.getSystemService("phone")).getDeviceId() : "";
        }
        Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.device.id' = '%1$s'", valueFakeID));
        return valueFakeID;
    }

    private String findHardware(Context context) {
        try {
            return (String) Build.class.getDeclaredField("HARDWARE").get(null);
        } catch (Exception e) {
            return "";
        }
    }

    private String findManufacturer(Context context) {
        try {
            return (String) Build.class.getDeclaredField("MANUFACTURER").get(null);
        } catch (Exception e) {
            return "";
        }
    }

    private int findSdkInt(Context context) {
        try {
            return Build.VERSION.class.getDeclaredField("SDK_INT").getInt(null);
        } catch (Exception e) {
            try {
                return Integer.parseInt(Build.VERSION.SDK);
            } catch (Exception e2) {
                return 3;
            }
        }
    }

    private String findSerialNo(Context context, int i) {
        String valueFakeID = OverridesUtility.getValueFakeID("identity.serial.number");
        if (!StringUtility.isNullOrEmpty(valueFakeID)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.serial.number' = '%1$s'", valueFakeID));
            return valueFakeID;
        } else if (i >= 9) {
            try {
                return (String) Build.class.getDeclaredField("SERIAL").get(null);
            } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | InvocationTargetException e) {
                return "";
            }
        } else {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            return (String) cls.getMethod("get", String.class, String.class).invoke(cls, "ro.serialno", null);
        }
    }

    private MetadataValue getMetadataValueInstance(String str) {
        return new MetadataValue(str, StringUtility.isNullOrEmpty(str) ? MetadataValue.MetadataReliability.NOT_AVAILABLE : MetadataValue.MetadataReliability.AVAILABLE);
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(this._deviceMetadata);
    }

    public String getMetadataValue(String str) {
        return this._deviceMetadata.get(str);
    }

    public String toJsonString() throws JSONException {
        return ServiceProxyBase.mapToJsonString(this._deviceMetadata);
    }

    public String toJsonStringWithReliabilities() throws JSONException {
        return ServiceProxyBase.metadataMapToJsonString(this._deviceMetadataWithReliability);
    }
}

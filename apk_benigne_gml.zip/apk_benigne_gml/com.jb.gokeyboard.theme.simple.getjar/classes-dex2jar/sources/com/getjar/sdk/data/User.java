package com.getjar.sdk.data;

import android.content.Context;
import com.getjar.sdk.utilities.Utility;

public class User {
    private String mAuthToken;
    private Context mContext;
    private DeviceMetadata mMetaData;

    public User(Context context) {
        this.mContext = context;
        this.mMetaData = new DeviceMetadata(context);
    }

    public String getAccessId() {
        return Utility.getUserAccessId(this.mContext);
    }

    public String getAuthToken() {
        return this.mAuthToken;
    }

    public DeviceMetadata getMetaData() {
        return this.mMetaData;
    }

    public void setAccessId(String str) {
        Utility.setUserAccessId(this.mContext, str);
    }

    public void setAuthToken(String str) {
        this.mAuthToken = str;
    }
}

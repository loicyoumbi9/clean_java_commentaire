package com.getjar.sdk.comm;

public class MetadataValue {
    private MetadataReliability _reliability;
    private String _value;

    public enum MetadataReliability {
        UNKNOWN,
        AVAILABLE,
        NOT_AVAILABLE
    }

    public MetadataValue(String str, MetadataReliability metadataReliability) {
        this._value = str;
        this._reliability = metadataReliability;
    }

    public MetadataReliability getReliability() {
        return this._reliability;
    }

    public String getValue() {
        return this._value;
    }
}

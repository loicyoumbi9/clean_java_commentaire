package com.getjar.sdk.comm.persistence;

import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;

public class RelatedPurchaseData implements Serializable {
    private static final long serialVersionUID = 1387628907828312943L;
    private Integer _amount;
    private String _productDescription;
    private String _productId;
    private String _productName;
    private HashMap<String, String> _trackingMetadata;

    public RelatedPurchaseData() {
    }

    public RelatedPurchaseData(String str, String str2, String str3, Integer num, HashMap<String, String> hashMap) {
        this._productId = str;
        this._productName = str2;
        this._productDescription = str3;
        this._amount = num;
        this._trackingMetadata = hashMap;
        validateObjectState();
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this._amount = Integer.valueOf(objectInputStream.readInt());
        this._productDescription = objectInputStream.readUTF();
        this._productId = objectInputStream.readUTF();
        this._productName = objectInputStream.readUTF();
        this._trackingMetadata = (HashMap) objectInputStream.readObject();
        validateObjectState();
    }

    private void validateObjectState() {
        if (this._amount == null || this._amount.intValue() < 0) {
            throw new IllegalStateException("'amount' can not be NULL or less than 0");
        } else if (StringUtility.isNullOrEmpty(this._productId)) {
            throw new IllegalStateException("'productId' can not be NULL or empty");
        } else if (StringUtility.isNullOrEmpty(this._productName)) {
            throw new IllegalStateException("'productName' can not be NULL or empty");
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeInt(this._amount.intValue());
        objectOutputStream.writeUTF(this._productDescription);
        objectOutputStream.writeUTF(this._productId);
        objectOutputStream.writeUTF(this._productName);
        objectOutputStream.writeObject(this._trackingMetadata);
    }

    public Integer getAmount() {
        return this._amount;
    }

    public String getProductDescription() {
        return this._productDescription;
    }

    public String getProductId() {
        return this._productId;
    }

    public String getProductName() {
        return this._productName;
    }

    public HashMap<String, String> getTrackingMetadata() {
        return this._trackingMetadata;
    }
}

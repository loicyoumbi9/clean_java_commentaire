package com.getjar.sdk.listener;

public interface PricingRatioListener {
    void pricingRatioEvent(float f);
}

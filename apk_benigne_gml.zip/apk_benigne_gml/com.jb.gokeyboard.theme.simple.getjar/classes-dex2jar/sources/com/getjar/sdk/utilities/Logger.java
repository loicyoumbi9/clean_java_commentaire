package com.getjar.sdk.utilities;

import android.util.Log;

public class Logger {
    public static final int DEBUG = 3;
    public static final int ERROR = 0;
    public static final int INFO = 2;
    public static final int VERBOSE = 4;
    public static final int WARNING = 1;
    private static int mLoglevel = 4;
    private String mPrefix;

    public Logger(int i, Object obj) {
        Log.v(Constants.TAG, "log level set to :" + i);
        if (obj == null) {
            throw new IllegalArgumentException("'obj' can not be null");
        }
        setloglevel(i);
        this.mPrefix = buildPrefix(obj);
    }

    public Logger(Object obj) {
        if (obj == null) {
            throw new IllegalArgumentException("'obj' can not be null");
        }
        this.mPrefix = buildPrefix(obj);
    }

    private String AddPrefix(String str) {
        StringBuilder append = new StringBuilder("[").append(this.mPrefix);
        append.append("] : ").append(str);
        return append.toString();
    }

    private static String GetExceptionText(Throwable th) {
        StringBuilder sb = new StringBuilder("***** ERROR *****\r\n");
        sb.append(th.getClass().getName() + "\r\n");
        sb.append("Message: " + th.getMessage() + "\n\n");
        sb.append(GetStackTrace());
        return sb.toString();
    }

    public static String GetStackTrace() {
        StringBuffer stringBuffer = new StringBuffer();
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        for (int i = 3; i < stackTrace.length; i++) {
            stringBuffer.append(String.format("%1$s : %2$s : %3$s [%4$d]\n", stackTrace[i].getFileName(), stackTrace[i].getClassName(), stackTrace[i].getMethodName(), Integer.valueOf(stackTrace[i].getLineNumber())));
        }
        return stringBuffer.toString();
    }

    private void Log(String str, boolean z) {
        if (z) {
            error(str);
        } else {
            debug(str);
        }
    }

    private String buildPrefix(Object obj) {
        return obj.getClass().getName();
    }

    public static int getloglevel() {
        return mLoglevel;
    }

    public static void sLog(String str) {
        Log.i(Constants.TAG, str);
    }

    public static void sLog(Throwable th) {
        Log.e(Constants.TAG, GetExceptionText(th));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void
     arg types: [java.lang.String, int]
     candidates:
      com.getjar.sdk.utilities.Logger.Log(java.lang.Throwable, java.lang.String):void
      com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void */
    public void Log(String str) {
        Log(str, false);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void
     arg types: [java.lang.String, int]
     candidates:
      com.getjar.sdk.utilities.Logger.Log(java.lang.Throwable, java.lang.String):void
      com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void */
    public void Log(Throwable th) {
        Log(GetExceptionText(th), true);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void
     arg types: [java.lang.String, int]
     candidates:
      com.getjar.sdk.utilities.Logger.Log(java.lang.Throwable, java.lang.String):void
      com.getjar.sdk.utilities.Logger.Log(java.lang.String, boolean):void */
    public void Log(Throwable th, String str) {
        Log(str + "\r\n" + GetExceptionText(th), true);
    }

    public void debug(String str) {
        if (mLoglevel >= 3) {
            Log.d(Constants.TAG, AddPrefix(str));
        }
    }

    public void error(String str) {
        if (mLoglevel >= 0) {
            Log.e(Constants.TAG, AddPrefix(str));
        }
    }

    public void info(String str) {
        if (mLoglevel >= 2) {
            Log.i(Constants.TAG, AddPrefix(str));
        }
    }

    public void setloglevel(int i) {
        mLoglevel = i;
    }

    public void verbose(String str) {
        if (mLoglevel >= 4) {
            Log.v(Constants.TAG, AddPrefix(str));
        }
    }

    public void warning(String str) {
        if (mLoglevel >= 1) {
            Log.w(Constants.TAG, AddPrefix(str));
        }
    }
}

package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Utility;
import java.io.UnsupportedEncodingException;
import java.net.BindException;
import java.net.ConnectException;
import java.net.HttpRetryException;
import java.net.NoRouteToHostException;
import java.net.PortUnreachableException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.net.UnknownServiceException;
import java.util.Iterator;
import java.util.Map;
import javax.net.ssl.SSLException;
import org.apache.http.Header;
import org.apache.http.client.methods.HttpRequestBase;
import org.json.JSONException;

public final class RequestUtilities {
    protected static boolean checkForRetryOnException(Exception exc) {
        if (!exc.getClass().getName().contains("Timeout")) {
            if (exc.getClass().getName().startsWith("org.apache.http")) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof ConnectException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof BindException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof HttpRetryException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof NoRouteToHostException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof PortUnreachableException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof ProtocolException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof SocketException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof UnknownHostException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof UnknownServiceException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof SSLException) {
                exc.printStackTrace();
                return true;
            } else if (exc instanceof NetworkUnavailableException) {
                exc.printStackTrace();
                return true;
            }
        }
        return false;
    }

    protected static void debugDumpRequestProperties(HttpRequestBase httpRequestBase) {
        try {
            Log.d(Constants.TAG, "The request properties for this request:");
            Header[] allHeaders = httpRequestBase.getAllHeaders();
            for (Header header : allHeaders) {
                Log.d(Constants.TAG, "      " + header.getName() + " = '" + header.getValue() + "'");
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    protected static String getPostDataBlob(Map<String, String> map) throws UnsupportedEncodingException {
        StringBuilder sb = new StringBuilder("");
        Iterator<String> it = map.keySet().iterator();
        while (it.hasNext()) {
            String next = it.next();
            sb.append(next);
            sb.append("=");
            sb.append(URLEncoder.encode(map.get(next), Constants.ENCODING_CHARSET));
            if (it.hasNext()) {
                sb.append(Utility.QUERY_APPENDIX);
            }
        }
        return sb.toString();
    }

    public static ServicesException getServicesException(Result result) throws ServicesException, JSONException {
        if (result == null) {
            throw new IllegalArgumentException("'result' can not be NULL");
        }
        if (result.getResponseJson() != null) {
            if (result.getResponseJson().has("error")) {
                return new ServicesException(String.format("[ResponseCode: %1$d] Result: %2$s", Integer.valueOf(result.getResponseCode()), result.getResponseJson().toString(2)), result);
            } else if (!result.getResponseJson().has("return")) {
                return new ServicesException(String.format("Unexpected JSON result [ResponseCode: %1$d] Result: %2$s", Integer.valueOf(result.getResponseCode()), result.getResponseJson().toString(2)), result);
            }
        }
        return null;
    }
}

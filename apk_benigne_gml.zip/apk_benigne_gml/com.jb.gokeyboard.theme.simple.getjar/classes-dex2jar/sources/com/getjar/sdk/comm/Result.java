package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.OnErrorConstants;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class Result implements Serializable {
    private static final long serialVersionUID = 7344515215545594367L;
    private Map<String, List<String>> _headers = null;
    private String _requestId = null;
    private String _responseBody = null;
    private int _responseCode;
    private JSONObject _responseJson = null;
    private int _responseTime = -1;
    private boolean _suppressInternalCallbacks = false;

    public Result() {
    }

    public Result(String str, Map<String, List<String>> map, int i, String str2, boolean z) {
        this._responseBody = str;
        if (!StringUtility.isNullOrEmpty(this._responseBody)) {
            try {
                this._responseJson = new JSONObject(this._responseBody);
            } catch (JSONException e) {
            }
        }
        this._headers = map;
        if (this._headers == null) {
            this._headers = new HashMap();
        }
        this._responseCode = i;
        this._requestId = str2;
        this._suppressInternalCallbacks = z;
        validateObjectState();
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this._responseBody = objectInputStream.readUTF();
        if (!StringUtility.isNullOrEmpty(this._responseBody)) {
            try {
                this._responseJson = new JSONObject(this._responseBody);
            } catch (JSONException e) {
            }
        }
        this._responseCode = objectInputStream.readInt();
        this._requestId = objectInputStream.readUTF();
        this._suppressInternalCallbacks = objectInputStream.readBoolean();
        this._headers = (Map) objectInputStream.readObject();
        this._responseTime = objectInputStream.readInt();
        validateObjectState();
    }

    private void validateObjectState() {
        if (this._responseCode < 0) {
            throw new IllegalStateException("'responseCode' can not be less than zero");
        } else if (this._headers == null) {
            throw new IllegalStateException("'headers' can not be NULL");
        } else if (this._responseTime < -1) {
            throw new IllegalStateException("'responseTime' must be greater than -1");
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        validateObjectState();
        objectOutputStream.writeUTF(this._responseBody != null ? this._responseBody : "");
        objectOutputStream.writeInt(this._responseCode);
        objectOutputStream.writeUTF(this._requestId);
        objectOutputStream.writeBoolean(this._suppressInternalCallbacks);
        objectOutputStream.writeObject(this._headers);
        objectOutputStream.writeInt(this._responseTime);
    }

    public boolean checkForBlacklisted() throws JSONException {
        if (checkForCallerUnauthorized() && this._responseJson.getJSONObject("error").has("subcode")) {
            String string = this._responseJson.getJSONObject("error").getString("subcode");
            if (string.equalsIgnoreCase("no_reauth") || string.startsWith("black_listed")) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x004e  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00b0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean checkForBlacklistedOrUnsupported(com.getjar.sdk.comm.CommContext r10) throws org.json.JSONException {
        /*
            r9 = this;
            r2 = 1
            r1 = 0
            boolean r0 = r9.checkForCallerUnauthorized()
            if (r0 == 0) goto L_0x00b6
            boolean r0 = r9.checkForBlacklisted()
            if (r0 == 0) goto L_0x0084
            org.json.JSONObject r0 = r9._responseJson
            java.lang.String r3 = "error"
            org.json.JSONObject r0 = r0.getJSONObject(r3)
            java.lang.String r3 = "subcode"
            java.lang.String r3 = r0.getString(r3)
            com.getjar.sdk.response.BlacklistedResponse$BlacklistType r0 = com.getjar.sdk.response.BlacklistedResponse.BlacklistType.DEVICE
            java.lang.String r4 = "black_listed_device"
            boolean r4 = r4.equalsIgnoreCase(r3)
            if (r4 == 0) goto L_0x0066
            com.getjar.sdk.response.BlacklistedResponse$BlacklistType r0 = com.getjar.sdk.response.BlacklistedResponse.BlacklistType.DEVICE
        L_0x0028:
            boolean r4 = r9._suppressInternalCallbacks
            if (r4 != 0) goto L_0x002f
            r10.makeAuthorizationFailureCallbacks(r3)
        L_0x002f:
            com.getjar.sdk.response.BlacklistedResponse r3 = new com.getjar.sdk.response.BlacklistedResponse
            r3.<init>(r0)
            r10.postResponse(r3)
            r0 = r1
            r3 = r2
        L_0x0039:
            java.lang.String r5 = com.getjar.sdk.utilities.Constants.TAG
            if (r3 != 0) goto L_0x003f
            if (r0 == 0) goto L_0x00ae
        L_0x003f:
            r4 = r2
        L_0x0040:
            java.lang.String r4 = java.lang.Boolean.toString(r4)
            java.lang.String r6 = r4.toUpperCase()
            if (r3 != 0) goto L_0x004c
            if (r0 == 0) goto L_0x00b3
        L_0x004c:
            if (r3 == 0) goto L_0x00b0
            java.lang.String r4 = "we are blacklisted"
        L_0x0050:
            java.lang.String r7 = "checkForBlacklistedOrUnsupported() returning %1$s %2$s"
            r8 = 2
            java.lang.Object[] r8 = new java.lang.Object[r8]
            r8[r1] = r6
            r8[r2] = r4
            java.lang.String r4 = java.lang.String.format(r7, r8)
            android.util.Log.v(r5, r4)
            if (r3 != 0) goto L_0x0064
            if (r0 == 0) goto L_0x0065
        L_0x0064:
            r1 = r2
        L_0x0065:
            return r1
        L_0x0066:
            java.lang.String r4 = "black_listed_user"
            boolean r4 = r4.equalsIgnoreCase(r3)
            if (r4 != 0) goto L_0x0076
            java.lang.String r4 = "no_reauth"
            boolean r4 = r4.equalsIgnoreCase(r3)
            if (r4 == 0) goto L_0x0079
        L_0x0076:
            com.getjar.sdk.response.BlacklistedResponse$BlacklistType r0 = com.getjar.sdk.response.BlacklistedResponse.BlacklistType.USER
            goto L_0x0028
        L_0x0079:
            java.lang.String r4 = "black_listed_app"
            boolean r4 = r4.equalsIgnoreCase(r3)
            if (r4 == 0) goto L_0x0028
            com.getjar.sdk.response.BlacklistedResponse$BlacklistType r0 = com.getjar.sdk.response.BlacklistedResponse.BlacklistType.APP
            goto L_0x0028
        L_0x0084:
            boolean r0 = r9.checkForUnsupported()
            if (r0 == 0) goto L_0x00b6
            org.json.JSONObject r0 = r9._responseJson
            java.lang.String r3 = "error"
            org.json.JSONObject r0 = r0.getJSONObject(r3)
            java.lang.String r3 = "subcode"
            java.lang.String r0 = r0.getString(r3)
            boolean r3 = r9._suppressInternalCallbacks
            if (r3 != 0) goto L_0x009f
            r10.makeAuthorizationFailureCallbacks(r0)
        L_0x009f:
            com.getjar.sdk.response.DeviceUnsupportedResponse r0 = new com.getjar.sdk.response.DeviceUnsupportedResponse
            java.util.Map r3 = r10.getDeviceMetadata()
            r0.<init>(r3)
            r10.postResponse(r0)
            r0 = r2
            r3 = r1
            goto L_0x0039
        L_0x00ae:
            r4 = r1
            goto L_0x0040
        L_0x00b0:
            java.lang.String r4 = "we are unsupported"
            goto L_0x0050
        L_0x00b3:
            java.lang.String r4 = ""
            goto L_0x0050
        L_0x00b6:
            r0 = r1
            r3 = r1
            goto L_0x0039
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.Result.checkForBlacklistedOrUnsupported(com.getjar.sdk.comm.CommContext):boolean");
    }

    public boolean checkForCallerUnauthorized() throws JSONException {
        return this._responseJson != null && this._responseJson.has("error") && this._responseJson.getJSONObject("error").has("code") && this._responseJson.getJSONObject("error").getString("code").equalsIgnoreCase("CALLER_UNAUTHORIZED");
    }

    public boolean checkForUnauthorizedAndOKToReAuth(CommContext commContext) throws JSONException {
        boolean z;
        boolean z2;
        if (checkForCallerUnauthorized()) {
            z = true;
            z2 = checkForBlacklistedOrUnsupported(commContext);
        } else {
            z = false;
            z2 = false;
        }
        boolean z3 = z && !z2;
        if (z) {
            Log.v(Constants.TAG, String.format("checkForUnauthorizedAndOKToReAuth() isUnauthorized=%1$s and isNotOKToReAuth=%2$s, returning %3$s for:\r\n%4$s", Boolean.valueOf(z), Boolean.valueOf(z2), Boolean.valueOf(z3), getResponseJson() != null ? getResponseJson().toString(4) : ""));
        }
        return z3;
    }

    public boolean checkForUnsupported() throws JSONException {
        return checkForCallerUnauthorized() && this._responseJson.getJSONObject("error").has("subcode") && this._responseJson.getJSONObject("error").getString("subcode").equalsIgnoreCase(OnErrorConstants.SUBCODE_AUTH_UNSUPPORTED_DEVICE);
    }

    public int getEstimatedResponseSizeInBytes() {
        int i = 8;
        if (this._responseBody != null) {
            i = this._responseBody.getBytes().length + 8;
        }
        if (this._headers == null) {
            return i;
        }
        int i2 = i;
        for (String str : this._headers.keySet()) {
            if (!StringUtility.isNullOrEmpty(str)) {
                i2 += str.getBytes().length;
            }
            if (this._headers.get(str) != null) {
                for (String str2 : this._headers.get(str)) {
                    if (!StringUtility.isNullOrEmpty(str2)) {
                        i2 += str2.getBytes().length;
                    }
                }
            }
        }
        return i2;
    }

    public Map<String, List<String>> getHeaders() {
        return this._headers;
    }

    public String getRequestId() {
        return this._requestId;
    }

    public String getResponseBody() {
        return this._responseBody;
    }

    public int getResponseCode() {
        return this._responseCode;
    }

    public JSONObject getResponseJson() {
        return this._responseJson;
    }

    public int getResponseTime() {
        return this._responseTime;
    }

    public void setResponseTime(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("'responseTime' must be greater than 0");
        }
        this._responseTime = i;
    }
}

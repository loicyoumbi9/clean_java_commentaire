package com.getjar.sdk.rewards;

import android.content.pm.ApplicationInfo;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.Utility;

public class ApplicationInfoEx extends ApplicationInfo {
    public static int FLAG_ALLOW_BACKUP;
    public static int FLAG_EXTERNAL_STORAGE;
    public static int FLAG_FORWARD_LOCK;
    public static int FLAG_KILL_AFTER_RESTORE;
    public static int FLAG_NATIVE_DEBUGGABLE;
    public static int FLAG_RESIZEABLE_FOR_SCREENS;
    public static int FLAG_RESTORE_ANY_VERSION;
    public static int FLAG_SUPPORTS_LARGE_SCREENS;
    public static int FLAG_SUPPORTS_NORMAL_SCREENS;
    public static int FLAG_SUPPORTS_SCREEN_DENSITIES;
    public static int FLAG_SUPPORTS_SMALL_SCREENS;
    public static int FLAG_TEST_ONLY;
    public static int FLAG_UPDATED_SYSTEM_APP;
    public static int FLAG_VM_SAFE_MODE;

    static {
        FLAG_UPDATED_SYSTEM_APP = 128;
        FLAG_TEST_ONLY = 256;
        FLAG_SUPPORTS_SMALL_SCREENS = 512;
        FLAG_SUPPORTS_NORMAL_SCREENS = 1024;
        FLAG_SUPPORTS_LARGE_SCREENS = 2048;
        FLAG_RESIZEABLE_FOR_SCREENS = 4096;
        FLAG_SUPPORTS_SCREEN_DENSITIES = 8192;
        FLAG_VM_SAFE_MODE = 16384;
        FLAG_ALLOW_BACKUP = 32768;
        FLAG_KILL_AFTER_RESTORE = AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED;
        FLAG_RESTORE_ANY_VERSION = AccessibilityEventCompat.TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY;
        FLAG_EXTERNAL_STORAGE = 262144;
        FLAG_FORWARD_LOCK = 1048576;
        FLAG_NATIVE_DEBUGGABLE = 2097152;
        try {
            Integer staticIntegerField = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_UPDATED_SYSTEM_APP");
            if (staticIntegerField != null) {
                FLAG_UPDATED_SYSTEM_APP = staticIntegerField.intValue();
            }
            Integer staticIntegerField2 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_TEST_ONLY");
            if (staticIntegerField2 != null) {
                FLAG_TEST_ONLY = staticIntegerField2.intValue();
            }
            Integer staticIntegerField3 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_SUPPORTS_SMALL_SCREENS");
            if (staticIntegerField3 != null) {
                FLAG_SUPPORTS_SMALL_SCREENS = staticIntegerField3.intValue();
            }
            Integer staticIntegerField4 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_SUPPORTS_NORMAL_SCREENS");
            if (staticIntegerField4 != null) {
                FLAG_SUPPORTS_NORMAL_SCREENS = staticIntegerField4.intValue();
            }
            Integer staticIntegerField5 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_SUPPORTS_LARGE_SCREENS");
            if (staticIntegerField5 != null) {
                FLAG_SUPPORTS_LARGE_SCREENS = staticIntegerField5.intValue();
            }
            Integer staticIntegerField6 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_RESIZEABLE_FOR_SCREENS");
            if (staticIntegerField6 != null) {
                FLAG_RESIZEABLE_FOR_SCREENS = staticIntegerField6.intValue();
            }
            Integer staticIntegerField7 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_SUPPORTS_SCREEN_DENSITIES");
            if (staticIntegerField7 != null) {
                FLAG_SUPPORTS_SCREEN_DENSITIES = staticIntegerField7.intValue();
            }
            Integer staticIntegerField8 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_VM_SAFE_MODE");
            if (staticIntegerField8 != null) {
                FLAG_VM_SAFE_MODE = staticIntegerField8.intValue();
            }
            Integer staticIntegerField9 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_ALLOW_BACKUP");
            if (staticIntegerField9 != null) {
                FLAG_ALLOW_BACKUP = staticIntegerField9.intValue();
            }
            Integer staticIntegerField10 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_KILL_AFTER_RESTORE");
            if (staticIntegerField10 != null) {
                FLAG_KILL_AFTER_RESTORE = staticIntegerField10.intValue();
            }
            Integer staticIntegerField11 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_RESTORE_ANY_VERSION");
            if (staticIntegerField11 != null) {
                FLAG_RESTORE_ANY_VERSION = staticIntegerField11.intValue();
            }
            Integer staticIntegerField12 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_EXTERNAL_STORAGE");
            if (staticIntegerField12 != null) {
                FLAG_EXTERNAL_STORAGE = staticIntegerField12.intValue();
            }
            Integer staticIntegerField13 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_FORWARD_LOCK");
            if (staticIntegerField13 != null) {
                FLAG_FORWARD_LOCK = staticIntegerField13.intValue();
            }
            Integer staticIntegerField14 = Utility.getStaticIntegerField(ApplicationInfo.class, "FLAG_NATIVE_DEBUGGABLE");
            if (staticIntegerField14 != null) {
                FLAG_NATIVE_DEBUGGABLE = staticIntegerField14.intValue();
            }
        } catch (Throwable th) {
            Logger.sLog(th);
        }
    }

    public static Integer getIntegerField(ApplicationInfo applicationInfo, String str) throws IllegalArgumentException, IllegalAccessException {
        if (applicationInfo == null) {
            throw new IllegalArgumentException("'appInfo' can not be null");
        } else if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'fieldName' can not be null or empty");
        } else {
            try {
                return Integer.valueOf(applicationInfo.getClass().getDeclaredField(str).getInt(applicationInfo));
            } catch (NoSuchFieldException e) {
                return null;
            }
        }
    }

    public static Integer getTargetSdkVersion(ApplicationInfo applicationInfo) throws IllegalArgumentException, IllegalAccessException {
        return getIntegerField(applicationInfo, "targetSdkVersion");
    }
}

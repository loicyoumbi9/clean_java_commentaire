package com.getjar.sdk.comm;

import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.net.URLEncoder;
import java.util.HashMap;

public class TransactionServiceProxy extends AuthorizedServiceProxyBase {
    private static final String _CONTRACT_VERSION = "20120510";
    private static TransactionServiceProxy _Instance = null;
    private static final String _URL_TEMPLATE_CANCEL_UNMANAGED_OFFER = String.format("%1$s%2$s", "%1$stransaction/transactions/cancel?user_device_id=%2$s&client_transaction_id=%3$s&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_CONFIRM_UNMANAGED_OFFER = String.format("%1$s%2$s", "%1$stransaction/transactions/confirm?user_device_id=%2$s&client_transaction_id=%3$s&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_EARN = String.format("%1$s%2$s", "%1$stransaction/transactions/earn?user_device_id=%2$s&item_id=%3$s&client_transaction_id=%4$s&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_RESERVE_UNMANAGED_OFFER = String.format("%1$s%2$s", "%1$stransaction/transactions/purchase?user_device_id=%2$s&product_id=%3$s&product_name=%4$s&product_description=%5$s&amount=%6$s&client_transaction_id=%7$s&version=", _CONTRACT_VERSION);

    private TransactionServiceProxy() {
    }

    public static TransactionServiceProxy getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    private static void makeTheInstance() {
        synchronized (TransactionServiceProxy.class) {
            try {
                if (_Instance == null) {
                    _Instance = new TransactionServiceProxy();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* access modifiers changed from: protected */
    public Operation cancelUnmanagedPurchase(CommContext commContext, String str, boolean z) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'client_transaction_id' was not provided");
        } else {
            commContext.waitForUserDevice();
            return makeAsyncPOSTRequestForJson("cancelUnmanagedPurchase", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_CANCEL_UNMANAGED_OFFER, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_SERVICE_ENDPOINT), URLEncoder.encode(commContext.getUserDeviceId(), Constants.ENCODING_CHARSET), URLEncoder.encode(str, Constants.ENCODING_CHARSET)), null, null, z);
        }
    }

    /* access modifiers changed from: protected */
    public Operation confirmUnmanagedPurchase(CommContext commContext, String str, boolean z) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'client_transaction_id' was not provided");
        } else {
            commContext.waitForUserDevice();
            return makeAsyncPOSTRequestForJson("confirmUnmanagedPurchase", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_CONFIRM_UNMANAGED_OFFER, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_SERVICE_ENDPOINT), URLEncoder.encode(commContext.getUserDeviceId(), Constants.ENCODING_CHARSET), URLEncoder.encode(str, Constants.ENCODING_CHARSET)), null, null, z);
        }
    }

    /* access modifiers changed from: protected */
    public Operation earn(CommContext commContext, String str, String str2, String str3, HashMap<String, String> hashMap, HashMap<String, String> hashMap2, boolean z) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'item_id' was not provided");
        } else if (StringUtility.isNullOrEmpty(str3)) {
            throw new IllegalArgumentException("The required parameter 'client_transaction_id' was not provided");
        } else if (hashMap == null) {
            throw new IllegalArgumentException("The required parameter 'item_metadata' was not provided");
        } else if (hashMap2 == null) {
            throw new IllegalArgumentException("The required parameter 'tracking_metadata' was not provided");
        } else if (hashMap2.size() <= 0) {
            throw new IllegalArgumentException("The required parameter 'tracking_metadata' contains no data");
        } else {
            HashMap hashMap3 = new HashMap(2);
            hashMap3.put("item_metadata", mapToJsonString(hashMap));
            hashMap3.put("tracking_metadata", mapToJsonString(hashMap2));
            commContext.waitForUserDevice();
            return makeAsyncPOSTRequestForJson("earn", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_EARN, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_SERVICE_ENDPOINT), URLEncoder.encode(commContext.getUserDeviceId(), Constants.ENCODING_CHARSET), URLEncoder.encode(str, Constants.ENCODING_CHARSET), URLEncoder.encode(str3, Constants.ENCODING_CHARSET)), hashMap3, null, z);
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase, com.getjar.sdk.comm.AuthorizedServiceProxyBase
    public Request.ServiceName getServiceName() {
        return Request.ServiceName.TRANSACTION;
    }

    /* access modifiers changed from: protected */
    public Operation reserveUnmanagedPurchase(CommContext commContext, String str, String str2, String str3, Integer num, String str4, HashMap<String, String> hashMap, boolean z) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'productId' was not provided");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("The required parameter 'productName' was not provided");
        } else if (StringUtility.isNullOrEmpty(str3)) {
            throw new IllegalArgumentException("The required parameter 'productDescription' was not provided");
        } else if (num == null) {
            throw new IllegalArgumentException("The required parameter 'amount' was not provided");
        } else if (num.intValue() < 0) {
            throw new IllegalArgumentException("The parameter 'amount' can not have a negative value");
        } else if (StringUtility.isNullOrEmpty(str4)) {
            throw new IllegalArgumentException("The required parameter 'client_transaction_id' was not provided");
        } else if (hashMap == null) {
            throw new IllegalArgumentException("The required parameter 'trackingData' was not provided");
        } else if (hashMap.size() <= 0) {
            throw new IllegalArgumentException("The required parameter 'trackingData' contains no data");
        } else {
            HashMap hashMap2 = new HashMap(1);
            hashMap2.put("tracking_metadata", mapToJsonString(hashMap));
            commContext.waitForUserDevice();
            return makeAsyncPOSTRequestForJson("reserveUnmanagedPurchase", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_RESERVE_UNMANAGED_OFFER, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_SERVICE_ENDPOINT), URLEncoder.encode(commContext.getUserDeviceId(), Constants.ENCODING_CHARSET), URLEncoder.encode(str, Constants.ENCODING_CHARSET), URLEncoder.encode(str2, Constants.ENCODING_CHARSET), URLEncoder.encode(str3, Constants.ENCODING_CHARSET), Integer.toString(num.intValue()), URLEncoder.encode(str4, Constants.ENCODING_CHARSET)), hashMap2, null, z);
        }
    }
}

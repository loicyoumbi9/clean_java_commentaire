package com.getjar.sdk.comm;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

class CachedResultFuture extends FutureTask<Result> {
    private static Callable<Result> _ReturnCachedResultCallable = new Callable<Result>() {
        /* class com.getjar.sdk.comm.CachedResultFuture.AnonymousClass1 */

        @Override // java.util.concurrent.Callable
        public Result call() throws Exception {
            return null;
        }
    };
    private Result _cachedResult = null;

    protected CachedResultFuture(Result result) {
        super(_ReturnCachedResultCallable);
        if (result == null) {
            throw new IllegalArgumentException("'cachedResult' can not be NULL");
        }
        this._cachedResult = result;
    }

    @Override // java.util.concurrent.Future, java.util.concurrent.FutureTask
    public Result get() {
        return this._cachedResult;
    }

    @Override // java.util.concurrent.Future, java.util.concurrent.FutureTask
    public Result get(long j, TimeUnit timeUnit) {
        return this._cachedResult;
    }

    public boolean isCancelled() {
        return false;
    }

    public boolean isDone() {
        return true;
    }

    public void run() {
    }
}

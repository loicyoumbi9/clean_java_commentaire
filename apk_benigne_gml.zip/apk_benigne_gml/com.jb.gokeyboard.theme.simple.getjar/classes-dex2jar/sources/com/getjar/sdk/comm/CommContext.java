package com.getjar.sdk.comm;

import android.content.Context;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;
import com.getjar.sdk.data.DeviceMetadata;
import com.getjar.sdk.response.BlacklistedResponse;
import com.getjar.sdk.response.CloseResponse;
import com.getjar.sdk.response.DeviceUnsupportedResponse;
import com.getjar.sdk.response.PurchaseSucceededResponse;
import com.getjar.sdk.response.Response;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.StringUtility;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

public class CommContext {
    public static final long ServiceCallTimeoutInMilliseconds = 35000;
    private static final Map<Class<? extends Response>, Integer> _ResponseOrderOfPrecedence = new HashMap<Class<? extends Response>, Integer>() {
        /* class com.getjar.sdk.comm.CommContext.AnonymousClass1 */

        {
            put(PurchaseSucceededResponse.class, 1);
            put(DeviceUnsupportedResponse.class, 2);
            put(BlacklistedResponse.class, 3);
            put(CloseResponse.class, 4);
        }
    };
    private static final int _WaitLoggingCountInterval = 10;
    private Context _applicationContext = null;
    private String _applicationKey = null;
    private Future<Result> _authFuture = null;
    private volatile String _authToken = null;
    private Object _authorizationStateLock = new Object();
    private String _commContextId = null;
    private ConcurrentLinkedQueue<CommFailureCallbackInterface> _commFailureCallbackInterfaceList = new ConcurrentLinkedQueue<>();
    private DeviceMetadata _deviceMetadata = null;
    private ConcurrentHashMap<Long, Throwable> _epochToException = new ConcurrentHashMap<>();
    private volatile boolean _isUserAccessIdReady = false;
    private volatile boolean _isUserAccessInErrorState = false;
    private volatile boolean _isUserDeviceIdReady = false;
    private volatile boolean _isUserDeviceInErrorState = false;
    private volatile long _lastUpdated;
    private Response _pulledResponse = null;
    private Object _pulledResponseLock = new Object();
    private ResultReceiver _resultReceiver = null;
    private String _sdkUserAgent = null;
    private volatile String _userAccessId = null;
    private Object _userAccessStateLock = new Object();
    private volatile String _userDeviceId = null;
    private Object _userDeviceStateLock = new Object();
    private String _webKitUserAgent = null;

    protected CommContext(String str, Context context, ResultReceiver resultReceiver) throws InterruptedException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'applicationKey' can not be NULL or empty");
        } else if (resultReceiver == null) {
            throw new IllegalArgumentException("'resultReceiver' can not be NULL");
        } else if (context == null) {
            throw new IllegalArgumentException("'context' can not be NULL");
        } else {
            this._resultReceiver = resultReceiver;
            this._applicationKey = str;
            this._commContextId = UUID.randomUUID().toString();
            this._deviceMetadata = new DeviceMetadata(context);
            this._applicationContext = context.getApplicationContext();
            this._sdkUserAgent = UserAgentValuesManager.getInstance().getSdkUserAgent(context, str);
            this._webKitUserAgent = UserAgentValuesManager.getInstance().getWebKitUserAgent(context);
            updateLastUpdated();
        }
    }

    private static <T extends Comparable<? super T>> List<T> asSortedList(Collection<T> collection) {
        ArrayList arrayList = new ArrayList(collection);
        Collections.sort(arrayList);
        return arrayList;
    }

    private void setResponse(Response response) {
        if (response == null) {
            throw new IllegalArgumentException("'response' can not be NULL");
        }
        synchronized (this._pulledResponseLock) {
            if (this._pulledResponse == null) {
                this._pulledResponse = response;
                Log.v(Constants.TAG, String.format("Current response updated to %1$s", this._pulledResponse.getClass().getName()));
            } else {
                int intValue = _ResponseOrderOfPrecedence.get(this._pulledResponse.getClass()).intValue();
                int intValue2 = _ResponseOrderOfPrecedence.get(response.getClass()).intValue();
                Log.v(Constants.TAG, String.format("setResponse() called [currentResponse:%1$d:%2$s] [newResponse:%3$d:%4$s]", Integer.valueOf(intValue), this._pulledResponse.getClass().getName(), Integer.valueOf(intValue2), response.getClass().getName()));
                if (intValue2 < intValue) {
                    this._pulledResponse = response;
                    Log.v(Constants.TAG, String.format("Current response updated to %1$s", this._pulledResponse.getClass().getName()));
                }
            }
        }
    }

    public void addException(Throwable th) {
        this._epochToException.put(Long.valueOf(System.currentTimeMillis()), th);
    }

    /* access modifiers changed from: protected */
    public void clearAuthentication() {
        synchronized (this._authorizationStateLock) {
            synchronized (this._userAccessStateLock) {
                synchronized (this._userDeviceStateLock) {
                    this._authFuture = null;
                    this._authToken = null;
                    this._userAccessId = null;
                    this._isUserAccessIdReady = false;
                    this._isUserAccessInErrorState = false;
                    this._userDeviceId = null;
                    this._isUserDeviceIdReady = false;
                    this._isUserDeviceInErrorState = false;
                    this._epochToException.clear();
                }
            }
        }
        CreateContextWorker.clearAuthPersistence(this._applicationContext);
    }

    /* access modifiers changed from: protected */
    public void clearExceptions() {
        this._epochToException.clear();
    }

    public void clearResponse() {
        synchronized (this._pulledResponseLock) {
            this._pulledResponse = null;
        }
        Log.v(Constants.TAG, "Current response cleared");
    }

    public Context getApplicationContext() {
        return this._applicationContext;
    }

    /* access modifiers changed from: protected */
    public String getApplicationKey() {
        return this._applicationKey;
    }

    public String getAuthToken() {
        return this._authToken;
    }

    public String getCommContextId() {
        return this._commContextId;
    }

    public Map<String, String> getDeviceMetadata() {
        return this._deviceMetadata.getMetadata();
    }

    /* access modifiers changed from: protected */
    public String getDeviceMetadataJson() throws JSONException {
        return this._deviceMetadata.toJsonString();
    }

    /* access modifiers changed from: protected */
    public String getDeviceMetadataJsonWithReliabilities() throws JSONException {
        return this._deviceMetadata.toJsonStringWithReliabilities();
    }

    public Map<Long, Throwable> getExceptions() {
        return Collections.unmodifiableMap(this._epochToException);
    }

    /* access modifiers changed from: protected */
    public long getLastUpdated() {
        return this._lastUpdated;
    }

    public Throwable getMostRecentException() {
        if (getExceptions().size() <= 0) {
            return null;
        }
        return getExceptions().get(asSortedList(getExceptions().keySet()).get(0));
    }

    public Response getResponse() {
        return this._pulledResponse;
    }

    public ResultReceiver getResultReceiver() {
        return this._resultReceiver;
    }

    public String getSdkUserAgent() {
        return this._sdkUserAgent;
    }

    public String getUserAccessId() {
        return this._userAccessId;
    }

    public String getUserDeviceId() {
        return this._userDeviceId;
    }

    public String getWebKitUserAgent() {
        return this._webKitUserAgent;
    }

    /* access modifiers changed from: protected */
    public boolean isUserAccessIdReady() {
        return this._isUserAccessIdReady;
    }

    /* access modifiers changed from: protected */
    public boolean isUserAccessInErrorState() {
        return this._isUserAccessInErrorState;
    }

    /* access modifiers changed from: protected */
    public boolean isUserDeviceIdReady() {
        return this._isUserDeviceIdReady;
    }

    /* access modifiers changed from: protected */
    public boolean isUserDeviceInErrorState() {
        return this._isUserDeviceInErrorState || this._isUserAccessInErrorState;
    }

    public void makeAuthorizationFailureCallbacks(String str) {
        Log.d(Constants.TAG, String.format("makeAuthorizationFailureCallbacks() with %1$d call-back interfaces registered [from %2$s]", Integer.valueOf(this._commFailureCallbackInterfaceList.size()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        Iterator<CommFailureCallbackInterface> it = this._commFailureCallbackInterfaceList.iterator();
        while (it.hasNext()) {
            try {
                it.next().authorizationFailure(str);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void makeNetworkFailureCallbacks() {
        Log.d(Constants.TAG, String.format("makeNetworkFailureCallbacks() with %1$d call-back interfaces registered [from %2$s]", Integer.valueOf(this._commFailureCallbackInterfaceList.size()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        Iterator<CommFailureCallbackInterface> it = this._commFailureCallbackInterfaceList.iterator();
        while (it.hasNext()) {
            try {
                it.next().networkFailure();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void makeServiceFailureCallbacks(Result result) {
        Log.d(Constants.TAG, String.format("makeServiceFailureCallbacks() with %1$d call-back interfaces registered [from %2$s]", Integer.valueOf(this._commFailureCallbackInterfaceList.size()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        Iterator<CommFailureCallbackInterface> it = this._commFailureCallbackInterfaceList.iterator();
        while (it.hasNext()) {
            try {
                it.next().serviceFailure(result);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void postResponse(Response response) {
        setResponse(response);
        if (this._resultReceiver != null) {
            Bundle bundle = new Bundle();
            bundle.putParcelable("response", response);
            this._resultReceiver.send(0, bundle);
        }
    }

    public void registerFailureCallback(CommFailureCallbackInterface commFailureCallbackInterface) {
        if (!this._commFailureCallbackInterfaceList.contains(commFailureCallbackInterface)) {
            this._commFailureCallbackInterfaceList.add(commFailureCallbackInterface);
        }
    }

    public void setAuthToken(String str) {
        if (str == null) {
            throw new IllegalArgumentException("'authToken' can not be NULL");
        }
        synchronized (this._authorizationStateLock) {
            this._authToken = str;
        }
    }

    /* access modifiers changed from: protected */
    public void setAuthorizationFuture(Future<Result> future) {
        if (future == null) {
            throw new IllegalArgumentException("'authFuture' can not be NULL");
        }
        synchronized (this._authorizationStateLock) {
            this._authFuture = future;
        }
    }

    /* access modifiers changed from: protected */
    public void setUserAccessId(String str) {
        synchronized (this._userAccessStateLock) {
            this._userAccessId = str;
            if (!StringUtility.isNullOrEmpty(this._userAccessId)) {
                this._isUserAccessIdReady = true;
                this._isUserAccessInErrorState = false;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setUserAccessInErrorState() {
        Log.e(Constants.TAG, String.format("setUserAccessInErrorState() Stack: %1$s", Logger.GetStackTrace()));
        synchronized (this._userAccessStateLock) {
            this._isUserAccessInErrorState = true;
            this._isUserAccessIdReady = false;
        }
    }

    /* access modifiers changed from: protected */
    public void setUserAccessNotFoundState() {
        Log.e(Constants.TAG, String.format("setUserAccessNotFoundState() Stack: %1$s", Logger.GetStackTrace()));
        synchronized (this._userAccessStateLock) {
            this._isUserAccessInErrorState = false;
            this._isUserAccessIdReady = false;
        }
    }

    /* access modifiers changed from: protected */
    public void setUserDeviceId(String str) {
        synchronized (this._userDeviceStateLock) {
            this._userDeviceId = str;
            if (!StringUtility.isNullOrEmpty(this._userDeviceId)) {
                this._isUserDeviceIdReady = true;
                this._isUserDeviceInErrorState = false;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setUserDeviceInErrorState() {
        Log.e(Constants.TAG, String.format("setUserDeviceInErrorState() Stack: %1$s", Logger.GetStackTrace()));
        synchronized (this._userDeviceStateLock) {
            this._isUserDeviceInErrorState = true;
            this._isUserDeviceIdReady = false;
        }
    }

    /* access modifiers changed from: protected */
    public void updateLastUpdated() {
        this._lastUpdated = System.currentTimeMillis();
    }

    public void waitForAuthorization() throws Exception {
        if (StringUtility.isNullOrEmpty(getAuthToken()) && this._authFuture == null) {
            for (int i = 0; i < 20; i++) {
                Thread.sleep(100);
                if (!StringUtility.isNullOrEmpty(getAuthToken()) || this._authFuture != null) {
                    break;
                }
            }
        }
        if (StringUtility.isNullOrEmpty(getAuthToken())) {
            if (this._authFuture == null) {
                throw new IllegalStateException(String.format("CommContext %1$s has no auth token or authorization future", getCommContextId()));
            }
            this._authFuture.get();
            if (StringUtility.isNullOrEmpty(getAuthToken())) {
                throw new IllegalStateException(String.format("CommContext %1$s authorization future finished, but we still have no auth token", getCommContextId()));
            }
        }
    }

    public void waitForUserAccess() throws InterruptedException, TimeoutException {
        int i = 0;
        long currentTimeMillis = System.currentTimeMillis();
        while (!isUserAccessIdReady() && !isUserAccessInErrorState()) {
            long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
            if (i % 10 == 0) {
                Log.v(Constants.TAG, String.format("Waiting for CommContext user access [%1$d] [thread:%2$s]", Long.valueOf(currentTimeMillis2), Long.valueOf(Thread.currentThread().getId())));
            }
            i++;
            if (currentTimeMillis2 >= ServiceCallTimeoutInMilliseconds) {
                throw new TimeoutException(String.format("waitForUserAccess() excceeded the given timeout value of %1$d milliseconds", Long.valueOf((long) ServiceCallTimeoutInMilliseconds)));
            }
            Thread.sleep(100);
        }
        if (isUserAccessInErrorState()) {
            String format = String.format("User Access failed for CommContext %1$s", getCommContextId());
            if (getExceptions().size() > 0) {
                throw new IllegalStateException(format, getMostRecentException());
            }
            throw new IllegalStateException(format);
        }
    }

    public void waitForUserDevice() throws InterruptedException, TimeoutException {
        int i = 0;
        long currentTimeMillis = System.currentTimeMillis();
        while (!isUserDeviceIdReady() && !isUserDeviceInErrorState()) {
            long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
            if (i % 10 == 0) {
                Log.v(Constants.TAG, String.format("Waiting for CommContext user device [%1$d] [thread:%2$s]", Long.valueOf(currentTimeMillis2), Long.valueOf(Thread.currentThread().getId())));
            }
            i++;
            if (currentTimeMillis2 >= ServiceCallTimeoutInMilliseconds) {
                StringBuilder sb = new StringBuilder("");
                List<StackTraceElement> asList = Arrays.asList(Thread.currentThread().getStackTrace());
                Collections.reverse(asList);
                for (StackTraceElement stackTraceElement : asList) {
                    sb.append(stackTraceElement.getMethodName());
                    sb.append("():");
                }
                throw new TimeoutException(String.format("waitForUserDevice() excceeded the given timeout value of %1$d milliseconds [called from %2$s]", Long.valueOf((long) ServiceCallTimeoutInMilliseconds), sb));
            }
            Thread.sleep(100);
        }
        if (isUserDeviceInErrorState()) {
            String format = String.format("User Device failed for CommContext %1$s", getCommContextId());
            if (getExceptions().size() > 0) {
                throw new IllegalStateException(format, getMostRecentException());
            }
            throw new IllegalStateException(format);
        }
    }
}

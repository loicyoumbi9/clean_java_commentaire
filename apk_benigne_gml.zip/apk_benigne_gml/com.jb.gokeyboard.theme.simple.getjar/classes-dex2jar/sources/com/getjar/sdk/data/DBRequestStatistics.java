package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.utilities.Constants;
import java.util.Map;
import java.util.TreeMap;

public class DBRequestStatistics extends SQLiteOpenHelper {
    private static final String[] DB_CREATE_TABLE_COMMANDS = {_DB_CREATE_TABLE_REQUESTS, _DB_CREATE_TABLE_RESPONSES};
    private static final String[] DB_TABLE_NAMES = {_DATABASE_TABLE_NAME_REQUESTS, _DATABASE_TABLE_NAME_RESPONSES};
    private static final String _DATABASE_NAME = "GetJarStatisticsDB";
    private static final String _DATABASE_TABLE_NAME_REQUESTS = "requests";
    private static final String _DATABASE_TABLE_NAME_RESPONSES = "responses";
    private static final int _DATABASE_VERSION = 4;
    private static final String _DB_CREATE_TABLE_REQUESTS = "CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, serviceName TEXT NOT NULL, requestType TEXT NOT NULL, requestCount INTEGER NOT NULL, responseCount INTEGER NOT NULL, observedSizeSmallest INTEGER NOT NULL, observedSizeLargest INTEGER NOT NULL);";
    private static final String _DB_CREATE_TABLE_RESPONSES = "CREATE TABLE IF NOT EXISTS responses (id INTEGER PRIMARY KEY AUTOINCREMENT, requestId INTEGER NOT NULL, responseTime INTEGER NOT NULL, responseSize INTEGER NOT NULL,responseCode INTEGER NOT NULL DEFAULT 0);";
    private static final int _MaxResponseRecordsCap = 600;
    private SQLiteDatabase _database = getWritableDatabase();

    public DBRequestStatistics(Context context) {
        super(context, _DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 4);
    }

    /* JADX INFO: finally extract failed */
    private void lruCapResponsesAtMaxRecords() {
        if (getResponseRecordCount() >= 600) {
            Cursor query = this._database.query(_DATABASE_TABLE_NAME_RESPONSES, new String[]{Constants.APP_ID}, null, null, null, null, "id DESC");
            try {
                Long valueOf = query.moveToPosition(_MaxResponseRecordsCap) ? Long.valueOf(query.getLong(0)) : null;
                query.close();
                Log.v(Constants.TAG, String.format("DBRequestStatistics: lruCapResponsesAtMaxRecords() %1$d LRU rows deleted form the response statistics DB", Integer.valueOf(this._database.delete(_DATABASE_TABLE_NAME_RESPONSES, String.format("id <= %1$d", valueOf), null))));
            } catch (Throwable th) {
                query.close();
                throw th;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    public boolean addResponseRecord(Request request, Result result) {
        if (request == null) {
            throw new IllegalArgumentException("'request' can not be NULL");
        } else if (result == null) {
            throw new IllegalArgumentException("'response' can not be NULL");
        } else {
            if (!checkForRequestEntry(request)) {
                upsertRequestRecord(request);
            }
            Cursor query = this._database.query(_DATABASE_TABLE_NAME_REQUESTS, null, "serviceName = ? AND requestType = ?", new String[]{request.getServiceName().name(), request.getRequestType()}, null, null, null);
            try {
                if (query.moveToNext()) {
                    int i = query.getInt(0);
                    int i2 = query.getInt(4);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("responseCount", Integer.valueOf(i2 + 1));
                    Log.v(Constants.TAG, String.format("DBRequestStatistics: addResponseRecord() Updating request stats record [serviceName:%1$s requestType:%2$s responseCount:%3$d]", request.getServiceName().name(), request.getRequestType(), Integer.valueOf(i2 + 1)));
                    this._database.update(_DATABASE_TABLE_NAME_REQUESTS, contentValues, "id = " + Integer.toString(i), null);
                    query.close();
                    int estimatedResponseSizeInBytes = result.getEstimatedResponseSizeInBytes();
                    ContentValues contentValues2 = new ContentValues();
                    contentValues2.put(Constants.REQUEST_ID, Integer.valueOf(i));
                    contentValues2.put("responseTime", Integer.valueOf(result.getResponseTime()));
                    contentValues2.put("responseSize", Integer.valueOf(estimatedResponseSizeInBytes));
                    contentValues2.put(Constants.RESPONSE_CODE, Integer.valueOf(result.getResponseCode()));
                    Log.v(Constants.TAG, String.format("DBRequestStatistics: addResponseRecord() Inserting response stats record [serviceName:%1$s requestType:%2$s responseTime:%3$d responseSize:%4$d responseCode:%5$d]", request.getServiceName().name(), request.getRequestType(), Integer.valueOf(result.getResponseTime()), Integer.valueOf(estimatedResponseSizeInBytes), Integer.valueOf(result.getResponseCode())));
                    boolean z = this._database.insert(_DATABASE_TABLE_NAME_RESPONSES, null, contentValues2) != -1;
                    lruCapResponsesAtMaxRecords();
                    return z;
                }
                throw new IllegalStateException("Unable to find or create a request statistics record");
            } catch (Throwable th) {
                query.close();
                throw th;
            }
        }
    }

    public boolean checkForRequestEntry(Request request) {
        boolean z = false;
        if (request == null) {
            throw new IllegalArgumentException("'request' can not be NULL");
        }
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s WHERE serviceName = ? AND requestType = ?", _DATABASE_TABLE_NAME_REQUESTS));
        try {
            compileStatement.bindString(1, request.getServiceName().name());
            compileStatement.bindString(2, request.getRequestType());
            if (compileStatement.simpleQueryForLong() > 0) {
                z = true;
            }
            try {
            } catch (Exception e) {
                Log.e(Constants.TAG, "DBRequestStatistics: checkForRequestEntry() SQLiteOpenHelper.close() failed", e);
            }
            return z;
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e2) {
                Log.e(Constants.TAG, "DBRequestStatistics: checkForRequestEntry() SQLiteOpenHelper.close() failed", e2);
            }
        }
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this._database.close();
    }

    public Map<String, Float> getAnalyticData() {
        TreeMap treeMap = new TreeMap();
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(requestCount) FROM %1$s", _DATABASE_TABLE_NAME_REQUESTS));
        try {
            treeMap.put("Overall: total number of requests", Float.valueOf((float) compileStatement.simpleQueryForLong()));
            SQLiteStatement compileStatement2 = this._database.compileStatement(String.format("SELECT count(responseCount) FROM %1$s", _DATABASE_TABLE_NAME_REQUESTS));
            try {
                treeMap.put("Overall: total number of responses", Float.valueOf((float) compileStatement2.simpleQueryForLong()));
                Cursor query = this._database.query(_DATABASE_TABLE_NAME_RESPONSES, new String[]{Constants.RESPONSE_CODE, "count(responseCode)"}, null, null, Constants.RESPONSE_CODE, null, null);
                while (query.moveToNext()) {
                    try {
                        treeMap.put(String.format("Overall: number of responses [response code: %1$d]", Integer.valueOf(query.getInt(0))), Float.valueOf((float) query.getInt(1)));
                    } finally {
                        try {
                            query.close();
                        } catch (Exception e) {
                        }
                    }
                }
                Cursor query2 = this._database.query(_DATABASE_TABLE_NAME_RESPONSES, new String[]{"min(responseTime)", "max(responseTime)", "avg(responseTime)", "min(responseSize)", "max(responseSize)", "avg(responseSize)"}, null, null, null, null, null);
                try {
                    if (query2.moveToNext()) {
                        treeMap.put("Overall: min response time", Float.valueOf(query2.getFloat(0)));
                        treeMap.put("Overall: max response time", Float.valueOf(query2.getFloat(1)));
                        treeMap.put("Overall: avg response time", Float.valueOf(query2.getFloat(2)));
                        treeMap.put("Overall: min response size", Float.valueOf(query2.getFloat(3)));
                        treeMap.put("Overall: max response size", Float.valueOf(query2.getFloat(4)));
                        treeMap.put("Overall: avg response size", Float.valueOf(query2.getFloat(5)));
                    }
                    try {
                        return treeMap;
                    } catch (Exception e2) {
                        return treeMap;
                    }
                } finally {
                    try {
                        query2.close();
                    } catch (Exception e3) {
                    }
                }
            } finally {
                try {
                    compileStatement2.close();
                } catch (Exception e4) {
                }
            }
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e5) {
            }
        }
    }

    public long getResponseRecordCount() {
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s", _DATABASE_TABLE_NAME_RESPONSES));
        try {
            return compileStatement.simpleQueryForLong();
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e) {
            }
        }
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        for (int i = 0; i < DB_CREATE_TABLE_COMMANDS.length; i++) {
            sQLiteDatabase.execSQL(DB_CREATE_TABLE_COMMANDS[i]);
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        Log.i(Constants.TAG, String.format("DBRequestStatistics: onUpgrade() Upgrading DB %1$s from version %2$d to %3$d (deletes all data)", _DATABASE_NAME, Integer.valueOf(i), Integer.valueOf(i2)));
        for (int i3 = 0; i3 < DB_TABLE_NAMES.length; i3++) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_NAMES[i3]);
        }
        onCreate(sQLiteDatabase);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean upsertRequestRecord(Request request) {
        boolean z = true;
        if (request == null) {
            throw new IllegalArgumentException("'request' can not be NULL");
        }
        Cursor query = this._database.query(_DATABASE_TABLE_NAME_REQUESTS, null, "serviceName = ? AND requestType = ?", new String[]{request.getServiceName().name(), request.getRequestType()}, null, null, null);
        try {
            if (query.moveToNext()) {
                int i = query.getInt(0);
                int i2 = query.getInt(3);
                int i3 = query.getInt(4);
                int i4 = query.getInt(5);
                int i5 = query.getInt(6);
                int estimatedRequestSizeInBytes = request.getEstimatedRequestSizeInBytes();
                ContentValues contentValues = new ContentValues();
                contentValues.put("requestCount", Integer.valueOf(i2 + 1));
                if (estimatedRequestSizeInBytes < i4) {
                    i4 = estimatedRequestSizeInBytes;
                }
                if (estimatedRequestSizeInBytes <= i5) {
                    estimatedRequestSizeInBytes = i5;
                }
                contentValues.put("observedSizeSmallest", Integer.valueOf(i4));
                contentValues.put("observedSizeLargest", Integer.valueOf(estimatedRequestSizeInBytes));
                Log.v(Constants.TAG, String.format("DBRequestStatistics: upsertRequestRecord() Updating request stats record [serviceName:%1$s requestType:%2$s requestCount:%3$d responseCount:%4$d observedSizeSmallest:%5$d observedSizeLargest:%6$d]", request.getServiceName().name(), request.getRequestType(), Integer.valueOf(i2 + 1), Integer.valueOf(i3), Integer.valueOf(i4), Integer.valueOf(estimatedRequestSizeInBytes)));
                if (this._database.update(_DATABASE_TABLE_NAME_REQUESTS, contentValues, "id = " + Integer.toString(i), null) <= 0) {
                    z = false;
                }
                return z;
            }
            int estimatedRequestSizeInBytes2 = request.getEstimatedRequestSizeInBytes();
            ContentValues contentValues2 = new ContentValues();
            contentValues2.put("serviceName", request.getServiceName().name());
            contentValues2.put("requestType", request.getRequestType());
            contentValues2.put("requestCount", (Integer) 1);
            contentValues2.put("responseCount", (Integer) 0);
            contentValues2.put("observedSizeSmallest", Integer.valueOf(estimatedRequestSizeInBytes2));
            contentValues2.put("observedSizeLargest", Integer.valueOf(estimatedRequestSizeInBytes2));
            Log.v(Constants.TAG, String.format("DBRequestStatistics: upsertRequestRecord() Inserting request stats record [serviceName:%1$s requestType:%2$s requestCount:%3$d responseCount:%4$d observedSizeSmallest:%5$d observedSizeLargest:%6$d]", request.getServiceName().name(), request.getRequestType(), 1, 0, Integer.valueOf(estimatedRequestSizeInBytes2), Integer.valueOf(estimatedRequestSizeInBytes2)));
            boolean z2 = this._database.insert(_DATABASE_TABLE_NAME_REQUESTS, null, contentValues2) != -1;
            query.close();
            return z2;
        } finally {
            query.close();
        }
    }
}

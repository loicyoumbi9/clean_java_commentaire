package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.net.URISyntaxException;

public class DBCache extends SQLiteOpenHelper {
    private static final String _DATABASE_NAME = "GetJarCacheDB";
    private static final String _DATABASE_TABLE_NAME = "cacheValues";
    private static final int _DATABASE_VERSION = 4;
    private static final String _DB_CREATE_TABLE = "CREATE TABLE IF NOT EXISTS cacheValues (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, value TEXT NOT NULL, createdTimestamp INTEGER NOT NULL, lastUpdated INTEGER NOT NULL, ttl INTEGER NOT NULL, uri TEXT, etag TEXT);";
    private static final int _MaxRecordsCap = 300;
    private SQLiteDatabase _database = getWritableDatabase();

    public DBCache(Context context) {
        super(context, _DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 4);
    }

    public boolean checkForCacheEntry(String str) {
        boolean z = false;
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'name' can not be NULL or empty");
        }
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s WHERE name = ?", _DATABASE_TABLE_NAME));
        try {
            compileStatement.bindString(1, str);
            if (compileStatement.simpleQueryForLong() > 0) {
                z = true;
            }
            try {
            } catch (Exception e) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e);
            }
            return z;
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e2) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e2);
            }
        }
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this._database.close();
    }

    public boolean deleteCacheEntry(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'name' can not be NULL or empty");
        }
        return this._database.delete(_DATABASE_TABLE_NAME, "name = ?", new String[]{str}) > 0;
    }

    public long getRecordCount() {
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s", _DATABASE_TABLE_NAME));
        try {
            long simpleQueryForLong = compileStatement.simpleQueryForLong();
            try {
            } catch (Exception e) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e);
            }
            return simpleQueryForLong;
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e2) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e2);
            }
        }
    }

    public CacheEntry loadCacheEntry(String str) throws URISyntaxException {
        CacheEntry cacheEntry = null;
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'name' can not be NULL or empty");
        }
        Cursor query = this._database.query(_DATABASE_TABLE_NAME, null, "name = ?", new String[]{str}, null, null, null);
        try {
            if (query.moveToNext()) {
                cacheEntry = new CacheEntry(query);
            } else {
                try {
                    query.close();
                } catch (Exception e) {
                }
            }
            return cacheEntry;
        } finally {
            try {
                query.close();
            } catch (Exception e2) {
            }
        }
    }

    public void lruCapAtMaxRecords() {
        if (getRecordCount() >= 300) {
            Cursor query = this._database.query(_DATABASE_TABLE_NAME, new String[]{Constants.APP_ID}, null, null, null, null, "createdTimestamp DESC");
            try {
                Log.v(Constants.TAG, String.format("%1$d LRU rows deleted form the cache DB", Integer.valueOf(this._database.delete(_DATABASE_TABLE_NAME, String.format("id <= %1$d", query.moveToPosition(_MaxRecordsCap) ? Long.valueOf(query.getLong(0)) : null), null))));
            } finally {
                try {
                    query.close();
                } catch (Exception e) {
                }
            }
        }
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(_DB_CREATE_TABLE);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        Log.i(Constants.TAG, String.format("Upgrading database from version %1$d to %2$d, which will destroy all old data", Integer.valueOf(i), Integer.valueOf(i2)));
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS cacheValues");
        onCreate(sQLiteDatabase);
    }

    public boolean upsertCacheEntry(CacheEntry cacheEntry) {
        if (cacheEntry == null) {
            throw new IllegalArgumentException("'cacheEntry' can not be null");
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", cacheEntry.getName());
        contentValues.put("value", cacheEntry.getValue());
        contentValues.put("ttl", cacheEntry.getTtl());
        if (cacheEntry.getUri() == null) {
            contentValues.putNull("uri");
        } else {
            contentValues.put("uri", cacheEntry.getUri().toString());
        }
        if (cacheEntry.getEtag() == null) {
            contentValues.putNull("etag");
        } else {
            contentValues.put("etag", cacheEntry.getEtag());
        }
        contentValues.put("lastUpdated", Long.valueOf(System.currentTimeMillis()));
        try {
            if (checkForCacheEntry(cacheEntry.getName())) {
                Log.v(Constants.TAG, String.format("Updating cache entry %1$s", cacheEntry.toString()));
                if (this._database.update(_DATABASE_TABLE_NAME, contentValues, "name = ?", new String[]{cacheEntry.getName()}) <= 0) {
                    return false;
                }
            } else {
                contentValues.put("createdTimestamp", Long.valueOf(System.currentTimeMillis()));
                Log.v(Constants.TAG, String.format("Inserting cache entry %1$s", cacheEntry.toString()));
                if (this._database.insert(_DATABASE_TABLE_NAME, null, contentValues) == -1) {
                    return false;
                }
            }
            return true;
        } catch (SQLiteException e) {
            Log.e(Constants.TAG, "upsertCacheEntry() failed", e);
            return false;
        }
    }
}

package com.getjar.sdk.comm;

import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

public class Request {
    private final HttpMethod _httpMethod;
    private final URI _normalizedRequestUri;
    private final Map<String, String> _postData;
    private final List<NameValuePair> _queryParams;
    private final String _requestType;
    private final ServiceName _serviceName;
    private final Integer _uniqueId;

    public enum HttpMethod {
        GET,
        POST
    }

    public enum ServiceName {
        AUTH,
        LOCALIZATION,
        TRANSACTION,
        USER
    }

    protected Request(ServiceName serviceName, String str, URI uri, HttpMethod httpMethod, Map<String, String> map) {
        if (serviceName == null) {
            throw new IllegalArgumentException("'serviceName' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'requestType' can not be NULL or empty");
        } else if (uri == null) {
            throw new IllegalArgumentException("'requestUri' can not be NULL");
        } else if (httpMethod == null) {
            throw new IllegalArgumentException("'httpMethod' can not be NULL");
        } else if (map == null || HttpMethod.POST.equals(httpMethod)) {
            this._serviceName = serviceName;
            this._requestType = str;
            this._httpMethod = httpMethod;
            this._normalizedRequestUri = uri.normalize();
            this._queryParams = URLEncodedUtils.parse(this._normalizedRequestUri, Constants.ENCODING_CHARSET);
            this._postData = map;
            this._uniqueId = Integer.valueOf(getUniqueId());
        } else {
            throw new IllegalArgumentException("'postData' can only be provided for requests of method type \"POST\"");
        }
    }

    private int getUniqueId() {
        StringBuilder sb = new StringBuilder();
        sb.append(this._normalizedRequestUri.getScheme());
        sb.append(this._normalizedRequestUri.getHost());
        sb.append(this._normalizedRequestUri.getPath());
        Collections.sort(this._queryParams, new Comparator<NameValuePair>() {
            /* class com.getjar.sdk.comm.Request.AnonymousClass1 */

            public int compare(NameValuePair nameValuePair, NameValuePair nameValuePair2) {
                return nameValuePair.getName().compareTo(nameValuePair2.getName());
            }
        });
        for (NameValuePair nameValuePair : this._queryParams) {
            sb.append(nameValuePair.getName());
            sb.append(nameValuePair.getValue());
        }
        sb.append(this._normalizedRequestUri.getFragment());
        if (this._postData != null) {
            for (String str : this._postData.keySet()) {
                sb.append(str);
                sb.append(this._postData.get(str));
            }
        }
        String sb2 = sb.toString();
        return StringUtility.isNullOrEmpty(sb2) ? this._normalizedRequestUri.getPort() : sb2.hashCode() + this._normalizedRequestUri.getPort();
    }

    public boolean equals(Object obj) {
        if (obj != null) {
            return (obj instanceof Request) && hashCode() == obj.hashCode();
        }
        throw new IllegalArgumentException("'object' can not be NULL");
    }

    public int getEstimatedRequestSizeInBytes() {
        int length = this._normalizedRequestUri.toString().getBytes().length;
        if (this._postData == null) {
            return length;
        }
        int i = length;
        for (String str : this._postData.keySet()) {
            int length2 = !StringUtility.isNullOrEmpty(str) ? str.getBytes().length + i : i;
            i = !StringUtility.isNullOrEmpty(this._postData.get(str)) ? this._postData.get(str).getBytes().length + length2 : length2;
        }
        return i;
    }

    public HttpMethod getHttpMethod() {
        return this._httpMethod;
    }

    public int getId() {
        if (this._uniqueId != null) {
            return this._uniqueId.intValue();
        }
        throw new IllegalStateException("Unique ID has not been calculated yet");
    }

    public URI getNormalizedRequestUri() {
        return this._normalizedRequestUri;
    }

    public Map<String, String> getPostData() {
        if (this._postData == null) {
            return null;
        }
        return Collections.unmodifiableMap(this._postData);
    }

    public String getRequestType() {
        return this._requestType;
    }

    public ServiceName getServiceName() {
        return this._serviceName;
    }

    public URI getUriForRequest() throws URISyntaxException, UnsupportedEncodingException {
        return this._normalizedRequestUri;
    }

    public int hashCode() {
        return getId();
    }
}

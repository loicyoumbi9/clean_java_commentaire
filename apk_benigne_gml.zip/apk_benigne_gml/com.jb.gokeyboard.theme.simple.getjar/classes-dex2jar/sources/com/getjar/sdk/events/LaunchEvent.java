package com.getjar.sdk.events;

public class LaunchEvent extends Event {
    private long usageTime;

    public long getUsageTime() {
        return this.usageTime;
    }

    public void setUsageTime(long j) {
        this.usageTime = j;
    }
}

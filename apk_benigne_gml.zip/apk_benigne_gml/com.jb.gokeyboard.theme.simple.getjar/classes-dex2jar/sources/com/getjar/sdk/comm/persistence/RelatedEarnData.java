package com.getjar.sdk.comm.persistence;

import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;

public class RelatedEarnData implements Serializable {
    private static final long serialVersionUID = -7091798013980336693L;
    private String _itemId;
    private HashMap<String, String> _itemMetadata;
    private String _packageName;
    private HashMap<String, String> _trackingMetadata;

    public RelatedEarnData() {
    }

    public RelatedEarnData(String str, String str2, HashMap<String, String> hashMap, HashMap<String, String> hashMap2) {
        this._itemId = str;
        this._packageName = str2;
        this._itemMetadata = hashMap;
        this._trackingMetadata = hashMap2;
        validateObjectState();
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        this._itemId = objectInputStream.readUTF();
        this._packageName = objectInputStream.readUTF();
        this._itemMetadata = (HashMap) objectInputStream.readObject();
        this._trackingMetadata = (HashMap) objectInputStream.readObject();
    }

    private void validateObjectState() {
        if (StringUtility.isNullOrEmpty(this._itemId)) {
            throw new IllegalStateException("'itemId' can not be NULL or empty");
        } else if (StringUtility.isNullOrEmpty(this._packageName)) {
            throw new IllegalStateException("'packageName' can not be NULL or empty");
        } else if (this._itemMetadata == null || this._itemMetadata.size() <= 0) {
            throw new IllegalStateException("'itemMetadata' can not be NULL or empty");
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeUTF(this._itemId);
        objectOutputStream.writeUTF(this._packageName);
        objectOutputStream.writeObject(this._itemMetadata);
        objectOutputStream.writeObject(this._trackingMetadata);
    }

    public String getItemId() {
        return this._itemId;
    }

    public HashMap<String, String> getItemMetadata() {
        return this._itemMetadata;
    }

    public String getPackageName() {
        return this._packageName;
    }

    public HashMap<String, String> getTrackingMetadata() {
        return this._trackingMetadata;
    }
}

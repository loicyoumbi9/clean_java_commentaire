package com.getjar.sdk.comm;

import java.util.Comparator;

public class OperationPriorityComparator implements Comparator<Operation> {
    private static OperationPriorityComparator _Instance = null;

    private OperationPriorityComparator() {
    }

    public static OperationPriorityComparator getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    private static void makeTheInstance() {
        synchronized (OperationPriorityComparator.class) {
            try {
                if (_Instance == null) {
                    _Instance = new OperationPriorityComparator();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public int compare(Operation operation, Operation operation2) {
        if (operation == null) {
            throw new IllegalArgumentException("'lhs' can not be NULL");
        } else if (operation2 == null) {
            throw new IllegalArgumentException("'rhs' can not be NULL");
        } else {
            int i = 0;
            if (operation.getPriority() < operation2.getPriority()) {
                i = -1;
            } else if (operation.getPriority() > operation2.getPriority()) {
                i = 1;
            }
            if (i == 0) {
                if (operation.getCreatedTimestamp() > operation2.getCreatedTimestamp()) {
                    return -1;
                }
                if (operation.getCreatedTimestamp() < operation2.getCreatedTimestamp()) {
                    return 1;
                }
            }
            return i;
        }
    }
}

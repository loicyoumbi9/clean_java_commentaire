package com.getjar.sdk.rewards;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.ResultReceiver;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import com.getjar.sdk.Product;
import com.getjar.sdk.comm.CallbackInterface;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.CommManager;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.comm.TransactionManager;
import com.getjar.sdk.comm.UserAgentValuesManager;
import com.getjar.sdk.rewards.GetJarWebViewActivity;
import com.getjar.sdk.rewards.WebSettingsEx;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetJarJavaScriptInterface {
    private long _lastReload = 0;
    /* access modifiers changed from: private */
    public GetJarWebViewActivity _parentActivity = null;
    private Map<String, GetJarWebViewActivity.ProductWithClientTransactionID> _productIdToProduct;
    /* access modifiers changed from: private */
    public Bundle failBundle;
    private boolean isExist = false;
    /* access modifiers changed from: private */
    public Logger log = new Logger(this);
    /* access modifiers changed from: private */
    public CommContext mCommContext;
    /* access modifiers changed from: private */
    public Handler mHandler = new Handler() {
        /* class com.getjar.sdk.rewards.GetJarJavaScriptInterface.AnonymousClass1 */

        public void handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    GetJarJavaScriptInterface.this.purchaseSuccess(GetJarJavaScriptInterface.this.successBundle);
                    return;
                case 1:
                    GetJarJavaScriptInterface.this.purchaseFail(GetJarJavaScriptInterface.this.failBundle);
                    return;
                default:
                    return;
            }
        }
    };
    private ResultReceiver mMessenger;
    /* access modifiers changed from: private */
    public Bundle successBundle;

    private class PurchaseCallback implements CallbackInterface {
        private GetJarWebViewActivity.ProductWithClientTransactionID _offer = null;

        protected PurchaseCallback(GetJarWebViewActivity.ProductWithClientTransactionID productWithClientTransactionID) {
            this._offer = productWithClientTransactionID;
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                Bundle bundle = new Bundle();
                bundle.putString(Constants.APP_ID, this._offer.getProduct().getProductId());
                bundle.putString(Constants.TRANSACTION_ID, this._offer.getClientTransactionId());
                bundle.putLong(Constants.APP_COST, this._offer.getProduct().getAmount());
                bundle.putString("name", this._offer.getProduct().getProductName());
                bundle.putString(Constants.RequestInstallSubState.KEY(), Utility.getResponseSubstate(exc, Constants.RequestInstallSubState.NONE.toString()));
                GetJarJavaScriptInterface.this.log.debug(String.format("PurchaseCallback: Request %1$s on CommContext %2$s resulted in a call to serviceRequestFailed(). %3$s", str, commContext == null ? "" : commContext.getCommContextId(), exc == null ? "" : exc.getMessage()));
                if (exc != null) {
                    GetJarJavaScriptInterface.this.log.debug(exc.toString());
                }
                Bundle unused = GetJarJavaScriptInterface.this.failBundle = bundle;
                Message message = new Message();
                message.what = 1;
                GetJarJavaScriptInterface.this.mHandler.sendMessage(message);
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                } catch (Exception e) {
                    e.printStackTrace();
                    commContext.addException(e);
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                commContext.addException(e2);
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                } catch (Exception e3) {
                    e3.printStackTrace();
                    commContext.addException(e3);
                }
            } catch (Throwable th) {
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                } catch (Exception e4) {
                    e4.printStackTrace();
                    commContext.addException(e4);
                }
                throw th;
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            try {
                GetJarJavaScriptInterface.this._parentActivity.setCurrentPurchaseClientTransactionId(null);
                GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                Bundle bundle = new Bundle();
                bundle.putString(Constants.APP_ID, this._offer.getProduct().getProductId());
                bundle.putString(Constants.TRANSACTION_ID, this._offer.getClientTransactionId());
                bundle.putLong(Constants.APP_COST, this._offer.getProduct().getAmount());
                bundle.putString("name", this._offer.getProduct().getProductName());
                bundle.putString(Constants.RequestInstallSubState.KEY(), Utility.getResponseSubstate(result, Constants.RequestInstallSubState.NONE.toString()));
                GetJarJavaScriptInterface.this.log.debug(String.format("PurchaseCallback: Request %1$s on CommContext %2$s resulted in a call to serviceRequestSucceeded()", str, commContext == null ? "" : commContext.getCommContextId()));
                Bundle unused = GetJarJavaScriptInterface.this.successBundle = bundle;
                Message message = new Message();
                message.what = 0;
                GetJarJavaScriptInterface.this.mHandler.sendMessage(message);
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                    RewardUtility.saveSalesRecord(commContext.getApplicationContext(), this._offer.getProduct().getProductId(), this._offer.getClientTransactionId());
                } catch (Exception e) {
                    e.printStackTrace();
                    commContext.addException(e);
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                commContext.addException(e2);
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                    RewardUtility.saveSalesRecord(commContext.getApplicationContext(), this._offer.getProduct().getProductId(), this._offer.getClientTransactionId());
                } catch (Exception e3) {
                    e3.printStackTrace();
                    commContext.addException(e3);
                }
            } catch (Throwable th) {
                try {
                    GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
                    RewardUtility.saveSalesRecord(commContext.getApplicationContext(), this._offer.getProduct().getProductId(), this._offer.getClientTransactionId());
                } catch (Exception e4) {
                    e4.printStackTrace();
                    commContext.addException(e4);
                }
                throw th;
            }
        }
    }

    private class ReauthThread implements Runnable {
        private ReauthThread() {
        }

        public void run() {
            try {
                GetJarJavaScriptInterface.this._parentActivity.waitForAuthorization();
                CommManager.reauthorizeContext(GetJarJavaScriptInterface.this.mCommContext);
            } catch (Exception e) {
                GetJarJavaScriptInterface.this.log.error(e.toString());
            } finally {
                GetJarJavaScriptInterface.this._parentActivity.waitDialogHide();
            }
        }
    }

    public GetJarJavaScriptInterface(CommContext commContext, GetJarWebViewActivity getJarWebViewActivity, ResultReceiver resultReceiver, List<GetJarWebViewActivity.ProductWithClientTransactionID> list) {
        if (commContext == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        } else if (getJarWebViewActivity == null) {
            throw new IllegalArgumentException("Must have a valid parent Activity.");
        } else if (list == null || list.size() <= 0) {
            throw new IllegalArgumentException("Must provide a non-empty list of offers.");
        } else {
            this.mCommContext = commContext;
            this._parentActivity = getJarWebViewActivity;
            this._productIdToProduct = new HashMap();
            for (GetJarWebViewActivity.ProductWithClientTransactionID productWithClientTransactionID : list) {
                this._productIdToProduct.put(productWithClientTransactionID.getProduct().getProductId(), productWithClientTransactionID);
            }
            this.isExist = false;
            this.mMessenger = resultReceiver;
        }
    }

    private void _requestInstall(String str, String str2, String str3, String str4, String str5, Constants.RequestInstallType requestInstallType) {
        this.log.debug("_requestInstall() -- thePackageName=" + str);
        this.log.debug("_requestInstall() -- downloadUrl:" + str3);
        this.log.debug("_requestInstall() -- FriendlyName=" + str2);
        this.log.debug("_requestInstall() -- theMetaData=" + str4);
        this.log.debug("_requestInstall() -- theTrackingData=" + str5);
        this.log.debug("_requestInstall() -- theInstallType=" + requestInstallType.toString());
        if (StringUtility.isNullOrEmpty(str4)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty app metadata.");
        } else if (StringUtility.isNullOrEmpty(str5)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty tracking metadata.");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty friendly name.");
        } else if (StringUtility.isNullOrEmpty(str3)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty download Url.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty package name.");
        } else {
            try {
                Context applicationContext = this.mCommContext.getApplicationContext();
                this.log.debug("....is the app in the shared Preference:" + RewardUtility.isPreInstallRewardApplication(applicationContext, str));
                HashMap<String, String> jsonArrayStringToMap = Utility.jsonArrayStringToMap(str5);
                if (jsonArrayStringToMap.size() > 0) {
                    jsonArrayStringToMap.put(Constants.META_CLIENT_APP_TOKEN, Utility.getApplicationKey(applicationContext));
                    jsonArrayStringToMap.put(Constants.META_LEGACY_UA, UserAgentValuesManager.getInstance().getWebKitUserAgent(applicationContext));
                    JSONObject jSONObject = new JSONObject(jsonArrayStringToMap);
                    if (jSONObject.length() > 0) {
                        JSONArray jSONArray = new JSONArray();
                        jSONArray.put(jSONObject);
                        str5 = jSONArray.toString();
                    }
                }
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.APPDATA_TIMESTAMP_SUFFIX, Long.toString(new Date().getTime()));
                this.log.debug("current timestamp:" + RewardUtility.getDefaultSharedPrefsMap(applicationContext).get(str + Constants.APPDATA_TIMESTAMP_SUFFIX));
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.APPDATA_FRIENDLY_SUFFIX, str2);
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.APPDATA_SUFFIX, str4);
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.TRACKING_SUFFIX, str5);
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.RequestInstallType.SUFFIX_NOTIFICATION, Constants.RequestInstallState.UNKNOWN.toString());
                switch (requestInstallType) {
                    case EARN:
                        RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.RequestInstallType.SUFFIX_DEFAULT, Constants.RequestInstallType.EARN.toString());
                        break;
                    case PURCHASE:
                        RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.RequestInstallType.SUFFIX_DEFAULT, Constants.RequestInstallType.PURCHASE.toString());
                        break;
                }
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.RequestInstallType.SUFFIX_STATE, Constants.RequestInstallState.UNKNOWN.toString());
                RewardUtility.savePreInstallRewardApplicationMetadata(applicationContext, str + Constants.RequestInstallType.SUFFIX_SUBSTATE, Constants.RequestInstallSubState.NONE.toString());
                Utility.savePackageNameInstallEntry(applicationContext, str);
                Map<String, ?> all = applicationContext.getSharedPreferences(RewardUtility._PreferencesInstalledAppFileName, 0).getAll();
                this.log.debug("Number of entry:" + all.size());
                Iterator<Map.Entry<String, ?>> it = all.entrySet().iterator();
                while (it.hasNext()) {
                    this.log.debug("SharedPreference Entry name:" + it.next().getKey());
                }
                this.log.debug("....is the app in the shared Preference:" + RewardUtility.isPreInstallRewardApplication(applicationContext, str));
                this.log.debug("downloadURl:" + str3);
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str3));
                intent.addFlags(268435456);
                intent.addFlags(134217728);
                intent.addFlags(1073741824);
                applicationContext.startActivity(intent);
            } catch (Exception e) {
                this.log.Log(e);
            }
        }
    }

    private Object getZoomDensity(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("zoomDensityString cannot be empty or null");
        } else if (str.equals("FAR")) {
            return WebSettingsEx.ZoomDensity.FAR;
        } else {
            if (str.equals("MEDIUM")) {
                return WebSettingsEx.ZoomDensity.MEDIUM;
            }
            if (str.equals("CLOSE")) {
                return WebSettingsEx.ZoomDensity.CLOSE;
            }
            return null;
        }
    }

    private void launch(String str) {
        if (!this.isExist) {
            try {
                this.log.debug("package name:" + str);
                new Intent("android.intent.action.MAIN");
                Intent launchIntentForPackage = this.mCommContext.getApplicationContext().getPackageManager().getLaunchIntentForPackage(str);
                launchIntentForPackage.addCategory("android.intent.category.LAUNCHER");
                launchIntentForPackage.setFlags(270532608);
                this.mCommContext.getApplicationContext().startActivity(launchIntentForPackage);
            } catch (Exception e) {
                this.log.Log(e);
            }
        }
    }

    /* access modifiers changed from: private */
    public void purchaseFail(Bundle bundle) {
        this.mMessenger.send(6, bundle);
    }

    /* access modifiers changed from: private */
    public void purchaseSuccess(Bundle bundle) {
        this.mMessenger.send(5, bundle);
    }

    private void reloadViewInternal(boolean z, boolean z2) {
        this.log.debug(String.format("reloadView called from thread.id:%1$d thread.name:%2$s", Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getName()));
        if (!this.isExist) {
            this.log.debug("reloadView past isExist");
            if (z) {
                long currentTimeMillis = System.currentTimeMillis() - this._lastReload;
                this._lastReload = System.currentTimeMillis();
                if (!z2 || currentTimeMillis >= 60000) {
                    this.log.debug("reloadView is re-authorizing");
                    try {
                        new Thread(new ReauthThread()).start();
                    } catch (Exception e) {
                        this.log.error(e.toString());
                    }
                } else {
                    this.log.error(String.format("A re-authorization/reload attempt was made %1$d milliseconds ago, skipping this attempt request", Long.valueOf(currentTimeMillis)));
                    this.mMessenger.send(3, null);
                }
            } else {
                this.mMessenger.send(10, null);
            }
        }
    }

    public void closeView() {
        this.log.debug("closeView is called");
        this.isExist = true;
        this.mMessenger.send(0, null);
    }

    public void configureWebView(Boolean bool, Boolean bool2, String str) {
        if (this._parentActivity == null) {
            Log.i(Constants.TAG, "getDisplayMetrics() -- _parentActivity cannot be null.");
            return;
        }
        WebSettings settings = ((WebView) ((FrameLayout) this._parentActivity.findViewById(16908290)).getChildAt(0)).getSettings();
        if (str != null) {
            Object zoomDensity = getZoomDensity(str);
            if (zoomDensity == null) {
                throw new IllegalArgumentException("zoomDensity should be either FAR, MEDIUM or CLOSE");
            }
            WebSettingsEx.setDefaultZoom(settings, zoomDensity);
        }
        if (bool != null) {
            settings.setBuiltInZoomControls(bool.booleanValue());
        }
        if (bool2 != null) {
            settings.setSupportZoom(bool2.booleanValue());
        }
    }

    public String getAppState(String str) {
        Constants.AppState appState = Constants.AppState.UNINSTALLED;
        try {
            this.mCommContext.getApplicationContext().getPackageManager().getApplicationInfo(str, 0);
            appState = Constants.AppState.INSTALLED;
        } catch (PackageManager.NameNotFoundException e) {
        }
        switch (appState) {
            case INSTALLED:
                return "INSTALLED";
            default:
                return "UNINSTALLED";
        }
    }

    public String getDisplayMetrics() {
        JSONObject jSONObject = new JSONObject();
        if (this._parentActivity == null) {
            Log.i(Constants.TAG, "getDisplayMetrics() -- _parentActivity cannot be null.");
            return jSONObject.toString();
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this._parentActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        DecimalFormat decimalFormat = new DecimalFormat("##.###");
        JSONObject jSONObject2 = new JSONObject();
        JSONObject jSONObject3 = new JSONObject();
        JSONObject jSONObject4 = new JSONObject();
        JSONObject jSONObject5 = new JSONObject();
        Rect rect = new Rect();
        Window window = this._parentActivity.getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rect);
        int top = window.findViewById(16908290).getTop();
        try {
            jSONObject2.put("width", displayMetrics.widthPixels);
            jSONObject2.put("height", displayMetrics.heightPixels);
        } catch (JSONException e) {
            this.log.debug("getDisplayMetrics() -- Error getting screen resolution " + e.getLocalizedMessage());
        }
        try {
            jSONObject4.put("x", decimalFormat.format((double) displayMetrics.xdpi));
            jSONObject4.put("y", decimalFormat.format((double) displayMetrics.ydpi));
        } catch (JSONException e2) {
            this.log.debug("getDisplayMetrics() -- Error getting screen dpi " + e2.getLocalizedMessage());
        }
        try {
            jSONObject3.put("height", displayMetrics.heightPixels - top);
            jSONObject3.put("width", displayMetrics.widthPixels);
        } catch (JSONException e3) {
            this.log.debug("getDisplayMetrics() -- Error getting screen's actual usable resolution " + e3.getLocalizedMessage());
        }
        try {
            jSONObject5.put("height", decimalFormat.format((double) (((float) displayMetrics.heightPixels) / displayMetrics.ydpi)));
            jSONObject5.put("width", decimalFormat.format((double) (((float) displayMetrics.widthPixels) / displayMetrics.xdpi)));
        } catch (Exception e4) {
            this.log.debug("getDisplayMetrics() -- Error getting screen size " + e4.getLocalizedMessage());
        }
        try {
            jSONObject.put("screen_dpi", jSONObject4);
            jSONObject.put("screen_resolution", jSONObject2);
            jSONObject.put("available_resolution", jSONObject3);
            jSONObject.put("screen_size", jSONObject5);
        } catch (JSONException e5) {
            this.log.debug("getDisplayMetrics() -- Error getting all json objects together " + e5.getLocalizedMessage());
        }
        return jSONObject.toString();
    }

    public String getUnmanagedOffer(String str) {
        JSONObject jSONObject;
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty product ID.");
        }
        JSONObject jSONObject2 = new JSONObject();
        Product product = this._productIdToProduct.get(str).getProduct();
        if (product != null) {
            try {
                jSONObject = product.toJSONObject();
            } catch (JSONException e) {
                this.log.error("productId=" + str + ": " + e);
                jSONObject = jSONObject2;
            }
        } else {
            jSONObject = jSONObject2;
        }
        return jSONObject.toString();
    }

    public String getUnmanagedOffers() {
        JSONArray jSONArray = new JSONArray();
        for (Map.Entry<String, GetJarWebViewActivity.ProductWithClientTransactionID> entry : this._productIdToProduct.entrySet()) {
            try {
                jSONArray.put(entry.getValue().getProduct().toJSONObject());
            } catch (JSONException e) {
                this.log.error("productId=" + entry.getValue().getProduct().getProductId() + ": " + e);
            }
        }
        return jSONArray.toString();
    }

    public void launchGetJarRewardsApp() {
        if (!this.isExist) {
            launch(Constants.GREENJAR_PACKAGE);
        }
    }

    public void purchaseUnmanagedOffer(String str, String str2) {
        if (!this.isExist) {
            this.log.debug("purchaseUnmanagedOffer() -- theProductId=" + str);
            GetJarWebViewActivity.ProductWithClientTransactionID productWithClientTransactionID = this._productIdToProduct.get(str);
            if (productWithClientTransactionID != null) {
                this._parentActivity.waitDialogShow();
                try {
                    PurchaseCallback purchaseCallback = new PurchaseCallback(productWithClientTransactionID);
                    HashMap<String, String> jsonArrayStringToMap = Utility.jsonArrayStringToMap(str2);
                    jsonArrayStringToMap.put(Constants.META_CLIENT_APP_TOKEN, Utility.getApplicationKey(this.mCommContext.getApplicationContext()));
                    jsonArrayStringToMap.put(Constants.TRACKING_USER_ACCESS_ID, this.mCommContext.getUserAccessId());
                    jsonArrayStringToMap.put(Constants.META_LEGACY_UA, UserAgentValuesManager.getInstance().getWebKitUserAgent(this.mCommContext.getApplicationContext()));
                    if (jsonArrayStringToMap.size() > 0) {
                        Log.v(Constants.TAG, String.format("Making a purchase with client transaction ID: '%1$s' [thread:%2$d]", productWithClientTransactionID.getClientTransactionId(), Long.valueOf(Thread.currentThread().getId())));
                        TransactionManager transactionManager = new TransactionManager(this.mCommContext.getApplicationContext());
                        this._parentActivity.setCurrentPurchaseClientTransactionId(productWithClientTransactionID.getClientTransactionId());
                        transactionManager.startPurchaseTransaction(productWithClientTransactionID.getClientTransactionId(), this.mCommContext, purchaseCallback, productWithClientTransactionID.getProduct().getProductId(), productWithClientTransactionID.getProduct().getProductName(), productWithClientTransactionID.getProduct().getProductDescription(), Integer.valueOf((int) productWithClientTransactionID.getProduct().getAmount()), jsonArrayStringToMap);
                        return;
                    }
                    this.log.error("ERROR: unable to send purchaseOffer transaction, empty tracking data.");
                    this._parentActivity.waitDialogHide();
                } catch (Exception e) {
                    Log.e(Constants.TAG, "purchaseUnmanagedOffer() failed", e);
                    this._parentActivity.waitDialogHide();
                }
            } else {
                this.log.debug("purchaseUnmanagedOffer() -- offer with theProductId=" + str + " was not found..");
            }
        }
    }

    public void reloadView(boolean z) {
        this.log.debug(String.format("reloadView(%1$s)", Boolean.toString(z)));
        reloadViewInternal(z, true);
    }

    public void reloadViewNoSafety(boolean z) {
        this.log.debug(String.format("reloadViewNoSafety(%1$s)", Boolean.toString(z)));
        reloadViewInternal(z, false);
    }

    public void requestEarnInstall(String str, String str2, String str3, String str4, String str5) {
        if (!this.isExist) {
            try {
                _requestInstall(str, str2, str3, str4, str5, Constants.RequestInstallType.EARN);
            } catch (Exception e) {
                try {
                    Log.e(Constants.TAG, String.format("requestEarnInstall() failed [thread:%1$d]", Long.valueOf(Thread.currentThread().getId())), e);
                    this._parentActivity.unableToDownloadDialogShow();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    public void requestPurchaseInstall(String str, String str2, String str3, String str4, String str5) {
        if (!this.isExist) {
            try {
                _requestInstall(str, str2, str3, str4, str5, Constants.RequestInstallType.PURCHASE);
            } catch (Exception e) {
                try {
                    Log.e(Constants.TAG, String.format("requestPurchaseInstall() failed [thread:%1$d]", Long.valueOf(Thread.currentThread().getId())), e);
                    this._parentActivity.unableToDownloadDialogShow();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    public void setAuthToken(String str) {
        if (this.isExist) {
            return;
        }
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty auth token.");
        }
        this.log.debug("setAuthToken() -- theAuthToken=" + str);
        this.mCommContext.setAuthToken(str);
        Bundle bundle = new Bundle();
        bundle.putString(Constants.AUTH_TOKEN_KEY, str);
        this.mMessenger.send(9, bundle);
    }
}

package com.getjar.sdk.rewards;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.ResultReceiver;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.CookieSyncManager;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getjar.sdk.Product;
import com.getjar.sdk.comm.CallbackInterface;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.CommFailureCallbackInterface;
import com.getjar.sdk.comm.CommManager;
import com.getjar.sdk.comm.GetJarConfig;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.comm.StatisticsTracker;
import com.getjar.sdk.comm.TransactionManager;
import com.getjar.sdk.response.CloseResponse;
import com.getjar.sdk.rewards.WebSettingsEx;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

public class GetJarWebViewActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static String Language = Constants.DEFAULT_LANGUAGE;
    public static ErrorSource sErrorSource;
    public static Object waitObject = new Object();
    private CommFailureCallback _commFailureCallback = new CommFailureCallback();
    private String _currentPurchaseClientTransactionId = null;
    private ProgressDialog _pleaseWaitDialog = null;
    private AlertDialog _unableToDownloadDialog = null;
    private boolean isForeground = false;
    /* access modifiers changed from: private */
    public Logger log = new Logger(this);
    /* access modifiers changed from: private */
    public boolean mCatchByMonitor = false;
    private CommContext mCommContext;
    ResultReceiver mDismissReceiver = new ResultReceiver(null) {
        /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass2 */

        /* access modifiers changed from: protected */
        public void onReceiveResult(int i, Bundle bundle) {
            GetJarWebViewActivity.this.log.debug("onReceiveResult:" + i);
            super.onReceiveResult(i, bundle);
            switch (i) {
                case 1:
                    GetJarWebViewActivity.this.mHandler.sendEmptyMessage(1);
                    return;
                case 2:
                    GetJarWebViewActivity.this.mHandler.sendEmptyMessage(2);
                    return;
                default:
                    return;
            }
        }
    };
    Handler mHandler = new Handler() {
        /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass3 */

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    GetJarWebViewActivity.this.dismiss();
                    return;
                case 2:
                    GetJarWebViewActivity.loadErrorPage(ErrorType.NETWORK, "", GetJarWebViewActivity.this.mWebView);
                    return;
                default:
                    return;
            }
        }
    };
    private GetJarJavaScriptInterface mJavaScriptInterface = null;
    private ArrayList<ProductWithClientTransactionID> mOffers = new ArrayList<>();
    private BroadcastReceiver mPackageReceiver = new BroadcastReceiver() {
        /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass4 */

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            GetJarWebViewActivity.this.log.debug(String.format("** PackageReceiver: %1$s [%2$s]", action, Utility.getPackageNameFromBroadcastIntent(intent)));
            if ("android.intent.action.PACKAGE_ADDED".equals(action)) {
                boolean unused = GetJarWebViewActivity.this.mCatchByMonitor = true;
                new Thread(new newPackageReceived(GetJarWebViewActivity.this.mReceiver)).start();
            }
        }
    };
    ResultReceiver mReceiver = new ResultReceiver(null) {
        /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass1 */

        /* access modifiers changed from: protected */
        public void onReceiveResult(int i, Bundle bundle) {
            GetJarWebViewActivity.this.log.debug("onReceiveResult:" + i);
            super.onReceiveResult(i, bundle);
            switch (i) {
                case 0:
                    GetJarWebViewActivity.this.close();
                    return;
                case 1:
                case 2:
                case 7:
                case 8:
                default:
                    return;
                case 3:
                    GetJarWebViewActivity.this.serviceFail(bundle);
                    return;
                case 4:
                    boolean unused = GetJarWebViewActivity.this.mCatchByMonitor = false;
                    GetJarWebViewActivity.this.reload();
                    return;
                case 5:
                    GetJarWebViewActivity.this.purchaseSuccess(bundle);
                    return;
                case 6:
                    GetJarWebViewActivity.this.purchaseFail(bundle);
                    return;
                case 9:
                    GetJarWebViewActivity.this.setAuthToken(bundle);
                    return;
                case 10:
                    GetJarWebViewActivity.this.simpleReload();
                    return;
            }
        }
    };
    private String mUrl = null;
    private String mUserAgent = "";
    /* access modifiers changed from: private */
    public WebView mWebView = null;

    private class CommFailureCallback implements CommFailureCallbackInterface {
        private CommFailureCallback() {
        }

        @Override // com.getjar.sdk.comm.CommFailureCallbackInterface
        public void authorizationFailure(String str) {
            GetJarWebViewActivity.this.waitDialogHide();
            GetJarWebViewActivity.loadErrorPage(ErrorType.AUTH, str, GetJarWebViewActivity.this.mWebView);
        }

        @Override // com.getjar.sdk.comm.CommFailureCallbackInterface
        public void networkFailure() {
            GetJarWebViewActivity.this.waitDialogHide();
            GetJarWebViewActivity.loadErrorPage(ErrorType.NETWORK, "", GetJarWebViewActivity.this.mWebView);
        }

        @Override // com.getjar.sdk.comm.CommFailureCallbackInterface
        public void serviceFailure(Result result) {
            GetJarWebViewActivity.this.waitDialogHide();
            if (result.getResponseCode() >= 500 && result.getResponseCode() < 600) {
                GetJarWebViewActivity.loadErrorPage(ErrorType.SERVICE, Utility.getResponseSubstateFromErrorResult(result, ""), GetJarWebViewActivity.this.mWebView);
            }
        }
    }

    private enum DialogType {
        WAIT,
        UNABLE_TO_DOWNLOAD
    }

    public class ErrorSource {
        public ErrorType mErrorType;
        public String mSubCode;

        public ErrorSource(ErrorType errorType, String str) {
            this.mErrorType = errorType;
            this.mSubCode = str;
        }
    }

    public enum ErrorType {
        AUTH,
        SERVICE,
        NETWORK
    }

    protected class ProductWithClientTransactionID {
        private String _clientTransactionId = null;
        private Product _product = null;

        protected ProductWithClientTransactionID(Product product) {
            this._product = product;
            this._clientTransactionId = UUID.randomUUID().toString();
            Log.v(Constants.TAG, String.format("Generated a new client transaction ID: '%1$s' [thread:%2$d]", this._clientTransactionId, Long.valueOf(Thread.currentThread().getId())));
        }

        public String getClientTransactionId() {
            return this._clientTransactionId;
        }

        public Product getProduct() {
            return this._product;
        }
    }

    private class newPackageReceived implements Runnable {
        ResultReceiver mReceiver;

        public newPackageReceived(ResultReceiver resultReceiver) {
            this.mReceiver = resultReceiver;
        }

        public void run() {
            try {
                GetJarWebViewActivity.this.log.debug("waiting...");
                Thread.sleep(10000);
                GetJarWebViewActivity.this.log.debug("finish waiting...");
                this.mReceiver.send(4, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private class waitForAuth implements Runnable {
        CommContext mContext;
        ResultReceiver mReceiver;

        public waitForAuth(CommContext commContext, ResultReceiver resultReceiver) {
            this.mContext = commContext;
            this.mReceiver = resultReceiver;
        }

        public void run() {
            try {
                this.mContext.waitForAuthorization();
                this.mContext.waitForUserAccess();
                this.mContext.waitForUserDevice();
                this.mReceiver.send(1, null);
                GetJarWebViewActivity.this.waitDialogHide();
            } catch (Exception e) {
                try {
                    e.printStackTrace();
                    for (Throwable th : this.mContext.getExceptions().values()) {
                        th.printStackTrace();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                } catch (Throwable th2) {
                    GetJarWebViewActivity.this.waitDialogHide();
                    throw th2;
                }
                try {
                    this.mReceiver.send(2, null);
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
                GetJarWebViewActivity.this.waitDialogHide();
            }
        }
    }

    private void RegisterPackageReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        registerReceiver(this.mPackageReceiver, new IntentFilter(intentFilter));
    }

    private void UnRegisterPackageReceiver() {
        unregisterReceiver(this.mPackageReceiver);
    }

    private boolean checkIfAlreadyShowingError() {
        return this.mWebView != null && Constants.DEFAULT_ERROR_PAGE.equalsIgnoreCase(this.mWebView.getUrl());
    }

    /* access modifiers changed from: private */
    public void close() {
        try {
            waitDialogHide();
            this.mCommContext.postResponse(new CloseResponse());
            final String currentPurchaseClientTransactionId = getCurrentPurchaseClientTransactionId();
            if (currentPurchaseClientTransactionId != null) {
                Log.d(Constants.TAG, String.format("Cancelling clientTransactionId %1$s", currentPurchaseClientTransactionId));
                new TransactionManager(getApplicationContext()).cancelPurchaseTransaction(currentPurchaseClientTransactionId, this.mCommContext, new CallbackInterface() {
                    /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass6 */

                    @Override // com.getjar.sdk.comm.CallbackInterface
                    public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
                        Log.w(Constants.TAG, String.format("CANCEL failed [clientTransactionId: %1$s]", currentPurchaseClientTransactionId));
                    }

                    @Override // com.getjar.sdk.comm.CallbackInterface
                    public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
                    }

                    @Override // com.getjar.sdk.comm.CallbackInterface
                    public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
                        Log.d(Constants.TAG, String.format("CANCEL succeeded [clientTransactionId: %1$s]", currentPurchaseClientTransactionId));
                    }
                });
            }
        } finally {
            finish();
        }
    }

    private void createPleaseWaitProgressDialog() {
        if (this._pleaseWaitDialog == null) {
            this._pleaseWaitDialog = new ProgressDialog(this);
            this._pleaseWaitDialog.setProgressStyle(0);
            this._pleaseWaitDialog.setMessage(Constants.WAIT_DIALOG_MSG);
            this._pleaseWaitDialog.setIndeterminate(true);
            this._pleaseWaitDialog.setCancelable(false);
            this._pleaseWaitDialog.setButton(-2, "Cancel", new DialogInterface.OnClickListener() {
                /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass8 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    Log.d(Constants.TAG, "User clicked CANCEL");
                    GetJarWebViewActivity.this.close();
                }
            });
        }
    }

    private void createUnableToDownloadDialog() {
        if (this._unableToDownloadDialog == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Unable to download at this time. Please try again later.").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass9 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            this._unableToDownloadDialog = builder.create();
            this.log.debug("Finished creating 'unable to download' dialog");
        }
    }

    private void dialogHide(final DialogType dialogType) {
        try {
            if (!Utility.isCurrentThreadTheUIThread()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass11 */

                    public void run() {
                        try {
                            GetJarWebViewActivity.this.dialogHideInternal(dialogType);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            } else {
                dialogHideInternal(dialogType);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    public void dialogHideInternal(DialogType dialogType) {
        if (dialogType == null) {
            try {
                throw new IllegalArgumentException("'dialogType' can not be NULL");
            } catch (Exception e) {
            }
        } else if (DialogType.WAIT.equals(dialogType)) {
            if (this._pleaseWaitDialog != null && this._pleaseWaitDialog.isShowing()) {
                this._pleaseWaitDialog.dismiss();
            }
        } else if (!DialogType.UNABLE_TO_DOWNLOAD.equals(dialogType)) {
            throw new IllegalStateException(String.format("Unrecognized dilaog type requested: %1$s", dialogType.name()));
        } else if (this._unableToDownloadDialog != null && this._unableToDownloadDialog.isShowing()) {
            this._unableToDownloadDialog.dismiss();
        }
    }

    private void dialogShow(final DialogType dialogType) {
        try {
            if (!this.isForeground) {
                Log.d(Constants.TAG, "Skipping dialog show because Activity is not in the foreground");
            } else if (!Utility.isCurrentThreadTheUIThread()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass10 */

                    public void run() {
                        try {
                            GetJarWebViewActivity.this.dialogShowInternal(dialogType);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            } else {
                dialogShowInternal(dialogType);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    public void dialogShowInternal(DialogType dialogType) {
        if (dialogType == null) {
            try {
                throw new IllegalArgumentException("'dialogType' can not be NULL");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (DialogType.WAIT.equals(dialogType)) {
            createPleaseWaitProgressDialog();
            if (!this._pleaseWaitDialog.isShowing()) {
                this._pleaseWaitDialog.show();
            }
        } else if (DialogType.UNABLE_TO_DOWNLOAD.equals(dialogType)) {
            createUnableToDownloadDialog();
            if (!this._unableToDownloadDialog.isShowing()) {
                this._unableToDownloadDialog.show();
            }
        } else {
            throw new IllegalStateException(String.format("Unrecognized dilaog type requested: %1$s", dialogType.name()));
        }
    }

    private String filterUrl(String str) {
        String str2;
        try {
            URL url = new URL(str);
            String query = url.getQuery();
            String format = String.format("%1$s://%2$s%3$s", url.getProtocol(), url.getAuthority(), url.getPath());
            this.log.debug("full url:" + format);
            this.log.debug("path " + url.getPath());
            this.log.debug("host:" + url.getHost());
            this.log.debug("query:" + query);
            if (!StringUtility.isNullOrEmpty(query)) {
                String[] split = query.split(Utility.QUERY_APPENDIX);
                String str3 = "";
                for (String str4 : split) {
                    String[] split2 = str4.split("=");
                    if (split2.length >= 2 && !split2[0].equalsIgnoreCase("device_filter") && !split2[0].equalsIgnoreCase(Constants.AUTH_TOKEN_KEY)) {
                        str3 = str3.length() > 0 ? str3 + String.format("&%1$s=%2$s", split2[0], split2[1]) : str3 + String.format("%1$s=%2$s", split2[0], split2[1]);
                    }
                }
                this.log.debug("filtered query:" + str3);
                str2 = format + Utility.QUERY_START + str3;
            } else {
                str2 = format;
            }
            String ref = url.getRef();
            return !StringUtility.isNullOrEmpty(ref) ? str2 + "#" + ref : str2;
        } catch (MalformedURLException e) {
            this.log.Log(e);
            return null;
        }
    }

    private String getAuthToken(String str) {
        int i = 0;
        try {
            this.log.debug("url:" + str);
            String query = new URL(str).getQuery();
            this.log.debug("query:" + query);
            if (!StringUtility.isNullOrEmpty(query)) {
                String[] split = query.split(Utility.QUERY_APPENDIX);
                int length = split.length;
                while (i < length) {
                    String[] split2 = split[i].split("=");
                    if (split2.length >= 2 && split2[0].equalsIgnoreCase(Constants.AUTH_TOKEN_KEY)) {
                        try {
                            String decode = URLDecoder.decode(split2[1], Constants.ENCODING_CHARSET);
                            this.log.debug("Auth Token:" + decode);
                            return decode;
                        } catch (Exception e) {
                            return null;
                        }
                    } else {
                        i++;
                    }
                }
            }
            return null;
        } catch (MalformedURLException e2) {
            this.log.Log(e2);
            return null;
        }
    }

    private String getHomeUrl() {
        Log.d(Constants.TAG, String.format("getHomeUrl(): current '%1$s'", this.mUrl));
        Map<String, ?> webSharedPrefsMap = RewardUtility.getWebSharedPrefsMap(this);
        if (webSharedPrefsMap.containsKey(Constants.WEB_LAST_KNOWN)) {
            this.log.debug("last known url:" + ((String) webSharedPrefsMap.get(Constants.WEB_LAST_KNOWN)));
            if (!isUrlExpired()) {
                this.mUrl = (String) webSharedPrefsMap.get(Constants.WEB_LAST_KNOWN);
            }
        }
        Log.d(Constants.TAG, String.format("getHomeUrl(): cached '%1$s'", this.mUrl));
        String updateUrlWithAuthorization = updateUrlWithAuthorization(this.mUrl, this.mCommContext);
        if (!StringUtility.isNullOrEmpty(filterUrl(this.mUrl))) {
            updateUrlWithAuthorization = updateUrlWithAuthorization(filterUrl(this.mUrl), this.mCommContext);
        }
        if (StringUtility.isNullOrEmpty(updateUrlWithAuthorization)) {
            if (checkIfAlreadyShowingError()) {
                return null;
            }
            updateUrlWithAuthorization = Constants.DEFAULT_ERROR_PAGE;
            sErrorSource.mErrorType = ErrorType.NETWORK;
        }
        Log.d(Constants.TAG, String.format("getHomeUrl(): returning '%1$s'", updateUrlWithAuthorization));
        return updateUrlWithAuthorization;
    }

    private void initWebView() {
        Log.w(Constants.TAG, "initWebView()");
        this.mJavaScriptInterface = new GetJarJavaScriptInterface(this.mCommContext, this, this.mReceiver, this.mOffers);
        this.mWebView.addJavascriptInterface(this.mJavaScriptInterface, "GetJarSDK");
        this.mWebView.setScrollBarStyle(33554432);
        WebSettings settings = this.mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setUserAgentString(this.mUserAgent);
        settings.setCacheMode(2);
        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);
        WebSettingsEx.setDefaultZoom(settings, WebSettingsEx.ZoomDensity.FAR);
        this.mWebView.setWebViewClient(new GetJarWebViewClient(this, this.mCommContext));
        this.mWebView.setWebChromeClient(new WebChromeClient() {
            /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass5 */

            public void onConsoleMessage(String str, int i, String str2) {
                GetJarWebViewActivity.this.log.debug(str + " -- From line " + i + " of " + str2);
            }

            public void onProgressChanged(WebView webView, int i) {
                if (i == 100) {
                    GetJarWebViewActivity.this.setProgressBarIndeterminateVisibility(false);
                    GetJarWebViewActivity.this.setProgressBarVisibility(false);
                } else {
                    GetJarWebViewActivity.this.setProgressBarIndeterminateVisibility(true);
                    GetJarWebViewActivity.this.setProgressBarVisibility(true);
                }
                GetJarWebViewActivity.this.setProgress(i * 100);
            }
        });
    }

    private boolean isUrlExpired() {
        this.log.debug("isUrlExpired() ");
        Map<String, ?> webSharedPrefsMap = RewardUtility.getWebSharedPrefsMap(this);
        this.log.debug("timestamp:" + webSharedPrefsMap.get(Constants.WEB_TIMESTAMP));
        this.log.debug("timestamp:" + ((Long) webSharedPrefsMap.get(Constants.WEB_TIMESTAMP)));
        this.log.debug("timestamp from storage:" + new Date(((Long) webSharedPrefsMap.get(Constants.WEB_TIMESTAMP)).longValue()));
        this.log.debug("current timestamp :" + new Date());
        Long valueOf = Long.valueOf(new Date().getTime() - ((Long) webSharedPrefsMap.get(Constants.WEB_TIMESTAMP)).longValue());
        this.log.debug("ShouldPushData interval:" + valueOf);
        try {
            return valueOf.longValue() >= Utility.convertMillSec(Long.parseLong(GetJarConfig.getInstance(this.mCommContext, true).getDirectiveValue(GetJarConfig.KEY_WEBVIEW_SAVED_URL_TTL)));
        } catch (Exception e) {
            this.log.error(e.toString());
            return false;
        }
    }

    public static void loadErrorPage(ErrorType errorType, String str, WebView webView) {
        Logger.sLog("loadErrorPage: ErrorType:" + errorType.toString());
        sErrorSource.mErrorType = errorType;
        sErrorSource.mSubCode = str;
        loadUrlInWebView(webView, Constants.DEFAULT_ERROR_PAGE);
    }

    protected static void loadUrlInWebView(final WebView webView, final String str) {
        Logger.sLog(String.format("Loading URL '%1$s' from '%2$s'", str, Thread.currentThread().getStackTrace()[3].getMethodName()));
        if (!Utility.isCurrentThreadTheUIThread()) {
            Log.e(Constants.TAG, String.format("Loading URL '%1$s' from non-UI thread! Posting back to UI thread.", str));
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                /* class com.getjar.sdk.rewards.GetJarWebViewActivity.AnonymousClass7 */

                public void run() {
                    webView.loadUrl(str);
                }
            });
            return;
        }
        webView.loadUrl(str);
    }

    /* access modifiers changed from: private */
    public void purchaseFail(Bundle bundle) {
        waitDialogHide();
        String string = bundle.getString(Constants.APP_ID);
        String string2 = bundle.getString("name");
        long j = bundle.getLong(Constants.APP_COST);
        loadUrlInWebView(this.mWebView, "javascript:GJ.failedPurchaseUnmanagedOffer(\"" + string + "\",\"" + string2 + "\",\"" + bundle.getString(Constants.RequestInstallSubState.KEY()) + "\"," + Long.valueOf(j) + ")");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(0, intent);
        finish();
    }

    /* access modifiers changed from: private */
    public void purchaseSuccess(Bundle bundle) {
        waitDialogHide();
        String string = bundle.getString(Constants.APP_ID);
        String string2 = bundle.getString("name");
        Long valueOf = Long.valueOf(bundle.getLong(Constants.APP_COST));
        if (valueOf == null) {
            throw new IllegalStateException("Product cost cannot be null");
        }
        loadUrlInWebView(this.mWebView, "javascript:GJ.successfulPurchaseUnmanagedOffer(\"" + string + "\",\"" + string2 + "\",\"" + bundle.getString(Constants.RequestInstallSubState.KEY()) + "\"," + valueOf + ")");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(-1, intent);
        finish();
    }

    /* access modifiers changed from: private */
    public void serviceFail(Bundle bundle) {
        waitDialogHide();
        loadErrorPage(ErrorType.SERVICE, "", this.mWebView);
    }

    /* access modifiers changed from: private */
    public void simpleReload() {
        this.log.debug("Telling the WebView to reload the current URL");
        String homeUrl = getHomeUrl();
        if (!StringUtility.isNullOrEmpty(homeUrl)) {
            loadUrlInWebView(this.mWebView, homeUrl);
        }
    }

    private static String updateUrlWithAuthorization(String str, CommContext commContext) {
        Logger.sLog("updateUrlWithAuthorization() -- *START: sourceUrl=" + str);
        try {
            URI uri = new URI(str);
            String authToken = commContext.getAuthToken();
            String webKitUserAgent = commContext.getWebKitUserAgent();
            if (StringUtility.isNullOrEmpty(authToken) || StringUtility.isNullOrEmpty(webKitUserAgent)) {
                throw new IllegalStateException("Auth token and device filter values must be available");
            }
            Log.v(Constants.TAG, String.format("updateUrlWithAuthorization() has an auth token of '%1$s'", authToken));
            StringBuilder sb = new StringBuilder("");
            for (NameValuePair nameValuePair : URLEncodedUtils.parse(uri, Constants.ENCODING_CHARSET)) {
                if (!"device_filter".equalsIgnoreCase(nameValuePair.getName()) && !Constants.AUTH_TOKEN_KEY.equalsIgnoreCase(nameValuePair.getName()) && !"override.header.Accept-Language".equalsIgnoreCase(nameValuePair.getName())) {
                    if (sb.length() > 0) {
                        sb.append(Utility.QUERY_APPENDIX);
                    } else {
                        sb.append(Utility.QUERY_START);
                    }
                    sb.append(nameValuePair.getName());
                    sb.append("=");
                    sb.append(URLEncoder.encode(nameValuePair.getValue(), Constants.ENCODING_CHARSET));
                }
            }
            if (sb.length() > 0) {
                sb.append(Utility.QUERY_APPENDIX);
            } else {
                sb.append(Utility.QUERY_START);
            }
            sb.append("device_filter=");
            sb.append(URLEncoder.encode(webKitUserAgent, Constants.ENCODING_CHARSET));
            sb.append("&override.header.Authorization=");
            sb.append(URLEncoder.encode(authToken, Constants.ENCODING_CHARSET));
            sb.append("&override.header.Accept-Language=");
            sb.append(URLEncoder.encode(Language, Constants.ENCODING_CHARSET));
            Logger.sLog("updateUrlWithAuthorization() -- queryStr=\"" + ((Object) sb) + "\"");
            String format = String.format("%1$s%2$s", new URI(uri.getScheme(), uri.getUserInfo(), uri.getHost(), uri.getPort(), uri.getPath(), null, null).toString(), sb.toString());
            if (!StringUtility.isNullOrEmpty(uri.getFragment())) {
                format = String.format("%1$s#%2$s", format, uri.getFragment());
            }
            Logger.sLog("updateUrlWithAuthorization() -- DONE: new url=" + format);
            return format;
        } catch (Exception e) {
            e.printStackTrace();
            Logger.sLog("URL handling to add the Authorization value failed, returning NULL");
            return null;
        }
    }

    public void dismiss() {
        this.log.debug("Waiting for Auth is dismissed");
        waitDialogHide();
        String homeUrl = getHomeUrl();
        if (!StringUtility.isNullOrEmpty(homeUrl)) {
            loadUrlInWebView(this.mWebView, homeUrl);
        }
    }

    public String getCurrentPurchaseClientTransactionId() {
        Log.v(Constants.TAG, String.format("getCurrentPurchaseClientTransactionId() called from '%1$s' returning '%2$s'", Thread.currentThread().getStackTrace()[3].getMethodName(), this._currentPurchaseClientTransactionId));
        return this._currentPurchaseClientTransactionId;
    }

    public void onBackPressed() {
        try {
            if (!this.mWebView.canGoBack()) {
                this.log.debug("onBackPressed() -- on last page, exiting..");
                close();
                return;
            }
            WebBackForwardList copyBackForwardList = this.mWebView.copyBackForwardList();
            String authToken = getAuthToken(copyBackForwardList.getItemAtIndex(copyBackForwardList.getCurrentIndex() - 1).getUrl());
            this.log.debug("onBackPressed() -- context auth token=" + this.mCommContext.getAuthToken());
            if (authToken == null || !this.mCommContext.getAuthToken().equals(authToken)) {
                this.log.debug("onBackPressed() -- clear history..");
                this.mWebView.clearHistory();
                return;
            }
            this.log.debug("onBackPressed() -- go back..");
            this.mWebView.goBack();
        } catch (Throwable th) {
            this.log.Log(th);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    public void onCreate(Bundle bundle) {
        ArrayList arrayList;
        String str;
        this.log.debug("GetJarWebViewActivity.onCreate()");
        super.onCreate(bundle);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            arrayList = extras.getParcelableArrayList(Constants.PRODUCT_LIST);
            String string = extras.getString(Constants.GETJAR_CONTEXT_ID_KEY);
            String string2 = extras.getString(Constants.KEY_LANGUAGE);
            if (!StringUtility.isNullOrEmpty(string2)) {
                Language = string2;
                this.log.debug("GetJarWebViewActivity.onCreate() -- setting language to " + string2);
                str = string;
            } else {
                str = string;
            }
        } else {
            arrayList = null;
            str = null;
        }
        if (arrayList != null && arrayList.size() > 0) {
            this.mOffers.clear();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                this.mOffers.add(new ProductWithClientTransactionID((Product) it.next()));
            }
        }
        if (StringUtility.isNullOrEmpty(str)) {
            Log.e(Constants.TAG, String.format("The Intent used to start the GetJarWebViewActivity must contain a value for '%1$s' in its Extras", Constants.GETJAR_CONTEXT_ID_KEY));
            try {
                System.runFinalizersOnExit(true);
            } catch (Exception e) {
                Log.e(Constants.TAG, "System.runFinalizersOnExit() failed", e);
            }
            try {
                System.exit(-1);
            } catch (Exception e2) {
                Log.e(Constants.TAG, "System.exit() failed", e2);
            }
        }
        this.mCommContext = CommManager.retrieveContext(str);
        if (this.mCommContext == null) {
            Log.e(Constants.TAG, String.format("No CommContext instance found for the ID '%1$s'", str));
            try {
                System.runFinalizersOnExit(true);
            } catch (Exception e3) {
                Log.e(Constants.TAG, "System.runFinalizersOnExit() failed", e3);
            }
            try {
                System.exit(-1);
            } catch (Exception e4) {
                Log.e(Constants.TAG, "System.exit() failed", e4);
            }
        }
        Utility.previousVersionCleanUp(this);
        sErrorSource = new ErrorSource(ErrorType.NETWORK, "");
        this.mCommContext.registerFailureCallback(this._commFailureCallback);
        try {
            this.mUrl = GetJarConfig.getInstance(this.mCommContext, true).getDirectiveValue(GetJarConfig.KEY_DEFAULT_WEBVIEW_URL);
            this.log.debug("onCreate() -- using mUrl=" + this.mUrl);
            this.mUserAgent = this.mCommContext.getSdkUserAgent();
            CookieSyncManager.createInstance(this);
            this.mWebView = new WebView(this);
            if (bundle != null) {
                this.mWebView.restoreState(bundle);
            }
            requestWindowFeature(2);
            setContentView(this.mWebView);
            getWindow().setFeatureInt(2, -1);
            initWebView();
            waitForAuthorization();
        } catch (Exception e5) {
            this.log.error(e5.toString());
            throw new IllegalStateException("Failed to determine default webview url, unable to create webview");
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        try {
            this.mCommContext.postResponse(new CloseResponse());
            StatisticsTracker.dumpAllStatsToLogCat(this);
        } finally {
            waitDialogHide();
            super.onDestroy();
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || Build.VERSION.SDK_INT > 4) {
            return super.onKeyDown(i, keyEvent);
        }
        Log.v(Constants.TAG, "Back button pressed on an API level 4 device");
        onBackPressed();
        return true;
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        this.isForeground = false;
        waitDialogHide();
        CookieSyncManager.getInstance().stopSync();
        UnRegisterPackageReceiver();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.isForeground = true;
        waitDialogHide();
        RewardUtility.saveGetJarTimestamp(this);
        CookieSyncManager.getInstance().startSync();
        RegisterPackageReceiver();
        reload();
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        this.log.debug("onSaveInstanceState()");
        super.onSaveInstanceState(bundle);
        this.mWebView.saveState(bundle);
        bundle.putString(Constants.SDK_URL, this.mUrl);
        bundle.putString(Constants.GETJAR_CONTEXT_ID_KEY, this.mCommContext.getCommContextId());
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {
        try {
            String string = sharedPreferences.getString(str, "null");
            if ((!this.mCatchByMonitor && string.equalsIgnoreCase("SUCCESS")) || string.equalsIgnoreCase("FAIL")) {
                reload();
            }
        } catch (Exception e) {
        }
    }

    public void reload() {
        try {
            this.log.debug("reload");
            if (this.mWebView != null) {
                this.log.debug("onFocus is called");
                loadUrlInWebView(this.mWebView, "javascript:GJ.onFocus()");
                Map<String, ?> defaultSharedPrefsMap = RewardUtility.getDefaultSharedPrefsMap(this.mCommContext.getApplicationContext());
                this.log.debug("package size:" + defaultSharedPrefsMap.size());
                if (defaultSharedPrefsMap.size() > 0) {
                    SharedPreferences sharedPreferences = this.mCommContext.getApplicationContext().getSharedPreferences(Constants.PACKAGE_NAMES_INSTALLED_PREFS, 0);
                    SharedPreferences sharedPreferences2 = this.mCommContext.getApplicationContext().getSharedPreferences(RewardUtility._PreferencesInstalledAppFileName, 0);
                    Map<String, ?> all = sharedPreferences.getAll();
                    this.log.debug("Number of packages to scan:" + all.size());
                    for (Map.Entry<String, ?> entry : all.entrySet()) {
                        String key = entry.getKey();
                        this.log.debug("checking package=" + key);
                        String str = key + Constants.RequestInstallType.SUFFIX_STATE;
                        String str2 = defaultSharedPrefsMap.containsKey(str) ? (String) defaultSharedPrefsMap.get(str) : null;
                        this.log.debug("package=" + key + " installState:" + str2);
                        String str3 = key + Constants.RequestInstallType.SUFFIX_DEFAULT;
                        String str4 = key + Constants.RequestInstallType.SUFFIX_SUBSTATE;
                        String str5 = key + Constants.APPDATA_FRIENDLY_SUFFIX;
                        String str6 = key + Constants.RequestInstallType.SUFFIX_APP_ID;
                        String str7 = key + Constants.RequestInstallType.SUFFIX_AMOUNT;
                        String str8 = key + Constants.RequestInstallType.SUFFIX_NOTIFICATION;
                        String str9 = (String) defaultSharedPrefsMap.get(str3);
                        String str10 = (String) defaultSharedPrefsMap.get(str4);
                        String str11 = (String) defaultSharedPrefsMap.get(str5);
                        String str12 = (String) defaultSharedPrefsMap.get(str6);
                        String str13 = (String) defaultSharedPrefsMap.get(str7);
                        String str14 = (String) defaultSharedPrefsMap.get(str8);
                        this.log.debug("installType:" + defaultSharedPrefsMap.get(str3));
                        this.log.debug("SubstateKey:" + defaultSharedPrefsMap.get(str4));
                        this.log.debug("friendly Name:" + defaultSharedPrefsMap.get(str5));
                        this.log.debug("app Id:" + defaultSharedPrefsMap.get(str6));
                        this.log.debug("amount:" + defaultSharedPrefsMap.get(str7));
                        if (str2 == null || !str2.equals(Constants.RequestInstallState.SUCCESS.toString())) {
                            if (str2 != null) {
                                if (Constants.RequestInstallState.FAIL.toString().equals(str2)) {
                                    this.log.debug(".. invoking failed*Install() js callback, appId=" + str12 + ", pkgName=" + key + ", friendlyName=" + str11 + ", substate=" + str10 + ", amount=" + str13);
                                    if (Constants.RequestInstallType.EARN.toString().equals(str9) && str14.equals(Constants.RequestInstallState.UNKNOWN.toString())) {
                                        String str15 = "javascript:GJ.failedEarnInstall(\"" + str12 + "\",\"" + key + "\",\"" + str11 + "\",\"" + str10 + "\"," + str13 + ")";
                                        this.log.debug("send url:" + str15);
                                        loadUrlInWebView(this.mWebView, str15);
                                        RewardUtility.savePreInstallRewardApplicationMetadata(this, str8, "DONE");
                                    }
                                    if (str10.equals(Constants.ALREADY_REDEEMED_FAILURE) || str10.equals(Constants.ALREADY_USED_FAILURE) || str10.equals(Constants.CAP_REACHED_FAILURE)) {
                                        RewardUtility.removeSPEntry(sharedPreferences2.edit(), key);
                                        this.log.debug("application " + str5 + " is removed.");
                                        sharedPreferences.edit().remove(key).commit();
                                    }
                                }
                            }
                            if (str2 == null) {
                                this.log.debug(".. invoking appInstalled() js callback, pkgName=" + key);
                                loadUrlInWebView(this.mWebView, "javascript:GJ.appInstalled(\"" + key + "\")");
                                sharedPreferences.edit().remove(key).commit();
                            }
                        } else {
                            this.log.debug(".. invoking successful*Install() js callback, appId=" + str12 + ", pkgName=" + key + ", friendlyName=" + str11 + ", substate=" + str10 + ", amount=" + str13);
                            if (Constants.RequestInstallType.EARN.toString().equals(str9)) {
                                String str16 = "javascript:GJ.successfulEarnInstall(\"" + str12 + "\",\"" + key + "\",\"" + str11 + "\",\"" + str10 + "\"," + str13 + ")";
                                this.log.debug("send url:" + str16);
                                loadUrlInWebView(this.mWebView, str16);
                            }
                            RewardUtility.removeSPEntry(sharedPreferences2.edit(), key);
                            this.log.debug("application " + str5 + " is removed.");
                            sharedPreferences.edit().remove(key).commit();
                        }
                    }
                }
            } else {
                Logger.sLog("Web View is null");
            }
        } finally {
            waitDialogHide();
        }
    }

    public void setAuthToken(Bundle bundle) {
        loadUrlInWebView(this.mWebView, "javascript:GJ.setAuthToken(" + bundle.getString(Constants.AUTH_TOKEN_KEY) + ")");
    }

    public void setCurrentPurchaseClientTransactionId(String str) {
        Log.v(Constants.TAG, String.format("setCurrentPurchaseClientTransactionId(%1$s) called from '%2$s'", str, Thread.currentThread().getStackTrace()[3].getMethodName()));
        this._currentPurchaseClientTransactionId = str;
    }

    /* access modifiers changed from: protected */
    public void unableToDownloadDialogHide() {
        Log.d(Constants.TAG, String.format("Hiding 'unable to download' dialog [thread:%1$d] [called-from:%2$s()]", Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        if (this._unableToDownloadDialog != null) {
            dialogHide(DialogType.UNABLE_TO_DOWNLOAD);
        }
    }

    /* access modifiers changed from: protected */
    public void unableToDownloadDialogShow() {
        Log.d(Constants.TAG, String.format("Showing 'unable to download' dialog [thread:%1$d] [called-from:%2$s()]", Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        dialogShow(DialogType.UNABLE_TO_DOWNLOAD);
    }

    /* access modifiers changed from: protected */
    public void waitDialogHide() {
        Log.d(Constants.TAG, String.format("Hiding 'please wait' dialog [thread:%1$d] [called-from:%2$s()]", Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        if (this._pleaseWaitDialog != null) {
            dialogHide(DialogType.WAIT);
        }
    }

    /* access modifiers changed from: protected */
    public void waitDialogShow() {
        Log.d(Constants.TAG, String.format("Showing 'please wait' dialog [thread:%1$d] [called-from:%2$s()]", Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getStackTrace()[3].getMethodName()));
        dialogShow(DialogType.WAIT);
    }

    /* access modifiers changed from: protected */
    public void waitForAuthorization() {
        this.log.debug("Waiting for Auth is called");
        waitDialogShow();
        try {
            new Thread(new waitForAuth(this.mCommContext, this.mDismissReceiver)).start();
        } catch (Throwable th) {
            waitDialogHide();
            th.printStackTrace();
        }
    }
}

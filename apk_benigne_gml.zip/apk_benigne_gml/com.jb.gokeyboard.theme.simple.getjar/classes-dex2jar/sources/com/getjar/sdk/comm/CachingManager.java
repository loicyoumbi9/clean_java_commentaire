package com.getjar.sdk.comm;

import android.content.Context;
import android.util.Log;
import com.getjar.sdk.data.CacheEntry;
import com.getjar.sdk.data.DBCache;
import com.getjar.sdk.utilities.Base64;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Iterator;

public class CachingManager {
    private static final String _RequestResultCacheKeyFormat = "REQUEST_ID_%1$d";
    private Context _androidContext = null;

    public CachingManager(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'androidContext' can not be NULL");
        }
        this._androidContext = context;
    }

    private CacheEntry getCacheEntry(Request request) throws URISyntaxException {
        DBCache dBCache = new DBCache(this._androidContext);
        try {
            return dBCache.loadCacheEntry(getCacheKey(request));
        } finally {
            dBCache.close();
        }
    }

    private String getCacheKey(Request request) {
        return String.format(_RequestResultCacheKeyFormat, Integer.valueOf(request.getId()));
    }

    private String getETag(Result result) {
        if (result.getHeaders() == null || !result.getHeaders().containsKey("ETag") || result.getHeaders().get("ETag") == null || result.getHeaders().get("ETag").size() <= 0) {
            return null;
        }
        return result.getHeaders().get("ETag").get(0);
    }

    private Long getTtl(Result result) {
        if (result.getHeaders() == null || !result.getHeaders().containsKey("Cache-Control") || result.getHeaders().get("Cache-Control") == null || result.getHeaders().get("Cache-Control").size() <= 0) {
            return null;
        }
        Iterator<String> it = result.getHeaders().get("Cache-Control").iterator();
        String next = it.hasNext() ? it.next() : null;
        if (StringUtility.isNullOrEmpty(next)) {
            return null;
        }
        String[] split = next.split(",");
        Long l = null;
        for (String str : split) {
            if (str != null) {
                String trim = str.trim();
                if ("no-cache".equalsIgnoreCase(trim)) {
                    return null;
                }
                String[] split2 = trim.split("=");
                if (split2.length > 1 && split2[0] != null && split2[1] != null && "max-age".equalsIgnoreCase(split2[0].trim())) {
                    try {
                        long parseLong = Long.parseLong(split2[1].trim());
                        if (parseLong >= 0) {
                            l = Long.valueOf(parseLong * 1000);
                        }
                    } catch (NumberFormatException e) {
                        Log.e(Constants.TAG, "CachingManager: getTtl() Parsing max-age failed", e);
                    }
                }
            }
        }
        return l;
    }

    public void addResultToCache(Operation operation) throws IOException, URISyntaxException {
        Long ttl;
        if (operation == null) {
            throw new IllegalArgumentException("'operation' can not be NULL");
        } else if (operation.getResult() == null) {
            throw new IllegalStateException(String.format("Operation %1$d does not yet have a Result", Integer.valueOf(operation.getId())));
        } else if (operation.getResult().getResponseCode() == 200 && (ttl = getTtl(operation.getResult())) != null) {
            String eTag = getETag(operation.getResult());
            CacheEntry cacheEntry = new CacheEntry();
            cacheEntry.setName(getCacheKey(operation.getRequest()));
            cacheEntry.setValue(Base64.encodeObject(operation.getResult()));
            cacheEntry.setTtl(ttl);
            cacheEntry.setUri(operation.getRequest().getUriForRequest());
            if (!StringUtility.isNullOrEmpty(eTag)) {
                cacheEntry.setEtag(eTag);
            }
            DBCache dBCache = new DBCache(operation.getCommContext().getApplicationContext());
            try {
                if (!dBCache.upsertCacheEntry(cacheEntry)) {
                    Log.e(Constants.TAG, String.format("CachingManager: addResultToCache() Cache DB update for '%1$s' failed", getCacheKey(operation.getRequest())));
                } else {
                    Log.i(Constants.TAG, String.format("CachingManager: addResultToCache() Cache entry updated: %1$s", cacheEntry.toString()));
                }
            } finally {
                dBCache.close();
            }
        }
    }

    public String getETag(Operation operation) {
        try {
            CacheEntry cacheEntry = getCacheEntry(operation.getRequest());
            if (cacheEntry != null) {
                return cacheEntry.getEtag();
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, "CachingManager: getETag() failed", e);
        }
        return null;
    }

    public Result getRequestResult(Operation operation) {
        try {
            CacheEntry cacheEntry = getCacheEntry(operation.getRequest());
            if (cacheEntry != null && !cacheEntry.hasTtlExpired()) {
                Log.v(Constants.TAG, String.format("CachingManager: getRequestResult() Found a cached result for Request %1$d", Integer.valueOf(operation.getRequest().getId())));
                return (Result) Base64.decodeToObject(cacheEntry.getValue());
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, "CachingManager: getRequestResult() failed", e);
        }
        return null;
    }

    public void lruCapAtMaxRecords() {
        DBCache dBCache = new DBCache(this._androidContext);
        try {
            dBCache.lruCapAtMaxRecords();
        } finally {
            dBCache.close();
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00e9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void refreshCacheEntry(com.getjar.sdk.comm.Operation r10) throws java.net.URISyntaxException, java.io.IOException, java.lang.ClassNotFoundException, java.lang.IllegalStateException {
        /*
            r9 = this;
            r2 = 0
            r8 = 1
            r7 = 0
            if (r10 != 0) goto L_0x000d
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "'operation' can not be NULL"
            r0.<init>(r1)
            throw r0
        L_0x000d:
            com.getjar.sdk.comm.Result r0 = r10.getResult()
            if (r0 != 0) goto L_0x001b
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "refreshCacheEntry() can only be called for operations with a result"
            r0.<init>(r1)
            throw r0
        L_0x001b:
            com.getjar.sdk.comm.Result r0 = r10.getResult()
            int r0 = r0.getResponseCode()
            r1 = 304(0x130, float:4.26E-43)
            if (r0 == r1) goto L_0x002f
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "refreshCacheEntry() can only be called for operations with a 304 result"
            r0.<init>(r1)
            throw r0
        L_0x002f:
            com.getjar.sdk.comm.Result r0 = r10.getResult()
            com.getjar.sdk.comm.Request r1 = r10.getRequest()
            com.getjar.sdk.data.CacheEntry r3 = r9.getCacheEntry(r1)
            if (r3 != 0) goto L_0x0055
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Request %1$d received a 304, but no stale cache entry was found"
            java.lang.Object[] r2 = new java.lang.Object[r8]
            int r3 = r9.hashCode()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2[r7] = r3
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.<init>(r1)
            throw r0
        L_0x0055:
            java.lang.Long r0 = r9.getTtl(r0)     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            if (r0 == 0) goto L_0x0115
            r3.setTtl(r0)     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            com.getjar.sdk.data.DBCache r1 = new com.getjar.sdk.data.DBCache     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            com.getjar.sdk.comm.CommContext r0 = r10.getCommContext()     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            android.content.Context r0 = r0.getApplicationContext()     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            r1.<init>(r0)     // Catch:{ Exception -> 0x00de, all -> 0x00e1 }
            boolean r0 = r1.upsertCacheEntry(r3)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            if (r0 != 0) goto L_0x00ba
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            java.lang.String r2 = "CachingManager: refreshCacheEntry() Cache DB update for '%1$s' failed"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            r5 = 0
            com.getjar.sdk.comm.Request r6 = r10.getRequest()     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            java.lang.String r6 = r9.getCacheKey(r6)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            r4[r5] = r6     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            java.lang.String r2 = java.lang.String.format(r2, r4)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            android.util.Log.e(r0, r2)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
        L_0x008a:
            if (r1 == 0) goto L_0x008f
            r1.close()
        L_0x008f:
            java.lang.String r0 = r3.getValue()
            java.lang.Object r0 = com.getjar.sdk.utilities.Base64.decodeToObject(r0)
            com.getjar.sdk.comm.Result r0 = (com.getjar.sdk.comm.Result) r0
            r10.setResult(r0)
            com.getjar.sdk.comm.Result r0 = r10.getResult()
            if (r0 != 0) goto L_0x00e9
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Found a NULL result in cache for operation %1$d"
            java.lang.Object[] r2 = new java.lang.Object[r8]
            int r3 = r10.getId()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2[r7] = r3
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.<init>(r1)
            throw r0
        L_0x00ba:
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            java.lang.String r2 = "CachingManager: refreshCacheEntry() Cache entry updated: %1$s"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            r5 = 0
            java.lang.String r6 = r3.toString()     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            r4[r5] = r6     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            java.lang.String r2 = java.lang.String.format(r2, r4)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            android.util.Log.i(r0, r2)     // Catch:{ Exception -> 0x00d0, all -> 0x0110 }
            goto L_0x008a
        L_0x00d0:
            r0 = move-exception
        L_0x00d1:
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0112 }
            java.lang.String r4 = "CachingManager: refreshCacheEntry() Updating the cache entry TTL failed"
            android.util.Log.e(r2, r4, r0)     // Catch:{ all -> 0x0112 }
            if (r1 == 0) goto L_0x008f
            r1.close()
            goto L_0x008f
        L_0x00de:
            r0 = move-exception
            r1 = r2
            goto L_0x00d1
        L_0x00e1:
            r0 = move-exception
        L_0x00e2:
            r1 = r2
        L_0x00e3:
            if (r1 == 0) goto L_0x00e8
            r1.close()
        L_0x00e8:
            throw r0
        L_0x00e9:
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG
            java.lang.String r1 = "Operation %1$d recieved a 304 and has been updated to a cached result with %2$d"
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            int r3 = r10.getId()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2[r7] = r3
            com.getjar.sdk.comm.Result r3 = r10.getResult()
            int r3 = r3.getResponseCode()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2[r8] = r3
            java.lang.String r1 = java.lang.String.format(r1, r2)
            android.util.Log.v(r0, r1)
            return
        L_0x0110:
            r0 = move-exception
            goto L_0x00e3
        L_0x0112:
            r0 = move-exception
            r2 = r1
            goto L_0x00e2
        L_0x0115:
            r1 = r2
            goto L_0x008a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CachingManager.refreshCacheEntry(com.getjar.sdk.comm.Operation):void");
    }
}

package com.getjar.sdk;

import android.content.Intent;
import com.getjar.sdk.rewards.GetJarWebViewActivity;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.Utility;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public final class GetJarPage {
    private String _lang = Constants.DEFAULT_LANGUAGE;
    Logger log = new Logger(this);
    private final GetJarContext mGjContext;
    private Collection<Product> mProducts = Collections.unmodifiableCollection(new ArrayList(0));

    public GetJarPage(GetJarContext getJarContext) {
        this.log.debug("GetJarPage");
        if (getJarContext == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        this.mGjContext = getJarContext;
    }

    public Collection<Product> getProducts() {
        this.log.debug("GetJarPage.getProducts()");
        return this.mProducts;
    }

    public void setProduct(Product product) {
        this.log.debug("GetJarPage.setProduct()");
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(product);
        this.mProducts = Collections.unmodifiableCollection(arrayList);
    }

    public void setProduct(String str, String str2, String str3, long j) {
        this.log.debug("GetJarPage.setProduct()");
        Product product = new Product(str, str2, str3, j);
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(product);
        this.mProducts = Collections.unmodifiableCollection(arrayList);
    }

    public void setProducts(Collection<Product> collection) {
        this.log.debug("GetJarPage.setProducts()");
        if (collection == null || collection.size() == 0) {
            throw new IllegalArgumentException("need a list of products to offer");
        }
        this.mProducts = Collections.unmodifiableCollection(new ArrayList(collection));
    }

    public void showPage() {
        this.log.debug("showPage() -- deviceObject Id:" + Utility.getDeviceObjectId(this.mGjContext.getAndroidContext()));
        Intent intent = new Intent(this.mGjContext.getAndroidContext(), GetJarWebViewActivity.class);
        intent.addFlags(268435456);
        intent.putParcelableArrayListExtra(Constants.PRODUCT_LIST, new ArrayList(this.mProducts));
        intent.putExtra(Constants.GETJAR_CONTEXT_ID_KEY, this.mGjContext.getGetJarContextId());
        intent.putExtra(Constants.KEY_LANGUAGE, this._lang.replace("_", "-"));
        this.mGjContext.getAndroidContext().startActivity(intent);
    }
}

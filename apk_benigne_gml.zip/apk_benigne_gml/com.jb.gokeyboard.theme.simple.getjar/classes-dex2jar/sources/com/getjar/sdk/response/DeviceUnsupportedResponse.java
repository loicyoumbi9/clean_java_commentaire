package com.getjar.sdk.response;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.HashMap;
import java.util.Map;

public class DeviceUnsupportedResponse extends Response {
    public static final Parcelable.Creator<DeviceUnsupportedResponse> CREATOR = new Parcelable.Creator<DeviceUnsupportedResponse>() {
        /* class com.getjar.sdk.response.DeviceUnsupportedResponse.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public DeviceUnsupportedResponse createFromParcel(Parcel parcel) {
            return new DeviceUnsupportedResponse(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public DeviceUnsupportedResponse[] newArray(int i) {
            return new DeviceUnsupportedResponse[i];
        }
    };
    private Map<String, String> _deviceMetadata = new HashMap();

    public DeviceUnsupportedResponse(Parcel parcel) {
        super(parcel);
        parcel.readMap(this._deviceMetadata, String.class.getClassLoader());
    }

    public DeviceUnsupportedResponse(Map<String, String> map) {
        this._deviceMetadata = map;
    }

    public Map<String, String> getDeviceMetadata() {
        return this._deviceMetadata;
    }

    @Override // com.getjar.sdk.response.Response
    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeMap(this._deviceMetadata);
    }
}

package com.getjar.sdk.comm;

import android.content.Context;
import java.util.concurrent.ConcurrentHashMap;

public class StatisticsTracker {
    private static ConcurrentHashMap<String, Integer> _SessionRequestCounts = new ConcurrentHashMap<>();
    private static long _Start = System.currentTimeMillis();

    public static void dumpAllStatsToLogCat(Context context) {
    }

    private static void dumpSessionRatesToLogCat() {
    }

    public static void logRequest(Operation operation) {
    }

    public static void logResponse(Operation operation) {
    }
}

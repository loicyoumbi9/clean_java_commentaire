package com.getjar.sdk.response;

import android.os.Parcel;
import android.os.Parcelable;

public class CloseResponse extends Response {
    public static final Parcelable.Creator<CloseResponse> CREATOR = new Parcelable.Creator<CloseResponse>() {
        /* class com.getjar.sdk.response.CloseResponse.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public CloseResponse createFromParcel(Parcel parcel) {
            return new CloseResponse(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public CloseResponse[] newArray(int i) {
            return new CloseResponse[i];
        }
    };

    public CloseResponse() {
    }

    public CloseResponse(Parcel parcel) {
        super(parcel);
    }
}

package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.getjar.sdk.events.LaunchEvent;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.Utility;
import java.util.ArrayList;
import java.util.List;

public class DBAdapterAppData extends SQLiteOpenHelper {
    private static final String[] COLUMN_LAUNCH_COUNT = {"launchCount"};
    private static final String DATABASE_NAME = "GetJarDB";
    private static final String DATABASE_TABLE_MAIN = "appData";
    private static final String DATABASE_TABLE_USAGE = "appUsage";
    private static final int DATABASE_VERSION = 3;
    private static final String[] DB_CREATE_TABLE_COMMANDS = {DB_CREATE_TABLE_MAIN, DB_CREATE_TABLE_USAGE};
    private static final String DB_CREATE_TABLE_MAIN = "CREATE TABLE IF NOT EXISTS appData (id INTEGER PRIMARY KEY AUTOINCREMENT, packageName TEXT NOT NULL UNIQUE, status TEXT NOT NULL, versionCode INTEGER, versionName TEXT, targetSDK TEXT, flags INTEGER, appLabel TEXT, launchCount INTEGER DEFAULT 0, lastUsageTime INTEGER DEFAULT 0,synced INTEGER NOT NULL DEFAULT 0);";
    private static final String DB_CREATE_TABLE_USAGE = "CREATE TABLE IF NOT EXISTS appUsage (id INTEGER PRIMARY KEY AUTOINCREMENT, packageName TEXT NOT NULL, usageTime INTEGER NOT NULL DEFAULT 0, synced INTEGER NOT NULL DEFAULT 0);";
    private static final String[] DB_TABLE_NAMES = {DATABASE_TABLE_MAIN, DATABASE_TABLE_USAGE};
    private static final int USAGE_DATABASE_CAPACITY = 1000;
    private Logger log = new Logger(this);
    private SQLiteDatabase mDatabase = getWritableDatabase();

    public DBAdapterAppData(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 3);
    }

    private AppData makeAppData(Cursor cursor) {
        if (cursor == null) {
            throw new IllegalArgumentException("'results' can not be null");
        }
        AppData appData = new AppData();
        appData.setDBID(Integer.valueOf(cursor.getInt(0)));
        appData.setPackageName(cursor.getString(1));
        appData.setStatus(AppData.AppStatus.valueOf(cursor.getString(2)));
        appData.setVersionCode(Integer.valueOf(cursor.getInt(3)));
        appData.setVersionName(cursor.getString(4));
        appData.setTargetSDKVer(cursor.getString(5));
        appData.setFlags(cursor.getInt(6));
        appData.setAppName(cursor.getString(7));
        appData.setLaunchCount(cursor.getInt(8));
        appData.setUsageTime(cursor.getLong(9));
        return appData;
    }

    public boolean appDataIsEmpty() {
        boolean z = false;
        Cursor rawQuery = this.mDatabase.rawQuery("SELECT count(*) FROM appData", null);
        try {
            rawQuery.moveToFirst();
            if (rawQuery.getInt(0) <= 0) {
                z = true;
            }
            try {
                rawQuery.close();
            } catch (Throwable th) {
            }
            return z;
        } catch (Throwable th2) {
        }
        throw th;
    }

    public AppData appDataLoad(String str) {
        AppData appData = null;
        if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'packageName' can not be null or empty");
        }
        Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, null, "packageName = '" + str + "'", null, null, null, null);
        try {
            if (query.moveToNext()) {
                appData = makeAppData(query);
                try {
                    query.close();
                } catch (Throwable th) {
                }
            } else {
                try {
                    query.close();
                } catch (Throwable th2) {
                }
            }
            return appData;
        } catch (Throwable th3) {
        }
        throw th;
    }

    public List<AppData> appDataLoadAll() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, null, null, null, null, null, "packageName");
        while (query.moveToNext()) {
            try {
                arrayList.add(makeAppData(query));
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    public List<AppData> appDataLoadUnsynced() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, null, "synced = 0", null, null, null, null);
        while (query.moveToNext()) {
            try {
                arrayList.add(makeAppData(query));
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean appDataMarkAsSynced(String str) {
        if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'packageName' can not be null or empty");
        } else if (checkForRecord(DATABASE_TABLE_MAIN, str)) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("synced", (Integer) 1);
            contentValues.put("launchCount", (Integer) 0);
            return this.mDatabase.update(DATABASE_TABLE_MAIN, contentValues, new StringBuilder().append("packageName = '").append(str).append("'").toString(), null) > 0;
        } else {
            this.log.info(String.format("can not find package '%1$s' in order to update as synced", str));
            return false;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public AppData appDataUpdateStatus(String str, AppData.AppStatus appStatus) {
        if (appStatus == null) {
            throw new IllegalArgumentException("'newStatus' can not be null");
        } else if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'packageName' can not be null or empty");
        } else if (checkForRecord(DATABASE_TABLE_MAIN, str)) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("status", appStatus.name());
            contentValues.put("synced", (Integer) 0);
            this.mDatabase.update(DATABASE_TABLE_MAIN, contentValues, "packageName = '" + str + "'", null);
            return appDataLoad(str);
        } else {
            this.log.error(String.format("Failed to find package '%1$s' in order to update status", str));
            return null;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean appDataUpdateStatus(AppData appData) {
        if (appData == null) {
            throw new IllegalArgumentException("'item' can not be null");
        } else if (checkForRecord(DATABASE_TABLE_MAIN, appData.getPackageName())) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("status", appData.getStatus().name());
            contentValues.put("synced", (Integer) 0);
            return this.mDatabase.update(DATABASE_TABLE_MAIN, contentValues, new StringBuilder().append("packageName = '").append(appData.getPackageName()).append("'").toString(), null) > 0;
        } else {
            this.log.error(String.format("Failed to find package '%1$s' in order to update status", appData.getPackageName()));
            return false;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean appDataUpsert(AppData appData) {
        boolean z = true;
        if (appData == null) {
            throw new IllegalArgumentException("'item' can not be null");
        } else if (Utility.shouldFilterApp(appData)) {
            return false;
        } else {
            ContentValues contentValues = new ContentValues();
            contentValues.put("packageName", appData.getPackageName());
            contentValues.put("status", appData.getStatus().name());
            contentValues.put("versionCode", appData.getVersionCode());
            contentValues.put("versionName", appData.getVersionName());
            contentValues.put("targetSDK", appData.getTargetSDKVer());
            contentValues.put("flags", Integer.valueOf(appData.getFlags()));
            contentValues.put("appLabel", appData.getAppName());
            if (checkForRecord(DATABASE_TABLE_MAIN, appData.getPackageName())) {
                this.log.debug("update");
                return this.mDatabase.update(DATABASE_TABLE_MAIN, contentValues, new StringBuilder().append("packageName = '").append(appData.getPackageName()).append("'").toString(), null) > 0;
            }
            try {
                this.log.debug("Insert:");
                contentValues.put("launchCount", (Integer) 0);
                contentValues.put("lastUsageTime", (Integer) 0);
                if (this.mDatabase.insert(DATABASE_TABLE_MAIN, null, contentValues) == -1) {
                    z = false;
                }
                return z;
            } catch (SQLiteException e) {
                return false;
            }
        }
    }

    public boolean checkForRecord(String str, String str2) {
        boolean z = false;
        if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'tableName' can not be null or empty");
        } else if (str2 == null || str2.length() <= 0) {
            throw new IllegalArgumentException("'packageName' can not be null or empty");
        } else {
            Cursor rawQuery = this.mDatabase.rawQuery("SELECT count(*) FROM " + str + " WHERE packageName = '" + str2 + "'", null);
            this.log.debug("check for Record 2:" + str2);
            try {
                rawQuery.moveToFirst();
                if (rawQuery.getInt(0) > 0) {
                    z = true;
                }
                try {
                    rawQuery.close();
                } catch (Throwable th) {
                    this.log.Log(th);
                }
                return z;
            } catch (Throwable th2) {
                this.log.Log(th2);
            }
        }
        throw th;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this.mDatabase.close();
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0044  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getOldest(java.lang.String r12) {
        /*
            r11 = this;
            r8 = -1
            r9 = 0
            r10 = 0
            android.database.sqlite.SQLiteDatabase r0 = r11.mDatabase     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r1 = 1
            java.lang.String[] r2 = new java.lang.String[r1]     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r1 = 0
            java.lang.String r3 = "id"
            r2[r1] = r3     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            java.lang.String r7 = "id ASC"
            r1 = r12
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            if (r1 == 0) goto L_0x002b
            r1.moveToFirst()     // Catch:{ SQLiteException -> 0x004e, all -> 0x004b }
            r0 = 0
            int r0 = r1.getInt(r0)     // Catch:{ SQLiteException -> 0x004e, all -> 0x004b }
            if (r1 == 0) goto L_0x002a
            r1.deactivate()
            r1.close()
        L_0x002a:
            return r0
        L_0x002b:
            if (r1 == 0) goto L_0x0033
            r1.deactivate()
            r1.close()
        L_0x0033:
            r0 = r9
            goto L_0x002a
        L_0x0035:
            r0 = move-exception
            r0 = r10
        L_0x0037:
            if (r0 == 0) goto L_0x0051
            r0.deactivate()
            r0.close()
            r0 = r8
            goto L_0x002a
        L_0x0041:
            r0 = move-exception
        L_0x0042:
            if (r10 == 0) goto L_0x004a
            r10.deactivate()
            r10.close()
        L_0x004a:
            throw r0
        L_0x004b:
            r0 = move-exception
            r10 = r1
            goto L_0x0042
        L_0x004e:
            r0 = move-exception
            r0 = r1
            goto L_0x0037
        L_0x0051:
            r0 = r8
            goto L_0x002a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.DBAdapterAppData.getOldest(java.lang.String):int");
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x003f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int numRecords(java.lang.String r12) {
        /*
            r11 = this;
            r9 = 0
            r8 = -1
            r10 = 0
            android.database.sqlite.SQLiteDatabase r0 = r11.mDatabase     // Catch:{ SQLiteException -> 0x0030, all -> 0x003c }
            r1 = 1
            java.lang.String[] r2 = new java.lang.String[r1]     // Catch:{ SQLiteException -> 0x0030, all -> 0x003c }
            r1 = 0
            java.lang.String r3 = "id"
            r2[r1] = r3     // Catch:{ SQLiteException -> 0x0030, all -> 0x003c }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r1 = r12
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0030, all -> 0x003c }
            if (r1 == 0) goto L_0x0026
            int r0 = r1.getCount()     // Catch:{ SQLiteException -> 0x0049, all -> 0x0046 }
            if (r1 == 0) goto L_0x0025
            r1.deactivate()
            r1.close()
        L_0x0025:
            return r0
        L_0x0026:
            if (r1 == 0) goto L_0x002e
            r1.deactivate()
            r1.close()
        L_0x002e:
            r0 = r9
            goto L_0x0025
        L_0x0030:
            r0 = move-exception
            r0 = r10
        L_0x0032:
            if (r0 == 0) goto L_0x004c
            r0.deactivate()
            r0.close()
            r0 = r8
            goto L_0x0025
        L_0x003c:
            r0 = move-exception
        L_0x003d:
            if (r10 == 0) goto L_0x0045
            r10.deactivate()
            r10.close()
        L_0x0045:
            throw r0
        L_0x0046:
            r0 = move-exception
            r10 = r1
            goto L_0x003d
        L_0x0049:
            r0 = move-exception
            r0 = r1
            goto L_0x0032
        L_0x004c:
            r0 = r8
            goto L_0x0025
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.DBAdapterAppData.numRecords(java.lang.String):int");
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        for (int i = 0; i < DB_CREATE_TABLE_COMMANDS.length; i++) {
            sQLiteDatabase.execSQL(DB_CREATE_TABLE_COMMANDS[i]);
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        this.log.info("Upgrading database from version " + i + " to " + i2 + ", which will destroy all old data");
        for (int i3 = 0; i3 < DB_TABLE_NAMES.length; i3++) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_NAMES[i3]);
        }
        onCreate(sQLiteDatabase);
    }

    public boolean removeTask(long j, String str) {
        try {
            Log.d(Constants.TAG, String.format("Deleting ID %1$d from table %2$s", Long.valueOf(j), str));
            return this.mDatabase.delete(str, new StringBuilder().append("id = ").append(j).toString(), null) > 0;
        } catch (SQLiteException e) {
            return false;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean usageIncrementLaunchCount(String str, long j) {
        if (checkForRecord(DATABASE_TABLE_MAIN, str)) {
            Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, COLUMN_LAUNCH_COUNT, "packageName = '" + str + "'", null, null, null, null);
            try {
                query.moveToFirst();
                int i = query.getInt(0);
                try {
                    query.close();
                } catch (Throwable th) {
                }
                boolean z = i == 0;
                this.mDatabase.beginTransaction();
                try {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("launchCount", Integer.valueOf(i + 1));
                    contentValues.put("lastUsageTime", Long.valueOf(j));
                    this.mDatabase.update(DATABASE_TABLE_MAIN, contentValues, "packageName = '" + str + "'", null);
                    int numRecords = numRecords(DATABASE_TABLE_USAGE);
                    Log.d(Constants.TAG, String.format("Number of usage records %1$d", Integer.valueOf(numRecords)));
                    if (numRecords >= USAGE_DATABASE_CAPACITY) {
                        removeTask((long) getOldest(DATABASE_TABLE_USAGE), DATABASE_TABLE_USAGE);
                    }
                    ContentValues contentValues2 = new ContentValues();
                    contentValues2.put("packageName", str);
                    contentValues2.put("usageTime", Long.valueOf(j));
                    contentValues2.put("synced", (Integer) 0);
                    this.mDatabase.insert(DATABASE_TABLE_USAGE, null, contentValues2);
                    this.mDatabase.setTransactionSuccessful();
                    return z;
                } finally {
                    this.mDatabase.endTransaction();
                }
            } catch (Throwable th2) {
            }
        } else {
            this.log.error(String.format("Failed to find package '%1$s'", str));
            return false;
        }
        throw th;
    }

    public List<LaunchEvent> usageLoadNonSyncedLaunchEvents() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE_USAGE, null, "synced = 0", null, null, null, "usageTime");
        while (query.moveToNext()) {
            try {
                LaunchEvent launchEvent = new LaunchEvent();
                launchEvent.setId(query.getInt(0));
                launchEvent.setPackageName(query.getString(1));
                launchEvent.setUsageTime(query.getLong(2));
                launchEvent.setSynced(query.getInt(3) == 1);
                arrayList.add(launchEvent);
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    public void usagePurgeSyncedLaunchEvents() {
        this.mDatabase.delete(DATABASE_TABLE_USAGE, "synced = 1", null);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    public boolean usageUpdateLaunchEventAsSynced(LaunchEvent launchEvent) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("synced", (Integer) 1);
        return this.mDatabase.update(DATABASE_TABLE_USAGE, contentValues, new StringBuilder().append("id = ").append(Integer.toString(launchEvent.getId())).toString(), null) > 0;
    }
}

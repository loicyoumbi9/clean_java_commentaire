package com.getjar.sdk.utilities;

import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class DownloadHelper {
    public static final int BUFFER_SIZE = 2048;
    private Logger log = new Logger(this);
    private byte[] mBuffer = null;
    private String mByteSourceUri = null;
    private int mBytesAlreadyRead = -1;
    private int mBytesTotal = 0;
    public String mErrorMsg = "";
    private String mFileName = null;
    private InputStream mInStream = null;

    public DownloadHelper(String str) throws IOException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'apkUriStr' can not be null or empty");
        }
        this.mByteSourceUri = resolveByteSourceURL(str);
    }

    private String initStream(String str) throws IOException {
        if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'url' can not be null or empty");
        }
        close();
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setReadTimeout(10000);
        httpURLConnection.setInstanceFollowRedirects(false);
        httpURLConnection.connect();
        this.log.debug("download return code:" + httpURLConnection.getResponseCode());
        if (httpURLConnection.getResponseCode() == 301 || httpURLConnection.getResponseCode() == 302 || httpURLConnection.getResponseCode() == 303 || httpURLConnection.getResponseCode() == 307) {
            String headerField = httpURLConnection.getHeaderField("Location");
            this.log.verbose(String.format("Install redirecting to '%1$s'", headerField));
            if (isMarketURL(headerField)) {
                this.log.verbose("Redirect to Android Market Page");
                return headerField;
            }
            this.log.error("Your Download Link is expired.");
            return initStream(headerField);
        }
        this.mBytesTotal = httpURLConnection.getContentLength();
        this.mInStream = httpURLConnection.getInputStream();
        this.mBuffer = new byte[2048];
        return str;
    }

    public static boolean isMarketURL(String str) {
        if (str != null && str.length() > 0) {
            return str.startsWith("market://") || str.startsWith("http://market.android.com/") || str.startsWith("https://market.android.com/");
        }
        throw new IllegalArgumentException("'url' can not be null or empty");
    }

    private String resolveByteSourceURL(String str) throws IOException {
        if (str == null || str.length() <= 0) {
            throw new IllegalArgumentException("'apkUriStr' can not be null or empty");
        } else if (isMarketURL(str)) {
            return str;
        } else {
            try {
                this.mFileName = new URL(str).getFile();
                String initStream = initStream(str);
                try {
                    if (isMarketURL(initStream)) {
                        return initStream;
                    }
                    this.mBytesAlreadyRead = this.mInStream.read(this.mBuffer, 0, 2048);
                    if (this.mBytesAlreadyRead == -1) {
                        throw new IOException(String.format("Failed to get any content from download URL '%1$s'", str));
                    }
                    String trim = new String(this.mBuffer, 0, this.mBytesAlreadyRead, Constants.ENCODING_CHARSET).trim();
                    if (!isMarketURL(trim)) {
                        new URL(trim);
                    }
                    try {
                        Log.v("SDK", String.format("The install URL '%1$s' returned a byte source URL of '%2$s'", str, trim));
                        return trim;
                    } catch (MalformedURLException e) {
                        return trim;
                    }
                } catch (MalformedURLException e2) {
                    return initStream;
                }
            } catch (MalformedURLException e3) {
                return str;
            }
        }
    }

    public void close() throws IOException {
        if (this.mInStream != null) {
            try {
                this.mInStream.close();
            } catch (Throwable th) {
            }
        }
        this.mInStream = null;
        this.mBuffer = null;
    }

    /* access modifiers changed from: protected */
    public void finalize() {
        try {
            super.finalize();
        } catch (Throwable th) {
        }
        try {
            close();
        } catch (Throwable th2) {
        }
    }

    public byte[] getBuffer() {
        return this.mBuffer;
    }

    public String getByteSourceUri() {
        return this.mByteSourceUri;
    }

    public int getBytesAlreadyRead() {
        return this.mBytesAlreadyRead;
    }

    public int getBytesTotal() {
        return this.mBytesTotal;
    }

    public String getFileName() {
        return this.mFileName;
    }

    public InputStream getInStream() {
        return this.mInStream;
    }

    public void init() throws MalformedURLException, IOException {
        initStream(this.mByteSourceUri);
    }
}

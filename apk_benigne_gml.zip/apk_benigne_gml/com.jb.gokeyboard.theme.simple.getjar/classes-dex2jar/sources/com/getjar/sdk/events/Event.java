package com.getjar.sdk.events;

public class Event {
    private long eventTime = System.currentTimeMillis();
    private EventTypes eventType;
    private int id;
    private String packageName;
    private boolean synced;

    public enum EventTypes {
        INSTALL,
        OPEN
    }

    public long getEventTime() {
        return this.eventTime;
    }

    public EventTypes getEventType() {
        return this.eventType;
    }

    public int getId() {
        return this.id;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public boolean isSynced() {
        return this.synced;
    }

    public void setEventTime(long j) {
        this.eventTime = j;
    }

    public void setEventType(EventTypes eventTypes) {
        this.eventType = eventTypes;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setPackageName(String str) {
        this.packageName = str;
    }

    public void setSynced(boolean z) {
        this.synced = z;
    }
}

package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.net.URI;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

public class Operation implements Future<Result> {
    private static long _PriorityPromotionIntervalInMilliseconds = 60000;
    private final CommContext _commContext;
    private final long _createdTimestamp;
    private Exception _exception = null;
    private volatile FutureTask<Result> _future = null;
    private long _lastPriorityPromotionTimestamp;
    private int _priority;
    private final Request _request;
    private Result _result = null;
    private int _retryAfterCount = 0;
    private long _retryAfterTimestamp;
    private final ServiceContextInterface _serviceContextCallbacks;
    private final Priority _startingPriority;
    private Status _state = Status.CREATED;
    private final boolean _suppressInternalCallbacks;

    public enum Priority {
        LOW(10),
        MEDIUM(7),
        HIGH(3);
        
        private int _value;

        private Priority(int i) {
            this._value = i;
        }

        public int getValue() {
            return this._value;
        }
    }

    public enum Status {
        CREATED,
        WAITING,
        RUNNING,
        RETRYING,
        CANCELLED,
        COMPLETED
    }

    protected Operation(Request.ServiceName serviceName, String str, URI uri, Request.HttpMethod httpMethod, Map<String, String> map, Priority priority, CommContext commContext, ServiceContextInterface serviceContextInterface, boolean z) {
        if (serviceName == null) {
            throw new IllegalArgumentException("'serviceName' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'requestType' can not be NULL or empty");
        } else if (priority == null) {
            throw new IllegalArgumentException("'priority' can not be NULL");
        } else if (uri == null) {
            throw new IllegalArgumentException("'requestUri' can not be NULL");
        } else if (httpMethod == null) {
            throw new IllegalArgumentException("'httpMethod' can not be NULL");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        } else if (serviceContextInterface == null) {
            throw new IllegalArgumentException("'serviceContextCallbacks' can not be NULL");
        } else if (map == null || Request.HttpMethod.POST.equals(httpMethod)) {
            this._startingPriority = priority;
            this._commContext = commContext;
            this._suppressInternalCallbacks = z;
            this._serviceContextCallbacks = serviceContextInterface;
            this._priority = priority.getValue();
            this._createdTimestamp = System.currentTimeMillis();
            this._lastPriorityPromotionTimestamp = this._createdTimestamp;
            this._exception = null;
            this._state = Status.CREATED;
            this._request = new Request(serviceName, str, uri, httpMethod, map);
        } else {
            throw new IllegalArgumentException("'postData' can only be provided for requests of method type \"POST\"");
        }
    }

    public boolean cancel(boolean z) {
        return CommManager.getInstance().cancelRequest(this);
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            throw new IllegalArgumentException("'object' can not be NULL");
        } else if (!(obj instanceof Operation)) {
            return false;
        } else {
            return this._request.equals(((Operation) obj)._request);
        }
    }

    @Override // java.util.concurrent.Future
    public Result get() throws InterruptedException, ExecutionException {
        try {
            return CommManager.getInstance().waitOnOperation(this);
        } catch (InterruptedException e) {
            throw e;
        } catch (Exception e2) {
            throw new ExecutionException(e2);
        }
    }

    @Override // java.util.concurrent.Future
    @Deprecated
    public Result get(long j, TimeUnit timeUnit) throws InterruptedException, ExecutionException, TimeoutException {
        throw new UnsupportedOperationException("Not supported. Use get() instead.");
    }

    public CommContext getCommContext() {
        return this._commContext;
    }

    public long getCreatedTimestamp() {
        return this._createdTimestamp;
    }

    public Exception getException() {
        return this._exception;
    }

    /* access modifiers changed from: protected */
    public FutureTask<Result> getFuture() {
        return this._future;
    }

    public int getId() {
        return this._request.getId();
    }

    public long getLastPriorityPromotionTimestamp() {
        return this._lastPriorityPromotionTimestamp;
    }

    public int getPriority() {
        return this._priority;
    }

    public Request getRequest() {
        return this._request;
    }

    public Result getResult() {
        return this._result;
    }

    /* access modifiers changed from: protected */
    public int getRetryAfterCount() {
        return this._retryAfterCount;
    }

    /* access modifiers changed from: protected */
    public long getRetryAfterTimestamp() {
        return this._retryAfterTimestamp;
    }

    public ServiceContextInterface getServiceContextCallbacks() {
        return this._serviceContextCallbacks;
    }

    public Priority getStartingPriority() {
        return this._startingPriority;
    }

    public Status getState() {
        return this._state;
    }

    public boolean getSuppressInternalCallbacks() {
        return this._suppressInternalCallbacks;
    }

    public int hashCode() {
        return this._request.hashCode();
    }

    public boolean isCancelled() {
        return this._state == Status.CANCELLED;
    }

    public boolean isDone() {
        return this._state == Status.CANCELLED || this._state == Status.COMPLETED;
    }

    /* access modifiers changed from: protected */
    public void mapResultToCallbacks(CallbackInterface callbackInterface) throws ServicesException, JSONException {
        Result result;
        try {
            result = get();
            e = null;
        } catch (Exception e) {
            e = e;
            result = null;
        }
        if (result != null) {
            StatisticsTracker.logResponse(this);
            if (isCancelled()) {
                String num = Integer.toString(getId());
                CommContext commContext = getCommContext();
                callbackInterface.serviceRequestFailed(new RequestCancelledException(String.format("Request %1$s on CommContext %2$s was canceled", num, commContext)), num, commContext);
                return;
            }
            ServicesException servicesException = RequestUtilities.getServicesException(result);
            if (servicesException != null) {
                callbackInterface.serviceRequestFailed(servicesException, Integer.toString(getId()), getCommContext());
            } else if (result.getResponseCode() != 200) {
                callbackInterface.serviceRequestFailed(new RuntimeException(String.format("Non-200 response from request [response code: %1$d] [response body: %2$s]", Integer.valueOf(result.getResponseCode()), result.getResponseBody() != null ? result.getResponseBody() : "")), Integer.toString(getId()), getCommContext());
            } else {
                callbackInterface.serviceRequestSucceeded(result, Integer.toString(getId()), getCommContext());
            }
        } else if (getException() != null) {
            callbackInterface.serviceRequestFailed(getException(), Integer.toString(getId()), getCommContext());
        } else if (e != null) {
            callbackInterface.serviceRequestFailed(e, Integer.toString(getId()), getCommContext());
        }
    }

    /* access modifiers changed from: protected */
    public void promotePriority() {
        if (this._priority > 1) {
            if (System.currentTimeMillis() - this._lastPriorityPromotionTimestamp >= _PriorityPromotionIntervalInMilliseconds) {
                Log.v(Constants.TAG, String.format("Operation: promotePriority() BEFORE Promoting request %1$d [priority:%2$d lastPriorityPromotionTimestamp:%3$d]", Integer.valueOf(getId()), Integer.valueOf(this._priority), Long.valueOf(this._lastPriorityPromotionTimestamp)));
                this._lastPriorityPromotionTimestamp = System.currentTimeMillis();
                this._priority--;
                Log.v(Constants.TAG, String.format("Operation: promotePriority() AFTER Promoted request %1$d [priority:%2$d lastPriorityPromotionTimestamp:%3$d]", Integer.valueOf(getId()), Integer.valueOf(this._priority), Long.valueOf(this._lastPriorityPromotionTimestamp)));
            }
        }
    }

    public void setException(Exception exc) {
        this._exception = exc;
    }

    /* access modifiers changed from: protected */
    public void setFuture(FutureTask<Result> futureTask) {
        if (futureTask == null) {
            throw new IllegalArgumentException("'future' can not be NULL");
        }
        this._future = futureTask;
    }

    public void setResult(Result result) {
        if (result == null) {
            throw new IllegalArgumentException("'result' can not be NULL");
        }
        this._result = result;
    }

    /* access modifiers changed from: protected */
    public void setState(Status status) {
        if (status == null) {
            throw new IllegalArgumentException("'state' can not be NULL");
        }
        this._state = status;
    }

    /* access modifiers changed from: protected */
    public void tickRetryAfterCount() {
        this._retryAfterCount++;
    }

    /* access modifiers changed from: protected */
    public void updateRetryAfterTimestamp(long j) {
        this._retryAfterTimestamp = System.currentTimeMillis() + j;
    }
}

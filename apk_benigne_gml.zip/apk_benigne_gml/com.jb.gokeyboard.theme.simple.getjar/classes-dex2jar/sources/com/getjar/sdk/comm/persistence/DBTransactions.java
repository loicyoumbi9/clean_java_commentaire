package com.getjar.sdk.comm.persistence;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import com.getjar.sdk.utilities.Base64;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DBTransactions extends SQLiteOpenHelper {
    private static final String DATABASE_CREATE = "CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, clientTransactionId TEXT NOT NULL UNIQUE, timestampCreated INTEGER NOT NULL, timestampLastUpdated INTEGER NOT NULL, state TEXT NOT NULL, type TEXT NOT NULL, relatedObject TEXT);";
    private static final String DATABASE_NAME = "GetJarDBTransactions";
    private static final String DATABASE_TABLE = "transactions";
    private static final int DATABASE_VERSION = 1;
    private SQLiteDatabase _database = getWritableDatabase();

    public enum EarnState {
        CREATED,
        EARNING,
        DONE
    }

    public enum PurchaseState {
        CREATED,
        RESERVING,
        CANCELING,
        CONFIRMING,
        DONE
    }

    public enum TransactionType {
        PURCHASE,
        EARN
    }

    public DBTransactions(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    private TransactionBucket getTransactionBucketInstance(Cursor cursor) {
        TransactionBucket earnBucket;
        int i = cursor.getInt(0);
        String string = cursor.getString(1);
        int i2 = cursor.getInt(2);
        int i3 = cursor.getInt(3);
        String string2 = cursor.getString(4);
        TransactionType transactionType = (TransactionType) Enum.valueOf(TransactionType.class, cursor.getString(5));
        String string3 = cursor.getString(6);
        if (TransactionType.PURCHASE.equals(transactionType)) {
            earnBucket = new PurchaseUnmanagedBucket();
        } else if (TransactionType.EARN.equals(transactionType)) {
            earnBucket = new EarnBucket();
        } else {
            throw new IllegalStateException(String.format("Unrecognized transaction type '%1$s'", transactionType.name()));
        }
        earnBucket.setClientTransactionId(string);
        earnBucket.setDatabaseId(i);
        earnBucket.setSerializedRelatedObject(string3);
        earnBucket.setStateString(string2);
        earnBucket.setTimestampCreated((long) i2);
        earnBucket.setTimestampLastUpdated((long) i3);
        earnBucket.setType(transactionType);
        return earnBucket;
    }

    private boolean insertTransaction(String str, Serializable serializable, String str2) throws IOException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        } else if (checkForRecord(str)) {
            throw new IllegalStateException(String.format("A record with a client transaction ID of '%1$s' already exists in the database", str));
        } else {
            ContentValues contentValues = new ContentValues();
            contentValues.put("clientTransactionId", str);
            if (serializable == null) {
                contentValues.putNull("relatedObject");
            } else {
                contentValues.put("relatedObject", Base64.encodeObject(serializable));
            }
            contentValues.put("state", PurchaseState.CREATED.name());
            contentValues.put("type", str2);
            long currentTimeMillis = System.currentTimeMillis();
            contentValues.put("timestampCreated", Long.valueOf(currentTimeMillis));
            contentValues.put("timestampLastUpdated", Long.valueOf(currentTimeMillis));
            return this._database.insert(DATABASE_TABLE, null, contentValues) != -1;
        }
    }

    private boolean updateTransaction(TransactionBucket transactionBucket, String str) {
        boolean z = false;
        if (transactionBucket == null) {
            throw new IllegalArgumentException("'transaction' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(transactionBucket.getClientTransactionId())) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'state' can not be NULL or empty");
        } else {
            long currentTimeMillis = System.currentTimeMillis();
            ContentValues contentValues = new ContentValues();
            contentValues.put("timestampLastUpdated", Long.valueOf(currentTimeMillis));
            contentValues.put("state", str);
            if (this._database.update(DATABASE_TABLE, contentValues, "clientTransactionId = ?", new String[]{transactionBucket.getClientTransactionId()}) > 0) {
                z = true;
            }
            if (z) {
                transactionBucket.setStateString(str);
                transactionBucket.setTimestampLastUpdated(currentTimeMillis);
            }
            return z;
        }
    }

    public boolean checkForRecord(String str) {
        boolean z = false;
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        }
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s WHERE clientTransactionId = ?", DATABASE_TABLE));
        try {
            compileStatement.bindString(1, str);
            if (compileStatement.simpleQueryForLong() > 0) {
                z = true;
            }
            try {
            } catch (Exception e) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e);
            }
            return z;
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e2) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e2);
            }
        }
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this._database.close();
    }

    public boolean deleteTransaction(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        }
        return this._database.delete(DATABASE_TABLE, "clientTransactionId = ?", new String[]{str}) > 0;
    }

    public long getRecordCount() {
        SQLiteStatement compileStatement = this._database.compileStatement(String.format("SELECT count(*) FROM %1$s", DATABASE_TABLE));
        try {
            long simpleQueryForLong = compileStatement.simpleQueryForLong();
            try {
            } catch (Exception e) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e);
            }
            return simpleQueryForLong;
        } finally {
            try {
                compileStatement.close();
            } catch (Exception e2) {
                Log.e(Constants.TAG, "SQLiteStatement.close() failed", e2);
            }
        }
    }

    public boolean insertEarnTransaction(String str, Serializable serializable) throws IOException {
        return insertTransaction(str, serializable, TransactionType.EARN.name());
    }

    public boolean insertPurchaseTransaction(String str, Serializable serializable) throws IOException {
        return insertTransaction(str, serializable, TransactionType.PURCHASE.name());
    }

    public List<TransactionBucket> loadAllTransactions() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this._database.query(DATABASE_TABLE, null, null, null, null, null, "timestampCreated ASC");
        while (query.moveToNext()) {
            try {
                arrayList.add(getTransactionBucketInstance(query));
            } catch (Throwable th) {
            }
        }
        try {
            query.close();
            return arrayList;
        } catch (Throwable th2) {
            return arrayList;
        }
        throw th;
    }

    public TransactionBucket loadTransaction(String str) {
        Cursor query = this._database.query(DATABASE_TABLE, null, "clientTransactionId = ?", new String[]{str}, null, null, null);
        if (query.moveToNext()) {
            return getTransactionBucketInstance(query);
        }
        return null;
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(DATABASE_CREATE);
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        Log.d(Constants.TAG, String.format("Upgrading database from version %1$d to %2$d, which will destroy all old data", Integer.valueOf(i), Integer.valueOf(i2)));
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS transactions");
        onCreate(sQLiteDatabase);
    }

    public boolean updateEarnTransaction(EarnBucket earnBucket, EarnState earnState) {
        return updateTransaction(earnBucket, earnState.name());
    }

    public boolean updatePurchaseTransaction(PurchaseUnmanagedBucket purchaseUnmanagedBucket, PurchaseState purchaseState) {
        return updateTransaction(purchaseUnmanagedBucket, purchaseState.name());
    }
}

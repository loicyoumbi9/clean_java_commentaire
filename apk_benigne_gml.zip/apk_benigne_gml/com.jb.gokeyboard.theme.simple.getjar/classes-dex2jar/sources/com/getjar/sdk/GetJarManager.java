package com.getjar.sdk;

import android.content.Context;
import android.os.ResultReceiver;
import com.getjar.sdk.comm.CommManager;

public class GetJarManager {
    private GetJarManager() {
    }

    public static GetJarContext createContext(String str, Context context, ResultReceiver resultReceiver) throws InterruptedException {
        return new GetJarContext(CommManager.createContext(str, context, resultReceiver, true));
    }

    public static GetJarContext retrieveContext(String str) {
        return new GetJarContext(CommManager.retrieveContext(str));
    }
}

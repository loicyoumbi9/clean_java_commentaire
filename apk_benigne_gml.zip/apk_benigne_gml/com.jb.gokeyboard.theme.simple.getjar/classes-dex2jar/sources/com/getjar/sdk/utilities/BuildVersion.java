package com.getjar.sdk.utilities;

public final class BuildVersion {
    public static final String BUILD_VERSION = "20120921.02";
}

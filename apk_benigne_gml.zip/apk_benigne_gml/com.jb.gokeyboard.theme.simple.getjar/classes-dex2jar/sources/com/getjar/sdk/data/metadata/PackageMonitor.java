package com.getjar.sdk.data.metadata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.CommManager;
import com.getjar.sdk.comm.GetJarConfig;
import com.getjar.sdk.comm.TransactionManager;
import com.getjar.sdk.comm.persistence.EarnBucket;
import com.getjar.sdk.comm.persistence.TransactionBucket;
import com.getjar.sdk.data.DBAdapterAppData;
import com.getjar.sdk.data.ReportManager;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.utilities.AlarmsUtility;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

public class PackageMonitor extends BroadcastReceiver {
    public static final int MAX_EARN_RETRIES = 3;
    public static int mEarnRetries = 0;
    private Context mContext;

    private void checkForAndHandleManagedEvents(Context context, Intent intent, CommContext commContext, Constants.AppType appType, boolean z) {
        boolean z2;
        DBAdapterAppData dBAdapterAppData;
        DBAdapterAppData dBAdapterAppData2;
        Log.d(Constants.TAG, "PackageMonitor: checkForAndHandleManagedEvents()");
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be null");
        } else if (intent == null) {
            throw new IllegalArgumentException("'intent' can not be null");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be null");
        } else {
            try {
                String action = intent.getAction();
                String packageNameFromBroadcastIntent = Utility.getPackageNameFromBroadcastIntent(intent);
                if ("android.intent.action.PACKAGE_ADDED".equals(action) || "android.intent.action.PACKAGE_REPLACED".equals(action)) {
                    Log.d(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: Handling action '%1$s' for '%2$s'", action, packageNameFromBroadcastIntent));
                    try {
                        boolean isPreInstallRewardApplication = RewardUtility.isPreInstallRewardApplication(context, packageNameFromBroadcastIntent);
                        Log.d(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: Host app %1$s %2$s managing an event for %3$s", context.getPackageName(), isPreInstallRewardApplication ? "is" : "is NOT", packageNameFromBroadcastIntent));
                        if (appType == Constants.AppType.GREENJAR_CLIENT || !z) {
                            AppData applicationInfo = Utility.getApplicationInfo(context, packageNameFromBroadcastIntent, AppData.AppStatus.INSTALLED);
                            dBAdapterAppData = new DBAdapterAppData(context);
                            dBAdapterAppData.appDataUpsert(applicationInfo);
                            dBAdapterAppData.close();
                        }
                        Utility.savePackageNameInstallEntry(context, packageNameFromBroadcastIntent);
                        if (isPreInstallRewardApplication) {
                            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageNameFromBroadcastIntent, 128);
                            try {
                                z2 = (packageInfo.applicationInfo.flags & 1) == 1;
                            } catch (Exception e) {
                                z2 = false;
                            }
                            Log.v(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: [packageName: %1$s] [action: %2$s] [isSystemApp: %3$s]", packageNameFromBroadcastIntent, action, Boolean.toString(z2)));
                            String appMetadataString = RewardUtility.getAppMetadataString(context, packageNameFromBroadcastIntent);
                            HashMap<String, String> jsonArrayStringToMap = Utility.jsonArrayStringToMap(appMetadataString);
                            Log.d(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: application metadata size: %1$d", Integer.valueOf(jsonArrayStringToMap.size())));
                            String str = null;
                            if (jsonArrayStringToMap.size() > 0) {
                                str = jsonArrayStringToMap.get(Constants.META_ITEM_ID);
                                Log.d(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: app id: %1$s", str));
                                jsonArrayStringToMap.put(Constants.META_DEVICE_PLATFORM, "android");
                                jsonArrayStringToMap.put(Constants.META_DEVICE_PLATFORM_VERSION, Build.VERSION.RELEASE);
                                jsonArrayStringToMap.put(Constants.META_PACKAGE_VERSION_CODE, Integer.toString(packageInfo.versionCode));
                                jsonArrayStringToMap.put(Constants.META_PACKAGE_VERSION_NAME, packageInfo.versionName);
                                JSONObject jSONObject = new JSONObject(jsonArrayStringToMap);
                                if (jSONObject.length() > 0) {
                                    JSONArray jSONArray = new JSONArray();
                                    jSONArray.put(jSONObject);
                                    appMetadataString = jSONArray.toString();
                                }
                            }
                            RewardUtility.savePreInstallRewardApplicationMetadata(context, packageNameFromBroadcastIntent + Constants.RequestInstallType.SUFFIX_APP_ID, str);
                            RewardUtility.savePreInstallRewardApplicationMetadata(context, packageNameFromBroadcastIntent + Constants.APPDATA_SUFFIX, appMetadataString);
                            RewardUtility.savePreInstallRewardApplicationMetadata(context, packageNameFromBroadcastIntent + Constants.RequestInstallType.SUFFIX_STATE, Constants.RequestInstallState.INSTALL.toString());
                            if (Constants.RequestInstallType.EARN.toString().equals(RewardUtility.getRequestInstallType(context, packageNameFromBroadcastIntent)) && !z2) {
                                Log.v(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: Triggering Earn logic from action: %1$s", action));
                                earn(context, commContext, packageNameFromBroadcastIntent);
                            }
                        }
                    } catch (Exception e2) {
                        Log.e(Constants.TAG, "PackageMonitor: checkForAndHandleManagedEvents: failed", e2);
                    } catch (Throwable th) {
                        dBAdapterAppData.close();
                        throw th;
                    }
                    Log.d(Constants.TAG, "PackageMonitor: checkForAndHandleManagedEvents: DONE");
                }
                if ("android.intent.action.PACKAGE_REMOVED".equals(action)) {
                    Log.d(Constants.TAG, String.format("PackageMonitor: checkForAndHandleManagedEvents: Handling action '%1$s' for '%2$s'", action, packageNameFromBroadcastIntent));
                    if (appType == Constants.AppType.GREENJAR_CLIENT || !z) {
                        dBAdapterAppData2 = new DBAdapterAppData(context);
                        dBAdapterAppData2.appDataUpdateStatus(packageNameFromBroadcastIntent, AppData.AppStatus.UNINSTALLED);
                        dBAdapterAppData2.close();
                    }
                }
                Log.d(Constants.TAG, "PackageMonitor: checkForAndHandleManagedEvents: DONE");
            } catch (Throwable th2) {
                Log.e(Constants.TAG, "PackageMonitor: checkForAndHandleManagedEvents: failed", th2);
            }
        }
    }

    /* access modifiers changed from: private */
    public void doOnReceive(Context context, Intent intent) {
        try {
            Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): START");
            if (context == null) {
                throw new IllegalArgumentException("'context' cannot be null");
            } else if (intent == null) {
                throw new IllegalArgumentException("'intent' cannot be null");
            } else {
                this.mContext = context;
                Utility.previousVersionCleanUp(context);
                String applicationKey = Utility.getApplicationKey(context);
                if (StringUtility.isNullOrEmpty(applicationKey)) {
                    throw new IllegalStateException("Unable to access the application key");
                }
                CommContext createContext = CommManager.createContext(applicationKey, context, new ResultReceiver(null) {
                    /* class com.getjar.sdk.data.metadata.PackageMonitor.AnonymousClass2 */

                    /* access modifiers changed from: protected */
                    public void onReceiveResult(int i, Bundle bundle) {
                        Iterator<String> it = bundle.keySet().iterator();
                        while (it.hasNext()) {
                            Log.d(Constants.TAG, String.format("PackageMonitor: Callback from the GetJar SDK [%1$s]", bundle.get(it.next()).getClass().getName()));
                        }
                    }
                }, false);
                Bundle extras = intent.getExtras();
                if (createContext != null && !StringUtility.isNullOrEmpty(createContext.getAuthToken()) && shouldRetryTransactions(context, createContext)) {
                    runPendingEarnTransactionsAndCleanup(createContext, context);
                }
                Constants.AppType appType = Utility.getAppType(this.mContext);
                boolean isExistApp = Utility.isExistApp(this.mContext, Constants.GREENJAR_PACKAGE);
                if (extras == null || StringUtility.isNullOrEmpty(extras.getString(Constants.COLLECT_DATA))) {
                    if (extras != null) {
                        if (!StringUtility.isNullOrEmpty(extras.getString(Constants.USAGE_TRACKING))) {
                            if (appType == Constants.AppType.GREENJAR_CLIENT) {
                                AlarmsUtility.updateLastRunTimestampUsageReporting(this.mContext);
                                new ReportManager(this.mContext, createContext).sendUnsyncedUsageData();
                                Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): *** SENT USAGE DATA ***");
                            }
                        }
                    }
                    if (extras == null || StringUtility.isNullOrEmpty(extras.getString(Constants.EVENTS_REPORT))) {
                        String action = intent.getAction();
                        if (action != null) {
                            boolean booleanExtra = intent.getBooleanExtra("android.intent.extra.REPLACING", false);
                            Log.d(Constants.TAG, String.format("PackageMonitor: doOnReceive(): %1$s [%2$s] REPLACING:%3$s", action, Utility.getPackageNameFromBroadcastIntent(intent), Boolean.valueOf(booleanExtra)));
                            if (("android.intent.action.PACKAGE_ADDED".equals(action) || "android.intent.action.PACKAGE_REMOVED".equals(action)) && !booleanExtra) {
                                checkForAndHandleManagedEvents(this.mContext, intent, createContext, appType, isExistApp);
                                new ReportManager(this.mContext, createContext).sendUnsyncedEventData();
                                Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): *** SENT APP EVENT DATA (INSTALLED / UNINSTALLED) ***");
                            }
                        }
                    } else if (appType == Constants.AppType.GREENJAR_CLIENT || !isExistApp) {
                        AlarmsUtility.updateLastRunTimestampEventReporting(this.mContext);
                        new ReportManager(this.mContext, createContext).sendInstalledApps();
                        Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): *** SENT INSTALLED APPS DATA ***");
                    }
                } else if (appType == Constants.AppType.GREENJAR_CLIENT) {
                    AlarmsUtility.updateLastRunTimestampCollectUsage(this.mContext);
                    new ReportManager(this.mContext, createContext).doStatsWork();
                    Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): *** COLLECTED USAGE DATA ***");
                }
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, "PackageMonitor: doOnReceive(): failed", e);
        } finally {
            Log.d(Constants.TAG, "PackageMonitor: doOnReceive(): FINISHED");
        }
    }

    private void earn(Context context, CommContext commContext, String str) throws Exception {
        Log.d(Constants.TAG, "PackageMonitor: earn()");
        String uuid = UUID.randomUUID().toString();
        HashMap<String, String> trackingMetadata = RewardUtility.getTrackingMetadata(context, str);
        HashMap<String, String> appMetadata = RewardUtility.getAppMetadata(context, str);
        Log.d(Constants.TAG, String.format("PackageMonitor: Sending Earn transaction [clientTransactionId: %1$s]", uuid));
        new TransactionManager(context).runEarnTransaction(uuid, commContext, appMetadata.get(Constants.META_ITEM_ID), str, appMetadata, trackingMetadata);
    }

    private void runPendingEarnTransactionsAndCleanup(CommContext commContext, Context context) throws Exception {
        Log.d(Constants.TAG, "PackageMonitor: runPendingEarnTransactionsAndCleanup()");
        List<TransactionBucket> runEarnTransactions = new TransactionManager(this.mContext).runEarnTransactions(commContext);
        Map<String, ?> defaultSharedPrefsMap = RewardUtility.getDefaultSharedPrefsMap(context);
        Iterator<TransactionBucket> it = runEarnTransactions.iterator();
        while (it.hasNext()) {
            String packageName = ((EarnBucket) it.next()).getRelatedObject().getPackageName();
            if (shouldDeleteTransaction(commContext, defaultSharedPrefsMap, packageName)) {
                RewardUtility.removeSPEntry(context.getSharedPreferences(RewardUtility._PreferencesInstalledAppFileName, 0).edit(), packageName);
            }
        }
    }

    private boolean shouldDeleteTransaction(CommContext commContext, Map<String, ?> map, String str) {
        Log.d(Constants.TAG, "PackageMonitor: shouldDeleteTransaction()");
        try {
            long currentTimeMillis = System.currentTimeMillis();
            long parseLong = Long.parseLong((String) map.get(str + Constants.APPDATA_TIMESTAMP_SUFFIX));
            long convertMillSec = Utility.convertMillSec(Long.parseLong(GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_FAIL_ABANDON_TIME)));
            Log.d(Constants.TAG, String.format("PackageMonitor: shouldDeleteTransaction: [currentTime: %1$d] [transactionCreatedTime: %2$d] [timeoutInterval: %3$d]", Long.valueOf(currentTimeMillis), Long.valueOf(parseLong), Long.valueOf(convertMillSec)));
            return currentTimeMillis - parseLong >= convertMillSec;
        } catch (Exception e) {
            Log.e(Constants.TAG, "PackageMonitor: shouldDeleteTransaction() failed", e);
            return false;
        }
    }

    private boolean shouldRetryTransactions(Context context, CommContext commContext) {
        Log.d(Constants.TAG, "PackageMonitor: shouldRetryTransactions()");
        if (commContext == null) {
            return false;
        }
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.TIMESTAMP, 0);
            long currentTimeMillis = System.currentTimeMillis();
            long j = sharedPreferences.getLong(Constants.TRANSACTIONTIME, 0);
            long j2 = currentTimeMillis - j;
            long convertMillSec = Utility.convertMillSec(Long.parseLong(GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_TRANSACTION_FAIL_RETRY_INTERVAL)));
            Log.d(Constants.TAG, String.format("PackageMonitor: shouldRetryTransactions: [lastRetryTime: %1$d] [currentTime: %2$d] [delta: %3$d] [minimumDelta: %4$d]", Long.valueOf(j), Long.valueOf(currentTimeMillis), Long.valueOf(j2), Long.valueOf(convertMillSec)));
            if (j2 < convertMillSec) {
                return false;
            }
            sharedPreferences.edit().putLong(Constants.TRANSACTIONTIME, System.currentTimeMillis()).commit();
            return true;
        } catch (Exception e) {
            Log.e(Constants.TAG, "PackageMonitor: shouldRetryTransactions() failed", e);
            return false;
        }
    }

    public void onReceive(final Context context, final Intent intent) {
        Log.d(Constants.TAG, "PackageMonitor: onReceive(): START");
        if (Utility.isCurrentThreadTheUIThread()) {
            Log.d(Constants.TAG, "PackageMonitor: onReceive(): called from the UI thread, starting a worker thread...");
            new Thread(new Runnable() {
                /* class com.getjar.sdk.data.metadata.PackageMonitor.AnonymousClass1 */

                public void run() {
                    PackageMonitor.this.doOnReceive(context, intent);
                }
            }, "PackageMonitor Worker Thread").start();
            return;
        }
        doOnReceive(context, intent);
    }
}

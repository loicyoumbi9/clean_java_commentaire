package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class ServiceProxyBase {
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String USER_AGENT_HEADER = "User-Agent";
    private ServiceContextInterface _serviceProxyContextInterface = new ServiceContextInterface() {
        /* class com.getjar.sdk.comm.ServiceProxyBase.AnonymousClass2 */

        @Override // com.getjar.sdk.comm.ServiceContextInterface
        public boolean checkIfOperationShouldBeRetried(CommContext commContext, Result result, int i, int i2) throws JSONException {
            return ServiceProxyBase.this.checkIfOperationShouldBeRetried(commContext, result, i, i2);
        }

        @Override // com.getjar.sdk.comm.ServiceContextInterface
        public void preRequestWork(Operation operation) throws Exception {
            ServiceProxyBase.this.preRequestWork(operation);
        }
    };

    protected static String epochToISO8601(long j) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        gregorianCalendar.setTimeInMillis(j);
        return String.format("%1$04d-%2$02d-%3$02dT%4$02d:%5$02d:%6$02dZ", Integer.valueOf(gregorianCalendar.get(1)), Integer.valueOf(gregorianCalendar.get(2) + 1), Integer.valueOf(gregorianCalendar.get(5)), Integer.valueOf(gregorianCalendar.get(11)), Integer.valueOf(gregorianCalendar.get(12)), Integer.valueOf(gregorianCalendar.get(13)));
    }

    /* JADX WARN: Type inference failed for: r6v0, types: [java.util.Map<java.lang.String, java.lang.String>, java.util.Map] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String mapToJsonString(java.util.Map<java.lang.String, java.lang.String> r6) throws org.json.JSONException {
        /*
            org.json.JSONArray r1 = new org.json.JSONArray
            r1.<init>()
            java.util.Set r0 = r6.entrySet()
            java.util.Iterator r2 = r0.iterator()
        L_0x000d:
            boolean r0 = r2.hasNext()
            if (r0 == 0) goto L_0x0046
            java.lang.Object r0 = r2.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            org.json.JSONObject r3 = new org.json.JSONObject
            r3.<init>()
            java.lang.String r4 = "key"
            java.lang.Object r5 = r0.getKey()
            r3.put(r4, r5)
            java.lang.String r4 = "value"
            java.lang.Object r5 = r0.getValue()
            r3.put(r4, r5)
            java.lang.Object r4 = r0.getValue()
            if (r4 != 0) goto L_0x0041
            java.lang.Object r0 = org.json.JSONObject.NULL
        L_0x0038:
            java.lang.String r4 = "value"
            r3.put(r4, r0)
            r1.put(r3)
            goto L_0x000d
        L_0x0041:
            java.lang.Object r0 = r0.getValue()
            goto L_0x0038
        L_0x0046:
            java.lang.String r0 = r1.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.ServiceProxyBase.mapToJsonString(java.util.Map):java.lang.String");
    }

    private void mapWaitToCallbacks(final Operation operation, final CallbackInterface callbackInterface) {
        new Thread(new Runnable() {
            /* class com.getjar.sdk.comm.ServiceProxyBase.AnonymousClass1 */

            public void run() {
                try {
                    operation.mapResultToCallbacks(callbackInterface);
                } catch (Exception e) {
                    Log.e(Constants.TAG, "Legacy Callback Mapping Thread failed", e);
                }
            }
        }, "Legacy Callback Mapping Thread").start();
    }

    public static String metadataMapToJsonString(Map<String, MetadataValue> map) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        for (Map.Entry<String, MetadataValue> entry : map.entrySet()) {
            Object value = entry.getValue().getValue();
            JSONObject jSONObject = new JSONObject();
            if (value == null) {
                value = JSONObject.NULL;
            }
            jSONObject.put("value", value);
            jSONObject.put("reliability", entry.getValue().getReliability().name());
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("key", entry.getKey());
            jSONObject2.put("value", jSONObject);
            jSONArray.put(jSONObject2);
        }
        return jSONArray.toString();
    }

    /* access modifiers changed from: protected */
    public abstract boolean checkIfOperationShouldBeRetried(CommContext commContext, Result result, int i, int i2) throws JSONException;

    /* access modifiers changed from: protected */
    public abstract Request.ServiceName getServiceName();

    /* access modifiers changed from: protected */
    public Operation makeAsyncGETRequestForJson(String str, Operation.Priority priority, CommContext commContext, String str2, CallbackInterface callbackInterface, boolean z) {
        if (priority == null) {
            throw new IllegalArgumentException("'priority' can not be NULL");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("'urlStr' can not be NULL or empty");
        } else {
            try {
                URI uri = new URI(str2);
                CommManager.initialize(commContext.getApplicationContext());
                Operation enqueueOperation = CommManager.getInstance().enqueueOperation(getServiceName(), str, uri, Request.HttpMethod.GET, null, priority, commContext, this._serviceProxyContextInterface, false);
                StatisticsTracker.logRequest(enqueueOperation);
                if (callbackInterface != null) {
                    mapWaitToCallbacks(enqueueOperation, callbackInterface);
                }
                return enqueueOperation;
            } catch (URISyntaxException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* access modifiers changed from: protected */
    public Operation makeAsyncPOSTRequestForJson(String str, Operation.Priority priority, CommContext commContext, String str2, Map<String, String> map, CallbackInterface callbackInterface, boolean z) {
        if (priority == null) {
            throw new IllegalArgumentException("'priority' can not be NULL");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("'urlStr' can not be NULL or empty");
        } else {
            try {
                URI uri = new URI(str2);
                CommManager.initialize(commContext.getApplicationContext());
                Operation enqueueOperation = CommManager.getInstance().enqueueOperation(getServiceName(), str, uri, Request.HttpMethod.POST, map, priority, commContext, this._serviceProxyContextInterface, false);
                StatisticsTracker.logRequest(enqueueOperation);
                if (callbackInterface != null) {
                    mapWaitToCallbacks(enqueueOperation, callbackInterface);
                }
                return enqueueOperation;
            } catch (URISyntaxException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* access modifiers changed from: protected */
    public abstract void preRequestWork(Operation operation) throws Exception;
}

package com.getjar.sdk.data;

public class SalesRecord {
    String productid;
    String transactionid;

    public SalesRecord(String str, String str2) {
        this.productid = str;
        this.transactionid = str2;
    }

    public String getProductId() {
        return this.productid;
    }

    public String getTransactionId() {
        return this.transactionid;
    }
}

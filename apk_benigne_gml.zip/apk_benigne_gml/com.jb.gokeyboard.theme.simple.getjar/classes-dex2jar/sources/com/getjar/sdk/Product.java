package com.getjar.sdk;

import android.os.Parcel;
import android.os.Parcelable;
import com.getjar.sdk.utilities.StringUtility;
import org.json.JSONException;
import org.json.JSONObject;

public class Product implements Parcelable {
    public static final Parcelable.Creator<Product> CREATOR = new Parcelable.Creator<Product>() {
        /* class com.getjar.sdk.Product.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public Product createFromParcel(Parcel parcel) {
            return new Product(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public Product[] newArray(int i) {
            return new Product[i];
        }
    };
    private long mProductAmount;
    private String mProductDescription;
    private String mProductId;
    private String mProductName;

    private Product(Parcel parcel) {
        this.mProductId = parcel.readString();
        this.mProductName = parcel.readString();
        this.mProductDescription = parcel.readString();
        this.mProductAmount = parcel.readLong();
    }

    public Product(String str, String str2, String str3, long j) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("need a product id");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException(String.format("product '%s' needs a name", str));
        } else if (j <= 0) {
            throw new IllegalArgumentException(String.format("product '%s' needs an amount greater than zero", str));
        } else {
            this.mProductId = str;
            this.mProductName = str2;
            this.mProductDescription = str3;
            this.mProductAmount = j;
        }
    }

    public int describeContents() {
        return 0;
    }

    public long getAmount() {
        return this.mProductAmount;
    }

    public String getProductDescription() {
        return this.mProductDescription;
    }

    public String getProductId() {
        return this.mProductId;
    }

    public String getProductName() {
        return this.mProductName;
    }

    public JSONObject toJSONObject() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("amount", this.mProductAmount);
        jSONObject.put("product_id", this.mProductId);
        jSONObject.put("product_description", this.mProductDescription);
        jSONObject.put("product_name", this.mProductName);
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mProductId);
        parcel.writeString(this.mProductName);
        parcel.writeString(this.mProductDescription);
        parcel.writeLong(this.mProductAmount);
    }
}

package com.getjar.sdk.comm;

import com.getjar.sdk.comm.Request;
import org.json.JSONException;

public abstract class AuthorizedServiceProxyBase extends ServiceProxyBase {
    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public boolean checkIfOperationShouldBeRetried(CommContext commContext, Result result, int i, int i2) throws JSONException {
        if (result == null) {
            throw new IllegalArgumentException("'result' can not be NULL");
        } else if (i2 >= 2) {
            return false;
        } else {
            return result.checkForUnauthorizedAndOKToReAuth(commContext);
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public abstract Request.ServiceName getServiceName();

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public void preRequestWork(Operation operation) throws Exception {
        operation.getCommContext().waitForAuthorization();
        operation.getCommContext().waitForUserAccess();
    }
}

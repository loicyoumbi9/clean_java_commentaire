package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

public class UserServiceProxy extends AuthorizedServiceProxyBase {
    private static final String _CONTRACT_VERSION = "20120401";
    private static UserServiceProxy _Instance = null;
    private static final String _URL_TEMPLATE_APPLICATION_REPORT_USAGE = String.format("%1$s%2$s", "%1$suser/devices/%2$s/apps/report_usage?version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_DEVICE_ENSURE = String.format("%1$s%2$s", "%1$suser/users/%2$s/devices/ensure?version=", _CONTRACT_VERSION);
    private static final String _USER_DEVICE_TEMPLATE = "{  \"id\":null,  \"modification_timestamp\":null,  \"user_id\":null,  \"creation_timestamp\":null,  \"metadata\":%1$s}";

    private UserServiceProxy() {
    }

    private List<AppUsageData> filterAppUsageDataList(List<AppUsageData> list) {
        ArrayList arrayList = new ArrayList();
        for (AppUsageData appUsageData : list) {
            if ((appUsageData.getAppFlags() & 1) != 1) {
                arrayList.add(appUsageData);
            }
        }
        return arrayList;
    }

    public static UserServiceProxy getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    private static void makeTheInstance() {
        synchronized (UserServiceProxy.class) {
            try {
                if (_Instance == null) {
                    _Instance = new UserServiceProxy();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public String ensureUserDevice(CommContext commContext, CallbackInterface callbackInterface) throws UnsupportedEncodingException, JSONException, InterruptedException, TimeoutException, Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            HashMap hashMap = new HashMap(1);
            hashMap.put("user_device", String.format(_USER_DEVICE_TEMPLATE, commContext.getDeviceMetadataJson()));
            commContext.waitForUserAccess();
            return Integer.toString(makeAsyncPOSTRequestForJson("ensureUserDevice", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_DEVICE_ENSURE, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_USER_SERVICE_ENDPOINT), URLEncoder.encode(commContext.getUserAccessId(), Constants.ENCODING_CHARSET)), hashMap, callbackInterface, false).getId());
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase, com.getjar.sdk.comm.AuthorizedServiceProxyBase
    public Request.ServiceName getServiceName() {
        return Request.ServiceName.USER;
    }

    public String reportApplicationUsage(CommContext commContext, List<AppUsageData> list, CallbackInterface callbackInterface) throws UnsupportedEncodingException, JSONException, InterruptedException, TimeoutException, Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (list == null) {
            throw new IllegalArgumentException("The required parameter 'appUsageList' was not provided");
        } else if (list.size() <= 0) {
            throw new IllegalArgumentException("The required parameter 'appUsageList' contains no data");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            List<AppUsageData> filterAppUsageDataList = filterAppUsageDataList(list);
            Log.d(Constants.TAG, String.format("Filtered usage records to report from %1$d to %2$d", Integer.valueOf(list.size()), Integer.valueOf(filterAppUsageDataList.size())));
            if (filterAppUsageDataList.size() <= 0) {
                String uuid = UUID.randomUUID().toString();
                callbackInterface.serviceRequestSucceeded(null, uuid, commContext);
                return uuid;
            }
            StringBuilder sb = new StringBuilder("");
            Iterator<AppUsageData> it = filterAppUsageDataList.iterator();
            sb.append("[");
            while (it.hasNext()) {
                sb.append(it.next().toJson());
                if (it.hasNext()) {
                    sb.append(",");
                }
            }
            sb.append("]");
            HashMap hashMap = new HashMap(1);
            hashMap.put("app_usage_data", sb.toString());
            commContext.waitForUserDevice();
            return Integer.toString(makeAsyncPOSTRequestForJson("reportApplicationUsage", Operation.Priority.LOW, commContext, String.format(_URL_TEMPLATE_APPLICATION_REPORT_USAGE, GetJarConfig.getInstance(commContext, true).getDirectiveValue(GetJarConfig.KEY_REPORT_USAGE_ENDPOINT), URLEncoder.encode(commContext.getUserDeviceId(), Constants.ENCODING_CHARSET)), hashMap, callbackInterface, true).getId());
        }
    }
}

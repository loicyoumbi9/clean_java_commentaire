package com.getjar.sdk.comm;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import org.json.JSONException;

public class CreateContextWorker implements Runnable {
    private static final String _PrefKeyAuthenticationToken = "authenticationToken";
    private static final String _PrefKeyAuthenticationTokenTimestamp = "authenticationTokenTimestamp";
    private static final String _PrefKeyUserAccessID = "userAccessId";
    private static final String _PrefKeyUserDeviceID = "userDeviceId";
    private Object _asyncMonitorObject = new Object();
    private boolean _asyncWasSignalled = false;
    private CommContext _commContext = null;
    private volatile boolean _isBlacklistedOrUnsupported = false;
    /* access modifiers changed from: private */
    public volatile boolean _isUnauthorizedAndOKToReAuth = false;
    /* access modifiers changed from: private */
    public volatile boolean _isUserAccessFound = false;
    /* access modifiers changed from: private */
    public volatile boolean _isUserAccessValid = false;

    private class UserAccessCreateCallbacks implements CallbackInterface {
        private UserAccessCreateCallbacks() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                commContext.addException(exc);
                CreateContextWorker.this.doCallbackFailedDebugLogging(exc, str, commContext);
                CreateContextWorker.this.checkForBlacklistOrUnsupported(exc, commContext);
            } catch (Exception e) {
                commContext.addException(e);
                e.printStackTrace();
            } finally {
                commContext.setUserAccessInErrorState();
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            try {
                CreateContextWorker.this.doCallbackSucceededDebugLogging(result, str, commContext);
                String access$500 = CreateContextWorker.this.getIdFromReturn(result);
                if (StringUtility.isNullOrEmpty(access$500)) {
                    throw new IllegalStateException("Call to 'user_accesses.create' resulted in a null or empty user access ID");
                }
                commContext.setUserAccessId(access$500);
            } catch (Throwable th) {
                commContext.setUserAccessInErrorState();
                th.printStackTrace();
            }
        }
    }

    private class UserAccessFindCallbacks implements CallbackInterface {
        private UserAccessFindCallbacks() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                commContext.addException(exc);
                boolean unused = CreateContextWorker.this._isUserAccessFound = false;
                CreateContextWorker.this.doCallbackFailedDebugLogging(exc, str, commContext);
                CreateContextWorker.this.checkForBlacklistOrUnsupported(exc, commContext);
            } catch (Exception e) {
                commContext.addException(e);
                e.printStackTrace();
            } finally {
                commContext.setUserAccessInErrorState();
                CreateContextWorker.this.asyncNotify();
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            try {
                CreateContextWorker.this.doCallbackSucceededDebugLogging(result, str, commContext);
                String access$500 = CreateContextWorker.this.getIdFromReturn(result);
                if (!StringUtility.isNullOrEmpty(access$500)) {
                    boolean unused = CreateContextWorker.this._isUserAccessFound = true;
                    commContext.setUserAccessId(access$500);
                } else {
                    boolean unused2 = CreateContextWorker.this._isUserAccessFound = false;
                    commContext.setUserAccessNotFoundState();
                }
            } catch (Throwable th) {
                commContext.addException(th);
                commContext.setUserAccessInErrorState();
                th.printStackTrace();
            } finally {
                CreateContextWorker.this.asyncNotify();
            }
        }
    }

    private class UserAccessValidateCallbacks implements CallbackInterface {
        private UserAccessValidateCallbacks() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            Result requestResult;
            try {
                boolean unused = CreateContextWorker.this._isUserAccessValid = false;
                CreateContextWorker.this.doCallbackFailedDebugLogging(exc, str, commContext);
                if ((exc instanceof ServicesException) && (requestResult = ((ServicesException) exc).getRequestResult()) != null) {
                    boolean unused2 = CreateContextWorker.this._isUnauthorizedAndOKToReAuth = requestResult.checkForUnauthorizedAndOKToReAuth(commContext);
                }
                if (!CreateContextWorker.this._isUnauthorizedAndOKToReAuth) {
                    commContext.setUserAccessInErrorState();
                    commContext.addException(exc);
                }
                CreateContextWorker.this.asyncNotify();
            } catch (Exception e) {
                commContext.addException(e);
                e.printStackTrace();
                if (!CreateContextWorker.this._isUnauthorizedAndOKToReAuth) {
                    commContext.setUserAccessInErrorState();
                    commContext.addException(exc);
                }
                CreateContextWorker.this.asyncNotify();
            } catch (Throwable th) {
                if (!CreateContextWorker.this._isUnauthorizedAndOKToReAuth) {
                    commContext.setUserAccessInErrorState();
                    commContext.addException(exc);
                }
                CreateContextWorker.this.asyncNotify();
                throw th;
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            try {
                boolean unused = CreateContextWorker.this._isUserAccessValid = true;
                CreateContextWorker.this.doCallbackSucceededDebugLogging(result, str, commContext);
            } catch (Throwable th) {
                commContext.addException(th);
                commContext.setUserAccessInErrorState();
                th.printStackTrace();
            } finally {
                CreateContextWorker.this.asyncNotify();
            }
        }
    }

    private class UserDeviceCallbacks implements CallbackInterface {
        private UserDeviceCallbacks() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                commContext.addException(exc);
                CreateContextWorker.this.doCallbackFailedDebugLogging(exc, str, commContext);
                CreateContextWorker.this.checkForBlacklistOrUnsupported(exc, commContext);
            } catch (Exception e) {
                commContext.addException(e);
                e.printStackTrace();
            } finally {
                commContext.setUserDeviceInErrorState();
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            try {
                CreateContextWorker.this.doCallbackSucceededDebugLogging(result, str, commContext);
                String access$1200 = CreateContextWorker.this.getIdObjectStringFromReturn(result, Constants.APP_ID);
                if (StringUtility.isNullOrEmpty(access$1200)) {
                    throw new IllegalStateException("Call to 'user.users.devices.ensure' resulted in a null or empty user device ID");
                }
                commContext.setUserDeviceId(access$1200);
            } catch (Throwable th) {
                commContext.addException(th);
                commContext.setUserDeviceInErrorState();
                th.printStackTrace();
            }
        }
    }

    protected CreateContextWorker(CommContext commContext) {
        if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        }
        this._commContext = commContext;
    }

    /* access modifiers changed from: private */
    public void asyncNotify() {
        synchronized (this._asyncMonitorObject) {
            this._asyncWasSignalled = true;
            this._asyncMonitorObject.notify();
        }
    }

    private void asyncWait() throws InterruptedException {
        synchronized (this._asyncMonitorObject) {
            while (!this._asyncWasSignalled) {
                try {
                    this._asyncMonitorObject.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            this._asyncWasSignalled = false;
        }
    }

    /* access modifiers changed from: private */
    public void checkForBlacklistOrUnsupported(Exception exc, CommContext commContext) throws JSONException {
        Result requestResult;
        if ((exc instanceof ServicesException) && (requestResult = ((ServicesException) exc).getRequestResult()) != null) {
            this._isBlacklistedOrUnsupported = requestResult.checkForBlacklistedOrUnsupported(commContext);
            if (this._isBlacklistedOrUnsupported) {
                Log.d(Constants.TAG, "AuthFlow: We are blacklisted or unsupported");
            }
        }
    }

    protected static void clearAuthPersistence(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'androidContext' can not be NULL");
        }
        SharedPreferences.Editor edit = context.getApplicationContext().getSharedPreferences("GetJarClientPrefs", 0).edit();
        edit.remove(_PrefKeyAuthenticationToken).commit();
        edit.remove(_PrefKeyAuthenticationTokenTimestamp).commit();
        edit.remove("userAccessId").commit();
        edit.remove(_PrefKeyUserDeviceID).commit();
        edit.commit();
    }

    /* access modifiers changed from: private */
    public void doCallbackFailedDebugLogging(Exception exc, String str, CommContext commContext) {
        Log.e(Constants.TAG, String.format("AuthFlow: Request %1$s on CommContext %2$s resulted in a call to serviceRequestFailed(). %3$s", str, commContext == null ? "" : commContext.getCommContextId(), exc));
    }

    /* access modifiers changed from: private */
    public void doCallbackSucceededDebugLogging(Result result, String str, CommContext commContext) throws JSONException {
        Log.d(Constants.TAG, String.format("AuthFlow: Request %1$s on CommContext %2$s resulted in a call to serviceRequestSucceeded()", str, commContext == null ? "" : commContext.getCommContextId()));
    }

    private void findOrCreateUserAccess(String str) throws Exception {
        this._isUserAccessFound = false;
        Log.d(Constants.TAG, "AuthFlow: Calling userAccessFind()");
        AuthorizationServiceProxy.getInstance().userAccessFind(this._commContext, new UserAccessFindCallbacks(), str);
        asyncWait();
        if (!this._isUserAccessFound) {
            Log.d(Constants.TAG, "AuthFlow: Calling userAccessCreate()");
            AuthorizationServiceProxy.getInstance().userAccessCreate(this._commContext, new UserAccessCreateCallbacks(), str);
        }
    }

    /* access modifiers changed from: private */
    public String getIdFromReturn(Result result) {
        if (result == null) {
            return null;
        }
        try {
            if (result.getResponseJson() == null) {
                return null;
            }
            Log.d(Constants.TAG, String.format("AuthFlow: getIdFromReturn: %1$s", result.getResponseJson().getString("return")));
            if (!result.getResponseJson().getString("return").equals("null")) {
                return result.getResponseJson().getString("return");
            }
            return null;
        } catch (JSONException e) {
            return null;
        }
    }

    /* access modifiers changed from: private */
    public String getIdObjectStringFromReturn(Result result, String str) {
        if (result == null) {
            return null;
        }
        try {
            if (result.getResponseJson() == null || result.getResponseJson().isNull("return") || result.getResponseJson().getJSONObject("return").isNull(str)) {
                return null;
            }
            return result.getResponseJson().getJSONObject("return").getString(str);
        } catch (JSONException e) {
            return null;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x00ec A[SYNTHETIC, Splitter:B:33:0x00ec] */
    /* JADX WARNING: Removed duplicated region for block: B:68:? A[Catch:{ Exception -> 0x00e0 }, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r12 = this;
            r1 = 0
            r4 = 1
            r3 = 0
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x0244 }
            r2 = 1
            com.getjar.sdk.comm.GetJarConfig r0 = com.getjar.sdk.comm.GetJarConfig.getInstance(r0, r2)     // Catch:{ Exception -> 0x0244 }
            java.lang.String r2 = "service.auth_service.endpoint"
            java.lang.String r6 = r0.getDirectiveValue(r2)     // Catch:{ Exception -> 0x0244 }
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x0244 }
            android.content.Context r0 = r0.getApplicationContext()     // Catch:{ Exception -> 0x0244 }
            java.lang.String r2 = "GetJarClientPrefs"
            r5 = 0
            android.content.SharedPreferences r5 = r0.getSharedPreferences(r2, r5)     // Catch:{ Exception -> 0x0244 }
            java.lang.String r0 = "authenticationToken"
            boolean r0 = r5.contains(r0)     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x024a
            java.lang.String r0 = "authenticationToken"
            r2 = 0
            java.lang.String r0 = r5.getString(r0, r2)     // Catch:{ Exception -> 0x00e0 }
        L_0x002c:
            r8 = 0
            java.lang.Long r2 = java.lang.Long.valueOf(r8)     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r7 = "authenticationTokenTimestamp"
            boolean r7 = r5.contains(r7)     // Catch:{ Exception -> 0x00e0 }
            if (r7 == 0) goto L_0x0046
            java.lang.String r2 = "authenticationTokenTimestamp"
            r8 = 0
            long r8 = r5.getLong(r2, r8)     // Catch:{ Exception -> 0x00e0 }
            java.lang.Long r2 = java.lang.Long.valueOf(r8)     // Catch:{ Exception -> 0x00e0 }
        L_0x0046:
            java.lang.String r7 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r8 = "AuthFlow: Cached authentication token values [timestamp: %1$d] [value: %2$s]"
            r9 = 2
            java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ Exception -> 0x00e0 }
            r10 = 0
            r9[r10] = r2     // Catch:{ Exception -> 0x00e0 }
            r10 = 1
            r9[r10] = r0     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r8 = java.lang.String.format(r8, r9)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r7, r8)     // Catch:{ Exception -> 0x00e0 }
            r7 = 0
            r12._isBlacklistedOrUnsupported = r7     // Catch:{ Exception -> 0x00e0 }
            long r8 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x00e0 }
            long r10 = r2.longValue()     // Catch:{ Exception -> 0x00e0 }
            long r8 = r8 - r10
            boolean r2 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r0)     // Catch:{ Exception -> 0x00e0 }
            if (r2 != 0) goto L_0x00b0
            r10 = 158400000(0x970fe00, double:7.82599983E-316)
            int r2 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r2 >= 0) goto L_0x00b0
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = "AuthFlow: Using cached authentication token value [%1$d milliseconds old]"
            r7 = 1
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00e0 }
            r10 = 0
            java.lang.Long r8 = java.lang.Long.valueOf(r8)     // Catch:{ Exception -> 0x00e0 }
            r7[r10] = r8     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = java.lang.String.format(r4, r7)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r2, r4)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r2 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r2.setAuthToken(r0)     // Catch:{ Exception -> 0x00e0 }
            r2 = r3
        L_0x008e:
            java.lang.String r0 = "userAccessId"
            boolean r0 = r5.contains(r0)     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x0247
            java.lang.String r0 = "userAccessId"
            r3 = 0
            java.lang.String r0 = r5.getString(r0, r3)     // Catch:{ Exception -> 0x00e0 }
        L_0x009d:
            boolean r3 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r0)     // Catch:{ Exception -> 0x00e0 }
            if (r3 == 0) goto L_0x0116
            r12.findOrCreateUserAccess(r6)     // Catch:{ Exception -> 0x00e0 }
        L_0x00a6:
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r0.waitForUserAccess()     // Catch:{ Exception -> 0x00e0 }
            boolean r0 = r12._isBlacklistedOrUnsupported     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x01a5
        L_0x00af:
            return
        L_0x00b0:
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r2 = "AuthFlow: Requesting a new authentication token"
            android.util.Log.d(r0, r2)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.AuthorizationServiceProxy r0 = com.getjar.sdk.comm.AuthorizationServiceProxy.getInstance()     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r2 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.Operation r0 = r0.authorize(r2, r6)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r2 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r2.setAuthorizationFuture(r0)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.Result r0 = r0.get()     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x00af
            com.getjar.sdk.comm.CommContext r2 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            boolean r0 = r0.checkForBlacklistedOrUnsupported(r2)     // Catch:{ Exception -> 0x00e0 }
            r12._isBlacklistedOrUnsupported = r0     // Catch:{ Exception -> 0x00e0 }
            boolean r0 = r12._isBlacklistedOrUnsupported     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x0113
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "AuthFlow: We are blacklisted or unsupported"
            android.util.Log.d(r0, r1)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00af
        L_0x00e0:
            r0 = move-exception
            r1 = r5
        L_0x00e2:
            r0.printStackTrace()
            com.getjar.sdk.comm.CommContext r2 = r12._commContext
            r2.addException(r0)
            if (r1 == 0) goto L_0x00af
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x010e }
            java.lang.String r2 = "AuthFlow: Clearing cached auth token values"
            android.util.Log.d(r0, r2)     // Catch:{ Exception -> 0x010e }
            android.content.SharedPreferences$Editor r0 = r1.edit()     // Catch:{ Exception -> 0x010e }
            java.lang.String r2 = "authenticationToken"
            android.content.SharedPreferences$Editor r0 = r0.remove(r2)     // Catch:{ Exception -> 0x010e }
            r0.commit()     // Catch:{ Exception -> 0x010e }
            android.content.SharedPreferences$Editor r0 = r1.edit()     // Catch:{ Exception -> 0x010e }
            java.lang.String r1 = "authenticationTokenTimestamp"
            android.content.SharedPreferences$Editor r0 = r0.remove(r1)     // Catch:{ Exception -> 0x010e }
            r0.commit()     // Catch:{ Exception -> 0x010e }
            goto L_0x00af
        L_0x010e:
            r0 = move-exception
            r0.printStackTrace()
            goto L_0x00af
        L_0x0113:
            r2 = r4
            goto L_0x008e
        L_0x0116:
            if (r2 == 0) goto L_0x018d
            r3 = 0
            r12._isUserAccessValid = r3     // Catch:{ Exception -> 0x00e0 }
            r3 = 0
            r12._isUnauthorizedAndOKToReAuth = r3     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.AuthorizationServiceProxy r3 = com.getjar.sdk.comm.AuthorizationServiceProxy.getInstance()     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r4 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CreateContextWorker$UserAccessValidateCallbacks r7 = new com.getjar.sdk.comm.CreateContextWorker$UserAccessValidateCallbacks     // Catch:{ Exception -> 0x00e0 }
            r8 = 0
            r7.<init>()     // Catch:{ Exception -> 0x00e0 }
            r3.userAccessValidate(r4, r0, r7, r6)     // Catch:{ Exception -> 0x00e0 }
            r12.asyncWait()     // Catch:{ Exception -> 0x00e0 }
            boolean r3 = r12._isBlacklistedOrUnsupported     // Catch:{ Exception -> 0x00e0 }
            if (r3 != 0) goto L_0x00af
            boolean r3 = r12._isUserAccessValid     // Catch:{ Exception -> 0x00e0 }
            if (r3 != 0) goto L_0x0175
            boolean r3 = r12._isUnauthorizedAndOKToReAuth     // Catch:{ Exception -> 0x00e0 }
            if (r3 == 0) goto L_0x0162
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = "AuthFlow: userAccessValidate(%1$s) returned 'unauthorized-and-ok-to-reauth', deleting local IDs and attempting findOrCreateUserAccess()"
            r7 = 1
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00e0 }
            r8 = 0
            r7[r8] = r0     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r0 = java.lang.String.format(r4, r7)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r3, r0)     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r3 = "AuthFlow: Clearing cached values"
            android.util.Log.d(r0, r3)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            android.content.Context r0 = r0.getApplicationContext()     // Catch:{ Exception -> 0x00e0 }
            clearAuthPersistence(r0)     // Catch:{ Exception -> 0x00e0 }
            r12.findOrCreateUserAccess(r6)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00a6
        L_0x0162:
            java.lang.String r1 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r2 = "AuthFlow: userAccessValidate(%1$s) failed to validate, returning"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x00e0 }
            r4 = 0
            r3[r4] = r0     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r0 = java.lang.String.format(r2, r3)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r1, r0)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00af
        L_0x0175:
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = "AuthFlow: userAccessValidate(%1$s) validated, setting the ID on the CommContext"
            r6 = 1
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x00e0 }
            r7 = 0
            r6[r7] = r0     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = java.lang.String.format(r4, r6)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r3, r4)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r3 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r3.setUserAccessId(r0)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00a6
        L_0x018d:
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = "AuthFlow: Using cached UserAccess.id value [%1$s]"
            r6 = 1
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x00e0 }
            r7 = 0
            r6[r7] = r0     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = java.lang.String.format(r4, r6)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r3, r4)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r3 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r3.setUserAccessId(r0)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00a6
        L_0x01a5:
            android.content.SharedPreferences$Editor r0 = r5.edit()     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r3 = "userAccessId"
            com.getjar.sdk.comm.CommContext r4 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r4 = r4.getUserAccessId()     // Catch:{ Exception -> 0x00e0 }
            android.content.SharedPreferences$Editor r0 = r0.putString(r3, r4)     // Catch:{ Exception -> 0x00e0 }
            r0.commit()     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r0 = "userDeviceId"
            boolean r0 = r5.contains(r0)     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x01c7
            java.lang.String r0 = "userDeviceId"
            r1 = 0
            java.lang.String r1 = r5.getString(r0, r1)     // Catch:{ Exception -> 0x00e0 }
        L_0x01c7:
            boolean r0 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r1)     // Catch:{ Exception -> 0x00e0 }
            if (r0 == 0) goto L_0x022d
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "AuthFlow: No cached UserDevice.id value found, calling ensureUserDevice()"
            android.util.Log.d(r0, r1)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.UserServiceProxy r0 = com.getjar.sdk.comm.UserServiceProxy.getInstance()     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r1 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CreateContextWorker$UserDeviceCallbacks r3 = new com.getjar.sdk.comm.CreateContextWorker$UserDeviceCallbacks     // Catch:{ Exception -> 0x00e0 }
            r4 = 0
            r3.<init>()     // Catch:{ Exception -> 0x00e0 }
            r0.ensureUserDevice(r1, r3)     // Catch:{ Exception -> 0x00e0 }
        L_0x01e3:
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r0.waitForUserDevice()     // Catch:{ Exception -> 0x00e0 }
            boolean r0 = r12._isBlacklistedOrUnsupported     // Catch:{ Exception -> 0x00e0 }
            if (r0 != 0) goto L_0x00af
            android.content.SharedPreferences$Editor r0 = r5.edit()     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "userDeviceId"
            com.getjar.sdk.comm.CommContext r3 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r3 = r3.getUserDeviceId()     // Catch:{ Exception -> 0x00e0 }
            android.content.SharedPreferences$Editor r0 = r0.putString(r1, r3)     // Catch:{ Exception -> 0x00e0 }
            r0.commit()     // Catch:{ Exception -> 0x00e0 }
            if (r2 == 0) goto L_0x00af
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "AuthFlow: Setting cached auth token values"
            android.util.Log.d(r0, r1)     // Catch:{ Exception -> 0x00e0 }
            android.content.SharedPreferences$Editor r0 = r5.edit()     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "authenticationToken"
            com.getjar.sdk.comm.CommContext r2 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r2 = r2.getAuthToken()     // Catch:{ Exception -> 0x00e0 }
            android.content.SharedPreferences$Editor r1 = r0.putString(r1, r2)     // Catch:{ Exception -> 0x00e0 }
            r1.commit()     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r1 = "authenticationTokenTimestamp"
            long r2 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x00e0 }
            android.content.SharedPreferences$Editor r1 = r0.putLong(r1, r2)     // Catch:{ Exception -> 0x00e0 }
            r1.commit()     // Catch:{ Exception -> 0x00e0 }
            r0.commit()     // Catch:{ Exception -> 0x00e0 }
            goto L_0x00af
        L_0x022d:
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r3 = "AuthFlow: Using cached UserDevice.id value [%1$s]"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x00e0 }
            r6 = 0
            r4[r6] = r1     // Catch:{ Exception -> 0x00e0 }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ Exception -> 0x00e0 }
            android.util.Log.d(r0, r3)     // Catch:{ Exception -> 0x00e0 }
            com.getjar.sdk.comm.CommContext r0 = r12._commContext     // Catch:{ Exception -> 0x00e0 }
            r0.setUserDeviceId(r1)     // Catch:{ Exception -> 0x00e0 }
            goto L_0x01e3
        L_0x0244:
            r0 = move-exception
            goto L_0x00e2
        L_0x0247:
            r0 = r1
            goto L_0x009d
        L_0x024a:
            r0 = r1
            goto L_0x002c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CreateContextWorker.run():void");
    }
}

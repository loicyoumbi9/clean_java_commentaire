package com.getjar.sdk.utilities;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

public class GetJarDialog extends Dialog implements View.OnClickListener {
    public GetJarDialog(Context context, View view) {
        super(context, 16973840);
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be null");
        } else if (view == null) {
            throw new IllegalArgumentException("'v' can not be null");
        } else {
            requestWindowFeature(1);
            setContentView(view);
        }
    }

    public void onClick(View view) {
    }
}

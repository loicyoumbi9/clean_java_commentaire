package com.getjar.sdk.data;

import android.database.Cursor;
import com.getjar.sdk.utilities.StringUtility;
import java.net.URI;
import java.net.URISyntaxException;

public class CacheEntry {
    private Long _createTimestamp = null;
    private String _etag = null;
    private int _id;
    private Long _lastUpdated = null;
    private String _name = null;
    private Long _ttl = null;
    private URI _uri = null;
    private String _value = null;

    public CacheEntry() {
    }

    public CacheEntry(Cursor cursor) throws URISyntaxException {
        if (cursor == null) {
            throw new IllegalArgumentException("'dbCursor' can not be NULL");
        } else if (cursor.isBeforeFirst() || cursor.isAfterLast()) {
            throw new IllegalArgumentException("'dbCursor' must already be pointing to a valid record");
        } else {
            this._id = cursor.getInt(0);
            this._name = cursor.getString(1);
            this._value = cursor.getString(2);
            this._createTimestamp = Long.valueOf(cursor.getLong(3));
            this._lastUpdated = Long.valueOf(cursor.getLong(4));
            this._ttl = Long.valueOf(cursor.getLong(5));
            if (!cursor.isNull(6)) {
                String string = cursor.getString(6);
                if (!StringUtility.isNullOrEmpty(string)) {
                    this._uri = new URI(string);
                }
            }
            if (!cursor.isNull(7)) {
                this._etag = cursor.getString(7);
            }
        }
    }

    public Long getCreateTimestamp() {
        return this._createTimestamp;
    }

    public String getEtag() {
        return this._etag;
    }

    public int getId() {
        return this._id;
    }

    public Long getLastUpdated() {
        return this._lastUpdated;
    }

    public String getName() {
        return this._name;
    }

    public Long getTtl() {
        return this._ttl;
    }

    public URI getUri() {
        return this._uri;
    }

    public String getValue() {
        return this._value;
    }

    public boolean hasTtlExpired() {
        return getLastUpdated().longValue() + getTtl().longValue() < System.currentTimeMillis();
    }

    public void setEtag(String str) {
        this._etag = str;
    }

    public void setName(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'name' can not be NULL or empty");
        }
        this._name = str;
    }

    public void setTtl(Long l) {
        if (l == null) {
            throw new IllegalArgumentException("'ttl' can not be NULL");
        }
        this._ttl = l;
    }

    public void setUri(URI uri) {
        this._uri = uri;
    }

    public void setValue(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'value' can not be NULL or empty");
        }
        this._value = str;
    }

    public String toString() {
        return String.format("%1$s = %2$s [lastUpdated:%3$d ttl:%4$d etag:%5$s uri:%6$s]", this._name, this._value, this._lastUpdated, this._ttl, this._etag, this._uri);
    }
}

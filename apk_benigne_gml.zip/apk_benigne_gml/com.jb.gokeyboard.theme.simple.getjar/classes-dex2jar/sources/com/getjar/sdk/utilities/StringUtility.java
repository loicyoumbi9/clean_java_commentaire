package com.getjar.sdk.utilities;

public class StringUtility {
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.length() <= 0;
    }

    public static String zor(String str) {
        if (isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'value' must not empty or null.");
        }
        try {
            return (String) Class.forName("getjar.android.sdk.Z").getMethod("zor", String.class).invoke(null, str);
        } catch (Exception e) {
            return str;
        }
    }
}

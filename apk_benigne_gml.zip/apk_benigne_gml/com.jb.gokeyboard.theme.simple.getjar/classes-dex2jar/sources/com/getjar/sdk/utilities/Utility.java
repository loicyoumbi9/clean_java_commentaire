package com.getjar.sdk.utilities;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Environment;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.comm.ServicesException;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.rewards.ApplicationInfoEx;
import com.getjar.sdk.utilities.Constants;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Utility {
    public static final String GETJAR_CLIENT_PARAM = "gjclnt=1";
    private static final String GETJAR_V1_DB = "GetJarRewardsDB";
    public static final String PREFERENCES_FILE_NAME = "GetJarClientPrefs";
    public static final String PREFERENCES_KEY_APPLICATION_KEY = "ApplicationKey";
    public static final String PREFERENCES_KEY_DEVICEOBJECTID = "DeviceObjectID";
    public static final String PREFERENCES_KEY_FIRST_RUN_FLAG = "FirstRunFlag";
    public static final String PREFERENCES_KEY_FIRST_UX_RUN_FLAG = "FirstUXRun";
    public static final String PREFERENCES_KEY_INSTALLATIONID = "InstallationID";
    public static final String PREFERENCES_KEY_INSTALL_TIME = "InstallTime";
    public static final String PREFERENCES_KEY_LAUNCH_COUNT = "LaunchCount";
    public static final String PREFERENCES_KEY_LOCALE = "Locale";
    public static final String PREFERENCES_KEY_SANDBOX = "SandBox";
    public static final String PREFERENCES_KEY_USER_ACCESS_ID = "UserAccessID";
    public static final String PREFERENCES_KEY_USER_ID = "UserID";
    public static final String QUERY_APPENDIX = "&";
    public static final String QUERY_START = "?";
    public static final String READ_PHONE_STATE_PERMISSION = "android.permission.READ_PHONE_STATE";
    private static Random sRnd = new Random();

    private Utility() {
    }

    public static long convertMillSec(long j) {
        return 1000 * j;
    }

    public static void copyFile(File file, File file2) throws IOException {
        if (file == null) {
            throw new IllegalArgumentException("Input File have a valid context.");
        } else if (file2 == null) {
            throw new IllegalArgumentException("Output File have a valid context.");
        } else {
            FileChannel channel = new FileInputStream(file).getChannel();
            FileChannel channel2 = new FileOutputStream(file2).getChannel();
            try {
                channel.transferTo(0, channel.size(), channel2);
            } finally {
                if (channel != null) {
                    channel.close();
                }
                if (channel2 != null) {
                    channel2.close();
                }
            }
        }
    }

    public static String getAndroidID(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        String valueFakeID = OverridesUtility.getValueFakeID("identity.android.id");
        if (!StringUtility.isNullOrEmpty(valueFakeID)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.android.id' = '%1$s'", valueFakeID));
            return valueFakeID;
        }
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if (string == null || string.length() <= 1) {
            return null;
        }
        return string;
    }

    public static Constants.AppType getAppType(Context context) {
        return context.getPackageName().equals(Constants.GREENJAR_PACKAGE) ? Constants.AppType.GREENJAR_CLIENT : Constants.AppType.HOST_APP;
    }

    public static AppData getApplicationInfo(Context context, String str, AppData.AppStatus appStatus) throws PackageManager.NameNotFoundException, IllegalAccessException {
        if (context == null) {
            throw new IllegalArgumentException("Context Object must have a valid context.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Package Name must have a valid context.");
        } else if (appStatus == null) {
            throw new IllegalArgumentException("AppStatus Object must have a valid context.");
        } else {
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packageInfo = packageManager.getPackageInfo(str, 128);
            String str2 = "";
            Integer targetSdkVersion = ApplicationInfoEx.getTargetSdkVersion(packageInfo.applicationInfo);
            if (targetSdkVersion != null) {
                str2 = Integer.toString(targetSdkVersion.intValue());
            }
            return new AppData(str, appStatus, Integer.valueOf(packageInfo.versionCode), packageInfo.versionName, str2, packageInfo.applicationInfo.flags, (String) packageInfo.applicationInfo.loadLabel(packageManager), null);
        }
    }

    public static String getApplicationKey(Context context) {
        return context.getSharedPreferences("GetJarClientPrefs", 0).getString(PREFERENCES_KEY_APPLICATION_KEY, "");
    }

    public static File[] getCacheLocations(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        return new File[]{getExternalCacheLocation(), context.getFilesDir(), context.getCacheDir()};
    }

    public static String getCurrentLocale(Context context) {
        return context.getResources().getConfiguration().locale.getDisplayName();
    }

    public static String getDefaultLocale() {
        return Locale.getDefault().getDisplayName();
    }

    public static String getDeviceObjectId(Context context) {
        String str;
        String str2 = null;
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        String valueFakeID = OverridesUtility.getValueFakeID("identity.device.id");
        if (!StringUtility.isNullOrEmpty(valueFakeID)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.device.id' = '%1$s'", valueFakeID));
            return valueFakeID;
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences("GetJarClientPrefs", 0);
        if (sharedPreferences.contains(PREFERENCES_KEY_DEVICEOBJECTID)) {
            return sharedPreferences.getString(PREFERENCES_KEY_DEVICEOBJECTID, null);
        }
        if (RewardUtility.checkPermission(context, READ_PHONE_STATE_PERMISSION)) {
            str2 = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        }
        if (str2 == null || str2.length() <= 0) {
            try {
                Class<?> cls = Class.forName("android.os.SystemProperties");
                str = (String) cls.getMethod("get", String.class, String.class).invoke(cls, "ro.serialno", null);
            } catch (ClassNotFoundException e) {
                str = str2;
            } catch (NoSuchMethodException e2) {
                str = str2;
            } catch (InvocationTargetException e3) {
                str = str2;
            } catch (IllegalAccessException e4) {
                str = str2;
            }
        } else {
            str = str2;
        }
        if (str == null || str.length() <= 0) {
            str = Settings.Secure.getString(context.getContentResolver(), "android_id");
        }
        if (str == null || str.length() <= 0) {
            str = UUID.randomUUID().toString();
        }
        sharedPreferences.edit().putString(PREFERENCES_KEY_DEVICEOBJECTID, str).commit();
        return str;
    }

    public static File getExternalCacheLocation() {
        File file = new File(Environment.getExternalStorageDirectory(), "getjar" + File.separator + "cache");
        file.mkdirs();
        return file;
    }

    public static String getInstallationID(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        String valueFakeID = OverridesUtility.getValueFakeID("identity.device.id");
        if (!StringUtility.isNullOrEmpty(valueFakeID)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: 'identity.device.id' = '%1$s'", valueFakeID));
            return valueFakeID;
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences("GetJarClientPrefs", 0);
        if (sharedPreferences.contains("InstallationID")) {
            return sharedPreferences.getString("InstallationID", null);
        }
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if (string == null) {
            string = Long.toString(System.currentTimeMillis(), 36) + Integer.toString(sRnd.nextInt(Integer.MAX_VALUE), 36);
        }
        sharedPreferences.edit().putString("InstallationID", string).commit();
        return string;
    }

    public static List<String> getLocalIpAddresses() {
        ArrayList arrayList = new ArrayList();
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress nextElement = inetAddresses.nextElement();
                    if (!nextElement.isLoopbackAddress()) {
                        arrayList.add(nextElement.getHostAddress());
                    }
                }
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, "getLocalIpAddresses() failed", e);
        }
        return arrayList;
    }

    public static String getLocale(Context context) {
        return context.getSharedPreferences("GetJarClientPrefs", 0).getString(PREFERENCES_KEY_LOCALE, null);
    }

    public static String getPackageNameFromBroadcastIntent(Intent intent) {
        if (intent == null) {
            throw new IllegalArgumentException("Must have a valid intent.");
        }
        Uri data = intent.getData();
        if (data != null) {
            return data.getSchemeSpecificPart();
        }
        return null;
    }

    public static long getResponseAmount(Result result, long j) {
        JSONObject responseJson = result.getResponseJson();
        if (responseJson == null || responseJson.length() <= 0) {
            return j;
        }
        try {
            return (long) responseJson.getJSONObject("return").getInt("amount");
        } catch (JSONException e) {
            Logger.sLog(e.toString());
            return j;
        }
    }

    public static long getResponseAmount(Exception exc, long j) {
        JSONObject responseJson;
        if (!exc.getClass().isInstance(ServicesException.class) || (responseJson = ((ServicesException) exc).getRequestResult().getResponseJson()) == null || responseJson.length() <= 0) {
            return j;
        }
        try {
            return (long) responseJson.getJSONObject("return").getInt("amount");
        } catch (JSONException e) {
            Logger.sLog(e.toString());
            return j;
        }
    }

    public static String getResponseSubstate(Result result, String str) {
        JSONObject responseJson = result.getResponseJson();
        if (responseJson == null || responseJson.length() <= 0) {
            return str;
        }
        try {
            String string = responseJson.getJSONObject("return").getString("substate");
            return !StringUtility.isNullOrEmpty(string) ? string : str;
        } catch (JSONException e) {
            Logger.sLog(e.toString());
            return str;
        }
    }

    public static String getResponseSubstate(Exception exc, String str) {
        Logger.sLog("getResponseSubstate() -- START: defaultValue=" + str);
        try {
            Result requestResult = ((ServicesException) exc).getRequestResult();
            Logger.sLog("getResponseSubstate() -- RequestResult=" + requestResult.toString());
            str = getResponseSubstateFromErrorResult(requestResult, str);
        } catch (ClassCastException e) {
            Logger.sLog(e);
        }
        Logger.sLog("getResponseSubstate() -- DONE: substate=" + str);
        return str;
    }

    public static String getResponseSubstateFromErrorResult(Result result, String str) {
        if (result == null) {
            throw new IllegalArgumentException("'result' cannot be NULL");
        }
        try {
            JSONObject responseJson = result.getResponseJson();
            if (responseJson != null && responseJson.has("error") && responseJson.getJSONObject("error").has("subcode")) {
                return responseJson.getJSONObject("error").getString("subcode");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean getSandboxMode(Context context) {
        return context.getSharedPreferences("GetJarClientPrefs", 0).getBoolean(PREFERENCES_KEY_SANDBOX, false);
    }

    public static Integer getStaticIntegerField(Class<?> cls, String str) throws IllegalArgumentException, IllegalAccessException {
        if (cls == null) {
            throw new IllegalArgumentException("Must have a valid source type.");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must have a valid field name.");
        } else {
            try {
                return Integer.valueOf(cls.getDeclaredField(str).getInt(null));
            } catch (NoSuchFieldException e) {
                return null;
            }
        }
    }

    public static String getTransactionState(Result result, String str) {
        JSONObject responseJson = result.getResponseJson();
        if (responseJson == null || responseJson.length() <= 0) {
            return str;
        }
        try {
            String string = responseJson.getJSONObject("return").getString("state");
            return !StringUtility.isNullOrEmpty(string) ? string : str;
        } catch (JSONException e) {
            Logger.sLog(e.toString());
            return str;
        }
    }

    public static String getUserAccessId(Context context) {
        return context.getSharedPreferences("GetJarClientPrefs", 0).getString(PREFERENCES_KEY_USER_ACCESS_ID, null);
    }

    public static byte[] gzipCompress(String str) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(str.length());
        GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
        gZIPOutputStream.write(str.getBytes());
        gZIPOutputStream.close();
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        byteArrayOutputStream.close();
        return byteArray;
    }

    public static String gzipDecompress(byte[] bArr) throws IOException {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        GZIPInputStream gZIPInputStream = new GZIPInputStream(byteArrayInputStream, 32);
        StringBuilder sb = new StringBuilder();
        byte[] bArr2 = new byte[32];
        while (true) {
            int read = gZIPInputStream.read(bArr2);
            if (read != -1) {
                sb.append(new String(bArr2, 0, read));
            } else {
                gZIPInputStream.close();
                byteArrayInputStream.close();
                return sb.toString();
            }
        }
    }

    public static boolean isCurrentThreadTheUIThread() {
        return Looper.getMainLooper() == Looper.myLooper();
    }

    public static boolean isExistApp(Context context, String str) {
        try {
            if (context.getPackageManager().getApplicationInfo(str, 0) != null) {
                Log.d(Constants.TAG, "ReportUsage: isExistApp() -- TRUE..");
                return true;
            }
            Log.d(Constants.TAG, "ReportUsage: isExistApp() -- (appInfo NULL) FALSE..");
            return false;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d(Constants.TAG, "ReportUsage: isExistApp() -- (NameNotFoundException) FALSE..");
            return false;
        }
    }

    public static HashMap<String, String> jsonArrayStringToMap(String str) throws JSONException {
        HashMap<String, String> hashMap = new HashMap<>();
        Logger.sLog("Outside:" + str);
        if (!StringUtility.isNullOrEmpty(str)) {
            Logger.sLog("Inside");
            JSONArray jSONArray = new JSONArray(str);
            Logger.sLog("JSONARRAY size:" + jSONArray.length());
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                Logger.sLog("key:" + jSONObject.getString("key"));
                hashMap.put(jSONObject.getString("key"), jSONObject.getString("value"));
            }
        }
        return hashMap;
    }

    public static HashMap<String, String> jsonArrayStringToMapUnchange(String str) throws JSONException {
        HashMap<String, String> hashMap = new HashMap<>();
        Logger.sLog("Outside Unchange:" + str);
        if (!StringUtility.isNullOrEmpty(str)) {
            Logger.sLog("Inside");
            JSONArray jSONArray = new JSONArray(str);
            Logger.sLog("JSONARRAY size:" + jSONArray.length());
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= jSONArray.length()) {
                    break;
                }
                JSONObject jSONObject = jSONArray.getJSONObject(i2);
                Iterator<String> keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    hashMap.put(next, jSONObject.getString(next));
                }
                i = i2 + 1;
            }
        }
        for (Map.Entry<String, String> entry : hashMap.entrySet()) {
            Logger.sLog(entry.getKey() + ", " + entry.getValue());
        }
        return hashMap;
    }

    public static Map<String, String> jsonArrayToMap(JSONArray jSONArray) throws JSONException {
        HashMap hashMap = new HashMap();
        Logger.sLog("JSONARRAY size:" + jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            Logger.sLog("key:" + jSONObject.getString("key"));
            hashMap.put(jSONObject.getString("key"), jSONObject.getString("value"));
        }
        return hashMap;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0057  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.util.Map<java.lang.String, java.lang.String> parseUrl(java.lang.String r14) {
        /*
            r13 = 3
            r12 = 2
            r11 = 1
            r4 = 0
            boolean r0 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r14)
            if (r0 == 0) goto L_0x0012
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Url must have a valid context."
            r0.<init>(r1)
            throw r0
        L_0x0012:
            java.util.HashMap r5 = new java.util.HashMap
            r5.<init>(r12)
            java.lang.String r0 = ""
            java.net.URL r1 = new java.net.URL     // Catch:{ Throwable -> 0x0081 }
            r1.<init>(r14)     // Catch:{ Throwable -> 0x0081 }
            java.lang.String r0 = r1.getQuery()     // Catch:{ Throwable -> 0x0081 }
            java.lang.String r2 = "%1$s://%2$s%3$s"
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Throwable -> 0x0081 }
            r6 = 0
            java.lang.String r7 = r1.getProtocol()     // Catch:{ Throwable -> 0x0081 }
            r3[r6] = r7     // Catch:{ Throwable -> 0x0081 }
            r6 = 1
            java.lang.String r7 = r1.getAuthority()     // Catch:{ Throwable -> 0x0081 }
            r3[r6] = r7     // Catch:{ Throwable -> 0x0081 }
            r6 = 2
            java.lang.String r1 = r1.getPath()     // Catch:{ Throwable -> 0x0081 }
            r3[r6] = r1     // Catch:{ Throwable -> 0x0081 }
            java.lang.String r1 = java.lang.String.format(r2, r3)     // Catch:{ Throwable -> 0x0081 }
            if (r0 == 0) goto L_0x0048
            int r2 = r0.length()     // Catch:{ Throwable -> 0x010a }
            if (r2 != 0) goto L_0x0067
        L_0x0048:
            java.lang.String r0 = "gjclnt=1"
        L_0x004a:
            java.lang.String r2 = "&"
            java.lang.String[] r6 = r0.split(r2)
            java.lang.String r2 = ""
            int r7 = r6.length
            r0 = r1
            r3 = r4
        L_0x0055:
            if (r3 >= r7) goto L_0x00ff
            r1 = r6[r3]
            java.lang.String r8 = "="
            java.lang.String[] r1 = r1.split(r8)
            int r8 = r1.length
            if (r8 >= r12) goto L_0x009e
            r1 = r2
        L_0x0063:
            int r3 = r3 + 1
            r2 = r1
            goto L_0x0055
        L_0x0067:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x010a }
            r2.<init>()     // Catch:{ Throwable -> 0x010a }
            java.lang.StringBuilder r2 = r2.append(r0)     // Catch:{ Throwable -> 0x010a }
            java.lang.String r3 = "&"
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ Throwable -> 0x010a }
            java.lang.String r3 = "gjclnt=1"
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ Throwable -> 0x010a }
            java.lang.String r0 = r2.toString()     // Catch:{ Throwable -> 0x010a }
            goto L_0x004a
        L_0x0081:
            r2 = move-exception
            r1 = r14
        L_0x0083:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r6 = "Exception:"
            java.lang.StringBuilder r3 = r3.append(r6)
            java.lang.String r2 = r2.getLocalizedMessage()
            java.lang.StringBuilder r2 = r3.append(r2)
            java.lang.String r2 = r2.toString()
            com.getjar.sdk.utilities.Logger.sLog(r2)
            goto L_0x004a
        L_0x009e:
            r8 = r1[r4]
            java.lang.String r9 = "downloadUrl"
            boolean r8 = r8.equalsIgnoreCase(r9)
            if (r8 == 0) goto L_0x00b0
            r0 = r1[r11]
            java.lang.String r0 = java.net.URLDecoder.decode(r0)
            r1 = r2
            goto L_0x0063
        L_0x00b0:
            int r8 = r2.length()
            if (r8 <= 0) goto L_0x00dc
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.StringBuilder r2 = r8.append(r2)
            java.lang.String r8 = "%1$s%2$s=%3$s"
            java.lang.Object[] r9 = new java.lang.Object[r13]
            java.lang.String r10 = "&"
            r9[r4] = r10
            r10 = r1[r4]
            r9[r11] = r10
            r1 = r1[r11]
            r9[r12] = r1
            java.lang.String r1 = java.lang.String.format(r8, r9)
            java.lang.StringBuilder r1 = r2.append(r1)
            java.lang.String r1 = r1.toString()
            goto L_0x0063
        L_0x00dc:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.StringBuilder r2 = r8.append(r2)
            java.lang.String r8 = "%1$s=%2$s"
            java.lang.Object[] r9 = new java.lang.Object[r12]
            r10 = r1[r4]
            r9[r4] = r10
            r1 = r1[r11]
            r9[r11] = r1
            java.lang.String r1 = java.lang.String.format(r8, r9)
            java.lang.StringBuilder r1 = r2.append(r1)
            java.lang.String r1 = r1.toString()
            goto L_0x0063
        L_0x00ff:
            java.lang.String r1 = "apkUri"
            r5.put(r1, r0)
            java.lang.String r0 = "downloadArgs"
            r5.put(r0, r2)
            return r5
        L_0x010a:
            r2 = move-exception
            goto L_0x0083
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.utilities.Utility.parseUrl(java.lang.String):java.util.Map");
    }

    public static void previousVersionCleanUp(Context context) {
        String[] databaseList = context.databaseList();
        boolean z = true;
        int length = databaseList.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            }
            String str = databaseList[i];
            Log.d("GreenJar DEBUGGING", "database:" + str);
            if (str.equalsIgnoreCase(GETJAR_V1_DB)) {
                z = false;
                break;
            }
            i++;
        }
        if (!z) {
            context.deleteDatabase(GETJAR_V1_DB);
            SharedPreferences.Editor edit = context.getSharedPreferences("GetJarClientPrefs", 0).edit();
            edit.clear();
            context.getSharedPreferences(RewardUtility._PreferencesInstalledAppFileName, 0);
            edit.clear();
            edit.commit();
        }
    }

    public static void pushFailNotification(CommContext commContext, String str) {
        try {
            Log.d(Constants.TAG, "Send Fail Notification");
            PackageManager packageManager = commContext.getApplicationContext().getPackageManager();
            String format = String.format(str, (String) packageManager.getPackageInfo(commContext.getApplicationContext().getPackageName(), 128).applicationInfo.loadLabel(packageManager));
            Notification notification = new Notification(17301516, format, System.currentTimeMillis());
            notification.flags |= 16;
            String str2 = "Return to " + packageManager.getPackageInfo(commContext.getApplicationContext().getPackageName(), 128).applicationInfo.loadLabel(packageManager);
            new Intent("android.intent.action.MAIN");
            Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(commContext.getApplicationContext().getPackageName());
            launchIntentForPackage.addCategory("android.intent.category.LAUNCHER");
            launchIntentForPackage.setFlags(270532608);
            notification.setLatestEventInfo(commContext.getApplicationContext(), format, str2, PendingIntent.getActivity(commContext.getApplicationContext(), 0, launchIntentForPackage, 0));
            ((NotificationManager) commContext.getApplicationContext().getSystemService("notification")).notify(0, notification);
        } catch (Exception e) {
            Log.e(Constants.TAG, "pushFailNotification() failed", e);
        }
    }

    public static void pushSuccessNotification(CommContext commContext, String str) {
        String str2;
        try {
            Log.d(Constants.TAG, "Send Success Notification");
            PackageManager packageManager = commContext.getApplicationContext().getPackageManager();
            NotificationManager notificationManager = (NotificationManager) commContext.getApplicationContext().getSystemService("notification");
            Notification notification = new Notification(17301516, str, System.currentTimeMillis());
            notification.flags |= 16;
            String str3 = "Return to " + ((String) packageManager.getPackageInfo(commContext.getApplicationContext().getPackageName(), 128).applicationInfo.loadLabel(packageManager));
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            Iterator<ResolveInfo> it = packageManager.queryIntentActivities(intent, 0).iterator();
            while (true) {
                if (!it.hasNext()) {
                    str2 = "";
                    break;
                }
                ResolveInfo next = it.next();
                if (next.activityInfo.packageName.equals(commContext.getApplicationContext().getPackageName())) {
                    String str4 = next.activityInfo.name;
                    String str5 = (String) next.activityInfo.loadLabel(packageManager);
                    str2 = str4;
                    break;
                }
            }
            Intent intent2 = new Intent("android.intent.action.MAIN", (Uri) null);
            intent2.addCategory("android.intent.category.LAUNCHER");
            intent2.setComponent(new ComponentName(commContext.getApplicationContext().getPackageName(), str2));
            intent2.setFlags(268435456);
            notification.setLatestEventInfo(commContext.getApplicationContext(), str, str3, PendingIntent.getActivity(commContext.getApplicationContext(), 0, intent2, 0));
            notificationManager.notify(0, notification);
        } catch (Exception e) {
            Log.e(Constants.TAG, "pushSuccessNotification() failed", e);
        }
    }

    public static void removePackageNameInstallEntry(Context context, String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty packageName.");
        }
        context.getSharedPreferences(Constants.PACKAGE_NAMES_INSTALLED_PREFS, 0).edit().remove(str).commit();
    }

    public static void saveApplicationKey(Context context, String str) {
        SharedPreferences.Editor edit = context.getSharedPreferences("GetJarClientPrefs", 0).edit();
        edit.putString(PREFERENCES_KEY_APPLICATION_KEY, str).commit();
        edit.commit();
    }

    public static void saveLocale(Context context, String str) {
        context.getSharedPreferences("GetJarClientPrefs", 0).edit().putString(PREFERENCES_KEY_LOCALE, str).commit();
    }

    public static void savePackageNameInstallEntry(Context context, String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must provide a non-null, non-empty packageName.");
        }
        context.getSharedPreferences(Constants.PACKAGE_NAMES_INSTALLED_PREFS, 0).edit().putString(str, str).commit();
    }

    public static void saveSandboxMode(Context context, boolean z) {
        context.getSharedPreferences("GetJarClientPrefs", 0).edit().putBoolean(PREFERENCES_KEY_SANDBOX, z).commit();
    }

    public static void setLocale(Context context, String str) {
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
    }

    public static void setUserAccessId(Context context, String str) {
        context.getSharedPreferences("GetJarClientPrefs", 0).edit().putString(PREFERENCES_KEY_USER_ACCESS_ID, str).commit();
    }

    public static boolean shouldFilterApp(AppData appData) {
        if (appData != null) {
            return (appData.getFlags() & 1) == 1;
        }
        throw new IllegalArgumentException("Must have a valid Application Data.");
    }

    public static boolean shouldTrackInstallEvents(Context context) {
        if (context.getPackageName().equals(Constants.GREENJAR_PACKAGE)) {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackInstallEvents() TRUE: WE ARE GJ CLIENT..");
            return true;
        } else if (!isExistApp(context, Constants.GREENJAR_PACKAGE)) {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackInstallEvents() -- TRUE: WE ARE HOST APP -and- GJ CLIENT IS NOT INSTALLED..");
            return true;
        } else {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackInstallEvents() -- FALSE: WE ARE HOST APP -and- GJ CLIENT IS INSTALLED..");
            return false;
        }
    }

    public static boolean shouldTrackUsageEvents(Context context) {
        if (context.getPackageName().equals(Constants.GREENJAR_PACKAGE)) {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackUsageEvents() TRUE: WE ARE GJ CLIENT..");
            return true;
        } else if (!isExistApp(context, Constants.GREENJAR_PACKAGE)) {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackUsageEvents() -- FALSE: WE ARE HOST APP -and- GJ CLIENT IS NOT INSTALLED..");
            return false;
        } else {
            Log.d(Constants.TAG, "ReportUsage: shouldTrackUsageEvents() -- FALSE: WE ARE HOST APP -and- GJ CLIENT IS INSTALLED..");
            return false;
        }
    }
}

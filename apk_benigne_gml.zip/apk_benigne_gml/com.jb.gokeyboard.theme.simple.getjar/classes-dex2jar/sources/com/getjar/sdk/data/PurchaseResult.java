package com.getjar.sdk.data;

import android.os.Bundle;
import com.getjar.sdk.utilities.Constants;

public class PurchaseResult {
    private long mCost = 0;
    private String mProductId = "";
    private String mTransactionId = "";

    public PurchaseResult(Bundle bundle) {
        if (bundle == null) {
            throw new IllegalArgumentException("Must have a valid bundle.");
        }
        this.mTransactionId = bundle.getString(Constants.TRANSACTION_ID);
        this.mProductId = bundle.getString(Constants.APP_ID);
        this.mCost = bundle.getLong(Constants.APP_COST, 0);
    }

    public long getCost() {
        return this.mCost;
    }

    public String getProductId() {
        return this.mProductId;
    }

    public String getTransactionId() {
        return this.mTransactionId;
    }
}

package com.getjar.sdk.data;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.util.Log;
import com.getjar.sdk.comm.AppUsageData;
import com.getjar.sdk.comm.CallbackInterface;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.Result;
import com.getjar.sdk.comm.UserServiceProxy;
import com.getjar.sdk.events.LaunchEvent;
import com.getjar.sdk.rewards.AppData;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

public class ReportManager {
    /* access modifiers changed from: private */
    public static Object _DB_UPDATEING_LOCK = new Object();
    private CommContext _commContext;
    /* access modifiers changed from: private */
    public Context _context;
    Logger log = new Logger(this);

    protected abstract class ReportCallbackBase implements CallbackInterface {
        protected List<UsageBucket> _appUsageList = null;

        protected ReportCallbackBase() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public final void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                System.out.println(String.format("Request %1$s on CommContext %2$s resulted in a call to serviceRequestFailed(). %3$s", str, commContext == null ? "" : commContext.getCommContextId(), exc == null ? "" : exc.getMessage()));
                if (exc != null) {
                    exc.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public final void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public abstract void serviceRequestSucceeded(Result result, String str, CommContext commContext);

        /* access modifiers changed from: protected */
        public void setAppUsageData(List<UsageBucket> list) {
            this._appUsageList = new ArrayList(list.size());
            for (UsageBucket usageBucket : list) {
                this._appUsageList.add(usageBucket);
            }
        }
    }

    protected class ReportEventCallback extends ReportCallbackBase {
        protected ReportEventCallback() {
            super();
        }

        @Override // com.getjar.sdk.data.ReportManager.ReportCallbackBase, com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            DBAdapterAppData dBAdapterAppData;
            synchronized (ReportManager._DB_UPDATEING_LOCK) {
                try {
                    System.out.println(String.format("Request %1$s on CommContext %2$s resulted in a call to serviceRequestSucceeded()", str, commContext == null ? "" : commContext.getCommContextId()));
                    dBAdapterAppData = new DBAdapterAppData(ReportManager.this._context);
                    for (UsageBucket usageBucket : this._appUsageList) {
                        dBAdapterAppData.appDataMarkAsSynced(usageBucket.getAppUsageData().getPackageName());
                    }
                    Log.d(Constants.TAG, String.format("ReportManager: Updated %1$d EVENT records as synced", Integer.valueOf(this._appUsageList.size())));
                    dBAdapterAppData.close();
                } catch (Exception e) {
                    e.printStackTrace();
                } catch (Throwable th) {
                    dBAdapterAppData.close();
                    throw th;
                }
            }
        }
    }

    protected class ReportInstalledAppCallback implements CallbackInterface {
        protected List<String> _packageNames = null;

        protected ReportInstalledAppCallback() {
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            try {
                System.out.println(String.format("Request %1$s on CommContext %2$s resulted in a call to serviceRequestFailed(). %3$s", str, commContext == null ? "" : commContext.getCommContextId(), exc == null ? "" : exc.getMessage()));
                if (exc != null) {
                    exc.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0074 A[SYNTHETIC, Splitter:B:21:0x0074] */
        @Override // com.getjar.sdk.comm.CallbackInterface
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void serviceRequestSucceeded(com.getjar.sdk.comm.Result r7, java.lang.String r8, com.getjar.sdk.comm.CommContext r9) {
            /*
                r6 = this;
                java.io.PrintStream r1 = java.lang.System.out     // Catch:{ Exception -> 0x0078 }
                if (r9 != 0) goto L_0x007d
                java.lang.String r0 = ""
            L_0x0006:
                java.lang.String r2 = "Request %1$s on CommContext %2$s resulted in a call to serviceRequestSucceeded()"
                r3 = 2
                java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x0078 }
                r4 = 0
                r3[r4] = r8     // Catch:{ Exception -> 0x0078 }
                r4 = 1
                r3[r4] = r0     // Catch:{ Exception -> 0x0078 }
                java.lang.String r0 = java.lang.String.format(r2, r3)     // Catch:{ Exception -> 0x0078 }
                r1.println(r0)     // Catch:{ Exception -> 0x0078 }
                r2 = 0
                com.getjar.sdk.data.DBAdapterAppData r1 = new com.getjar.sdk.data.DBAdapterAppData     // Catch:{ all -> 0x0088 }
                com.getjar.sdk.data.ReportManager r0 = com.getjar.sdk.data.ReportManager.this     // Catch:{ all -> 0x0088 }
                android.content.Context r0 = r0._context     // Catch:{ all -> 0x0088 }
                r1.<init>(r0)     // Catch:{ all -> 0x0088 }
                java.util.List<java.lang.String> r0 = r6._packageNames     // Catch:{ all -> 0x0071 }
                java.util.Iterator r3 = r0.iterator()     // Catch:{ all -> 0x0071 }
            L_0x002a:
                boolean r0 = r3.hasNext()     // Catch:{ all -> 0x0071 }
                if (r0 == 0) goto L_0x0082
                java.lang.Object r0 = r3.next()     // Catch:{ all -> 0x0071 }
                java.lang.String r0 = (java.lang.String) r0     // Catch:{ all -> 0x0071 }
                com.getjar.sdk.rewards.AppData r2 = r1.appDataLoad(r0)     // Catch:{ all -> 0x0071 }
                if (r2 != 0) goto L_0x0048
                com.getjar.sdk.data.ReportManager r2 = com.getjar.sdk.data.ReportManager.this     // Catch:{ all -> 0x0071 }
                android.content.Context r2 = r2._context     // Catch:{ all -> 0x0071 }
                com.getjar.sdk.rewards.AppData$AppStatus r4 = com.getjar.sdk.rewards.AppData.AppStatus.INSTALLED     // Catch:{ all -> 0x0071 }
                com.getjar.sdk.rewards.AppData r2 = com.getjar.sdk.utilities.Utility.getApplicationInfo(r2, r0, r4)     // Catch:{ all -> 0x0071 }
            L_0x0048:
                if (r2 == 0) goto L_0x002a
                r1.appDataUpsert(r2)     // Catch:{ all -> 0x0071 }
                r1.appDataMarkAsSynced(r0)     // Catch:{ all -> 0x0071 }
                com.getjar.sdk.data.ReportManager r2 = com.getjar.sdk.data.ReportManager.this     // Catch:{ all -> 0x0071 }
                com.getjar.sdk.utilities.Logger r2 = r2.log     // Catch:{ all -> 0x0071 }
                java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0071 }
                r4.<init>()     // Catch:{ all -> 0x0071 }
                java.lang.String r5 = "serviceRequestSucceeded() -- marked "
                java.lang.StringBuilder r4 = r4.append(r5)     // Catch:{ all -> 0x0071 }
                java.lang.StringBuilder r0 = r4.append(r0)     // Catch:{ all -> 0x0071 }
                java.lang.String r4 = " as synced in DB.."
                java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ all -> 0x0071 }
                java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0071 }
                r2.debug(r0)     // Catch:{ all -> 0x0071 }
                goto L_0x002a
            L_0x0071:
                r0 = move-exception
            L_0x0072:
                if (r1 == 0) goto L_0x0077
                r1.close()     // Catch:{ Exception -> 0x0078 }
            L_0x0077:
                throw r0     // Catch:{ Exception -> 0x0078 }
            L_0x0078:
                r0 = move-exception
                r0.printStackTrace()
            L_0x007c:
                return
            L_0x007d:
                java.lang.String r0 = r9.getCommContextId()     // Catch:{ Exception -> 0x0078 }
                goto L_0x0006
            L_0x0082:
                if (r1 == 0) goto L_0x007c
                r1.close()     // Catch:{ Exception -> 0x0078 }
                goto L_0x007c
            L_0x0088:
                r0 = move-exception
                r1 = r2
                goto L_0x0072
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.ReportManager.ReportInstalledAppCallback.serviceRequestSucceeded(com.getjar.sdk.comm.Result, java.lang.String, com.getjar.sdk.comm.CommContext):void");
        }

        /* access modifiers changed from: protected */
        public void setPackageList(List<String> list) {
            this._packageNames = new ArrayList(list.size());
            for (String str : this._packageNames) {
                this._packageNames.add(str);
            }
        }
    }

    protected class ReportUsageCallback extends ReportCallbackBase {
        protected ReportUsageCallback() {
            super();
        }

        @Override // com.getjar.sdk.data.ReportManager.ReportCallbackBase, com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            DBAdapterAppData dBAdapterAppData;
            synchronized (ReportManager._DB_UPDATEING_LOCK) {
                try {
                    System.out.println(String.format("Request %1$s on CommContext %2$s resulted in a call to serviceRequestSucceeded()", str, commContext == null ? "" : commContext.getCommContextId()));
                    dBAdapterAppData = new DBAdapterAppData(ReportManager.this._context);
                    for (UsageBucket usageBucket : this._appUsageList) {
                        if (usageBucket.getLaunchEvent() == null) {
                            Log.e(Constants.TAG, "ReportManager: ReportUsageCallback: made with data that is missing required LaunchEvent instances");
                        } else {
                            dBAdapterAppData.usageUpdateLaunchEventAsSynced(usageBucket.getLaunchEvent());
                        }
                    }
                    Log.d(Constants.TAG, String.format("ReportManager: ReportUsageCallback: Updated %1$d USAGE records as synced", Integer.valueOf(this._appUsageList.size())));
                    dBAdapterAppData.usagePurgeSyncedLaunchEvents();
                    dBAdapterAppData.close();
                } catch (Exception e) {
                    e.printStackTrace();
                } catch (Throwable th) {
                    dBAdapterAppData.close();
                    throw th;
                }
            }
        }
    }

    public ReportManager(Context context, CommContext commContext) {
        if (context == null || commContext == null) {
            throw new IllegalArgumentException("invalid context or commContext supplied");
        }
        this._context = context;
        this._commContext = commContext;
    }

    private List<AppData> _getCurrentlyRunningApps() throws PackageManager.NameNotFoundException, IllegalArgumentException, IllegalAccessException {
        ArrayList arrayList = new ArrayList();
        List<ActivityManager.RunningTaskInfo> runningTasks = ((ActivityManager) this._context.getSystemService("activity")).getRunningTasks(5000);
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= runningTasks.size()) {
                return arrayList;
            }
            AppData applicationInfo = Utility.getApplicationInfo(this._context, runningTasks.get(i2).baseActivity.getPackageName(), AppData.AppStatus.INSTALLED);
            if (!Utility.shouldFilterApp(applicationInfo) && !applicationInfo.getPackageName().equalsIgnoreCase(this._context.getPackageName())) {
                arrayList.add(applicationInfo);
            }
            i = i2 + 1;
        }
    }

    private List<AppData> _getRecentlyRunAppsFromOS() throws PackageManager.NameNotFoundException, IllegalArgumentException, IllegalAccessException {
        ArrayList arrayList = new ArrayList();
        PackageManager packageManager = this._context.getPackageManager();
        List<ActivityManager.RecentTaskInfo> recentTasks = ((ActivityManager) this._context.getSystemService("activity")).getRecentTasks(5000, 1);
        for (int i = 0; i < recentTasks.size(); i++) {
            ActivityManager.RecentTaskInfo recentTaskInfo = recentTasks.get(i);
            Intent intent = new Intent(recentTaskInfo.baseIntent);
            if (recentTaskInfo.origActivity != null) {
                intent.setComponent(recentTaskInfo.origActivity);
            }
            intent.setFlags((intent.getFlags() & -2097153) | 268435456);
            ResolveInfo resolveActivity = packageManager.resolveActivity(intent, 0);
            if (resolveActivity != null) {
                AppData applicationInfo = Utility.getApplicationInfo(this._context, resolveActivity.activityInfo.packageName, AppData.AppStatus.INSTALLED);
                if (!Utility.shouldFilterApp(applicationInfo) && !applicationInfo.getPackageName().equalsIgnoreCase(this._context.getPackageName())) {
                    arrayList.add(applicationInfo);
                }
            }
        }
        return arrayList;
    }

    private void _reportApplicationUsageInChunks(List<UsageBucket> list, Class<?> cls) throws Exception {
        Log.d(Constants.TAG, "ReportManager: _reportApplicationUsageInChunks() -- START");
        if (!ReportCallbackBase.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("'reportCallbackType' must be a subclass of ReportCallbackBase");
        }
        Constructor<?> declaredConstructor = cls.getDeclaredConstructor(ReportManager.class);
        declaredConstructor.setAccessible(true);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.add(list.get(i));
            arrayList2.add(list.get(i).getAppUsageData());
            if (arrayList.size() >= 50) {
                ReportCallbackBase reportCallbackBase = (ReportCallbackBase) declaredConstructor.newInstance(this);
                reportCallbackBase.setAppUsageData(arrayList);
                Log.d(Constants.TAG, String.format("ReportManager: _reportApplicationUsageInChunks() -- Calling reportApplicationUsage for %1$d records [callback:%2$s]", Integer.valueOf(arrayList2.size()), reportCallbackBase.getClass().getName()));
                UserServiceProxy.getInstance().reportApplicationUsage(this._commContext, arrayList2, reportCallbackBase);
                arrayList.clear();
                arrayList2.clear();
            }
        }
        if (arrayList.size() > 0) {
            ReportCallbackBase reportCallbackBase2 = (ReportCallbackBase) declaredConstructor.newInstance(this);
            reportCallbackBase2.setAppUsageData(arrayList);
            Log.d(Constants.TAG, String.format("ReportManager: _reportApplicationUsageInChunks() -- Calling reportApplicationUsage for %1$d records [callback:%2$s]", Integer.valueOf(arrayList2.size()), reportCallbackBase2.getClass().getName()));
            UserServiceProxy.getInstance().reportApplicationUsage(this._commContext, arrayList2, reportCallbackBase2);
            arrayList.clear();
            arrayList2.clear();
        }
        Log.d(Constants.TAG, "ReportManager: _reportApplicationUsageInChunks() -- DONE");
    }

    /* JADX DEBUG: Type inference failed for r2v35. Raw type applied. Possible types: java.util.List<com.getjar.sdk.rewards.AppData> */
    /* JADX DEBUG: Type inference failed for r2v36. Raw type applied. Possible types: java.util.List<com.getjar.sdk.rewards.AppData> */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void doStatsWork() {
        /*
            r12 = this;
            r3 = 0
            com.getjar.sdk.utilities.Logger r2 = r12.log
            java.lang.String r4 = "doStatsWork() -- START"
            r2.debug(r4)
            com.getjar.sdk.data.DBAdapterRunningApps r7 = new com.getjar.sdk.data.DBAdapterRunningApps
            android.content.Context r2 = r12._context
            r7.<init>(r2)
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ Throwable -> 0x00c2 }
            r2.<init>()     // Catch:{ Throwable -> 0x00c2 }
            android.content.Context r4 = r12._context     // Catch:{ Throwable -> 0x00c2 }
            java.lang.String r5 = "android.permission.GET_TASKS"
            boolean r4 = com.getjar.sdk.utilities.RewardUtility.checkPermission(r4, r5)     // Catch:{ Throwable -> 0x00c2 }
            if (r4 == 0) goto L_0x013c
            java.util.List r2 = r12._getRecentlyRunAppsFromOS()     // Catch:{ Throwable -> 0x00c2 }
            r6 = r2
        L_0x0023:
            java.util.List r8 = r7.loadAll()     // Catch:{ Throwable -> 0x00c2 }
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ Throwable -> 0x00c2 }
            r2.<init>()     // Catch:{ Throwable -> 0x00c2 }
            android.content.Context r4 = r12._context     // Catch:{ Throwable -> 0x00c2 }
            java.lang.String r5 = "android.permission.GET_TASKS"
            boolean r4 = com.getjar.sdk.utilities.RewardUtility.checkPermission(r4, r5)     // Catch:{ Throwable -> 0x00c2 }
            if (r4 == 0) goto L_0x0139
            java.util.List r2 = r12._getCurrentlyRunningApps()     // Catch:{ Throwable -> 0x00c2 }
            r5 = r2
        L_0x003b:
            r7.deleteAppData()     // Catch:{ Throwable -> 0x00c2 }
            java.util.ArrayList r9 = new java.util.ArrayList     // Catch:{ Throwable -> 0x00c2 }
            r9.<init>()     // Catch:{ Throwable -> 0x00c2 }
            r4 = r3
        L_0x0044:
            int r2 = r5.size()     // Catch:{ Throwable -> 0x00c2 }
            if (r4 >= r2) goto L_0x005e
            java.lang.Object r2 = r5.get(r4)     // Catch:{ Throwable -> 0x00c2 }
            com.getjar.sdk.rewards.AppData r2 = (com.getjar.sdk.rewards.AppData) r2     // Catch:{ Throwable -> 0x00c2 }
            r10 = 1
            r2.setWasRunning(r10)     // Catch:{ Throwable -> 0x00c2 }
            r7.addAppData(r2)     // Catch:{ Throwable -> 0x00c2 }
            r9.add(r2)     // Catch:{ Throwable -> 0x00c2 }
            int r2 = r4 + 1
            r4 = r2
            goto L_0x0044
        L_0x005e:
            r4 = r3
        L_0x005f:
            int r2 = r6.size()     // Catch:{ Throwable -> 0x00c2 }
            if (r4 >= r2) goto L_0x007f
            java.lang.Object r2 = r6.get(r4)     // Catch:{ Throwable -> 0x00c2 }
            com.getjar.sdk.rewards.AppData r2 = (com.getjar.sdk.rewards.AppData) r2     // Catch:{ Throwable -> 0x00c2 }
            r10 = 0
            r2.setWasRunning(r10)     // Catch:{ Throwable -> 0x00c2 }
            r7.addAppData(r2)     // Catch:{ Throwable -> 0x00c2 }
            boolean r10 = r9.contains(r2)     // Catch:{ Throwable -> 0x00c2 }
            if (r10 != 0) goto L_0x007b
            r9.add(r2)     // Catch:{ Throwable -> 0x00c2 }
        L_0x007b:
            int r2 = r4 + 1
            r4 = r2
            goto L_0x005f
        L_0x007f:
            r4 = r3
        L_0x0080:
            int r2 = r9.size()     // Catch:{ Throwable -> 0x00c2 }
            if (r4 >= r2) goto L_0x00d5
            java.lang.Object r2 = r9.get(r4)     // Catch:{ Throwable -> 0x00c2 }
            com.getjar.sdk.rewards.AppData r2 = (com.getjar.sdk.rewards.AppData) r2     // Catch:{ Throwable -> 0x00c2 }
            boolean r6 = r8.contains(r2)     // Catch:{ Throwable -> 0x00c2 }
            if (r6 != 0) goto L_0x00b9
            com.getjar.sdk.data.DBAdapterAppData r6 = new com.getjar.sdk.data.DBAdapterAppData     // Catch:{ Throwable -> 0x00c2 }
            android.content.Context r10 = r12._context     // Catch:{ Throwable -> 0x00c2 }
            r6.<init>(r10)     // Catch:{ Throwable -> 0x00c2 }
            java.lang.String r10 = r2.getPackageName()     // Catch:{ all -> 0x00bd }
            com.getjar.sdk.rewards.AppData r10 = r6.appDataLoad(r10)     // Catch:{ all -> 0x00bd }
            if (r10 != 0) goto L_0x00a6
            r6.appDataUpsert(r2)     // Catch:{ all -> 0x00bd }
        L_0x00a6:
            java.lang.String r2 = r2.getPackageName()     // Catch:{ all -> 0x00bd }
            java.util.Date r10 = new java.util.Date     // Catch:{ all -> 0x00bd }
            r10.<init>()     // Catch:{ all -> 0x00bd }
            long r10 = r10.getTime()     // Catch:{ all -> 0x00bd }
            r6.usageIncrementLaunchCount(r2, r10)     // Catch:{ all -> 0x00bd }
            r6.close()     // Catch:{ Throwable -> 0x00c2 }
        L_0x00b9:
            int r2 = r4 + 1
            r4 = r2
            goto L_0x0080
        L_0x00bd:
            r2 = move-exception
            r6.close()     // Catch:{ Throwable -> 0x00c2 }
            throw r2     // Catch:{ Throwable -> 0x00c2 }
        L_0x00c2:
            r2 = move-exception
            com.getjar.sdk.utilities.Logger r3 = r12.log     // Catch:{ all -> 0x0126 }
            r3.Log(r2)     // Catch:{ all -> 0x0126 }
            if (r7 == 0) goto L_0x00cd
            r7.close()     // Catch:{ Throwable -> 0x0135 }
        L_0x00cd:
            com.getjar.sdk.utilities.Logger r2 = r12.log
            java.lang.String r3 = "doStatsWork() -- DONE"
            r2.debug(r3)
            return
        L_0x00d5:
            r4 = r3
        L_0x00d6:
            int r2 = r5.size()     // Catch:{ Throwable -> 0x00c2 }
            if (r4 >= r2) goto L_0x012d
            java.lang.Object r2 = r5.get(r4)     // Catch:{ Throwable -> 0x00c2 }
            r0 = r2
            com.getjar.sdk.rewards.AppData r0 = (com.getjar.sdk.rewards.AppData) r0     // Catch:{ Throwable -> 0x00c2 }
            r3 = r0
            int r2 = r8.indexOf(r3)     // Catch:{ Throwable -> 0x00c2 }
            if (r2 < 0) goto L_0x011d
            java.lang.Object r2 = r8.get(r2)     // Catch:{ Throwable -> 0x00c2 }
            com.getjar.sdk.rewards.AppData r2 = (com.getjar.sdk.rewards.AppData) r2     // Catch:{ Throwable -> 0x00c2 }
            boolean r2 = r2.getWasRunning()     // Catch:{ Throwable -> 0x00c2 }
            if (r2 != 0) goto L_0x011d
            com.getjar.sdk.data.DBAdapterAppData r6 = new com.getjar.sdk.data.DBAdapterAppData     // Catch:{ Throwable -> 0x00c2 }
            android.content.Context r2 = r12._context     // Catch:{ Throwable -> 0x00c2 }
            r6.<init>(r2)     // Catch:{ Throwable -> 0x00c2 }
            java.lang.String r2 = r3.getPackageName()     // Catch:{ all -> 0x0121 }
            com.getjar.sdk.rewards.AppData r2 = r6.appDataLoad(r2)     // Catch:{ all -> 0x0121 }
            if (r2 != 0) goto L_0x010a
            r6.appDataUpsert(r3)     // Catch:{ all -> 0x0121 }
        L_0x010a:
            java.lang.String r2 = r3.getPackageName()     // Catch:{ all -> 0x0121 }
            java.util.Date r3 = new java.util.Date     // Catch:{ all -> 0x0121 }
            r3.<init>()     // Catch:{ all -> 0x0121 }
            long r10 = r3.getTime()     // Catch:{ all -> 0x0121 }
            r6.usageIncrementLaunchCount(r2, r10)     // Catch:{ all -> 0x0121 }
            r6.close()     // Catch:{ Throwable -> 0x00c2 }
        L_0x011d:
            int r2 = r4 + 1
            r4 = r2
            goto L_0x00d6
        L_0x0121:
            r2 = move-exception
            r6.close()     // Catch:{ Throwable -> 0x00c2 }
            throw r2     // Catch:{ Throwable -> 0x00c2 }
        L_0x0126:
            r2 = move-exception
            if (r7 == 0) goto L_0x012c
            r7.close()     // Catch:{ Throwable -> 0x0137 }
        L_0x012c:
            throw r2
        L_0x012d:
            if (r7 == 0) goto L_0x00cd
            r7.close()     // Catch:{ Throwable -> 0x0133 }
            goto L_0x00cd
        L_0x0133:
            r2 = move-exception
            goto L_0x00cd
        L_0x0135:
            r2 = move-exception
            goto L_0x00cd
        L_0x0137:
            r3 = move-exception
            goto L_0x012c
        L_0x0139:
            r5 = r2
            goto L_0x003b
        L_0x013c:
            r6 = r2
            goto L_0x0023
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.ReportManager.doStatsWork():void");
    }

    public void sendInstalledApps() throws Exception {
        int i;
        this.log.debug("sendInstalledApps() -- START");
        PackageManager packageManager = this._context.getPackageManager();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(128);
        int i2 = 0;
        int i3 = 0;
        while (i3 < installedApplications.size()) {
            int i4 = i2 + 1;
            try {
                String str = installedApplications.get(i3).packageName;
                arrayList2.add(str);
                try {
                    ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str, 128);
                    i = applicationInfo != null ? applicationInfo.flags : 0;
                } catch (Exception e) {
                    i = 0;
                }
                AppUsageData appUsageData = new AppUsageData(str, i);
                appUsageData.setType(AppUsageData.UsageType.FOUND_INSTALLED);
                this.log.debug("sendInstalledApps() -- FOUND_INSTALLED: " + str);
                PackageInfo packageInfo = packageManager.getPackageInfo(str, 128);
                appUsageData.setEventTimestamp(System.currentTimeMillis());
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM, "android");
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM_VERSION, Build.VERSION.RELEASE);
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_NAME, str);
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_CODE, Integer.toString(packageInfo.versionCode));
                if (!StringUtility.isNullOrEmpty(packageInfo.versionName)) {
                    appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_NAME, packageInfo.versionName);
                }
                arrayList.add(appUsageData);
                if (i4 % 50 == 0) {
                    if (arrayList.size() > 0) {
                        ReportInstalledAppCallback reportInstalledAppCallback = new ReportInstalledAppCallback();
                        reportInstalledAppCallback.setPackageList(arrayList2);
                        UserServiceProxy.getInstance().reportApplicationUsage(this._commContext, arrayList, reportInstalledAppCallback);
                    }
                    arrayList.clear();
                    arrayList2.clear();
                }
            } catch (PackageManager.NameNotFoundException e2) {
            }
            i3++;
            i2 = i4;
        }
        if (arrayList.size() > 0) {
            ReportInstalledAppCallback reportInstalledAppCallback2 = new ReportInstalledAppCallback();
            reportInstalledAppCallback2.setPackageList(arrayList2);
            UserServiceProxy.getInstance().reportApplicationUsage(this._commContext, arrayList, reportInstalledAppCallback2);
        }
    }

    /* JADX INFO: finally extract failed */
    public void sendUnsyncedEventData() throws Exception {
        new ArrayList();
        DBAdapterAppData dBAdapterAppData = new DBAdapterAppData(this._context);
        try {
            List<AppData> appDataLoadUnsynced = dBAdapterAppData.appDataLoadUnsynced();
            dBAdapterAppData.close();
            ArrayList arrayList = new ArrayList();
            Log.d(Constants.TAG, String.format("ReportManager: sendUnsyncedEventData() -- Sending %1$d EVENT records", Integer.valueOf(appDataLoadUnsynced.size())));
            for (AppData appData : appDataLoadUnsynced) {
                AppUsageData appUsageData = new AppUsageData(appData.getPackageName(), appData.getFlags());
                if (appData.getStatus() == AppData.AppStatus.UNINSTALLED) {
                    appUsageData.setType(AppUsageData.UsageType.UNINSTALLED);
                } else if (appData.getStatus() == AppData.AppStatus.INSTALLED) {
                    appUsageData.setType(AppUsageData.UsageType.INSTALLED);
                }
                appUsageData.setEventTimestamp(System.currentTimeMillis());
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM, "android");
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM_VERSION, Build.VERSION.RELEASE);
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_NAME, appData.getPackageName());
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_CODE, appData.getVersionCode().toString());
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_NAME, appData.getVersionName());
                arrayList.add(new UsageBucket(appUsageData, appData));
            }
            if (arrayList.size() > 0) {
                _reportApplicationUsageInChunks(arrayList, ReportEventCallback.class);
            }
        } catch (Throwable th) {
            dBAdapterAppData.close();
            throw th;
        }
    }

    /* JADX INFO: finally extract failed */
    public void sendUnsyncedUsageData() throws Exception {
        ArrayList arrayList = new ArrayList();
        DBAdapterAppData dBAdapterAppData = new DBAdapterAppData(this._context);
        try {
            List<LaunchEvent> usageLoadNonSyncedLaunchEvents = dBAdapterAppData.usageLoadNonSyncedLaunchEvents();
            Log.d(Constants.TAG, String.format("ReportManager: sendUnsyncedUsageData() -- Sending %1$d USAGE records", Integer.valueOf(usageLoadNonSyncedLaunchEvents.size())));
            for (LaunchEvent launchEvent : usageLoadNonSyncedLaunchEvents) {
                AppData appDataLoad = dBAdapterAppData.appDataLoad(launchEvent.getPackageName());
                AppUsageData appUsageData = new AppUsageData(appDataLoad.getPackageName(), appDataLoad.getFlags());
                appUsageData.setEventTimestamp(System.currentTimeMillis());
                appUsageData.setType(AppUsageData.UsageType.USED);
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM, "android");
                appUsageData.getAppMetadata().put(Constants.META_DEVICE_PLATFORM_VERSION, Build.VERSION.RELEASE);
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_NAME, appDataLoad.getPackageName());
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_CODE, appDataLoad.getVersionCode().toString());
                appUsageData.getAppMetadata().put(Constants.META_PACKAGE_VERSION_NAME, appDataLoad.getVersionName());
                arrayList.add(new UsageBucket(appUsageData, launchEvent));
            }
            dBAdapterAppData.close();
            if (arrayList.size() > 0) {
                _reportApplicationUsageInChunks(arrayList, ReportUsageCallback.class);
            }
        } catch (Throwable th) {
            dBAdapterAppData.close();
            throw th;
        }
    }
}

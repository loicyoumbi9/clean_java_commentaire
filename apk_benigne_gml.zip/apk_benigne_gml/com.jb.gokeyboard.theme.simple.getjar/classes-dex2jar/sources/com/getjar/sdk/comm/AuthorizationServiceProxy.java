package com.getjar.sdk.comm;

import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import org.json.JSONException;

public class AuthorizationServiceProxy extends ServiceProxyBase {
    private static final String _CONTRACT_VERSION = "20120416";
    private static AuthorizationServiceProxy _Instance = null;
    private static final String _URL_TEMPLATE_AUTHORIZE = String.format("%1$s%2$s", "%1$sbase_auth/authorize?application_key=%2$s&provider_filter=device&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_USER_ACCESS_CREATE = String.format("%1$s%2$s", "%1$suser_access/user_accesses/create?provider_filter=device_user&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_USER_ACCESS_FIND = String.format("%1$s%2$s", "%1$suser_access/user_accesses?provider_filter=device_user&version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_USER_ACCESS_GET = String.format("%1$s%2$s", "%1$suser_access/user_accesses/%2$s?version=", _CONTRACT_VERSION);
    private static final String _URL_TEMPLATE_USER_ACCESS_VALIDATE = String.format("%1$s%2$s", "%1$suser_access/user_accesses/validate?user_access_id=%2$s&version=", _CONTRACT_VERSION);

    private AuthorizationServiceProxy() {
    }

    public static AuthorizationServiceProxy getInstance() {
        if (_Instance == null) {
            makeTheInstance();
        }
        return _Instance;
    }

    private static void makeTheInstance() {
        synchronized (AuthorizationServiceProxy.class) {
            try {
                if (_Instance == null) {
                    _Instance = new AuthorizationServiceProxy();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public Operation authorize(CommContext commContext, String str) throws UnsupportedEncodingException, JSONException {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        }
        HashMap hashMap = new HashMap(2);
        hashMap.put("scope", "[\"default\"]");
        hashMap.put("metadata", commContext.getDeviceMetadataJsonWithReliabilities());
        return makeAsyncPOSTRequestForJson("authorize", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_AUTHORIZE, str, URLEncoder.encode(commContext.getApplicationKey(), Constants.ENCODING_CHARSET)), hashMap, null, false);
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public boolean checkIfOperationShouldBeRetried(CommContext commContext, Result result, int i, int i2) throws JSONException {
        return false;
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public Request.ServiceName getServiceName() {
        return Request.ServiceName.AUTH;
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.ServiceProxyBase
    public void preRequestWork(Operation operation) {
    }

    public String userAccessCreate(CommContext commContext, CallbackInterface callbackInterface, String str) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            commContext.waitForAuthorization();
            HashMap hashMap = new HashMap(2);
            hashMap.put("scope", "[\"default\"]");
            hashMap.put("metadata", commContext.getDeviceMetadataJsonWithReliabilities());
            return Integer.toString(makeAsyncPOSTRequestForJson("userAccessCreate", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_USER_ACCESS_CREATE, str, URLEncoder.encode(commContext.getApplicationKey(), Constants.ENCODING_CHARSET)), hashMap, callbackInterface, false).getId());
        }
    }

    public String userAccessFind(CommContext commContext, CallbackInterface callbackInterface, String str) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            commContext.waitForAuthorization();
            HashMap hashMap = new HashMap(1);
            hashMap.put("metadata", commContext.getDeviceMetadataJsonWithReliabilities());
            return Integer.toString(makeAsyncPOSTRequestForJson("userAccessFind", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_USER_ACCESS_FIND, str), hashMap, callbackInterface, false).getId());
        }
    }

    public String userAccessGet(CommContext commContext, String str, CallbackInterface callbackInterface, String str2) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'userAccessId' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            commContext.waitForAuthorization();
            commContext.waitForUserAccess();
            return Integer.toString(makeAsyncGETRequestForJson("userAccessGet", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_USER_ACCESS_GET, str2, URLEncoder.encode(str, Constants.ENCODING_CHARSET)), callbackInterface, false).getId());
        }
    }

    public String userAccessValidate(CommContext commContext, String str, CallbackInterface callbackInterface, String str2) throws Exception {
        if (commContext == null) {
            throw new IllegalArgumentException("The required parameter 'commContext' was not provided");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("The required parameter 'userAccessId' was not provided");
        } else if (callbackInterface == null) {
            throw new IllegalArgumentException("The required parameter 'callbacks' was not provided");
        } else {
            commContext.waitForAuthorization();
            HashMap hashMap = new HashMap(1);
            hashMap.put("metadata", commContext.getDeviceMetadataJsonWithReliabilities());
            return Integer.toString(makeAsyncPOSTRequestForJson("userAccessValidate", Operation.Priority.HIGH, commContext, String.format(_URL_TEMPLATE_USER_ACCESS_VALIDATE, str2, URLEncoder.encode(str, Constants.ENCODING_CHARSET)), hashMap, callbackInterface, false).getId());
        }
    }
}

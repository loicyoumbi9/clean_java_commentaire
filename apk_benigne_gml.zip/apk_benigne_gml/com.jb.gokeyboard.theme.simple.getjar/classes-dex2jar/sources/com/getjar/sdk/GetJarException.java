package com.getjar.sdk;

public class GetJarException extends RuntimeException {
    private static final long serialVersionUID = -127143903208982659L;

    public GetJarException() {
    }

    public GetJarException(String str) {
        super(str);
    }

    public GetJarException(String str, Throwable th) {
        super(str, th);
    }

    public GetJarException(Throwable th) {
        super(th);
    }
}

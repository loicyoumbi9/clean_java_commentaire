package com.getjar.sdk.utilities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import com.getjar.sdk.comm.CommContext;
import com.getjar.sdk.comm.GetJarConfig;
import com.getjar.sdk.data.metadata.PackageMonitor;

public final class AlarmsUtility {
    private static String _KeyLastRunTimestampCollectUsage = "CollectUsageLastRunTimestamp";
    private static String _KeyLastRunTimestampEventReporting = "EventReportingLastRunTimestamp";
    private static String _KeyLastRunTimestampUsageReporting = "UsageReportingLastRunTimestamp";

    private static boolean checkLastRun(Context context, String str, long j) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("GetJarClientPrefs", 0);
        if (sharedPreferences.contains(str)) {
            long j2 = sharedPreferences.getLong(str, 0);
            return j2 == 0 || j2 + j < System.currentTimeMillis();
        }
    }

    private static void ensureCollectUsageAlarm(Context context, long j) {
        synchronized (AlarmsUtility.class) {
            try {
                Log.d(Constants.TAG, String.format("Alarms: ensureCollectUsageAlarm() -- START: collectUsageInterval=%1$d", Long.valueOf(j)));
                if (context == null) {
                    throw new IllegalArgumentException("'context' can not be NULL");
                }
                if (checkLastRun(context, _KeyLastRunTimestampCollectUsage, j)) {
                    scheduleAlarm(context, Constants.COLLECT_DATA, 10000, j, 0);
                } else {
                    Log.v(Constants.TAG, "Alarms: ensureCollectUsageAlarm() -- Alarm does not need to be scheduled or run at this time");
                }
                Log.d(Constants.TAG, "Alarms: ensureCollectUsageAlarm() -- END");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static void ensureEventReportingAlarm(Context context, long j) {
        synchronized (AlarmsUtility.class) {
            try {
                Log.d(Constants.TAG, String.format("Alarms: ensureEventReportingAlarm() -- START: eventReportingInterval=%1$d", Long.valueOf(j)));
                if (context == null) {
                    throw new IllegalArgumentException("'context' can not be NULL");
                }
                if (checkLastRun(context, _KeyLastRunTimestampEventReporting, j)) {
                    scheduleAlarm(context, Constants.EVENTS_REPORT, 40000, j, 2);
                } else {
                    Log.v(Constants.TAG, "Alarms: ensureEventReportingAlarm() -- Alarm does not need to be scheduled or run at this time");
                }
                Log.d(Constants.TAG, "Alarms: ensureEventReportingAlarm() -- END");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static void ensureUsageReportingAlarm(Context context, long j) {
        synchronized (AlarmsUtility.class) {
            try {
                Log.d(Constants.TAG, String.format("Alarms: ensureUsageReportingAlarm() -- START: usageReportingInterval=%1$d", Long.valueOf(j)));
                if (context == null) {
                    throw new IllegalArgumentException("'context' can not be NULL");
                }
                if (checkLastRun(context, _KeyLastRunTimestampUsageReporting, j)) {
                    scheduleAlarm(context, Constants.USAGE_TRACKING, 20000, j, 1);
                } else {
                    Log.v(Constants.TAG, "Alarms: ensureUsageReportingAlarm() -- Alarm does not need to be scheduled or run at this time");
                }
                Log.d(Constants.TAG, "Alarms: ensureUsageReportingAlarm() -- END");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static void scheduleAlarm(Context context, String str, long j, long j2, int i) {
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'operation' can not be NULL or empty");
        } else if (Constants.COLLECT_DATA.equals(str) || Constants.USAGE_TRACKING.equals(str) || Constants.EVENTS_REPORT.equals(str)) {
            Log.d(Constants.TAG, String.format("Alarms: ensureAlarm() -- Scheduling alarm [operation:%1$s start:%2$d, interval:%3$d, requestCode:%4$d]", str, Long.valueOf(j), Long.valueOf(j2), Integer.valueOf(i)));
            Intent intent = new Intent();
            intent.setClass(context, PackageMonitor.class);
            intent.putExtra(str, str);
            ((AlarmManager) context.getSystemService("alarm")).setRepeating(0, System.currentTimeMillis() + j, j2, PendingIntent.getBroadcast(context, i, intent, 134217728));
        } else {
            throw new IllegalArgumentException("'operation' must be one of Constants.COLLECT_DATA, Constants.USAGE_TRACKING, or Constants.EVENTS_REPORT");
        }
    }

    public static void startBackgroundReporting(CommContext commContext, GetJarConfig getJarConfig) {
        synchronized (AlarmsUtility.class) {
            try {
                Log.d(Constants.TAG, "startBackgroundReporting() -- START");
                if (commContext == null) {
                    throw new IllegalArgumentException("'commContext' can not be NULL");
                } else if (getJarConfig == null) {
                    throw new IllegalArgumentException("'getJarConfig' can not be NULL");
                } else {
                    Context applicationContext = commContext.getApplicationContext();
                    Long valueOf = Long.valueOf(Utility.convertMillSec(Long.parseLong(getJarConfig.getDirectiveValue(GetJarConfig.KEY_COLLECT_USAGE_INTERVAL))));
                    if (valueOf != null && valueOf.longValue() > 0) {
                        ensureCollectUsageAlarm(applicationContext, valueOf.longValue());
                    }
                    try {
                        Long valueOf2 = Long.valueOf(Utility.convertMillSec(Long.parseLong(getJarConfig.getDirectiveValue(GetJarConfig.KEY_SEND_ALL_INSTALL_INTERVAL))));
                        if (valueOf2 != null && valueOf2.longValue() > 0) {
                            ensureEventReportingAlarm(applicationContext, valueOf2.longValue());
                        }
                    } catch (Exception e) {
                        Log.e(Constants.TAG, "ERROR: unable to start background EVENT reporting", e);
                    }
                    try {
                        Long valueOf3 = Long.valueOf(Utility.convertMillSec(Long.parseLong(getJarConfig.getDirectiveValue(GetJarConfig.KEY_SEND_USAGE_INTERVAL))));
                        if (valueOf3 != null && valueOf3.longValue() > 0) {
                            ensureUsageReportingAlarm(applicationContext, valueOf3.longValue());
                        }
                    } catch (Exception e2) {
                        Log.e(Constants.TAG, "ERROR: unable to start background USAGE reporting", e2);
                    }
                    Log.d(Constants.TAG, "startBackgroundReporting() -- END");
                }
            } catch (Exception e3) {
                Log.e(Constants.TAG, "ERROR: unable to start background USAGE collection", e3);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static void updateLastRunTimestamp(Context context, String str) {
        SharedPreferences.Editor edit = context.getSharedPreferences("GetJarClientPrefs", 0).edit();
        edit.putLong(str, System.currentTimeMillis()).commit();
        edit.commit();
    }

    public static void updateLastRunTimestampCollectUsage(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be NULL");
        }
        updateLastRunTimestamp(context, _KeyLastRunTimestampCollectUsage);
    }

    public static void updateLastRunTimestampEventReporting(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be NULL");
        }
        updateLastRunTimestamp(context, _KeyLastRunTimestampEventReporting);
    }

    public static void updateLastRunTimestampUsageReporting(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'context' can not be NULL");
        }
        updateLastRunTimestamp(context, _KeyLastRunTimestampUsageReporting);
    }
}

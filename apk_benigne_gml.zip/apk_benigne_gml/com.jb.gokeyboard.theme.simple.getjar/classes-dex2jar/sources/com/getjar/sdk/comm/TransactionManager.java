package com.getjar.sdk.comm;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import com.getjar.sdk.comm.persistence.DBTransactions;
import com.getjar.sdk.comm.persistence.EarnBucket;
import com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket;
import com.getjar.sdk.comm.persistence.RelatedEarnData;
import com.getjar.sdk.comm.persistence.RelatedPurchaseData;
import com.getjar.sdk.comm.persistence.TransactionBucket;
import com.getjar.sdk.response.PurchaseSucceededResponse;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.RewardUtility;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class TransactionManager {
    private static ConcurrentLinkedQueue<String> _CanceledClientTransactionIDs = new ConcurrentLinkedQueue<>();
    private static Object _PurchaseTransactionStateLock = new Object();
    private static final Object _TransactionFlowLock = new Object();
    private Context _applicationContext;

    private class ResilienceRetryEarnCallback implements CallbackInterface {
        private EarnBucket _earnBucket = null;
        private RelatedEarnData _earnData = null;

        public ResilienceRetryEarnCallback(EarnBucket earnBucket, RelatedEarnData relatedEarnData) {
            if (relatedEarnData == null) {
                throw new IllegalArgumentException("'earn' can not be NULL");
            } else if (earnBucket == null) {
                throw new IllegalArgumentException("'earnBucket' can not be NULL");
            } else if (StringUtility.isNullOrEmpty(earnBucket.getClientTransactionId())) {
                throw new IllegalArgumentException("'earnBucket.getClientTransactionId()' can not be NULL or empty");
            } else {
                this._earnData = relatedEarnData;
                this._earnBucket = earnBucket;
            }
        }

        private void updateCrazySharedPrefsStuff(Context context, String str, Result result, Constants.RequestInstallState requestInstallState) {
            if (result != null) {
                RewardUtility.savePreInstallRewardApplicationMetadata(context, str + Constants.RequestInstallType.SUFFIX_STATE, requestInstallState.toString());
                RewardUtility.savePreInstallRewardApplicationMetadata(context, str + Constants.RequestInstallType.SUFFIX_SUBSTATE, Utility.getResponseSubstate(result, Constants.RequestInstallSubState.NONE.toString()));
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryEarnCallback: request failed [clientTransactionId: %1$s]", this._earnBucket.getClientTransactionId()));
            Utility.pushFailNotification(commContext, String.format(Constants.NOTIFICATION_FAIL_SUBMISSION, this._earnData.getPackageName()));
            if (exc != null && ServicesException.class.isAssignableFrom(exc.getClass())) {
                updateCrazySharedPrefsStuff(commContext.getApplicationContext(), this._earnData.getPackageName(), ((ServicesException) exc).getRequestResult(), Constants.RequestInstallState.FAIL);
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryEarnCallback: retrying request [clientTransactionId: %1$s]", this._earnBucket.getClientTransactionId()));
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            String str2;
            String str3;
            String format;
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryEarnCallback: request succeeded [clientTransactionId: %1$s]", this._earnBucket.getClientTransactionId()));
            String transactionState = Utility.getTransactionState(result, "");
            String responseSubstate = Utility.getResponseSubstate(result, Constants.RequestInstallSubState.NONE.toString());
            long responseAmount = Utility.getResponseAmount(result, -1);
            String packageName = this._earnData.getPackageName();
            try {
                PackageManager packageManager = commContext.getApplicationContext().getPackageManager();
                str2 = (String) packageManager.getPackageInfo(this._earnData.getPackageName(), 128).applicationInfo.loadLabel(packageManager);
            } catch (Exception e) {
                str2 = packageName;
            }
            Log.d(Constants.TAG, String.format("TransactionManager: Pushing Earn notification [amount: %1$d] [state: %2$s] [substate: %3$s]", Long.valueOf(responseAmount), transactionState, responseSubstate));
            if (Constants.CAP_REACHED_FAILURE.equalsIgnoreCase(responseSubstate)) {
                Utility.pushFailNotification(commContext, String.format(Constants.NOTIFICATION_FAIL_CAP_REACHED, str2));
                updateCrazySharedPrefsStuff(commContext.getApplicationContext(), this._earnData.getPackageName(), result, Constants.RequestInstallState.FAIL);
            } else if (Constants.ALREADY_REDEEMED_FAILURE.equalsIgnoreCase(responseSubstate) || Constants.ALREADY_USED_FAILURE.equalsIgnoreCase(responseSubstate)) {
                Utility.pushFailNotification(commContext, String.format(Constants.NOTIFICATION_FAIL_REDEEMED, str2));
                updateCrazySharedPrefsStuff(commContext.getApplicationContext(), this._earnData.getPackageName(), result, Constants.RequestInstallState.FAIL);
            } else if (responseAmount > 0) {
                try {
                    PackageManager packageManager2 = commContext.getApplicationContext().getPackageManager();
                    str3 = (String) packageManager2.getPackageInfo(commContext.getApplicationContext().getPackageName(), 128).applicationInfo.loadLabel(packageManager2);
                } catch (Exception e2) {
                    Log.e(Constants.TAG, "TransactionManager: ResilienceRetryEarnCallback: Failed to get the name of the Hosting Application", e2);
                    str3 = null;
                }
                if (StringUtility.isNullOrEmpty(str3)) {
                    format = String.format(Constants.NOTIFICATION_PASS, Long.valueOf(responseAmount));
                } else {
                    format = String.format(Constants.NOTIFICATION_PASS_WITH_APP_NAME, Long.valueOf(responseAmount), str3);
                }
                if (!this._earnBucket.getIsNewTransaction()) {
                    format = String.format("%1$s %2$s", format, Constants.NOTIFICATION_PASS_POST_RETRY_ADDENDUM);
                }
                Utility.pushSuccessNotification(commContext, format);
                updateCrazySharedPrefsStuff(commContext.getApplicationContext(), this._earnData.getPackageName(), result, Constants.RequestInstallState.SUCCESS);
                RewardUtility.savePreInstallRewardApplicationMetadata(commContext.getApplicationContext(), this._earnData.getPackageName() + Constants.RequestInstallType.SUFFIX_AMOUNT, Long.toString(responseAmount));
            }
        }
    }

    private class ResilienceRetryPurchaseCallback implements CallbackInterface {
        private String _clientTransactionId = null;
        private RelatedPurchaseData _purchase = null;

        public ResilienceRetryPurchaseCallback(String str, RelatedPurchaseData relatedPurchaseData) {
            if (relatedPurchaseData == null) {
                throw new IllegalArgumentException("'purchase' can not be NULL");
            } else if (StringUtility.isNullOrEmpty(str)) {
                throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
            } else {
                this._purchase = relatedPurchaseData;
                this._clientTransactionId = str;
            }
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestFailed(Exception exc, String str, CommContext commContext) {
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryPurchaseCallback: request failed [clientTransactionId: %1$s]", this._clientTransactionId));
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestRetry(Exception exc, String str, CommContext commContext, int i) {
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryPurchaseCallback: retrying request [clientTransactionId: %1$s]", this._clientTransactionId));
        }

        @Override // com.getjar.sdk.comm.CallbackInterface
        public void serviceRequestSucceeded(Result result, String str, CommContext commContext) {
            Log.d(Constants.TAG, String.format("TransactionManager: ResilienceRetryPurchaseCallback: request succeeded [clientTransactionId: %1$s]", this._clientTransactionId));
        }
    }

    public TransactionManager(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'applicationContext' can not be NULL");
        }
        this._applicationContext = context.getApplicationContext();
    }

    private boolean checkCancelling(PurchaseUnmanagedBucket purchaseUnmanagedBucket) {
        if (_CanceledClientTransactionIDs.contains(purchaseUnmanagedBucket.getClientTransactionId())) {
            purchaseUnmanagedBucket.setState(DBTransactions.PurchaseState.CANCELING);
            Log.v(Constants.TAG, String.format("TransactionManager: checkCancelling() returning TRUE [clientTransactionId: %1$s] [thread: %2$d]", purchaseUnmanagedBucket.getClientTransactionId(), Long.valueOf(Thread.currentThread().getId())));
            return true;
        }
        Log.v(Constants.TAG, String.format("TransactionManager: checkCancelling() returning FALSE [clientTransactionId: %1$s] [thread: %2$d]", purchaseUnmanagedBucket.getClientTransactionId(), Long.valueOf(Thread.currentThread().getId())));
        return false;
    }

    private void handleSuccessfulReserveResult(Result result, CommContext commContext, CallbackInterface callbackInterface, PurchaseUnmanagedBucket purchaseUnmanagedBucket) {
        boolean z;
        Throwable th;
        DBTransactions dBTransactions;
        boolean z2 = false;
        try {
            synchronized (_PurchaseTransactionStateLock) {
                try {
                    dBTransactions = new DBTransactions(this._applicationContext);
                    TransactionBucket loadTransaction = dBTransactions.loadTransaction(purchaseUnmanagedBucket.getClientTransactionId());
                    try {
                        dBTransactions.close();
                    } catch (Exception e) {
                    }
                    if (loadTransaction != null) {
                        if (DBTransactions.PurchaseState.RESERVING.equals(((PurchaseUnmanagedBucket) loadTransaction).getState())) {
                            try {
                                updatePurchaseStateFromResponseState(result, purchaseUnmanagedBucket, DBTransactions.PurchaseState.CONFIRMING);
                                z = true;
                            } catch (Throwable th2) {
                                th = th2;
                                z2 = true;
                                throw th;
                            }
                        }
                    }
                    z = false;
                    try {
                    } catch (Throwable th3) {
                        th = th3;
                        z2 = z;
                        throw th;
                    }
                } catch (Throwable th4) {
                    th = th4;
                }
            }
        } catch (Exception e2) {
            try {
                Log.e(Constants.TAG, "TransactionManager: failure", e2);
                commContext.addException(e2);
                z = z2;
            } catch (Exception e3) {
                Log.e(Constants.TAG, "TransactionManager: failure", e3);
                commContext.addException(e3);
                return;
            }
        }
        if (z) {
            try {
                commContext.postResponse(new PurchaseSucceededResponse(purchaseUnmanagedBucket.getRelatedObject().getProductId(), (long) purchaseUnmanagedBucket.getRelatedObject().getAmount().intValue(), purchaseUnmanagedBucket.getRelatedObject().getProductName(), purchaseUnmanagedBucket.getClientTransactionId()));
            } catch (Exception e4) {
                Log.e(Constants.TAG, "TransactionManager: failure", e4);
                commContext.addException(e4);
            }
        }
    }

    private void runEarnTransaction(EarnBucket earnBucket, CommContext commContext, CallbackInterface callbackInterface, boolean z) throws Exception {
        String clientTransactionId = earnBucket.getClientTransactionId();
        Log.v(Constants.TAG, String.format("TransactionManager: runEarnTransaction() [clientTransactionId: %1$s] [state: %2$s] [callback: %3$s] [thread: %4$d]", clientTransactionId, earnBucket.getState().name(), callbackInterface.getClass().getName(), Long.valueOf(Thread.currentThread().getId())));
        if (DBTransactions.EarnState.CREATED.equals(earnBucket.getState()) || DBTransactions.EarnState.EARNING.equals(earnBucket.getState())) {
            if (DBTransactions.EarnState.CREATED.equals(earnBucket.getState())) {
                updateEarnTransactionState(this._applicationContext, earnBucket, DBTransactions.EarnState.EARNING);
            }
            RelatedEarnData relatedObject = earnBucket.getRelatedObject();
            Operation earn = TransactionServiceProxy.getInstance().earn(commContext, relatedObject.getItemId(), relatedObject.getPackageName(), clientTransactionId, relatedObject.getItemMetadata(), relatedObject.getTrackingMetadata(), z);
            try {
                earn.mapResultToCallbacks(callbackInterface);
            } catch (Exception e) {
                Log.e(Constants.TAG, "Result to callback mapping failed", e);
            }
            Result result = earn.get();
            if (result == null) {
                Log.e(Constants.TAG, String.format("TransactionManager: runEarnTransaction() Earn operation %1$d failed to get results", Integer.valueOf(earn.getId())));
            } else if (result.getResponseCode() == 200) {
                String responseSubstate = Utility.getResponseSubstate(result, Constants.RequestInstallSubState.NONE.toString());
                if (!"INCOMPLETE_RECONCILE_WARNING".equalsIgnoreCase(responseSubstate) && !"DEPENDENT_SERVICE_FAILURE".equalsIgnoreCase(responseSubstate) && !"UNKNOWN_RETRY_WARNING".equalsIgnoreCase(responseSubstate)) {
                    updateEarnTransactionState(this._applicationContext, earnBucket, DBTransactions.EarnState.DONE);
                }
            } else if (RequestUtilities.getServicesException(result) != null) {
                updateEarnTransactionState(this._applicationContext, earnBucket, DBTransactions.EarnState.DONE);
            }
        }
        if (DBTransactions.EarnState.DONE.equals(earnBucket.getState())) {
            DBTransactions dBTransactions = new DBTransactions(this._applicationContext);
            try {
                if (!dBTransactions.deleteTransaction(clientTransactionId)) {
                    Log.e(Constants.TAG, String.format("TransactionManager: runEarnTransaction() failed to delete a Purchase transaction in the DONE state [clientTransactionId: %1$s]", clientTransactionId));
                } else {
                    Log.v(Constants.TAG, String.format("TransactionManager: runEarnTransaction() deleted a Purchase transaction in the DONE state [clientTransactionId: %1$s]", clientTransactionId));
                }
            } finally {
                try {
                    dBTransactions.close();
                } catch (Exception e2) {
                }
            }
        }
    }

    private void runPurchaseTransaction(PurchaseUnmanagedBucket purchaseUnmanagedBucket, CommContext commContext, CallbackInterface callbackInterface, boolean z) throws Exception {
        Result result;
        Result result2;
        String clientTransactionId = purchaseUnmanagedBucket.getClientTransactionId();
        Log.v(Constants.TAG, String.format("TransactionManager: runPurchaseTransaction() [clientTransactionId: %1$s] [state: %2$s] [callback: %3$s] [thread: %4$d]", clientTransactionId, purchaseUnmanagedBucket.getState().name(), callbackInterface.getClass().getName(), Long.valueOf(Thread.currentThread().getId())));
        checkCancelling(purchaseUnmanagedBucket);
        if (DBTransactions.PurchaseState.CREATED.equals(purchaseUnmanagedBucket.getState()) || DBTransactions.PurchaseState.RESERVING.equals(purchaseUnmanagedBucket.getState())) {
            if (DBTransactions.PurchaseState.CREATED.equals(purchaseUnmanagedBucket.getState())) {
                synchronized (_PurchaseTransactionStateLock) {
                    updatePurchaseTransactionState(this._applicationContext, purchaseUnmanagedBucket, DBTransactions.PurchaseState.RESERVING);
                }
            }
            if (!checkCancelling(purchaseUnmanagedBucket)) {
                Operation reserveUnmanagedPurchase = TransactionServiceProxy.getInstance().reserveUnmanagedPurchase(commContext, purchaseUnmanagedBucket.getRelatedObject().getProductId(), purchaseUnmanagedBucket.getRelatedObject().getProductName(), purchaseUnmanagedBucket.getRelatedObject().getProductDescription(), purchaseUnmanagedBucket.getRelatedObject().getAmount(), clientTransactionId, purchaseUnmanagedBucket.getRelatedObject().getTrackingMetadata(), z);
                try {
                    reserveUnmanagedPurchase.mapResultToCallbacks(callbackInterface);
                } catch (Exception e) {
                    Log.e(Constants.TAG, "Result to callback mapping failed", e);
                }
                Result result3 = reserveUnmanagedPurchase.get();
                if (result3 != null) {
                    if (result3.getResponseCode() == 200) {
                        handleSuccessfulReserveResult(result3, commContext, callbackInterface, purchaseUnmanagedBucket);
                    } else if (RequestUtilities.getServicesException(result3) != null) {
                        synchronized (_PurchaseTransactionStateLock) {
                            updatePurchaseTransactionState(this._applicationContext, purchaseUnmanagedBucket, DBTransactions.PurchaseState.DONE);
                        }
                    }
                }
            }
        }
        checkCancelling(purchaseUnmanagedBucket);
        if (DBTransactions.PurchaseState.CONFIRMING.equals(purchaseUnmanagedBucket.getState()) && (result2 = TransactionServiceProxy.getInstance().confirmUnmanagedPurchase(commContext, clientTransactionId, z).get()) != null) {
            if (result2.getResponseCode() == 200) {
                synchronized (_PurchaseTransactionStateLock) {
                    updatePurchaseStateFromResponseState(result2, purchaseUnmanagedBucket, DBTransactions.PurchaseState.DONE);
                }
            } else if (RequestUtilities.getServicesException(result2) != null) {
                synchronized (_PurchaseTransactionStateLock) {
                    updatePurchaseTransactionState(this._applicationContext, purchaseUnmanagedBucket, DBTransactions.PurchaseState.DONE);
                }
            }
        }
        if (DBTransactions.PurchaseState.CANCELING.equals(purchaseUnmanagedBucket.getState()) && (result = TransactionServiceProxy.getInstance().cancelUnmanagedPurchase(commContext, clientTransactionId, z).get()) != null) {
            if (result.getResponseCode() == 200) {
                synchronized (_PurchaseTransactionStateLock) {
                    updatePurchaseStateFromResponseState(result, purchaseUnmanagedBucket, DBTransactions.PurchaseState.DONE);
                }
                _CanceledClientTransactionIDs.remove(purchaseUnmanagedBucket.getClass());
            } else if (RequestUtilities.getServicesException(result) != null) {
                synchronized (_PurchaseTransactionStateLock) {
                    updatePurchaseTransactionState(this._applicationContext, purchaseUnmanagedBucket, DBTransactions.PurchaseState.DONE);
                }
                _CanceledClientTransactionIDs.remove(purchaseUnmanagedBucket.getClass());
            }
        }
        if (DBTransactions.PurchaseState.DONE.equals(purchaseUnmanagedBucket.getState())) {
            DBTransactions dBTransactions = new DBTransactions(this._applicationContext);
            try {
                if (!dBTransactions.deleteTransaction(clientTransactionId)) {
                    Log.e(Constants.TAG, String.format("TransactionManager: runPurchaseTransaction() failed to delete a Purchase transaction in the DONE state [clientTransactionId: %1$s]", clientTransactionId));
                } else {
                    Log.v(Constants.TAG, String.format("TransactionManager: runPurchaseTransaction() deleted a Purchase transaction in the DONE state [clientTransactionId: %1$s]", clientTransactionId));
                }
            } finally {
                try {
                    dBTransactions.close();
                } catch (Exception e2) {
                }
            }
        }
    }

    private void runTransactions(final CommContext commContext, final CallbackInterface callbackInterface) {
        Log.v(Constants.TAG, String.format("TransactionManager: runTransactions() [thread: %1$d]", Long.valueOf(Thread.currentThread().getId())));
        new Thread(new Runnable() {
            /* class com.getjar.sdk.comm.TransactionManager.AnonymousClass2 */

            public void run() {
                try {
                    List unused = TransactionManager.this.runTransactionsInternal(commContext, callbackInterface, false, false);
                } catch (Exception e) {
                    Log.e(Constants.TAG, "TransactionManager Worker Thread failed", e);
                }
            }
        }, "TransactionManager Worker Thread").start();
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:8:0x0016=Splitter:B:8:0x0016, B:47:0x0106=Splitter:B:47:0x0106, B:14:0x0068=Splitter:B:14:0x0068} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<com.getjar.sdk.comm.persistence.TransactionBucket> runTransactionsInternal(com.getjar.sdk.comm.CommContext r14, com.getjar.sdk.comm.CallbackInterface r15, boolean r16, boolean r17) {
        /*
            r13 = this;
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.lang.Object r7 = com.getjar.sdk.comm.TransactionManager._TransactionFlowLock
            monitor-enter(r7)
            com.getjar.sdk.comm.persistence.DBTransactions r2 = new com.getjar.sdk.comm.persistence.DBTransactions     // Catch:{ all -> 0x00ff }
            android.content.Context r3 = r13._applicationContext     // Catch:{ all -> 0x00ff }
            r2.<init>(r3)     // Catch:{ all -> 0x00ff }
            java.util.List r8 = r2.loadAllTransactions()     // Catch:{ all -> 0x0102 }
            r2.close()     // Catch:{ Exception -> 0x017c }
        L_0x0016:
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x00ff }
            java.lang.String r3 = "TransactionManager: runTransactionsInternal() loaded %1$d persisted transactions [thread: %2$d]"
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x00ff }
            r5 = 0
            int r6 = r8.size()     // Catch:{ all -> 0x00ff }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ all -> 0x00ff }
            r4[r5] = r6     // Catch:{ all -> 0x00ff }
            r5 = 1
            java.lang.Thread r6 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x00ff }
            long r10 = r6.getId()     // Catch:{ all -> 0x00ff }
            java.lang.Long r6 = java.lang.Long.valueOf(r10)     // Catch:{ all -> 0x00ff }
            r4[r5] = r6     // Catch:{ all -> 0x00ff }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x00ff }
            android.util.Log.v(r2, r3)     // Catch:{ all -> 0x00ff }
            r3 = 0
            r2 = 1
            com.getjar.sdk.comm.GetJarConfig r2 = com.getjar.sdk.comm.GetJarConfig.getInstance(r14, r2)     // Catch:{ Exception -> 0x0107 }
            java.lang.String r4 = "transaction.fail.abandon.time"
            java.lang.String r2 = r2.getDirectiveValue(r4)     // Catch:{ Exception -> 0x0107 }
            long r4 = java.lang.Long.parseLong(r2)     // Catch:{ Exception -> 0x0107 }
            long r4 = com.getjar.sdk.utilities.Utility.convertMillSec(r4)     // Catch:{ Exception -> 0x0107 }
            java.lang.Long r3 = java.lang.Long.valueOf(r4)     // Catch:{ Exception -> 0x0107 }
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x0107 }
            java.lang.String r4 = "TransactionManager: Loaded a transaction TTL of %1$d milliseconds"
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x0107 }
            r6 = 0
            r5[r6] = r3     // Catch:{ Exception -> 0x0107 }
            java.lang.String r4 = java.lang.String.format(r4, r5)     // Catch:{ Exception -> 0x0107 }
            android.util.Log.v(r2, r4)     // Catch:{ Exception -> 0x0107 }
            r6 = r3
        L_0x0068:
            java.util.Iterator r9 = r8.iterator()     // Catch:{ all -> 0x00ff }
        L_0x006c:
            boolean r2 = r9.hasNext()     // Catch:{ all -> 0x00ff }
            if (r2 == 0) goto L_0x017a
            java.lang.Object r2 = r9.next()     // Catch:{ all -> 0x00ff }
            com.getjar.sdk.comm.persistence.TransactionBucket r2 = (com.getjar.sdk.comm.persistence.TransactionBucket) r2     // Catch:{ all -> 0x00ff }
            r3 = 0
            if (r6 == 0) goto L_0x008d
            long r4 = r2.getTimestampCreated()     // Catch:{ Exception -> 0x00dc }
            long r10 = r6.longValue()     // Catch:{ Exception -> 0x00dc }
            long r4 = r4 + r10
            long r10 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x00dc }
            int r4 = (r4 > r10 ? 1 : (r4 == r10 ? 0 : -1))
            if (r4 <= 0) goto L_0x008d
            r3 = 1
        L_0x008d:
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r4 = com.getjar.sdk.comm.persistence.DBTransactions.TransactionType.PURCHASE     // Catch:{ Exception -> 0x00dc }
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r5 = r2.getType()     // Catch:{ Exception -> 0x00dc }
            boolean r4 = r4.equals(r5)     // Catch:{ Exception -> 0x00dc }
            if (r4 == 0) goto L_0x0115
            if (r16 != 0) goto L_0x006c
            if (r3 == 0) goto L_0x00c1
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = "TransactionManager: Transaction %1$s has exceeded the TTL and timed out, removing it..."
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x00dc }
            r10 = 0
            java.lang.String r11 = r2.getClientTransactionId()     // Catch:{ Exception -> 0x00dc }
            r5[r10] = r11     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = java.lang.String.format(r4, r5)     // Catch:{ Exception -> 0x00dc }
            android.util.Log.v(r3, r4)     // Catch:{ Exception -> 0x00dc }
            java.lang.Object r4 = com.getjar.sdk.comm.TransactionManager._PurchaseTransactionStateLock     // Catch:{ Exception -> 0x00dc }
            monitor-enter(r4)     // Catch:{ Exception -> 0x00dc }
            android.content.Context r5 = r13._applicationContext     // Catch:{ all -> 0x0112 }
            r0 = r2
            com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket r0 = (com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket) r0     // Catch:{ all -> 0x0112 }
            r3 = r0
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r10 = com.getjar.sdk.comm.persistence.DBTransactions.PurchaseState.DONE     // Catch:{ all -> 0x0112 }
            updatePurchaseTransactionState(r5, r3, r10)     // Catch:{ all -> 0x0112 }
            monitor-exit(r4)     // Catch:{ all -> 0x0112 }
        L_0x00c1:
            if (r15 != 0) goto L_0x0183
            com.getjar.sdk.comm.TransactionManager$ResilienceRetryPurchaseCallback r4 = new com.getjar.sdk.comm.TransactionManager$ResilienceRetryPurchaseCallback     // Catch:{ Exception -> 0x00dc }
            java.lang.String r5 = r2.getClientTransactionId()     // Catch:{ Exception -> 0x00dc }
            java.io.Serializable r3 = r2.getRelatedObject()     // Catch:{ Exception -> 0x00dc }
            com.getjar.sdk.comm.persistence.RelatedPurchaseData r3 = (com.getjar.sdk.comm.persistence.RelatedPurchaseData) r3     // Catch:{ Exception -> 0x00dc }
            r4.<init>(r5, r3)     // Catch:{ Exception -> 0x00dc }
        L_0x00d2:
            r0 = r2
            com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket r0 = (com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket) r0     // Catch:{ Exception -> 0x00dc }
            r3 = r0
            r0 = r17
            r13.runPurchaseTransaction(r3, r14, r4, r0)     // Catch:{ Exception -> 0x00dc }
            goto L_0x006c
        L_0x00dc:
            r3 = move-exception
            java.lang.String r4 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x00ff }
            java.lang.String r5 = "TransactionManager: A persisted '%1$s' transaction failed [ClientTransactionId: %2$s]"
            r10 = 2
            java.lang.Object[] r10 = new java.lang.Object[r10]     // Catch:{ all -> 0x00ff }
            r11 = 0
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r12 = r2.getType()     // Catch:{ all -> 0x00ff }
            java.lang.String r12 = r12.name()     // Catch:{ all -> 0x00ff }
            r10[r11] = r12     // Catch:{ all -> 0x00ff }
            r11 = 1
            java.lang.String r2 = r2.getClientTransactionId()     // Catch:{ all -> 0x00ff }
            r10[r11] = r2     // Catch:{ all -> 0x00ff }
            java.lang.String r2 = java.lang.String.format(r5, r10)     // Catch:{ all -> 0x00ff }
            android.util.Log.e(r4, r2, r3)     // Catch:{ all -> 0x00ff }
            goto L_0x006c
        L_0x00ff:
            r2 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x00ff }
            throw r2
        L_0x0102:
            r3 = move-exception
            r2.close()     // Catch:{ Exception -> 0x017f }
        L_0x0106:
            throw r3     // Catch:{ all -> 0x00ff }
        L_0x0107:
            r2 = move-exception
            java.lang.String r4 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x00ff }
            java.lang.String r5 = "TransactionManager: Failed to get transaction TTL from config"
            android.util.Log.e(r4, r5, r2)     // Catch:{ all -> 0x00ff }
            r6 = r3
            goto L_0x0068
        L_0x0112:
            r3 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0112 }
            throw r3     // Catch:{ Exception -> 0x00dc }
        L_0x0115:
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r4 = com.getjar.sdk.comm.persistence.DBTransactions.TransactionType.EARN     // Catch:{ Exception -> 0x00dc }
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r5 = r2.getType()     // Catch:{ Exception -> 0x00dc }
            boolean r4 = r4.equals(r5)     // Catch:{ Exception -> 0x00dc }
            if (r4 == 0) goto L_0x0160
            if (r3 == 0) goto L_0x0143
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = "TransactionManager: Transaction %1$s has exceeded the TTL and timed out, removing it..."
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x00dc }
            r10 = 0
            java.lang.String r11 = r2.getClientTransactionId()     // Catch:{ Exception -> 0x00dc }
            r5[r10] = r11     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = java.lang.String.format(r4, r5)     // Catch:{ Exception -> 0x00dc }
            android.util.Log.v(r3, r4)     // Catch:{ Exception -> 0x00dc }
            android.content.Context r4 = r13._applicationContext     // Catch:{ Exception -> 0x00dc }
            r0 = r2
            com.getjar.sdk.comm.persistence.EarnBucket r0 = (com.getjar.sdk.comm.persistence.EarnBucket) r0     // Catch:{ Exception -> 0x00dc }
            r3 = r0
            com.getjar.sdk.comm.persistence.DBTransactions$EarnState r5 = com.getjar.sdk.comm.persistence.DBTransactions.EarnState.DONE     // Catch:{ Exception -> 0x00dc }
            updateEarnTransactionState(r4, r3, r5)     // Catch:{ Exception -> 0x00dc }
        L_0x0143:
            if (r15 != 0) goto L_0x0181
            com.getjar.sdk.comm.TransactionManager$ResilienceRetryEarnCallback r5 = new com.getjar.sdk.comm.TransactionManager$ResilienceRetryEarnCallback     // Catch:{ Exception -> 0x00dc }
            r0 = r2
            com.getjar.sdk.comm.persistence.EarnBucket r0 = (com.getjar.sdk.comm.persistence.EarnBucket) r0     // Catch:{ Exception -> 0x00dc }
            r3 = r0
            java.io.Serializable r4 = r2.getRelatedObject()     // Catch:{ Exception -> 0x00dc }
            com.getjar.sdk.comm.persistence.RelatedEarnData r4 = (com.getjar.sdk.comm.persistence.RelatedEarnData) r4     // Catch:{ Exception -> 0x00dc }
            r5.<init>(r3, r4)     // Catch:{ Exception -> 0x00dc }
            r4 = r5
        L_0x0155:
            r0 = r2
            com.getjar.sdk.comm.persistence.EarnBucket r0 = (com.getjar.sdk.comm.persistence.EarnBucket) r0     // Catch:{ Exception -> 0x00dc }
            r3 = r0
            r0 = r17
            r13.runEarnTransaction(r3, r14, r4, r0)     // Catch:{ Exception -> 0x00dc }
            goto L_0x006c
        L_0x0160:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = "Unrecognized trnasaction type: %1$s"
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x00dc }
            r10 = 0
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r11 = r2.getType()     // Catch:{ Exception -> 0x00dc }
            java.lang.String r11 = r11.name()     // Catch:{ Exception -> 0x00dc }
            r5[r10] = r11     // Catch:{ Exception -> 0x00dc }
            java.lang.String r4 = java.lang.String.format(r4, r5)     // Catch:{ Exception -> 0x00dc }
            r3.<init>(r4)     // Catch:{ Exception -> 0x00dc }
            throw r3     // Catch:{ Exception -> 0x00dc }
        L_0x017a:
            monitor-exit(r7)     // Catch:{ all -> 0x00ff }
            return r8
        L_0x017c:
            r2 = move-exception
            goto L_0x0016
        L_0x017f:
            r2 = move-exception
            goto L_0x0106
        L_0x0181:
            r4 = r15
            goto L_0x0155
        L_0x0183:
            r4 = r15
            goto L_0x00d2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.TransactionManager.runTransactionsInternal(com.getjar.sdk.comm.CommContext, com.getjar.sdk.comm.CallbackInterface, boolean, boolean):java.util.List");
    }

    private static void updateEarnTransactionState(Context context, EarnBucket earnBucket, DBTransactions.EarnState earnState) {
        Log.v(Constants.TAG, String.format("TransactionManager: updateEarnTransactionState() [clientTransactionId: %1$s] [old: %2$s] [new: %3$s] [thread: %4$d]", earnBucket.getClientTransactionId(), earnBucket.getState().name(), earnState.name(), Long.valueOf(Thread.currentThread().getId())));
        DBTransactions dBTransactions = new DBTransactions(context);
        try {
            dBTransactions.updateEarnTransaction(earnBucket, earnState);
            earnBucket.setState(earnState);
        } finally {
            try {
                dBTransactions.close();
            } catch (Exception e) {
            }
        }
    }

    private void updatePurchaseStateFromResponseState(Result result, PurchaseUnmanagedBucket purchaseUnmanagedBucket, DBTransactions.PurchaseState purchaseState) {
        try {
            String transactionState = Utility.getTransactionState(result, "");
            if ("SUCCESS".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.DONE;
            } else if ("FAIL".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.DONE;
            } else if ("CANCELED".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.DONE;
            } else if ("CREATED".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.RESERVING;
            } else if ("RESERVED".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.CONFIRMING;
            } else if ("CONFIRMED".equalsIgnoreCase(transactionState)) {
                purchaseState = DBTransactions.PurchaseState.CONFIRMING;
            }
        } catch (Exception e) {
            Log.e(Constants.TAG, String.format("updatePurchaseStateFromResponseState() failed, setting state to: %1$s", purchaseState.name()), e);
        }
        updatePurchaseTransactionState(this._applicationContext, purchaseUnmanagedBucket, purchaseState);
    }

    private static void updatePurchaseTransactionState(Context context, PurchaseUnmanagedBucket purchaseUnmanagedBucket, DBTransactions.PurchaseState purchaseState) {
        Log.v(Constants.TAG, String.format("TransactionManager: updatePurchaseTransactionState() [clientTransactionId: %1$s] [old: %2$s] [new: %3$s] [thread: %4$d]", purchaseUnmanagedBucket.getClientTransactionId(), purchaseUnmanagedBucket.getState().name(), purchaseState.name(), Long.valueOf(Thread.currentThread().getId())));
        if (!_CanceledClientTransactionIDs.contains(purchaseUnmanagedBucket.getClientTransactionId()) || DBTransactions.PurchaseState.CANCELING.equals(purchaseState)) {
            DBTransactions dBTransactions = new DBTransactions(context);
            try {
                dBTransactions.updatePurchaseTransaction(purchaseUnmanagedBucket, purchaseState);
            } finally {
                try {
                    dBTransactions.close();
                } catch (Exception e) {
                }
            }
        } else {
            purchaseUnmanagedBucket.setState(DBTransactions.PurchaseState.CANCELING);
        }
    }

    /* JADX WARNING: Unknown top exception splitter block from list: {B:27:0x0094=Splitter:B:27:0x0094, B:21:0x008e=Splitter:B:21:0x008e} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void cancelPurchaseTransaction(java.lang.String r11, com.getjar.sdk.comm.CommContext r12, com.getjar.sdk.comm.CallbackInterface r13) {
        /*
            r10 = this;
            java.lang.Object r4 = com.getjar.sdk.comm.TransactionManager._PurchaseTransactionStateLock
            monitor-enter(r4)
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0095 }
            java.lang.String r3 = "TransactionManager: cancelPurchaseTransaction() [clientTransactionId: %1$s] [thread: %2$d]"
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ all -> 0x0095 }
            r6 = 0
            r5[r6] = r11     // Catch:{ all -> 0x0095 }
            r6 = 1
            java.lang.Thread r7 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0095 }
            long r8 = r7.getId()     // Catch:{ all -> 0x0095 }
            java.lang.Long r7 = java.lang.Long.valueOf(r8)     // Catch:{ all -> 0x0095 }
            r5[r6] = r7     // Catch:{ all -> 0x0095 }
            java.lang.String r3 = java.lang.String.format(r3, r5)     // Catch:{ all -> 0x0095 }
            android.util.Log.v(r2, r3)     // Catch:{ all -> 0x0095 }
            com.getjar.sdk.comm.persistence.DBTransactions r5 = new com.getjar.sdk.comm.persistence.DBTransactions     // Catch:{ all -> 0x0095 }
            android.content.Context r2 = r10._applicationContext     // Catch:{ all -> 0x0095 }
            r5.<init>(r2)     // Catch:{ all -> 0x0095 }
            com.getjar.sdk.comm.persistence.TransactionBucket r3 = r5.loadTransaction(r11)     // Catch:{ all -> 0x0090 }
            if (r3 == 0) goto L_0x008b
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r2 = com.getjar.sdk.comm.persistence.DBTransactions.TransactionType.PURCHASE     // Catch:{ all -> 0x0090 }
            com.getjar.sdk.comm.persistence.DBTransactions$TransactionType r6 = r3.getType()     // Catch:{ all -> 0x0090 }
            boolean r2 = r2.equals(r6)     // Catch:{ all -> 0x0090 }
            if (r2 == 0) goto L_0x008b
            r0 = r3
            com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket r0 = (com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket) r0     // Catch:{ all -> 0x0090 }
            r2 = r0
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r2 = r2.getState()     // Catch:{ all -> 0x0090 }
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r6 = com.getjar.sdk.comm.persistence.DBTransactions.PurchaseState.CREATED     // Catch:{ all -> 0x0090 }
            boolean r6 = r6.equals(r2)     // Catch:{ all -> 0x0090 }
            if (r6 != 0) goto L_0x005c
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r6 = com.getjar.sdk.comm.persistence.DBTransactions.PurchaseState.RESERVING     // Catch:{ all -> 0x0090 }
            boolean r6 = r6.equals(r2)     // Catch:{ all -> 0x0090 }
            if (r6 != 0) goto L_0x005c
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r6 = com.getjar.sdk.comm.persistence.DBTransactions.PurchaseState.CANCELING     // Catch:{ all -> 0x0090 }
            boolean r6 = r6.equals(r2)     // Catch:{ all -> 0x0090 }
            if (r6 == 0) goto L_0x008b
        L_0x005c:
            java.lang.String r6 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0090 }
            java.lang.String r7 = "TransactionManager: Transaction %1$s was found and is in the %2$s state, cancelling..."
            r8 = 2
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ all -> 0x0090 }
            r9 = 0
            r8[r9] = r11     // Catch:{ all -> 0x0090 }
            r9 = 1
            java.lang.String r2 = r2.name()     // Catch:{ all -> 0x0090 }
            r8[r9] = r2     // Catch:{ all -> 0x0090 }
            java.lang.String r2 = java.lang.String.format(r7, r8)     // Catch:{ all -> 0x0090 }
            android.util.Log.v(r6, r2)     // Catch:{ all -> 0x0090 }
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.String> r2 = com.getjar.sdk.comm.TransactionManager._CanceledClientTransactionIDs     // Catch:{ all -> 0x0090 }
            boolean r2 = r2.contains(r11)     // Catch:{ all -> 0x0090 }
            if (r2 != 0) goto L_0x0081
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.String> r2 = com.getjar.sdk.comm.TransactionManager._CanceledClientTransactionIDs     // Catch:{ all -> 0x0090 }
            r2.add(r11)     // Catch:{ all -> 0x0090 }
        L_0x0081:
            com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket r3 = (com.getjar.sdk.comm.persistence.PurchaseUnmanagedBucket) r3     // Catch:{ all -> 0x0090 }
            com.getjar.sdk.comm.persistence.DBTransactions$PurchaseState r2 = com.getjar.sdk.comm.persistence.DBTransactions.PurchaseState.CANCELING     // Catch:{ all -> 0x0090 }
            r5.updatePurchaseTransaction(r3, r2)     // Catch:{ all -> 0x0090 }
            r10.runTransactions(r12, r13)     // Catch:{ all -> 0x0090 }
        L_0x008b:
            r5.close()     // Catch:{ Exception -> 0x0098 }
        L_0x008e:
            monitor-exit(r4)     // Catch:{ all -> 0x0095 }
            return
        L_0x0090:
            r2 = move-exception
            r5.close()     // Catch:{ Exception -> 0x009a }
        L_0x0094:
            throw r2     // Catch:{ all -> 0x0095 }
        L_0x0095:
            r2 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0095 }
            throw r2
        L_0x0098:
            r2 = move-exception
            goto L_0x008e
        L_0x009a:
            r3 = move-exception
            goto L_0x0094
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.TransactionManager.cancelPurchaseTransaction(java.lang.String, com.getjar.sdk.comm.CommContext, com.getjar.sdk.comm.CallbackInterface):void");
    }

    public void recoverOrphanedTransactions(final CommContext commContext) {
        synchronized (this) {
            Log.v(Constants.TAG, String.format("TransactionManager: recoverOrphanedTransactions() [thread: %1$d]", Long.valueOf(Thread.currentThread().getId())));
            DBTransactions dBTransactions = new DBTransactions(this._applicationContext);
            try {
                int i = 0;
                for (TransactionBucket transactionBucket : dBTransactions.loadAllTransactions()) {
                    if (System.currentTimeMillis() - transactionBucket.getTimestampLastUpdated() > 300000) {
                        int i2 = i + 1;
                        if (DBTransactions.TransactionType.PURCHASE.equals(transactionBucket.getType())) {
                            if (DBTransactions.PurchaseState.CREATED.equals(((PurchaseUnmanagedBucket) transactionBucket).getState())) {
                                Log.d(Constants.TAG, String.format("TransactionManager: Orphaned purchase found in the CREATED state, deleting [clientTransactionId: %1$s]", transactionBucket.getClientTransactionId()));
                                dBTransactions.deleteTransaction(transactionBucket.getClientTransactionId());
                                i = i2;
                            } else if (DBTransactions.PurchaseState.RESERVING.equals(((PurchaseUnmanagedBucket) transactionBucket).getState())) {
                                Log.d(Constants.TAG, String.format("TransactionManager: Orphaned purchase found in the RESERVING state, updating to CANCELING [clientTransactionId: %1$s]", transactionBucket.getClientTransactionId()));
                                dBTransactions.updatePurchaseTransaction((PurchaseUnmanagedBucket) transactionBucket, DBTransactions.PurchaseState.CANCELING);
                                i = i2;
                            }
                        }
                        i = i2;
                    }
                }
                Log.d(Constants.TAG, String.format("TransactionManager: Found %1$d orphaned transactions", Integer.valueOf(i)));
                try {
                    dBTransactions.close();
                } catch (Exception e) {
                }
                if (i > 0) {
                    new Thread(new Runnable() {
                        /* class com.getjar.sdk.comm.TransactionManager.AnonymousClass1 */

                        public void run() {
                            try {
                                List unused = TransactionManager.this.runTransactionsInternal(commContext, null, false, true);
                            } catch (Exception e) {
                                Log.e(Constants.TAG, "TransactionManager Worker Thread failed", e);
                            }
                        }
                    }, "TransactionManager Worker Thread").start();
                }
            } catch (Throwable th) {
                try {
                    dBTransactions.close();
                } catch (Exception e2) {
                }
                throw th;
            }
        }
        return;
    }

    public List<TransactionBucket> runEarnTransaction(String str, CommContext commContext, String str2, String str3, HashMap<String, String> hashMap, HashMap<String, String> hashMap2) throws IOException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("'itemId' can not be NULL or empty");
        } else if (StringUtility.isNullOrEmpty(str3)) {
            throw new IllegalArgumentException("'packageName' can not be NULL or empty");
        } else if (hashMap == null || hashMap.size() <= 0) {
            throw new IllegalArgumentException("'itemMetadata' can not be NULL or empty");
        } else {
            Log.v(Constants.TAG, String.format("TransactionManager: startEarnTransaction() [clientTransactionId: %1$s] [thread: %2$d]", str, Long.valueOf(Thread.currentThread().getId())));
            RelatedEarnData relatedEarnData = new RelatedEarnData(str2, str3, hashMap, hashMap2);
            DBTransactions dBTransactions = new DBTransactions(this._applicationContext);
            try {
                dBTransactions.insertEarnTransaction(str, relatedEarnData);
                try {
                    dBTransactions.close();
                } catch (Exception e) {
                }
            } catch (IllegalStateException e2) {
                try {
                    dBTransactions.close();
                } catch (Exception e3) {
                }
            } catch (Throwable th) {
                try {
                    dBTransactions.close();
                } catch (Exception e4) {
                }
                throw th;
            }
            return runEarnTransactions(commContext);
        }
    }

    public List<TransactionBucket> runEarnTransactions(CommContext commContext) {
        return runTransactionsInternal(commContext, null, true, false);
    }

    public void startPurchaseTransaction(String str, CommContext commContext, CallbackInterface callbackInterface, String str2, String str3, String str4, Integer num, HashMap<String, String> hashMap) throws IOException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        } else if (commContext == null) {
            throw new IllegalArgumentException("'commContext' can not be NULL");
        } else if (StringUtility.isNullOrEmpty(str2)) {
            throw new IllegalArgumentException("'productId' can not be NULL or empty");
        } else if (StringUtility.isNullOrEmpty(str3)) {
            throw new IllegalArgumentException("'productName' can not be NULL or empty");
        } else if (num == null || num.intValue() < 0) {
            throw new IllegalArgumentException("'amount' can not be NULL or less than 0");
        } else {
            Log.v(Constants.TAG, String.format("TransactionManager: startPurchaseTransaction() [clientTransactionId: %1$s] [thread: %2$d]", str, Long.valueOf(Thread.currentThread().getId())));
            RelatedPurchaseData relatedPurchaseData = new RelatedPurchaseData(str2, str3, str4, num, hashMap);
            DBTransactions dBTransactions = new DBTransactions(this._applicationContext);
            try {
                dBTransactions.insertPurchaseTransaction(str, relatedPurchaseData);
                try {
                    dBTransactions.close();
                } catch (Exception e) {
                }
            } catch (IllegalStateException e2) {
                try {
                    dBTransactions.close();
                } catch (Exception e3) {
                }
            } catch (Throwable th) {
                try {
                    dBTransactions.close();
                } catch (Exception e4) {
                }
                throw th;
            }
            runTransactions(commContext, callbackInterface);
        }
    }
}

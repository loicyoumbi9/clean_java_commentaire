package com.getjar.sdk.utilities;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.getjar.sdk.comm.CommContext;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TransactionUtility {
    private static PackageInfo _PackageInfo = null;

    public static Map<String, String> getBaseParams(CommContext commContext, String str) {
        if (commContext == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        HashMap hashMap = new HashMap(3);
        try {
            if (_PackageInfo == null) {
                _PackageInfo = commContext.getApplicationContext().getPackageManager().getPackageInfo(commContext.getApplicationContext().getPackageName(), 128);
            }
            String androidID = Utility.getAndroidID(commContext.getApplicationContext());
            String str2 = _PackageInfo.versionName;
            hashMap.put("gjsrc", commContext.getSdkUserAgent());
            hashMap.put("channelId", str);
            if (androidID == null) {
                androidID = "";
            }
            hashMap.put("androidID", androidID);
            hashMap.put("gjClientVerCode", Integer.toString(_PackageInfo.versionCode));
            if (str2 == null) {
                str2 = "";
            }
            hashMap.put("gjClientVerName", str2);
            hashMap.put("gjClientInstallationID", Utility.getInstallationID(commContext.getApplicationContext()));
        } catch (PackageManager.NameNotFoundException e) {
            Logger.sLog(e);
        }
        return hashMap;
    }

    public static String getBaseURLParams(CommContext commContext, String str) {
        if (commContext == null) {
            throw new IllegalArgumentException("Must have a valid context.");
        }
        String str2 = "";
        Map<String, String> baseParams = getBaseParams(commContext, str);
        Iterator<String> it = baseParams.keySet().iterator();
        while (true) {
            String str3 = str2;
            if (!it.hasNext()) {
                return str3;
            }
            String next = it.next();
            String str4 = baseParams.get(next);
            if (str4 == null) {
                str4 = "";
            }
            try {
                str2 = str3 + String.format("%1$s=%2$s", next, URLEncoder.encode(str4, Constants.ENCODING_CHARSET));
            } catch (UnsupportedEncodingException e) {
                Logger.sLog(e);
                str2 = str3;
            }
            if (it.hasNext()) {
                str2 = str2 + Utility.QUERY_APPENDIX;
            }
        }
    }
}

package com.getjar.sdk.data;

import com.getjar.sdk.comm.AppUsageData;
import com.getjar.sdk.events.LaunchEvent;
import com.getjar.sdk.rewards.AppData;

public class UsageBucket {
    private AppData _appData = null;
    private AppUsageData _appUsageData = null;
    private LaunchEvent _launchEvent = null;

    public UsageBucket(AppUsageData appUsageData, LaunchEvent launchEvent) {
        this._appUsageData = appUsageData;
        this._launchEvent = launchEvent;
    }

    public UsageBucket(AppUsageData appUsageData, AppData appData) {
        this._appUsageData = appUsageData;
        this._appData = appData;
    }

    /* access modifiers changed from: protected */
    public AppData getAppData() {
        return this._appData;
    }

    /* access modifiers changed from: protected */
    public AppUsageData getAppUsageData() {
        return this._appUsageData;
    }

    /* access modifiers changed from: protected */
    public LaunchEvent getLaunchEvent() {
        return this._launchEvent;
    }
}

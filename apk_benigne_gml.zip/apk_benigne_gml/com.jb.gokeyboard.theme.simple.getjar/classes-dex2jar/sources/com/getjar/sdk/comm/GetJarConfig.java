package com.getjar.sdk.comm;

import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import com.getjar.sdk.utilities.OverridesUtility;
import com.getjar.sdk.utilities.StringUtility;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class GetJarConfig {
    private static final String CONFIG_PREFS = "GetJarConfig";
    private static final String CONFIG_PREFS_KEY = "config";
    private static final String DEFAULT_CONFIG_FILE = "config.ini";
    private static final String DEFAULT_LOOKUP_KEY = "default";
    public static final String KEY_AUTH_SERVICE_ENDPOINT = "service.auth_service.endpoint";
    public static final String KEY_COLLECT_USAGE_INTERVAL = "collect.usage.interval";
    public static final String KEY_DEFAULT_WEBVIEW_URL = "webview.default_url";
    public static final String KEY_LOCALIZATION_SERVICE_ENDPOINT = "service.localization_service.endpoint";
    public static final String KEY_REPORT_USAGE_ENDPOINT = "service.report_usage.endpoint";
    public static final String KEY_SEND_ALL_INSTALL_INTERVAL = "send.all_install.interval";
    public static final String KEY_SEND_USAGE_INTERVAL = "send.usage.interval";
    public static final String KEY_TRANSACTION_FAIL_ABANDON_TIME = "transaction.fail.abandon.time";
    public static final String KEY_TRANSACTION_FAIL_RETRY_INTERVAL = "transaction.fail.retry.time";
    public static final String KEY_TRANSACTION_SERVICE_ENDPOINT = "service.transaction_service.endpoint";
    public static final String KEY_USER_SERVICE_ENDPOINT = "service.user_service.endpoint";
    public static final String KEY_WEBVIEW_SAVED_URL_TTL = "webview.saved_url.ttl";
    private static Map<String, GetJarConfig> sInstances = new HashMap();
    private static final String[] sRequiredKeys = {KEY_TRANSACTION_SERVICE_ENDPOINT, KEY_AUTH_SERVICE_ENDPOINT, KEY_USER_SERVICE_ENDPOINT, KEY_DEFAULT_WEBVIEW_URL, KEY_TRANSACTION_FAIL_RETRY_INTERVAL, KEY_TRANSACTION_FAIL_ABANDON_TIME, KEY_COLLECT_USAGE_INTERVAL, KEY_SEND_USAGE_INTERVAL, KEY_SEND_ALL_INSTALL_INTERVAL, KEY_WEBVIEW_SAVED_URL_TTL};
    private Logger log = new Logger(this);
    private CommContext mCommContext;
    private JSONObject mDirectives;

    private GetJarConfig(CommContext commContext, boolean z) throws Exception {
        _initialize(commContext, z);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x0066  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private org.json.JSONObject _getDefaultDirectives() throws java.io.IOException {
        /*
            r7 = this;
            r6 = 2
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            r2 = 0
            java.io.BufferedReader r1 = new java.io.BufferedReader     // Catch:{ all -> 0x0075 }
            java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch:{ all -> 0x0075 }
            com.getjar.sdk.comm.CommContext r4 = r7.mCommContext     // Catch:{ all -> 0x0075 }
            android.content.Context r4 = r4.getApplicationContext()     // Catch:{ all -> 0x0075 }
            android.content.res.AssetManager r4 = r4.getAssets()     // Catch:{ all -> 0x0075 }
            java.lang.String r5 = "config.ini"
            java.io.InputStream r4 = r4.open(r5)     // Catch:{ all -> 0x0075 }
            r3.<init>(r4)     // Catch:{ all -> 0x0075 }
            r1.<init>(r3)     // Catch:{ all -> 0x0075 }
        L_0x0021:
            java.lang.String r2 = r1.readLine()     // Catch:{ all -> 0x0063 }
            if (r2 == 0) goto L_0x006a
            java.lang.String r3 = "="
            r4 = 2
            java.lang.String[] r2 = r2.split(r3, r4)     // Catch:{ all -> 0x0063 }
            int r3 = r2.length     // Catch:{ all -> 0x0063 }
            if (r3 != r6) goto L_0x0021
            com.getjar.sdk.utilities.Logger r3 = r7.log     // Catch:{ all -> 0x0063 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0063 }
            r4.<init>()     // Catch:{ all -> 0x0063 }
            java.lang.String r5 = "_getDefaultDirectives() -- detected "
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch:{ all -> 0x0063 }
            r5 = 0
            r5 = r2[r5]     // Catch:{ all -> 0x0063 }
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch:{ all -> 0x0063 }
            java.lang.String r5 = "="
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch:{ all -> 0x0063 }
            r5 = 1
            r5 = r2[r5]     // Catch:{ all -> 0x0063 }
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch:{ all -> 0x0063 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0063 }
            r3.debug(r4)     // Catch:{ all -> 0x0063 }
            r3 = 0
            r3 = r2[r3]     // Catch:{ all -> 0x0063 }
            r4 = 1
            r2 = r2[r4]     // Catch:{ all -> 0x0063 }
            r0.put(r3, r2)     // Catch:{ all -> 0x0063 }
            goto L_0x0021
        L_0x0063:
            r0 = move-exception
        L_0x0064:
            if (r1 == 0) goto L_0x0069
            r1.close()
        L_0x0069:
            throw r0
        L_0x006a:
            if (r1 == 0) goto L_0x006f
            r1.close()
        L_0x006f:
            org.json.JSONObject r1 = new org.json.JSONObject
            r1.<init>(r0)
            return r1
        L_0x0075:
            r0 = move-exception
            r1 = r2
            goto L_0x0064
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.GetJarConfig._getDefaultDirectives():org.json.JSONObject");
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x007c A[SYNTHETIC, Splitter:B:28:0x007c] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x009d A[SYNTHETIC, Splitter:B:37:0x009d] */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00c5 A[Catch:{ JSONException -> 0x00ac }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void _initialize(com.getjar.sdk.comm.CommContext r6, boolean r7) throws java.lang.Exception {
        /*
            r5 = this;
            r1 = 1
            r0 = 0
            monitor-enter(r5)
            com.getjar.sdk.utilities.Logger r2 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0030 }
            r3.<init>()     // Catch:{ all -> 0x0030 }
            java.lang.String r4 = "_initialize() -- START: appToken="
            java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0030 }
            java.lang.String r4 = r6.getApplicationKey()     // Catch:{ all -> 0x0030 }
            java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0030 }
            r2.debug(r3)     // Catch:{ all -> 0x0030 }
            r2 = 0
            r5.mDirectives = r2     // Catch:{ all -> 0x0030 }
            r5.mCommContext = r6     // Catch:{ all -> 0x0030 }
            com.getjar.sdk.comm.CommContext r2 = r5.mCommContext     // Catch:{ all -> 0x0030 }
            if (r2 != 0) goto L_0x0033
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "'theCommContext' can not be NULL"
            r0.<init>(r1)     // Catch:{ all -> 0x0030 }
            throw r0     // Catch:{ all -> 0x0030 }
        L_0x0030:
            r0 = move-exception
            monitor-exit(r5)
            throw r0
        L_0x0033:
            com.getjar.sdk.comm.CommContext r2 = r5.mCommContext     // Catch:{ all -> 0x0030 }
            android.content.Context r2 = r2.getApplicationContext()     // Catch:{ all -> 0x0030 }
            if (r2 != 0) goto L_0x0043
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "'theCommContext.getApplicationContext()' can not be NULL"
            r0.<init>(r1)     // Catch:{ all -> 0x0030 }
            throw r0     // Catch:{ all -> 0x0030 }
        L_0x0043:
            com.getjar.sdk.utilities.Logger r2 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "#2: _initialize() -- unable to fetch server config, trying to read from SharedPrefs file.."
            r2.debug(r3)     // Catch:{ all -> 0x0030 }
            com.getjar.sdk.comm.CommContext r2 = r5.mCommContext     // Catch:{ all -> 0x0030 }
            android.content.Context r2 = r2.getApplicationContext()     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "GetJarConfig"
            r4 = 0
            android.content.SharedPreferences r2 = r2.getSharedPreferences(r3, r4)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "config"
            r4 = 0
            java.lang.String r2 = r2.getString(r3, r4)     // Catch:{ all -> 0x0030 }
            boolean r3 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r2)     // Catch:{ all -> 0x0030 }
            if (r3 != 0) goto L_0x00de
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch:{ JSONException -> 0x00ac }
            r3.<init>(r2)     // Catch:{ JSONException -> 0x00ac }
            boolean r2 = r5._validateJsonDirectives(r3)     // Catch:{ JSONException -> 0x00d3 }
            if (r2 == 0) goto L_0x0079
            r5.mDirectives = r3     // Catch:{ JSONException -> 0x00d3 }
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ JSONException -> 0x00d6 }
            java.lang.String r2 = "_initialize() -- OK: config is ready (from SharedPrefs).."
            r0.debug(r2)     // Catch:{ JSONException -> 0x00d6 }
            r0 = r1
        L_0x0079:
            r2 = r0
        L_0x007a:
            if (r2 != 0) goto L_0x00dc
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "#3: _initialize() -- unable to read form SharedPrefs file, using DEFAULTS.."
            r0.debug(r3)     // Catch:{ all -> 0x0030 }
            org.json.JSONObject r0 = r5._getDefaultDirectives()     // Catch:{ IOException -> 0x00b9 }
            boolean r3 = r5._validateJsonDirectives(r0)     // Catch:{ IOException -> 0x00b9 }
            if (r3 == 0) goto L_0x00dc
            r5.mDirectives = r0     // Catch:{ IOException -> 0x00b9 }
            org.json.JSONObject r0 = r5.mDirectives     // Catch:{ IOException -> 0x00b9 }
            r5._persistIntoSharedPrefs(r0)     // Catch:{ IOException -> 0x00b9 }
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ IOException -> 0x00da }
            java.lang.String r2 = "_initialize() -- OK: config is ready (using DEFAULTS).."
            r0.debug(r2)     // Catch:{ IOException -> 0x00da }
        L_0x009b:
            if (r1 != 0) goto L_0x00c5
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "** FATAL ERROR: invalid configuration, unable to proceed.."
            r0.error(r1)     // Catch:{ all -> 0x0030 }
            java.lang.Exception r0 = new java.lang.Exception     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "** FATAL ERROR: invalid configuration, unable to proceed.."
            r0.<init>(r1)     // Catch:{ all -> 0x0030 }
            throw r0     // Catch:{ all -> 0x0030 }
        L_0x00ac:
            r2 = move-exception
            r3 = r0
        L_0x00ae:
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0030 }
            r0.error(r2)     // Catch:{ all -> 0x0030 }
            r2 = r3
            goto L_0x007a
        L_0x00b9:
            r0 = move-exception
            r1 = r2
        L_0x00bb:
            com.getjar.sdk.utilities.Logger r2 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0030 }
            r2.error(r0)     // Catch:{ all -> 0x0030 }
            goto L_0x009b
        L_0x00c5:
            com.getjar.sdk.utilities.Logger r0 = r5.log     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "_initialize() -- OK: config directives READY, starting AlarmManagers.."
            r0.debug(r1)     // Catch:{ all -> 0x0030 }
            com.getjar.sdk.comm.CommContext r0 = r5.mCommContext     // Catch:{ all -> 0x0030 }
            com.getjar.sdk.utilities.AlarmsUtility.startBackgroundReporting(r0, r5)     // Catch:{ all -> 0x0030 }
            monitor-exit(r5)
            return
        L_0x00d3:
            r2 = move-exception
            r3 = r0
            goto L_0x00ae
        L_0x00d6:
            r0 = move-exception
            r2 = r0
            r3 = r1
            goto L_0x00ae
        L_0x00da:
            r0 = move-exception
            goto L_0x00bb
        L_0x00dc:
            r1 = r2
            goto L_0x009b
        L_0x00de:
            r2 = r0
            goto L_0x007a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.GetJarConfig._initialize(com.getjar.sdk.comm.CommContext, boolean):void");
    }

    private void _persistIntoSharedPrefs(JSONObject jSONObject) {
        synchronized (this) {
            if (jSONObject == null) {
                throw new IllegalArgumentException("Must have a valid json object.");
            }
            this.mCommContext.getApplicationContext().getSharedPreferences(CONFIG_PREFS, 0).edit().putString(CONFIG_PREFS_KEY, jSONObject.toString());
            this.log.debug("_persistIntoSharedPrefs() -- OK: stored key=config, val=" + jSONObject.toString());
        }
    }

    private boolean _validateJsonDirectives(JSONObject jSONObject) {
        if (jSONObject == null) {
            throw new IllegalArgumentException("Must have a valid json object.");
        }
        try {
            String[] strArr = sRequiredKeys;
            for (String str : strArr) {
                if (!jSONObject.has(str) || StringUtility.isNullOrEmpty(jSONObject.getString(str))) {
                    return false;
                }
            }
            return true;
        } catch (JSONException e) {
            this.log.error(e.toString());
            return false;
        }
    }

    public static GetJarConfig getInstance(CommContext commContext, boolean z) throws Exception {
        GetJarConfig getJarConfig;
        synchronized (GetJarConfig.class) {
            if (commContext == null) {
                try {
                    throw new IllegalArgumentException("Must supply a valid GetJarContext.");
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                String applicationKey = commContext.getApplicationKey();
                String str = StringUtility.isNullOrEmpty(applicationKey) ? DEFAULT_LOOKUP_KEY : applicationKey;
                if (sInstances.containsKey(str)) {
                    Logger.sLog("GetJarConfig()::getInstance() -- re-using existing GetJarConfig instance for appToken=" + str);
                    getJarConfig = sInstances.get(str);
                } else {
                    Logger.sLog("GetJarConfig()::getInstance() -- creating a new GetJarConfig instance for appToken=" + str);
                    getJarConfig = new GetJarConfig(commContext, z);
                    sInstances.put(str, getJarConfig);
                }
            }
        }
        return getJarConfig;
    }

    public String getDirectiveValue(String str) throws Exception {
        String str2 = null;
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("Must have a valid key.");
        }
        String value = OverridesUtility.getValue(str, null);
        if (!StringUtility.isNullOrEmpty(value)) {
            Log.v(Constants.TAG, String.format("[*** OVERRIDE ***] Override value being used: '%1$s' = '%2$s'", str, value));
            return value;
        }
        try {
            str2 = this.mDirectives.getString(str);
        } catch (JSONException e) {
            this.log.error(e.toString());
        }
        if (!StringUtility.isNullOrEmpty(str2)) {
            return str2;
        }
        throw new Exception("ERROR: no value found for config directive=" + str);
    }
}

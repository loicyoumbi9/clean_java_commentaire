package com.getjar.sdk.comm.persistence;

import com.getjar.sdk.comm.persistence.DBTransactions;
import com.getjar.sdk.utilities.Base64;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.Serializable;

public abstract class TransactionBucket {
    private String _clientTransactionId;
    private int _databaseId;
    private boolean _isNewTransaction = false;
    protected String _relatedObject = null;
    private String _state = null;
    private long _timestampCreated;
    private long _timestampLastUpdated;
    private DBTransactions.TransactionType _type;

    protected TransactionBucket() {
    }

    protected TransactionBucket(String str, DBTransactions.TransactionType transactionType, Serializable serializable) throws IOException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'clientTransactionId' can not be NULL or empty");
        } else if (transactionType == null) {
            throw new IllegalArgumentException("'type' can not be NULL");
        } else {
            this._clientTransactionId = str;
            this._type = transactionType;
            if (serializable != null) {
                this._relatedObject = Base64.encodeObject(serializable);
            }
        }
    }

    public String getClientTransactionId() {
        return this._clientTransactionId;
    }

    /* access modifiers changed from: protected */
    public int getDatabaseId() {
        return this._databaseId;
    }

    public boolean getIsNewTransaction() {
        return this._isNewTransaction;
    }

    public Serializable getRelatedObject() throws IOException, ClassNotFoundException {
        if (StringUtility.isNullOrEmpty(this._relatedObject)) {
            return null;
        }
        return (Serializable) Base64.decodeToObject(this._relatedObject);
    }

    /* access modifiers changed from: protected */
    public String getSerializedRelatedObject() {
        return this._relatedObject;
    }

    /* access modifiers changed from: protected */
    public String getStateString() {
        return this._state;
    }

    public long getTimestampCreated() {
        return this._timestampCreated;
    }

    public long getTimestampLastUpdated() {
        return this._timestampLastUpdated;
    }

    public DBTransactions.TransactionType getType() {
        return this._type;
    }

    /* access modifiers changed from: protected */
    public String getTypeString() {
        return this._type.name();
    }

    public void setClientTransactionId(String str) {
        this._clientTransactionId = str;
    }

    /* access modifiers changed from: protected */
    public void setDatabaseId(int i) {
        this._databaseId = i;
    }

    public void setRelatedObject(Serializable serializable) throws IOException {
        if (serializable == null) {
            this._relatedObject = null;
        } else {
            this._relatedObject = Base64.encodeObject(serializable);
        }
    }

    /* access modifiers changed from: protected */
    public void setSerializedRelatedObject(String str) {
        this._relatedObject = str;
    }

    /* access modifiers changed from: protected */
    public void setStateString(String str) {
        try {
            if ((EarnBucket.class.isInstance(this) && ((DBTransactions.EarnState) Enum.valueOf(DBTransactions.EarnState.class, str)).equals(DBTransactions.EarnState.CREATED)) || (PurchaseUnmanagedBucket.class.isInstance(this) && ((DBTransactions.PurchaseState) Enum.valueOf(DBTransactions.PurchaseState.class, str)).equals(DBTransactions.PurchaseState.CREATED))) {
                this._isNewTransaction = true;
            }
            this._state = str;
        } catch (Exception e) {
            throw new IllegalArgumentException(String.format("Unable to parse the string '%1$s' into one of our transaction state enums", str), e);
        }
    }

    public void setTimestampCreated(long j) {
        this._timestampCreated = j;
    }

    public void setTimestampLastUpdated(long j) {
        this._timestampLastUpdated = j;
    }

    public void setType(DBTransactions.TransactionType transactionType) {
        this._type = transactionType;
    }

    /* access modifiers changed from: protected */
    public void setTypeString(String str) {
        this._type = (DBTransactions.TransactionType) Enum.valueOf(DBTransactions.TransactionType.class, str);
    }

    public String toString() {
        return "DB ID: " + this._databaseId + "\r\n      " + this._clientTransactionId + "\r\n      " + this._timestampCreated + "\r\n      " + this._timestampLastUpdated + "\r\n      " + this._type.name() + "\r\n      " + this._state + "\r\n      " + this._relatedObject;
    }
}

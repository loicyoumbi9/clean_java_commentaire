package com.getjar.sdk.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Logger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DBPurchaseData extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "GetJarPurchaseDB";
    private static final String DATABASE_TABLE_MAIN = "purchaseData";
    private static final int DATABASE_VERSION = 1;
    private static final String[] DB_CREATE_TABLE_COMMANDS = {DB_CREATE_TABLE_MAIN};
    private static final String DB_CREATE_TABLE_MAIN = "CREATE TABLE IF NOT EXISTS purchaseData (id INTEGER PRIMARY KEY AUTOINCREMENT, productId TEXT NOT NULL UNIQUE, transactionId TEXT NOT NULL, lastUsageTime INTEGER DEFAULT 0);";
    private static final String[] DB_TABLE_NAMES = {DATABASE_TABLE_MAIN};
    private static final int TRANSACTION_DATABASE_CAPACITY = 500;
    private Logger log = new Logger(this);
    private SQLiteDatabase mDatabase = getWritableDatabase();

    public DBPurchaseData(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        super.close();
        this.mDatabase.close();
    }

    public SalesRecord getSaleRecord(String str) {
        Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, null, "transactionId = '" + str + "'", null, null, null, null);
        if (query.moveToFirst()) {
            SalesRecord salesRecord = new SalesRecord(query.getString(query.getColumnIndex("productId")), query.getString(query.getColumnIndex(Constants.TRANSACTION_ID)));
            query.close();
            return salesRecord;
        }
        query.close();
        return null;
    }

    public List<SalesRecord> getSalesRecords() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.mDatabase.query(DATABASE_TABLE_MAIN, null, null, null, null, null, null);
        while (query.moveToNext()) {
            arrayList.add(new SalesRecord(query.getString(query.getColumnIndex("productId")), query.getString(query.getColumnIndex(Constants.TRANSACTION_ID))));
        }
        query.close();
        return arrayList;
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0044  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getoldest(java.lang.String r12) {
        /*
            r11 = this;
            r8 = -1
            r9 = 0
            r10 = 0
            android.database.sqlite.SQLiteDatabase r0 = r11.mDatabase     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r1 = 1
            java.lang.String[] r2 = new java.lang.String[r1]     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r1 = 0
            java.lang.String r3 = "id"
            r2[r1] = r3     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            java.lang.String r7 = "id ASC"
            r1 = r12
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0035, all -> 0x0041 }
            if (r1 == 0) goto L_0x002b
            r1.moveToFirst()     // Catch:{ SQLiteException -> 0x004e, all -> 0x004b }
            r0 = 0
            int r0 = r1.getInt(r0)     // Catch:{ SQLiteException -> 0x004e, all -> 0x004b }
            if (r1 == 0) goto L_0x002a
            r1.deactivate()
            r1.close()
        L_0x002a:
            return r0
        L_0x002b:
            if (r1 == 0) goto L_0x0033
            r1.deactivate()
            r1.close()
        L_0x0033:
            r0 = r9
            goto L_0x002a
        L_0x0035:
            r0 = move-exception
            r0 = r10
        L_0x0037:
            if (r0 == 0) goto L_0x0051
            r0.deactivate()
            r0.close()
            r0 = r8
            goto L_0x002a
        L_0x0041:
            r0 = move-exception
        L_0x0042:
            if (r10 == 0) goto L_0x004a
            r10.deactivate()
            r10.close()
        L_0x004a:
            throw r0
        L_0x004b:
            r0 = move-exception
            r10 = r1
            goto L_0x0042
        L_0x004e:
            r0 = move-exception
            r0 = r1
            goto L_0x0037
        L_0x0051:
            r0 = r8
            goto L_0x002a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.DBPurchaseData.getoldest(java.lang.String):int");
    }

    public boolean insertPurchase(SalesRecord salesRecord) {
        if (salesRecord == null) {
            throw new IllegalArgumentException("'item' can not be null");
        }
        try {
            if (numofdata(DATABASE_TABLE_MAIN) >= 500 && !removeTask((long) getoldest(DATABASE_TABLE_MAIN), DATABASE_TABLE_MAIN)) {
                return false;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("productId", salesRecord.productid);
            contentValues.put(Constants.TRANSACTION_ID, salesRecord.transactionid);
            contentValues.put("lastUsageTime", Long.valueOf(new Date().getTime()));
            return this.mDatabase.insert(DATABASE_TABLE_MAIN, null, contentValues) != -1;
        } catch (SQLiteException e) {
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0038  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int numofdata(java.lang.String r12) {
        /*
            r11 = this;
            r8 = 0
            r9 = -1
            r10 = 0
            android.database.sqlite.SQLiteDatabase r0 = r11.mDatabase     // Catch:{ SQLiteException -> 0x0029, all -> 0x0035 }
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r1 = r12
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0029, all -> 0x0035 }
            if (r1 == 0) goto L_0x0020
            int r0 = r1.getCount()     // Catch:{ SQLiteException -> 0x0042, all -> 0x003f }
            if (r1 == 0) goto L_0x001e
            r1.deactivate()
            r1.close()
        L_0x001e:
            r8 = r0
        L_0x001f:
            return r8
        L_0x0020:
            if (r1 == 0) goto L_0x0047
            r1.deactivate()
            r1.close()
            goto L_0x001f
        L_0x0029:
            r0 = move-exception
            r0 = r10
        L_0x002b:
            if (r0 == 0) goto L_0x0045
            r0.deactivate()
            r0.close()
            r8 = r9
            goto L_0x001f
        L_0x0035:
            r0 = move-exception
        L_0x0036:
            if (r10 == 0) goto L_0x003e
            r10.deactivate()
            r10.close()
        L_0x003e:
            throw r0
        L_0x003f:
            r0 = move-exception
            r10 = r1
            goto L_0x0036
        L_0x0042:
            r0 = move-exception
            r0 = r1
            goto L_0x002b
        L_0x0045:
            r0 = r9
            goto L_0x001e
        L_0x0047:
            r0 = r8
            goto L_0x001e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.data.DBPurchaseData.numofdata(java.lang.String):int");
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        for (int i = 0; i < DB_CREATE_TABLE_COMMANDS.length; i++) {
            sQLiteDatabase.execSQL(DB_CREATE_TABLE_COMMANDS[i]);
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        this.log.info("Upgrading database from version " + i + " to " + i2 + ", which will destroy all old data");
        for (int i3 = 0; i3 < DB_TABLE_NAMES.length; i3++) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_NAMES[i3]);
        }
        onCreate(sQLiteDatabase);
    }

    public boolean removePurchase(String str) {
        try {
            return this.mDatabase.delete(DATABASE_TABLE_MAIN, new StringBuilder().append("clientTransactionId = '").append(str).append("'").toString(), null) > 0;
        } catch (SQLiteException e) {
            return false;
        }
    }

    public boolean removeTask(long j, String str) {
        try {
            Log.d(Constants.TAG, String.format("Deleting ID %1$d from table %2$s", Long.valueOf(j), str));
            return this.mDatabase.delete(str, new StringBuilder().append("id = ").append(j).toString(), null) > 0;
        } catch (SQLiteException e) {
            return false;
        }
    }
}

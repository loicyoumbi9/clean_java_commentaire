package com.getjar.sdk.comm;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AppUsageData {
    private int _appFlags;
    private String _packageName;
    private Map<String, String> appMetadata = new HashMap();
    private long eventTimestamp;
    private Map<String, String> trackingMetadata = new HashMap();
    private UsageType usageType = UsageType.UNKNOWN;

    public enum UsageType {
        UNKNOWN,
        QUEUED,
        DOWNLOADED,
        INSTALLED,
        UNINSTALLED,
        USED,
        FOUND_INSTALLED,
        FOUND_UNINSTALLED
    }

    public AppUsageData(String str, int i) {
        this._packageName = str;
        this._appFlags = i;
    }

    public int getAppFlags() {
        return this._appFlags;
    }

    public Map<String, String> getAppMetadata() {
        return this.appMetadata;
    }

    public long getEventTimestamp() {
        return this.eventTimestamp;
    }

    public String getPackageName() {
        return this._packageName;
    }

    public Map<String, String> getTrackingMetadata() {
        return this.trackingMetadata;
    }

    public UsageType getUsageType() {
        return this.usageType;
    }

    public void setAppMetadata(Map<String, String> map) {
        this.appMetadata = map;
    }

    public void setEventTimestamp(long j) {
        this.eventTimestamp = j;
    }

    public void setTrackingMetadata(Map<String, String> map) {
        this.trackingMetadata = map;
    }

    public void setType(UsageType usageType2) {
        this.usageType = usageType2;
    }

    /* access modifiers changed from: protected */
    public String toJson() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("usage_type", getUsageType().name());
        jSONObject.put("event_timestamp", ServiceProxyBase.epochToISO8601(getEventTimestamp()));
        JSONArray jSONArray = new JSONArray();
        for (String str : getAppMetadata().keySet()) {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("key", str);
            String str2 = getAppMetadata().get(str);
            if (str2 != null) {
                jSONObject2.put("value", str2);
            } else {
                jSONObject2.put("value", JSONObject.NULL);
            }
            jSONArray.put(jSONObject2);
        }
        jSONObject.put("app_metadata", jSONArray);
        JSONArray jSONArray2 = new JSONArray();
        for (String str3 : getTrackingMetadata().keySet()) {
            JSONObject jSONObject3 = new JSONObject();
            jSONObject3.put("key", str3);
            String str4 = getTrackingMetadata().get(str3);
            if (str4 != null) {
                jSONObject3.put("value", str4);
            } else {
                jSONObject3.put("value", JSONObject.NULL);
            }
            jSONArray2.put(jSONObject3);
        }
        jSONObject.put("tracking_metadata", jSONArray2);
        return jSONObject.toString();
    }
}

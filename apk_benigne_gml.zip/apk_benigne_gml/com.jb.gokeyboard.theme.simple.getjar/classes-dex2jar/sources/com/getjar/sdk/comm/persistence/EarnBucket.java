package com.getjar.sdk.comm.persistence;

import com.getjar.sdk.comm.persistence.DBTransactions;
import com.getjar.sdk.utilities.Base64;
import com.getjar.sdk.utilities.StringUtility;
import java.io.IOException;
import java.io.Serializable;

public class EarnBucket extends TransactionBucket {
    public EarnBucket() {
        setType(DBTransactions.TransactionType.EARN);
    }

    public EarnBucket(String str, Serializable serializable) throws IOException {
        super(str, DBTransactions.TransactionType.EARN, serializable);
    }

    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public RelatedEarnData getRelatedObject() throws IOException, ClassNotFoundException {
        if (StringUtility.isNullOrEmpty(this._relatedObject)) {
            return null;
        }
        return (RelatedEarnData) Base64.decodeToObject(this._relatedObject);
    }

    public DBTransactions.EarnState getState() {
        return (DBTransactions.EarnState) Enum.valueOf(DBTransactions.EarnState.class, super.getStateString());
    }

    public void setState(DBTransactions.EarnState earnState) {
        setStateString(earnState.name());
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setStateString(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'state' can not be NULL or empty");
        }
        try {
            Enum.valueOf(DBTransactions.EarnState.class, str);
            super.setStateString(str);
        } catch (Exception e) {
            throw new IllegalArgumentException(String.format("Can not set the state for EarnBucket to '%1$s'", str), e);
        }
    }

    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setType(DBTransactions.TransactionType transactionType) {
        if (!DBTransactions.TransactionType.EARN.equals(transactionType)) {
            throw new IllegalArgumentException(String.format("Can not set the TransactionType for EarnBucket to '%1$s'", transactionType.name()));
        } else {
            super.setTypeString(DBTransactions.TransactionType.EARN.name());
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.getjar.sdk.comm.persistence.TransactionBucket
    public void setTypeString(String str) {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'type' can not be NULL or empty");
        }
        if (!DBTransactions.TransactionType.EARN.equals((DBTransactions.TransactionType) Enum.valueOf(DBTransactions.TransactionType.class, str))) {
            throw new IllegalArgumentException(String.format("Can not set the TransactionType for EarnBucket to '%1$s'", str));
        } else {
            super.setTypeString(DBTransactions.TransactionType.EARN.name());
        }
    }
}

package com.getjar.sdk.utilities;

import android.content.Context;
import android.util.Log;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Constants {
    public static final String ALREADY_REDEEMED_FAILURE = "ALREADY_REDEEMED_FAILURE";
    public static final String ALREADY_USED_FAILURE = "ALREADY_USED_FAILURE";
    public static final String APK_CACHE_CLEANUP_AGE = "7200000";
    public static final String APK_URI_KEY = "apkUri";
    public static final String APPDATA_FRIENDLY_SUFFIX = "_friendly";
    public static final String APPDATA_SUFFIX = "_appdata";
    public static final String APPDATA_TIMESTAMP_SUFFIX = "_timestamp";
    public static final String APP_BLOB = "applicationBlob";
    public static final String APP_COST = "price";
    public static final String APP_DESCRIPTION = "description";
    public static final String APP_ID = "id";
    public static final String APP_NAME = "name";
    public static final String AUTHORIZATION = "authorization";
    public static final String AUTH_TOKEN_KEY = "override.header.Authorization";
    public static List<String> AllowedLocales = Collections.unmodifiableList(Arrays.asList("en_us", "zh_cn", "zh_tw", "fr_fr", "it_it", "de_de", "id_id", "pt_br", "es_es", "es_us", "tr_tr", "vi_vn", "ru_ru", "lt_lt", "ko_kr", "ja_jp"));
    public static final String BROADCAST_INTENT_ACTION = "getjar.gc.sync";
    public static final String CAP_REACHED_FAILURE = "CAP_REACHED_FAILURE";
    public static final String CHANNEL_ID = "342";
    public static final int CLOSE = 0;
    public static final String COLLECT_DATA = "collectData";
    public static final String CONFIGURATION_SETTING = "Configure Setting";
    public static final String CONTENT_PROVIDER_LABEL = "getjar.gc.sync";
    public static final String CONTENT_PROVIDER_SELECTION_PACKAGENAMES = "PACKAGENAMES";
    public static final String CONTENT_PROVIDER_SELECTION_TRANSACTIONS = "TRANSACTIONS";
    public static final String CROSS_PROMO_RESPONSE_ERROR = "Error connecting, please try again.";
    public static final String CROSS_PROMO_RESPONSE_FILE_LOCATION = "file_location";
    public static final String CROSS_PROMO_RESPONSE_ICON_LINK = "icon_link";
    public static final String CROSS_PROMO_RESPONSE_NAME = "name";
    public static final String CROSS_PROMO_RESPONSE_PACKAGE_NAME = "android_package_name";
    public static final String DEFAULT_ERROR_PAGE = "file:///android_asset/errorMessage.html";
    public static final String DEFAULT_GETJAR_PACKAGE_NAME = "getjar.android.client";
    public static final String DEFAULT_ICON_NAME = "getjaricon.png";
    public static final String DEFAULT_LANGUAGE = "en-us";
    public static final int DISMISS = 1;
    public static final String DLFAIL_MSG = "Download failed, please try again.";
    public static final String DOWNLOADBKGD_MSG = "Download in progress...";
    public static final String DOWNLOADCMP_MSG = "Download complete!";
    public static final String DOWNLOAD_ARGS = "downloadArgs";
    public static final String DOWNLOAD_FAIL = "Sorry, your download has failed. Please try again.";
    public static final String DOWNLOAD_IN_PLACE = "Download in progress...!";
    public static final String ELAPSED_TIME = "elapsedTime";
    public static final String ENCODING_CHARSET = "UTF-8";
    public static final String ERROR_CODE = "errorCode";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String EVENTS_REPORT = "eventsReport";
    public static final String EXCEPTION_NO_CONTEXT = "The GetJar SDK requires your applications context";
    public static final int FAIL_NETWORK = 2;
    public static final int FAIL_SERVICE = 3;
    public static final int FILE_DELETE_DELAY_MILLS = 60000;
    public static final String GETJAR_CONTEXT_ID_KEY = "getjarContextId";
    public static final String GETJAR_KEY = "AH7EGvRim#HyA,mFg+%nEcVNqTCN7hFHyMV57xnso%gy#H4XE,0TafrF";
    public static final String GREENJAR_PACKAGE = "com.getjar.rewards";
    public static final String INSTALLED_MSG = "Installed.";
    public static final String ITEM_PURCHASED = "Thank you for purchase.";
    public static final String ITEM_PURCHASE_FAILED = "Sorry, your purchase has failed. Please try again.";
    public static final String KEY_LANGUAGE = "lang";
    public static final String KEY_TRANSACTION_COIN_DELTA = "TransactionCoinDelta";
    public static final String KEY_TRANSACTION_HOSTING_APP_PACKAGENAME = "TransactionHostingAppPackageName";
    public static final String KEY_TRANSACTION_ID = "TransactionID";
    public static final String KEY_TRANSACTION_PACKAGENAME_OR_PRODUCT_ID = "TransactionPackageNameOrProductID";
    public static final String KEY_TRANSACTION_TIMESTAMP = "TransactionTimestamp";
    public static final String KEY_TRANSACTION_TYPE = "TransactionType";
    public static final String META_CLIENT_APP_TOKEN = "client_app.token";
    public static final String META_DEVICE_PLATFORM = "device.platform";
    public static final String META_DEVICE_PLATFORM_ANDROID = "android";
    public static final String META_DEVICE_PLATFORM_VERSION = "device.platform_version";
    public static final String META_ITEM_ID = "app.id";
    public static final String META_LEGACY_UA = "legacy.device.user_agent";
    public static final String META_PACKAGE_NAME = "android.package.name";
    public static final String META_PACKAGE_VERSION_CODE = "android.package.version_code";
    public static final String META_PACKAGE_VERSION_NAME = "android.package.version_name";
    public static final String NETWORK_DOWN = "Please connect to the Internet to use GetJar Rewards.";
    public static final String NORECEIVE_MSG = "Starting download...";
    public static final String NOTIFICATION_FAIL_CAP_REACHED = "Thank you for installing %1$s. You must spend gold before you can earn more.";
    public static final String NOTIFICATION_FAIL_REDEEMED = "Thank you for installing %1$s again. No gold was earned.";
    public static final String NOTIFICATION_FAIL_SUBMISSION = "Thank you for installing %1$s! No gold was earned.";
    public static final String NOTIFICATION_PASS = "You've earned %1$d Gold!";
    public static final String NOTIFICATION_PASS_POST_RETRY_ADDENDUM = "Thanks for your patience!";
    public static final String NOTIFICATION_PASS_WITH_APP_NAME = "%1$d Gold earned via %2$s!";
    public static final String PACKAGE_NAMES_INSTALLED_PREFS = "GetJarPkgNamesInstalled";
    protected static final String PICON_LOCATION = "/getjar/picons/";
    public static final String PLATFORM = "android";
    public static final String PRODUCT_LIST = "productList";
    public static final String PROPERTIES_FILE = "getjar_properties";
    public static final int PURCHASE_FAIL = 6;
    public static final int PURCHASE_SUCCESS = 5;
    public static final String PUSHTIME = "pushtimestamp";
    public static final String PreferencesFileName = "GetJarClientPrefs";
    public static final String PrefsKeyInstallationID = "InstallationID";
    public static final int RELOAD = 4;
    public static final String REPORTTIME = "reporttimestamp";
    public static final String REQUEST_ID = "requestId";
    public static final String RESPONSE_CODE = "responseCode";
    public static final String SDK_URL = "sdkUrl";
    public static final int SET_AUTH_TOKEN = 9;
    public static final int SIMPLE_RELOAD = 10;
    public static final String SPONSORSED_MSG = " sponsored by GetJar!";
    public static String TAG = "GetJar SDK";
    public static final String THANKYOU_MSG = "Thanks for installing! ";
    public static final String TIMESTAMP = "timestamp";
    public static final String TRACKING_LEGACY_SOURCE = "legacy.tracking.source";
    public static final String TRACKING_SUFFIX = "_tracking";
    public static final String TRACKING_USER_ACCESS_ID = "user.user_access_id";
    public static final String TRANSACTIONTIME = "transactiontimestamp";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String UNKNOWN_SOURCE_NOT_CHECKED = "GetJar requires approval to download apps. Please check the Unknown Sources setting and try again.";
    public static final String USAGE_TRACKING = "usageTracking";
    public static final String USER_ACCESS_ID = "userAccessId";
    public static final String USER_AGENT_APP = "GetJarSDK/";
    public static final String USER_AGENT_UNKOWN_APP = "unknown/0000";
    public static final String WAITGETJAR_MSG = "Waiting for GetJar installation to complete.";
    public static final String WAIT_DIALOG_MSG = "Please wait...";
    public static final int WALLET_CAP = 500;
    public static final String WEB_LAST_KNOWN = "web.last.known";
    public static final String WEB_TIMESTAMP = "web.timestamp";
    public static final String ZIP_JAR_FILE = "GetJarAndroidZ.jar";
    private static String _PACKAGE_NAME = null;

    public enum AppState {
        UNINSTALLED,
        INSTALLED,
        RUNNING
    }

    public enum AppType {
        GREENJAR_CLIENT,
        HOST_APP
    }

    public enum RequestInstallState {
        UNKNOWN,
        INSTALL,
        SUCCESS,
        FAIL;

        public String toString() {
            switch (this) {
                case INSTALL:
                    return "INSTALL";
                case SUCCESS:
                    return "SUCCESS";
                case FAIL:
                    return "FAIL";
                default:
                    return "UNKNOWN";
            }
        }
    }

    public enum RequestInstallSubState {
        NONE,
        ALREADY_REDEEMED_FAILURE,
        INCOMPLETE_RECONCILE_FAILURE,
        RECONCILE_DATA_FAILURE,
        UNKNOWN_FAILURE,
        FUNDS_INSUFFICIENT_FAILURE,
        FUNDS_OVERDRAWN_WARNING,
        CAP_REACHED_FAILURE,
        CAP_EXCEEDED_WARNING,
        DEPENDENT_SERVICE_FAILURE;

        public static String KEY() {
            return "request_install_substate";
        }

        public String toString() {
            switch (this) {
                case NONE:
                    return "NONE";
                case ALREADY_REDEEMED_FAILURE:
                    return Constants.ALREADY_REDEEMED_FAILURE;
                case INCOMPLETE_RECONCILE_FAILURE:
                    return "INCOMPLETE_RECONCILE_FAILURE";
                case RECONCILE_DATA_FAILURE:
                    return "RECONCILE_DATA_FAILURE";
                case UNKNOWN_FAILURE:
                    return "UNKNOWN_FAILURE";
                case FUNDS_INSUFFICIENT_FAILURE:
                    return "FUNDS_INSUFFICIENT_FAILURE";
                case FUNDS_OVERDRAWN_WARNING:
                    return "FUNDS_OVERDRAWN_WARNING";
                case CAP_REACHED_FAILURE:
                    return Constants.CAP_REACHED_FAILURE;
                case CAP_EXCEEDED_WARNING:
                    return "CAP_EXCEEDED_WARNING";
                case DEPENDENT_SERVICE_FAILURE:
                    return "DEPENDENT_SERVICE_FAILURE";
                default:
                    return "NONE";
            }
        }
    }

    public enum RequestInstallType {
        UNDEFINED,
        EARN,
        PURCHASE;
        
        public static final String SUFFIX_AMOUNT = "_amount";
        public static final String SUFFIX_APP_ID = "_app_id";
        public static final String SUFFIX_DEFAULT = "_install_type";
        public static final String SUFFIX_NOTIFICATION = "_install_notification";
        public static final String SUFFIX_STATE = "_install_state";
        public static final String SUFFIX_SUBSTATE = "_install_substate";

        public String toString() {
            switch (this) {
                case EARN:
                    return "EARN";
                case PURCHASE:
                    return "PURCHASE";
                default:
                    return "UNKNOWN";
            }
        }
    }

    public static void updateLoggingTagWithPackageName(Context context) {
        try {
            if (_PACKAGE_NAME == null) {
                _PACKAGE_NAME = context.getPackageName();
                TAG = String.format("%1$s [%2$s]", TAG, _PACKAGE_NAME);
            }
        } catch (Exception e) {
            Log.e(TAG, "updateLoggingTagWithPackageName() failed", e);
        }
    }
}

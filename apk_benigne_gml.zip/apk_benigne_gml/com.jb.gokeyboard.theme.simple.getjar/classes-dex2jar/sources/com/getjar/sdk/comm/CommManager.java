package com.getjar.sdk.comm;

import android.content.Context;
import android.os.Process;
import android.os.ResultReceiver;
import android.util.Log;
import com.getjar.sdk.comm.Operation;
import com.getjar.sdk.comm.Request;
import com.getjar.sdk.data.LocalizationEngine;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.StringUtility;
import com.getjar.sdk.utilities.Utility;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class CommManager {
    /* access modifiers changed from: private */
    public static ArrayList<Operation> _ActiveRequests = new ArrayList<>();
    private static final int _ConnectionTimeout = 30000;
    /* access modifiers changed from: private */
    public static final ExecutorService _ExecutorService = Executors.newFixedThreadPool(3);
    private static ConcurrentHashMap<String, CommContext> _IdentifierToCommContextMap = new ConcurrentHashMap<>();
    private static CommManager _Instance = null;
    private static final int _MaxNumberOfSimultaneousRequests = 3;
    private static ConcurrentLinkedQueue<String> _ReauthorizingCommContextIDs = new ConcurrentLinkedQueue<>();
    /* access modifiers changed from: private */
    public static Object _RequestPipelineLock = new Object();
    /* access modifiers changed from: private */
    public static LinkedList<Operation> _RequestQueue = new LinkedList<>();
    /* access modifiers changed from: private */
    public static ArrayList<Operation> _RetryRequests = new ArrayList<>();
    private static final int _SocketTimeout = 30000;
    private static Thread _WorkerThread = null;
    private static Object _WorkerThreadLock = new Object();
    /* access modifiers changed from: private */
    public static volatile boolean _WorkerThreadStopping = false;
    /* access modifiers changed from: private */
    public CachingManager _cachingManager = null;

    private static class DoLaunchWork implements Runnable {
        private CommContext _commContext = null;

        public DoLaunchWork(CommContext commContext) {
            if (commContext == null) {
                throw new IllegalArgumentException("'commContext' can not be NULL");
            }
            this._commContext = commContext;
        }

        public void run() {
            try {
                new LocalizationEngine(this._commContext).getPricingRatio(false);
            } catch (Exception e) {
                Log.e(Constants.TAG, String.format("%1$s Updating cached location based Pricing Ratio failed", CommManager.getLoggingPrefix()), e);
            }
            try {
                CommManager.sendUsedEvent(this._commContext);
            } catch (Exception e2) {
                Log.e(Constants.TAG, String.format("%1$s Sending 'USED' event failed", CommManager.getLoggingPrefix()), e2);
            }
            try {
                new TransactionManager(this._commContext.getApplicationContext()).recoverOrphanedTransactions(this._commContext);
            } catch (Exception e3) {
                Log.e(Constants.TAG, String.format("%1$s Recovering orphaned transactions failed", CommManager.getLoggingPrefix()), e3);
            }
        }
    }

    private class RequestCallable implements Callable<Result> {
        /* access modifiers changed from: private */
        public Operation _operation;

        private RequestCallable(Operation operation) {
            this._operation = null;
            if (operation == null) {
                throw new IllegalArgumentException("'operation' can not be NULL");
            }
            this._operation = operation;
        }

        @Override // java.util.concurrent.Callable
        public Result call() throws Exception {
            Result access$1200 = CommManager.this.processesRequestWithRetries(this._operation);
            if (access$1200 == null) {
                Log.e(Constants.TAG, String.format("%1$s Recieved a NULL result", CommManager.getLoggingPrefix(this._operation)));
            } else {
                if (access$1200.getResponseJson() != null) {
                    Log.d(Constants.TAG, String.format("%1$s Recieved response body:\r\n%2$s", CommManager.getLoggingPrefix(this._operation), access$1200.getResponseJson().toString(4)));
                } else if (!StringUtility.isNullOrEmpty(access$1200.getResponseBody())) {
                    Log.d(Constants.TAG, String.format("%1$s Recieved response body:\r\n%2$s", CommManager.getLoggingPrefix(this._operation), access$1200.getResponseBody()));
                }
                if (access$1200.getHeaders() != null && access$1200.getHeaders().size() > 0) {
                    StringBuilder sb = new StringBuilder(CommManager.getLoggingPrefix(this._operation));
                    sb.append(" Recieved response headers:\r\n");
                    for (String str : access$1200.getHeaders().keySet()) {
                        for (String str2 : access$1200.getHeaders().get(str)) {
                            sb.append("    ");
                            sb.append(str);
                            sb.append(" = ");
                            sb.append(str2);
                            sb.append("\r\n");
                        }
                    }
                    Log.d(Constants.TAG, sb.toString());
                    return access$1200;
                }
            }
            return access$1200;
        }
    }

    private class RequestFutureTask extends FutureTask<Result> {
        private RequestCallable _callable;

        private RequestFutureTask(RequestCallable requestCallable) {
            super(requestCallable);
            this._callable = null;
            if (requestCallable == null) {
                throw new IllegalArgumentException("'callable' can not be NULL");
            }
            this._callable = requestCallable;
        }

        private void cleanup() {
            synchronized (CommManager._RequestPipelineLock) {
                try {
                    CommManager.this.updateOperationStateFromResult(this._callable._operation);
                } catch (Exception e) {
                    Log.e(Constants.TAG, String.format("%1$s updateOperationStateFromResult() failed", CommManager.getLoggingPrefix(this._callable._operation)), e);
                }
                if (CommManager._ActiveRequests.remove(this._callable._operation)) {
                    Log.i(Constants.TAG, String.format("%1$s Completed Request has been removed from _ActiveRequests", CommManager.getLoggingPrefix(this._callable._operation)));
                } else {
                    Log.i(Constants.TAG, String.format("%1$s Completed Request was not found in _ActiveRequests", CommManager.getLoggingPrefix(this._callable._operation)));
                }
                if (CommManager._RequestQueue.remove(this._callable._operation)) {
                    Log.e(Constants.TAG, String.format("%1$s Found completed Request in _RequestQueue", CommManager.getLoggingPrefix(this._callable._operation)));
                }
                if (CommManager._RetryRequests.remove(this._callable._operation)) {
                    Log.e(Constants.TAG, String.format("%1$s Found completed Request in _RetryRequests", CommManager.getLoggingPrefix(this._callable._operation)));
                }
                Log.v(Constants.TAG, String.format("%1$s kicking worker thread", CommManager.getLoggingPrefix(this._callable._operation)));
                CommManager._RequestPipelineLock.notify();
            }
        }

        /* access modifiers changed from: protected */
        public void done() {
            cleanup();
        }

        @Override // java.util.concurrent.Future, java.util.concurrent.FutureTask
        public Result get() {
            Result result;
            try {
                result = (Result) super.get();
                try {
                    cleanup();
                } catch (Exception e) {
                    e = e;
                    Log.e(Constants.TAG, String.format("%1$s failed", CommManager.getLoggingPrefix(this._callable._operation)), e);
                    return result;
                }
            } catch (Exception e2) {
                e = e2;
                result = null;
                Log.e(Constants.TAG, String.format("%1$s failed", CommManager.getLoggingPrefix(this._callable._operation)), e);
                return result;
            }
            return result;
        }

        /* access modifiers changed from: protected */
        public void setException(Throwable th) {
            super.setException(th);
        }
    }

    private class RequestPipelineManagementRunnable implements Runnable {
        private RequestPipelineManagementRunnable() {
        }

        public void run() {
            while (!CommManager._WorkerThreadStopping) {
                try {
                    if (CommManager._WorkerThreadStopping) {
                        break;
                    }
                    synchronized (CommManager._RequestPipelineLock) {
                        Log.v(Constants.TAG, String.format("%1$s queued:%2$d active:%3$d retry:%4$d", CommManager.getLoggingPrefix(), Integer.valueOf(CommManager._RequestQueue.size()), Integer.valueOf(CommManager._ActiveRequests.size()), Integer.valueOf(CommManager._RetryRequests.size())));
                        long currentTimeMillis = System.currentTimeMillis();
                        ArrayList<Operation> arrayList = new ArrayList();
                        Iterator it = CommManager._RetryRequests.iterator();
                        while (it.hasNext()) {
                            Operation operation = (Operation) it.next();
                            if (operation.getRetryAfterTimestamp() <= currentTimeMillis) {
                                arrayList.add(operation);
                            }
                        }
                        for (Operation operation2 : arrayList) {
                            CommManager._RetryRequests.remove(operation2);
                            CommManager._RequestQueue.add(operation2);
                            operation2.setState(Operation.Status.WAITING);
                            Log.v(Constants.TAG, String.format("%1$s moved request from retry to queue", CommManager.getLoggingPrefix(operation2)));
                        }
                        while (CommManager._ActiveRequests.size() < 3 && CommManager._RequestQueue.size() > 0) {
                            Iterator it2 = CommManager._RequestQueue.iterator();
                            while (it2.hasNext()) {
                                ((Operation) it2.next()).promotePriority();
                            }
                            Collections.sort(CommManager._RequestQueue, OperationPriorityComparator.getInstance());
                            Operation operation3 = (Operation) CommManager._RequestQueue.remove();
                            CommManager._ActiveRequests.add(operation3);
                            operation3.setState(Operation.Status.RUNNING);
                            CommManager._ExecutorService.execute(operation3.getFuture());
                        }
                        CommManager.this._cachingManager.lruCapAtMaxRecords();
                        long access$1600 = CommManager.this.getSleepTime();
                        Log.i(Constants.TAG, String.format("%1$s Worker Thread is waiting to be notified", CommManager.getLoggingPrefix()));
                        CommManager._RequestPipelineLock.wait(access$1600);
                        Log.i(Constants.TAG, String.format("%1$s Worker Thread is awake", CommManager.getLoggingPrefix()));
                    }
                    if (CommManager._WorkerThreadStopping) {
                        break;
                    }
                } catch (Exception e) {
                    Log.e(Constants.TAG, String.format("%1$s failure", CommManager.getLoggingPrefix()), e);
                    try {
                        Thread.sleep(5000);
                    } catch (Exception e2) {
                    }
                }
            }
            Log.i(Constants.TAG, String.format("%1$s Worker Thread exited", CommManager.getLoggingPrefix()));
        }
    }

    private CommManager(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("'androidContext' can not be NULL");
        }
        this._cachingManager = new CachingManager(context);
        startWorker();
    }

    public static CommContext createContext(String str, Context context, ResultReceiver resultReceiver, boolean z) throws InterruptedException {
        if (StringUtility.isNullOrEmpty(str)) {
            throw new IllegalArgumentException("'applicationKey' can not be NULL or empty");
        } else if (context == null) {
            throw new IllegalArgumentException("'androidContext' can not be NULL");
        } else if (resultReceiver == null) {
            throw new IllegalArgumentException("'resultReceiver' can not be NULL");
        } else {
            UUID.fromString(str);
            Utility.saveApplicationKey(context, str);
            Constants.updateLoggingTagWithPackageName(context);
            CommContext commContext = new CommContext(str, context, resultReceiver);
            _IdentifierToCommContextMap.put(commContext.getCommContextId(), commContext);
            Log.d(Constants.TAG, String.format("%1$s Created a NEW CommContext from %2$s.%3$s() [PID:%4$d] [AppKey:%5$s] [CommContext.Id:%6$s]", getLoggingPrefix(), Thread.currentThread().getStackTrace()[3].getClassName(), Thread.currentThread().getStackTrace()[3].getMethodName(), Integer.valueOf(Process.myPid()), str, commContext.getCommContextId()));
            new Thread(new CreateContextWorker(commContext), String.format("CreateContextWorker thread [Context Id: %1$s]", commContext.getCommContextId())).start();
            if (z) {
                new Thread(new DoLaunchWork(commContext)).start();
            }
            return commContext;
        }
    }

    private Operation enqueueOperationForRetry(Operation operation) {
        if (operation == null) {
            throw new IllegalArgumentException("'operation' can not be NULL");
        } else if (operation.getState() == Operation.Status.RETRYING) {
            return enqueueRequest(operation, true);
        } else {
            throw new IllegalStateException("enqueueOperationForRetry() can not be called on an operation that is not in the RETRYING state");
        }
    }

    private Operation enqueueRequest(Operation operation, boolean z) {
        boolean z2;
        Operation operation2 = null;
        boolean z3 = false;
        if (operation == null) {
            throw new IllegalArgumentException("'newOperation' can not be NULL");
        } else if (operation.getState() == Operation.Status.CREATED || operation.getState() == Operation.Status.RETRYING) {
            Log.v(Constants.TAG, String.format("%1$s Adding [isRetry:%2$s]", getLoggingPrefix(operation), Boolean.valueOf(z)));
            synchronized (_RequestPipelineLock) {
                int indexOf = _ActiveRequests.indexOf(operation);
                if (indexOf >= 0) {
                    operation2 = _ActiveRequests.get(indexOf);
                } else {
                    int indexOf2 = _RequestQueue.indexOf(operation);
                    if (indexOf2 >= 0) {
                        operation2 = _RequestQueue.get(indexOf2);
                    }
                }
                if (operation2 != null) {
                    String format = String.format("%1$s Returning preexisting enqueued", getLoggingPrefix(operation2));
                    if (z) {
                        Log.e(Constants.TAG, format);
                        operation = operation2;
                    } else {
                        Log.v(Constants.TAG, format);
                        operation = operation2;
                    }
                } else {
                    Result requestResult = this._cachingManager.getRequestResult(operation);
                    if (requestResult != null) {
                        operation.setResult(requestResult);
                        operation.setState(Operation.Status.COMPLETED);
                        String format2 = String.format("%1$s Returning cached results", getLoggingPrefix(operation));
                        if (z) {
                            Log.e(Constants.TAG, format2);
                            z2 = false;
                        } else {
                            Log.v(Constants.TAG, format2);
                            z2 = false;
                        }
                    } else {
                        operation.setFuture(new RequestFutureTask(new RequestCallable(operation)));
                        if (z) {
                            _RetryRequests.add(operation);
                            operation.setState(Operation.Status.RETRYING);
                            Log.v(Constants.TAG, String.format("%1$s Returning new Request, added to retry pool", getLoggingPrefix(operation)));
                        } else {
                            _RequestQueue.add(operation);
                            operation.setState(Operation.Status.WAITING);
                            Log.v(Constants.TAG, String.format("%1$s Returning new Request, added to priority queue", getLoggingPrefix(operation)));
                        }
                        z2 = true;
                    }
                    z3 = z2;
                }
                if (z3) {
                    Log.v(Constants.TAG, String.format("%1$s kicking worker thread", getLoggingPrefix(operation)));
                    _RequestPipelineLock.notify();
                }
            }
            return operation;
        } else {
            throw new IllegalStateException("enqueueRequest() can not be called on an operation that is not in the CREATED or RETRYING state");
        }
    }

    public static CommManager getInstance() {
        if (_Instance != null) {
            return _Instance;
        }
        throw new IllegalStateException("CommManager.initialize() must be called first");
    }

    /* access modifiers changed from: private */
    public static final String getLoggingPrefix() {
        String str = "";
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace != null && stackTrace.length >= 3) {
            str = stackTrace[3].getMethodName();
        }
        return String.format("CommManager: %1$s() [thread:%2$d]", str, Long.valueOf(Thread.currentThread().getId()));
    }

    /* access modifiers changed from: private */
    public static final String getLoggingPrefix(Operation operation) {
        String str = "";
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace != null && stackTrace.length >= 3) {
            str = stackTrace[3].getMethodName();
        }
        String str2 = "";
        if (operation != null) {
            str2 = String.format(" [request:%1$d]", Integer.valueOf(operation.getId()));
        }
        return String.format("CommManager: %1$s() [thread:%2$d]%3$s", str, Long.valueOf(Thread.currentThread().getId()), str2);
    }

    /* access modifiers changed from: private */
    public long getSleepTime() {
        long currentTimeMillis = System.currentTimeMillis();
        Iterator<Operation> it = _RetryRequests.iterator();
        long j = Long.MAX_VALUE;
        while (it.hasNext()) {
            long retryAfterTimestamp = it.next().getRetryAfterTimestamp() - currentTimeMillis;
            if (retryAfterTimestamp < j) {
                j = retryAfterTimestamp;
            }
        }
        long j2 = j < 1 ? 1 : j;
        if (j2 == Long.MAX_VALUE) {
            Log.v(Constants.TAG, String.format("%1$s returning a sleep time of MAX_VALUE", getLoggingPrefix()));
        } else {
            Log.v(Constants.TAG, String.format("%1$s returning a sleep time of %2$d milliseconds", getLoggingPrefix(), Long.valueOf(j2)));
        }
        return j2;
    }

    public static void initialize(Context context) {
        synchronized (CommManager.class) {
            try {
                if (_Instance == null) {
                    _Instance = new CommManager(context);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: additional move instructions added (1) to help type inference */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v3, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v4, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v7, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: java.net.URI} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v8, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v12, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v21, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v7, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v32, resolved type: org.apache.http.client.methods.HttpGet} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v8, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v9, resolved type: java.lang.String} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x0427  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x042b  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0232  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0255  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.getjar.sdk.comm.Result processesRequest(com.getjar.sdk.comm.Operation r19) throws java.lang.Exception {
        /*
            r18 = this;
            if (r19 != 0) goto L_0x000a
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r3 = "'operation' can not be NULL"
            r2.<init>(r3)
            throw r2
        L_0x000a:
            com.getjar.sdk.comm.Operation$Status r2 = r19.getState()
            com.getjar.sdk.comm.Operation$Status r3 = com.getjar.sdk.comm.Operation.Status.CANCELLED
            if (r2 != r3) goto L_0x0017
            com.getjar.sdk.comm.Result r2 = r19.getResult()
        L_0x0016:
            return r2
        L_0x0017:
            com.getjar.sdk.comm.Operation$Status r2 = r19.getState()
            com.getjar.sdk.comm.Operation$Status r3 = com.getjar.sdk.comm.Operation.Status.RUNNING
            if (r2 == r3) goto L_0x0039
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.String r3 = "processesRequestWithRetries() for an operation in the %1$s state"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = 0
            com.getjar.sdk.comm.Operation$Status r6 = r19.getState()
            java.lang.String r6 = r6.name()
            r4[r5] = r6
            java.lang.String r3 = java.lang.String.format(r3, r4)
            r2.<init>(r3)
            throw r2
        L_0x0039:
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG
            java.lang.String r3 = "%1$s Starting Request %2$d"
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = 0
            java.lang.String r6 = getLoggingPrefix(r19)
            r4[r5] = r6
            r5 = 1
            int r6 = r19.getId()
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r4[r5] = r6
            java.lang.String r3 = java.lang.String.format(r3, r4)
            android.util.Log.i(r2, r3)
            r8 = 0
            r2 = 0
            long r12 = java.lang.System.currentTimeMillis()
            com.getjar.sdk.comm.ServiceContextInterface r3 = r19.getServiceContextCallbacks()     // Catch:{ all -> 0x0451 }
            r0 = r19
            r3.preRequestWork(r0)     // Catch:{ all -> 0x0451 }
            com.getjar.sdk.comm.Request r3 = r19.getRequest()     // Catch:{ all -> 0x0451 }
            java.net.URI r8 = r3.getUriForRequest()     // Catch:{ all -> 0x0451 }
            r2 = 0
            r9 = 0
            r10 = r2
        L_0x0073:
            r5 = 418(0x1a2, float:5.86E-43)
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x043d }
            java.lang.String r3 = "%1$s Making a request to: '%2$s'"
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x043d }
            r6 = 0
            java.lang.String r7 = getLoggingPrefix(r19)     // Catch:{ all -> 0x043d }
            r4[r6] = r7     // Catch:{ all -> 0x043d }
            r6 = 1
            r4[r6] = r8     // Catch:{ all -> 0x043d }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x043d }
            android.util.Log.d(r2, r3)     // Catch:{ all -> 0x043d }
            com.getjar.sdk.comm.CommContext r2 = r19.getCommContext()     // Catch:{ all -> 0x043d }
            java.lang.String r2 = r2.getSdkUserAgent()     // Catch:{ all -> 0x043d }
            r3 = 30000(0x7530, float:4.2039E-41)
            r4 = 30000(0x7530, float:4.2039E-41)
            com.getjar.sdk.comm.GetJarHttpClient r11 = com.getjar.sdk.comm.GetJarHttpClient.newInstance(r2, r3, r4)     // Catch:{ all -> 0x043d }
            com.getjar.sdk.comm.Request$HttpMethod r2 = com.getjar.sdk.comm.Request.HttpMethod.POST     // Catch:{ all -> 0x0207 }
            com.getjar.sdk.comm.Request r3 = r19.getRequest()     // Catch:{ all -> 0x0207 }
            com.getjar.sdk.comm.Request$HttpMethod r3 = r3.getHttpMethod()     // Catch:{ all -> 0x0207 }
            boolean r2 = r2.equals(r3)     // Catch:{ all -> 0x0207 }
            if (r2 == 0) goto L_0x025b
            org.apache.http.client.methods.HttpPost r3 = new org.apache.http.client.methods.HttpPost     // Catch:{ all -> 0x0207 }
            r3.<init>(r8)     // Catch:{ all -> 0x0207 }
            com.getjar.sdk.comm.Request r2 = r19.getRequest()     // Catch:{ all -> 0x0442 }
            java.util.Map r2 = r2.getPostData()     // Catch:{ all -> 0x0442 }
            if (r2 == 0) goto L_0x044e
            com.getjar.sdk.comm.Request r2 = r19.getRequest()     // Catch:{ all -> 0x0442 }
            java.util.Map r2 = r2.getPostData()     // Catch:{ all -> 0x0442 }
            int r2 = r2.size()     // Catch:{ all -> 0x0442 }
            if (r2 <= 0) goto L_0x044e
            com.getjar.sdk.comm.Request r2 = r19.getRequest()     // Catch:{ all -> 0x0442 }
            java.util.Map r2 = r2.getPostData()     // Catch:{ all -> 0x0442 }
            java.lang.String r4 = com.getjar.sdk.comm.RequestUtilities.getPostDataBlob(r2)     // Catch:{ all -> 0x0442 }
            boolean r2 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r4)     // Catch:{ all -> 0x0442 }
            if (r2 != 0) goto L_0x0124
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0442 }
            java.lang.String r6 = "%1$s Sending POST data as part of the request [length: %2$d]:\r\n%3$s"
            r7 = 3
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ all -> 0x0442 }
            r14 = 0
            java.lang.String r15 = getLoggingPrefix(r19)     // Catch:{ all -> 0x0442 }
            r7[r14] = r15     // Catch:{ all -> 0x0442 }
            r14 = 1
            java.lang.String r15 = "UTF-8"
            byte[] r15 = r4.getBytes(r15)     // Catch:{ all -> 0x0442 }
            int r15 = r15.length     // Catch:{ all -> 0x0442 }
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)     // Catch:{ all -> 0x0442 }
            r7[r14] = r15     // Catch:{ all -> 0x0442 }
            r14 = 2
            r7[r14] = r4     // Catch:{ all -> 0x0442 }
            java.lang.String r6 = java.lang.String.format(r6, r7)     // Catch:{ all -> 0x0442 }
            android.util.Log.d(r2, r6)     // Catch:{ all -> 0x0442 }
            r0 = r3
            org.apache.http.client.methods.HttpPost r0 = (org.apache.http.client.methods.HttpPost) r0     // Catch:{ all -> 0x0442 }
            r2 = r0
            java.lang.String r6 = "Content-Language"
            java.lang.String r7 = "en-US"
            r2.setHeader(r6, r7)     // Catch:{ all -> 0x0442 }
            r0 = r3
            org.apache.http.client.methods.HttpPost r0 = (org.apache.http.client.methods.HttpPost) r0     // Catch:{ all -> 0x0442 }
            r2 = r0
            java.lang.String r6 = "Content-Type"
            java.lang.String r7 = "application/x-www-form-urlencoded"
            r2.setHeader(r6, r7)     // Catch:{ all -> 0x0442 }
            r0 = r3
            org.apache.http.client.methods.HttpPost r0 = (org.apache.http.client.methods.HttpPost) r0     // Catch:{ all -> 0x0442 }
            r2 = r0
            org.apache.http.entity.StringEntity r6 = new org.apache.http.entity.StringEntity     // Catch:{ all -> 0x0442 }
            r6.<init>(r4)     // Catch:{ all -> 0x0442 }
            r2.setEntity(r6)     // Catch:{ all -> 0x0442 }
        L_0x0124:
            r4 = r3
        L_0x0125:
            java.lang.String r2 = "User-Agent"
            com.getjar.sdk.comm.CommContext r3 = r19.getCommContext()     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = r3.getSdkUserAgent()     // Catch:{ all -> 0x0207 }
            r4.setHeader(r2, r3)     // Catch:{ all -> 0x0207 }
            com.getjar.sdk.comm.CommContext r2 = r19.getCommContext()     // Catch:{ all -> 0x0207 }
            java.lang.String r2 = r2.getAuthToken()     // Catch:{ all -> 0x0207 }
            boolean r2 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r2)     // Catch:{ all -> 0x0207 }
            if (r2 != 0) goto L_0x014d
            java.lang.String r2 = "Authorization"
            com.getjar.sdk.comm.CommContext r3 = r19.getCommContext()     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = r3.getAuthToken()     // Catch:{ all -> 0x0207 }
            r4.setHeader(r2, r3)     // Catch:{ all -> 0x0207 }
        L_0x014d:
            r0 = r18
            com.getjar.sdk.comm.CachingManager r2 = r0._cachingManager     // Catch:{ all -> 0x0207 }
            r0 = r19
            java.lang.String r2 = r2.getETag(r0)     // Catch:{ all -> 0x0207 }
            boolean r3 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r2)     // Catch:{ all -> 0x0207 }
            if (r3 != 0) goto L_0x017a
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = "%1$s Adding the 'If-None-Match' header [ETag = %2$s]"
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ all -> 0x0207 }
            r14 = 0
            java.lang.String r15 = getLoggingPrefix(r19)     // Catch:{ all -> 0x0207 }
            r7[r14] = r15     // Catch:{ all -> 0x0207 }
            r14 = 1
            r7[r14] = r2     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = java.lang.String.format(r6, r7)     // Catch:{ all -> 0x0207 }
            android.util.Log.v(r3, r6)     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = "If-None-Match"
            r4.setHeader(r3, r2)     // Catch:{ all -> 0x0207 }
        L_0x017a:
            org.apache.http.HttpHost r2 = new org.apache.http.HttpHost     // Catch:{ Exception -> 0x0263 }
            java.net.URI r3 = r4.getURI()     // Catch:{ Exception -> 0x0263 }
            java.lang.String r3 = r3.getHost()     // Catch:{ Exception -> 0x0263 }
            java.net.URI r6 = r4.getURI()     // Catch:{ Exception -> 0x0263 }
            int r6 = r6.getPort()     // Catch:{ Exception -> 0x0263 }
            java.net.URI r7 = r4.getURI()     // Catch:{ Exception -> 0x0263 }
            java.lang.String r7 = r7.getScheme()     // Catch:{ Exception -> 0x0263 }
            r2.<init>(r3, r6, r7)     // Catch:{ Exception -> 0x0263 }
            org.apache.http.conn.routing.HttpRoutePlanner r3 = r11.getRoutePlanner()     // Catch:{ Exception -> 0x0263 }
            r6 = 0
            org.apache.http.conn.routing.HttpRoute r2 = r3.determineRoute(r2, r4, r6)     // Catch:{ Exception -> 0x0263 }
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x0263 }
            java.lang.String r6 = "%1$s ROUTE [ResolvedIP: %2$s  ProxyHost: %3$s  TargetHoust: %4$s  Secured: %5$s  Tunnelled: %6$s]"
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x0263 }
            r14 = 0
            java.lang.String r15 = getLoggingPrefix(r19)     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r15     // Catch:{ Exception -> 0x0263 }
            r14 = 1
            java.net.URI r15 = r4.getURI()     // Catch:{ Exception -> 0x0263 }
            java.lang.String r15 = r15.getHost()     // Catch:{ Exception -> 0x0263 }
            java.net.InetAddress r15 = java.net.InetAddress.getByName(r15)     // Catch:{ Exception -> 0x0263 }
            java.lang.String r15 = r15.getHostAddress()     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r15     // Catch:{ Exception -> 0x0263 }
            r14 = 2
            org.apache.http.HttpHost r15 = r2.getProxyHost()     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r15     // Catch:{ Exception -> 0x0263 }
            r14 = 3
            org.apache.http.HttpHost r15 = r2.getTargetHost()     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r15     // Catch:{ Exception -> 0x0263 }
            r14 = 4
            boolean r15 = r2.isSecure()     // Catch:{ Exception -> 0x0263 }
            java.lang.Boolean r15 = java.lang.Boolean.valueOf(r15)     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r15     // Catch:{ Exception -> 0x0263 }
            r14 = 5
            boolean r2 = r2.isTunnelled()     // Catch:{ Exception -> 0x0263 }
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)     // Catch:{ Exception -> 0x0263 }
            r7[r14] = r2     // Catch:{ Exception -> 0x0263 }
            java.lang.String r2 = java.lang.String.format(r6, r7)     // Catch:{ Exception -> 0x0263 }
            android.util.Log.v(r3, r2)     // Catch:{ Exception -> 0x0263 }
        L_0x01ec:
            com.getjar.sdk.comm.RequestUtilities.debugDumpRequestProperties(r4)     // Catch:{ all -> 0x0207 }
            org.apache.http.HttpResponse r6 = r11.execute(r4)     // Catch:{ all -> 0x0207 }
            if (r6 != 0) goto L_0x027e
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = "Failed to get a response from a service call [URL:%1$s]"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x0207 }
            r5 = 0
            r4[r5] = r8     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x0207 }
            r2.<init>(r3)     // Catch:{ all -> 0x0207 }
            throw r2     // Catch:{ all -> 0x0207 }
        L_0x0207:
            r2 = move-exception
            r3 = r2
        L_0x0209:
            org.apache.http.conn.ClientConnectionManager r2 = r11.getConnectionManager()     // Catch:{ all -> 0x0211 }
            r2.shutdown()     // Catch:{ all -> 0x0211 }
            throw r3     // Catch:{ all -> 0x0211 }
        L_0x0211:
            r3 = move-exception
            r4 = r8
            r5 = r9
        L_0x0214:
            r2 = r3
        L_0x0215:
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            java.lang.String r6 = "%1$s Finished Request"
            r7 = 1
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = 0
            java.lang.String r9 = getLoggingPrefix(r19)
            r7[r8] = r9
            java.lang.String r6 = java.lang.String.format(r6, r7)
            android.util.Log.i(r3, r6)
            long r6 = java.lang.System.currentTimeMillis()
            long r6 = r6 - r12
            int r3 = (int) r6
            if (r5 == 0) goto L_0x0235
            r5.setResponseTime(r3)
        L_0x0235:
            java.lang.String r5 = getLoggingPrefix(r19)
            if (r4 == 0) goto L_0x0427
        L_0x023b:
            java.lang.String r6 = "%1$s REQUEST TIMING: %2$d [TO: %3$s]"
            r7 = 3
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = 0
            r7[r8] = r5
            r5 = 1
            java.lang.Integer r8 = java.lang.Integer.valueOf(r3)
            r7[r5] = r8
            r5 = 2
            r7[r5] = r4
            java.lang.String r4 = java.lang.String.format(r6, r7)
            r5 = 1000(0x3e8, float:1.401E-42)
            if (r3 <= r5) goto L_0x042b
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.e(r3, r4)
        L_0x025a:
            throw r2
        L_0x025b:
            org.apache.http.client.methods.HttpGet r3 = new org.apache.http.client.methods.HttpGet     // Catch:{ all -> 0x0207 }
            r3.<init>(r8)     // Catch:{ all -> 0x0207 }
            r4 = r3
            goto L_0x0125
        L_0x0263:
            r2 = move-exception
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = "%1$s Failed to resolve and log the request route for '%2$s'"
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ all -> 0x0207 }
            r14 = 0
            java.lang.String r15 = getLoggingPrefix(r19)     // Catch:{ all -> 0x0207 }
            r7[r14] = r15     // Catch:{ all -> 0x0207 }
            r14 = 1
            r7[r14] = r8     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = java.lang.String.format(r6, r7)     // Catch:{ all -> 0x0207 }
            android.util.Log.e(r3, r6, r2)     // Catch:{ all -> 0x0207 }
            goto L_0x01ec
        L_0x027e:
            org.apache.http.StatusLine r2 = r6.getStatusLine()     // Catch:{ all -> 0x0207 }
            if (r2 == 0) goto L_0x028c
            org.apache.http.StatusLine r2 = r6.getStatusLine()     // Catch:{ all -> 0x0207 }
            int r5 = r2.getStatusCode()     // Catch:{ all -> 0x0207 }
        L_0x028c:
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = "%1$s Result code: %2$d"
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ all -> 0x0207 }
            r14 = 0
            java.lang.String r15 = getLoggingPrefix(r19)     // Catch:{ all -> 0x0207 }
            r7[r14] = r15     // Catch:{ all -> 0x0207 }
            r14 = 1
            java.lang.Integer r15 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x0207 }
            r7[r14] = r15     // Catch:{ all -> 0x0207 }
            java.lang.String r3 = java.lang.String.format(r3, r7)     // Catch:{ all -> 0x0207 }
            android.util.Log.d(r2, r3)     // Catch:{ all -> 0x0207 }
            r2 = 0
            java.lang.String r3 = "Authorization"
            org.apache.http.Header r3 = r6.getFirstHeader(r3)     // Catch:{ all -> 0x0207 }
            if (r3 == 0) goto L_0x02b5
            java.lang.String r2 = r3.getValue()     // Catch:{ all -> 0x0207 }
        L_0x02b5:
            java.lang.String r3 = "Authorization"
            java.lang.String r3 = r3.toLowerCase()     // Catch:{ all -> 0x0207 }
            org.apache.http.Header r3 = r6.getFirstHeader(r3)     // Catch:{ all -> 0x0207 }
            if (r3 == 0) goto L_0x02c5
            java.lang.String r2 = r3.getValue()     // Catch:{ all -> 0x0207 }
        L_0x02c5:
            java.lang.String r3 = "Authorization"
            java.lang.String r3 = r3.toUpperCase()     // Catch:{ all -> 0x0207 }
            org.apache.http.Header r3 = r6.getFirstHeader(r3)     // Catch:{ all -> 0x0207 }
            if (r3 == 0) goto L_0x02d5
            java.lang.String r2 = r3.getValue()     // Catch:{ all -> 0x0207 }
        L_0x02d5:
            boolean r3 = com.getjar.sdk.utilities.StringUtility.isNullOrEmpty(r2)     // Catch:{ all -> 0x0207 }
            if (r3 != 0) goto L_0x02e2
            com.getjar.sdk.comm.CommContext r3 = r19.getCommContext()     // Catch:{ all -> 0x0207 }
            r3.setAuthToken(r2)     // Catch:{ all -> 0x0207 }
        L_0x02e2:
            r3 = 0
            org.apache.http.HttpEntity r2 = r6.getEntity()     // Catch:{ all -> 0x0207 }
            if (r2 == 0) goto L_0x0313
            java.io.InputStream r7 = r2.getContent()     // Catch:{ all -> 0x0207 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ RuntimeException -> 0x0352 }
            java.lang.String r2 = ""
            r3.<init>(r2)     // Catch:{ RuntimeException -> 0x0352 }
            java.io.BufferedReader r14 = new java.io.BufferedReader     // Catch:{ RuntimeException -> 0x0352 }
            java.io.InputStreamReader r2 = new java.io.InputStreamReader     // Catch:{ RuntimeException -> 0x0352 }
            r2.<init>(r7)     // Catch:{ RuntimeException -> 0x0352 }
            r14.<init>(r2)     // Catch:{ RuntimeException -> 0x0352 }
            java.lang.String r2 = r14.readLine()     // Catch:{ RuntimeException -> 0x0352 }
        L_0x0302:
            if (r2 == 0) goto L_0x030c
            r3.append(r2)     // Catch:{ RuntimeException -> 0x0352 }
            java.lang.String r2 = r14.readLine()     // Catch:{ RuntimeException -> 0x0352 }
            goto L_0x0302
        L_0x030c:
            java.lang.String r3 = r3.toString()     // Catch:{ RuntimeException -> 0x0352 }
            r7.close()     // Catch:{ all -> 0x0207 }
        L_0x0313:
            java.util.HashMap r4 = new java.util.HashMap     // Catch:{ all -> 0x0207 }
            r4.<init>()     // Catch:{ all -> 0x0207 }
            org.apache.http.Header[] r7 = r6.getAllHeaders()     // Catch:{ all -> 0x0207 }
            int r14 = r7.length     // Catch:{ all -> 0x0207 }
            r2 = 0
            r6 = r2
        L_0x031f:
            if (r6 >= r14) goto L_0x035c
            r15 = r7[r6]
            java.lang.String r2 = r15.getName()     // Catch:{ all -> 0x0207 }
            boolean r2 = r4.containsKey(r2)     // Catch:{ all -> 0x0207 }
            if (r2 != 0) goto L_0x033d
            java.lang.String r2 = r15.getName()     // Catch:{ all -> 0x0207 }
            java.util.ArrayList r16 = new java.util.ArrayList     // Catch:{ all -> 0x0207 }
            r17 = 1
            r16.<init>(r17)     // Catch:{ all -> 0x0207 }
            r0 = r16
            r4.put(r2, r0)     // Catch:{ all -> 0x0207 }
        L_0x033d:
            java.lang.String r2 = r15.getName()     // Catch:{ all -> 0x0207 }
            java.lang.Object r2 = r4.get(r2)     // Catch:{ all -> 0x0207 }
            java.util.List r2 = (java.util.List) r2     // Catch:{ all -> 0x0207 }
            java.lang.String r15 = r15.getValue()     // Catch:{ all -> 0x0207 }
            r2.add(r15)     // Catch:{ all -> 0x0207 }
            int r2 = r6 + 1
            r6 = r2
            goto L_0x031f
        L_0x0352:
            r2 = move-exception
            r4.abort()     // Catch:{ all -> 0x0357 }
            throw r2     // Catch:{ all -> 0x0357 }
        L_0x0357:
            r2 = move-exception
            r7.close()     // Catch:{ all -> 0x0207 }
            throw r2     // Catch:{ all -> 0x0207 }
        L_0x035c:
            com.getjar.sdk.comm.Result r2 = new com.getjar.sdk.comm.Result     // Catch:{ all -> 0x0207 }
            int r6 = r19.getId()     // Catch:{ all -> 0x0207 }
            java.lang.String r6 = java.lang.Integer.toString(r6)     // Catch:{ all -> 0x0207 }
            boolean r7 = r19.getSuppressInternalCallbacks()     // Catch:{ all -> 0x0207 }
            r2.<init>(r3, r4, r5, r6, r7)     // Catch:{ all -> 0x0207 }
            r0 = r19
            r0.setResult(r2)     // Catch:{ all -> 0x0446 }
            int r4 = r2.getResponseCode()     // Catch:{ all -> 0x0446 }
            r6 = 200(0xc8, float:2.8E-43)
            if (r4 != r6) goto L_0x03a2
            org.json.JSONObject r4 = r2.getResponseJson()     // Catch:{ all -> 0x0446 }
            if (r4 != 0) goto L_0x03a2
            java.lang.String r4 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x0446 }
            java.lang.String r6 = "%1$s Recieved a bad response from a service call [URL:%2$s] [RESPONSE_CODE: %3$d] [RESPONSE:%4$s]"
            r7 = 4
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ all -> 0x0446 }
            r9 = 0
            java.lang.String r14 = getLoggingPrefix(r19)     // Catch:{ all -> 0x0446 }
            r7[r9] = r14     // Catch:{ all -> 0x0446 }
            r9 = 1
            r7[r9] = r8     // Catch:{ all -> 0x0446 }
            r9 = 2
            java.lang.Integer r14 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x0446 }
            r7[r9] = r14     // Catch:{ all -> 0x0446 }
            r9 = 3
            r7[r9] = r3     // Catch:{ all -> 0x0446 }
            java.lang.String r3 = java.lang.String.format(r6, r7)     // Catch:{ all -> 0x0446 }
            android.util.Log.w(r4, r3)     // Catch:{ all -> 0x0446 }
        L_0x03a2:
            int r3 = r10 + 1
            com.getjar.sdk.comm.ServiceContextInterface r4 = r19.getServiceContextCallbacks()     // Catch:{ all -> 0x0446 }
            com.getjar.sdk.comm.CommContext r6 = r19.getCommContext()     // Catch:{ all -> 0x0446 }
            boolean r4 = r4.checkIfOperationShouldBeRetried(r6, r2, r5, r3)     // Catch:{ all -> 0x0446 }
            if (r4 == 0) goto L_0x03b9
            com.getjar.sdk.comm.CommContext r5 = r19.getCommContext()     // Catch:{ all -> 0x0446 }
            reauthorizeContext(r5)     // Catch:{ all -> 0x0446 }
        L_0x03b9:
            org.apache.http.conn.ClientConnectionManager r5 = r11.getConnectionManager()     // Catch:{ all -> 0x0456 }
            r5.shutdown()     // Catch:{ all -> 0x0456 }
            if (r4 != 0) goto L_0x044a
            r0 = r18
            com.getjar.sdk.comm.CachingManager r3 = r0._cachingManager     // Catch:{ all -> 0x0456 }
            r0 = r19
            r3.addResultToCache(r0)     // Catch:{ all -> 0x0456 }
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            java.lang.String r4 = "%1$s Finished Request"
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = 0
            java.lang.String r7 = getLoggingPrefix(r19)
            r5[r6] = r7
            java.lang.String r4 = java.lang.String.format(r4, r5)
            android.util.Log.i(r3, r4)
            long r4 = java.lang.System.currentTimeMillis()
            long r4 = r4 - r12
            int r3 = (int) r4
            if (r2 == 0) goto L_0x03eb
            r2.setResponseTime(r3)
        L_0x03eb:
            java.lang.String r4 = getLoggingPrefix(r19)
            if (r8 == 0) goto L_0x0412
        L_0x03f1:
            java.lang.String r5 = "%1$s REQUEST TIMING: %2$d [TO: %3$s]"
            r6 = 3
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = 0
            r6[r7] = r4
            r4 = 1
            java.lang.Integer r7 = java.lang.Integer.valueOf(r3)
            r6[r4] = r7
            r4 = 2
            r6[r4] = r8
            java.lang.String r4 = java.lang.String.format(r5, r6)
            r5 = 1000(0x3e8, float:1.401E-42)
            if (r3 <= r5) goto L_0x0415
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.e(r3, r4)
            goto L_0x0016
        L_0x0412:
            java.lang.String r8 = ""
            goto L_0x03f1
        L_0x0415:
            r5 = 500(0x1f4, float:7.0E-43)
            if (r3 <= r5) goto L_0x0420
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.w(r3, r4)
            goto L_0x0016
        L_0x0420:
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.d(r3, r4)
            goto L_0x0016
        L_0x0427:
            java.lang.String r4 = ""
            goto L_0x023b
        L_0x042b:
            r5 = 500(0x1f4, float:7.0E-43)
            if (r3 <= r5) goto L_0x0436
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.w(r3, r4)
            goto L_0x025a
        L_0x0436:
            java.lang.String r3 = com.getjar.sdk.utilities.Constants.TAG
            android.util.Log.d(r3, r4)
            goto L_0x025a
        L_0x043d:
            r2 = move-exception
            r4 = r8
            r5 = r9
            goto L_0x0215
        L_0x0442:
            r2 = move-exception
            r3 = r2
            goto L_0x0209
        L_0x0446:
            r3 = move-exception
            r9 = r2
            goto L_0x0209
        L_0x044a:
            r9 = r2
            r10 = r3
            goto L_0x0073
        L_0x044e:
            r4 = r3
            goto L_0x0125
        L_0x0451:
            r3 = move-exception
            r4 = r8
            r5 = r2
            goto L_0x0214
        L_0x0456:
            r3 = move-exception
            r4 = r8
            r5 = r2
            goto L_0x0214
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CommManager.processesRequest(com.getjar.sdk.comm.Operation):com.getjar.sdk.comm.Result");
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00a7  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x001b A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.getjar.sdk.comm.Result processesRequestWithRetries(com.getjar.sdk.comm.Operation r12) {
        /*
            r11 = this;
            r10 = 5
            r5 = 1
            r1 = 0
            r3 = 0
            if (r12 != 0) goto L_0x000e
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "'operation' can not be NULL"
            r0.<init>(r1)
            throw r0
        L_0x000e:
            com.getjar.sdk.comm.Operation$Status r0 = r12.getState()
            com.getjar.sdk.comm.Operation$Status r2 = com.getjar.sdk.comm.Operation.Status.CANCELLED
            if (r0 != r2) goto L_0x001c
            com.getjar.sdk.comm.Result r0 = r12.getResult()
        L_0x001a:
            r1 = r0
        L_0x001b:
            return r1
        L_0x001c:
            com.getjar.sdk.comm.Operation$Status r0 = r12.getState()
            com.getjar.sdk.comm.Operation$Status r2 = com.getjar.sdk.comm.Operation.Status.RUNNING
            if (r0 == r2) goto L_0x003c
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "processesRequestWithRetries() for an operation in the %1$s state"
            java.lang.Object[] r2 = new java.lang.Object[r5]
            com.getjar.sdk.comm.Operation$Status r4 = r12.getState()
            java.lang.String r4 = r4.name()
            r2[r3] = r4
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.<init>(r1)
            throw r0
        L_0x003c:
            r0 = r1
            r7 = r3
        L_0x003e:
            int r2 = r12.getId()     // Catch:{ Exception -> 0x0091 }
            java.lang.String r2 = java.lang.Integer.toString(r2)     // Catch:{ Exception -> 0x0091 }
            boolean r4 = r12.isCancelled()     // Catch:{ Exception -> 0x0091 }
            if (r4 != 0) goto L_0x001b
            java.lang.String r4 = "%1$s Starting request %2$s for CommContext %3$s [Attempt %4$d]"
            r6 = 4
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x0091 }
            r8 = 0
            java.lang.String r9 = getLoggingPrefix(r12)     // Catch:{ Exception -> 0x0091 }
            r6[r8] = r9     // Catch:{ Exception -> 0x0091 }
            r8 = 1
            r6[r8] = r2     // Catch:{ Exception -> 0x0091 }
            r2 = 2
            com.getjar.sdk.comm.CommContext r8 = r12.getCommContext()     // Catch:{ Exception -> 0x0091 }
            java.lang.String r8 = r8.getCommContextId()     // Catch:{ Exception -> 0x0091 }
            r6[r2] = r8     // Catch:{ Exception -> 0x0091 }
            r2 = 3
            int r8 = r7 + 1
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x0091 }
            r6[r2] = r8     // Catch:{ Exception -> 0x0091 }
            java.lang.String r2 = java.lang.String.format(r4, r6)     // Catch:{ Exception -> 0x0091 }
            if (r7 <= 0) goto L_0x00bd
            java.lang.String r4 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x0091 }
            android.util.Log.e(r4, r2)     // Catch:{ Exception -> 0x0091 }
        L_0x007a:
            boolean r2 = r12.isCancelled()     // Catch:{ Exception -> 0x0091 }
            if (r2 != 0) goto L_0x001b
            com.getjar.sdk.comm.Result r0 = r11.processesRequest(r12)     // Catch:{ Exception -> 0x0091 }
            if (r0 != 0) goto L_0x00c3
            java.lang.Exception r2 = r12.getException()     // Catch:{ Exception -> 0x0091 }
            if (r2 == 0) goto L_0x011d
            java.lang.Exception r2 = r12.getException()     // Catch:{ Exception -> 0x0091 }
            throw r2     // Catch:{ Exception -> 0x0091 }
        L_0x0091:
            r2 = move-exception
            r4 = r2
            boolean r2 = com.getjar.sdk.comm.RequestUtilities.checkForRetryOnException(r4)
            if (r2 == 0) goto L_0x009b
            if (r7 < r10) goto L_0x00eb
        L_0x009b:
            r12.setException(r4)
            r0 = r1
            r4 = r3
            r6 = r5
        L_0x00a1:
            boolean r8 = r12.isCancelled()
            if (r8 != 0) goto L_0x001b
            if (r2 == 0) goto L_0x00ab
            if (r7 < r10) goto L_0x0118
        L_0x00ab:
            if (r6 == 0) goto L_0x0100
            boolean r1 = r12.getSuppressInternalCallbacks()
            if (r1 != 0) goto L_0x0100
            com.getjar.sdk.comm.CommContext r1 = r12.getCommContext()
            r1.makeNetworkFailureCallbacks()
            r1 = r0
            goto L_0x001b
        L_0x00bd:
            java.lang.String r4 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x0091 }
            android.util.Log.d(r4, r2)     // Catch:{ Exception -> 0x0091 }
            goto L_0x007a
        L_0x00c3:
            com.getjar.sdk.comm.ServicesException r6 = com.getjar.sdk.comm.RequestUtilities.getServicesException(r0)     // Catch:{ Exception -> 0x0091 }
            if (r6 == 0) goto L_0x011d
            com.getjar.sdk.comm.Result r2 = r6.getRequestResult()     // Catch:{ JSONException -> 0x0115 }
            boolean r2 = r2.checkForBlacklisted()     // Catch:{ JSONException -> 0x0115 }
        L_0x00d1:
            com.getjar.sdk.comm.Result r4 = r6.getRequestResult()     // Catch:{ JSONException -> 0x0112 }
            boolean r4 = r4.checkForUnsupported()     // Catch:{ JSONException -> 0x0112 }
        L_0x00d9:
            com.getjar.sdk.comm.Result r6 = r6.getRequestResult()     // Catch:{ Exception -> 0x0091 }
            if (r6 == 0) goto L_0x00e7
            if (r2 != 0) goto L_0x00e3
            if (r4 == 0) goto L_0x00e7
        L_0x00e3:
            r2 = r3
            r4 = r3
            r6 = r3
            goto L_0x00a1
        L_0x00e7:
            r2 = r3
            r4 = r5
            r6 = r3
            goto L_0x00a1
        L_0x00eb:
            boolean r4 = r12.isCancelled()
            if (r4 != 0) goto L_0x001b
            r8 = 2000(0x7d0, double:9.88E-321)
            java.lang.Thread.sleep(r8)     // Catch:{ InterruptedException -> 0x00f9 }
            r4 = r3
            r6 = r5
            goto L_0x00a1
        L_0x00f9:
            r4 = move-exception
            r4.printStackTrace()
            r4 = r3
            r6 = r5
            goto L_0x00a1
        L_0x0100:
            if (r4 == 0) goto L_0x001a
            boolean r1 = r12.getSuppressInternalCallbacks()
            if (r1 != 0) goto L_0x001a
            com.getjar.sdk.comm.CommContext r1 = r12.getCommContext()
            r1.makeServiceFailureCallbacks(r0)
            r1 = r0
            goto L_0x001b
        L_0x0112:
            r4 = move-exception
            r4 = r3
            goto L_0x00d9
        L_0x0115:
            r2 = move-exception
            r2 = r3
            goto L_0x00d1
        L_0x0118:
            int r2 = r7 + 1
            r7 = r2
            goto L_0x003e
        L_0x011d:
            r2 = r3
            r4 = r3
            r6 = r3
            goto L_0x00a1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CommManager.processesRequestWithRetries(com.getjar.sdk.comm.Operation):com.getjar.sdk.comm.Result");
    }

    public static void reauthorizeContext(CommContext commContext) throws Exception {
        boolean z;
        String commContextId = commContext.getCommContextId();
        String format = String.format("[CommContext.Id:%1$s Thread.Name:%2$s]", commContext.getCommContextId(), Thread.currentThread().getName());
        if (!_ReauthorizingCommContextIDs.contains(commContextId)) {
            synchronized (commContext) {
                if (!_ReauthorizingCommContextIDs.contains(commContextId)) {
                    _ReauthorizingCommContextIDs.add(commContextId);
                    z = false;
                } else {
                    z = true;
                }
            }
        } else {
            z = true;
        }
        if (!z) {
            try {
                Log.e(Constants.TAG, String.format("%1$s REAUTHORIZING %2$s", getLoggingPrefix(), format));
                commContext.clearAuthentication();
                new Thread(new CreateContextWorker(commContext), String.format("CreateContextWorker thread, re-auth [Context Id: %1$s]", commContext.getCommContextId())).start();
                commContext.waitForAuthorization();
                commContext.waitForUserAccess();
                commContext.waitForUserDevice();
                Log.e(Constants.TAG, String.format("%1$s REAUTHORIZATION FINISHED %2$s", getLoggingPrefix(), format));
                synchronized (commContext) {
                    _ReauthorizingCommContextIDs.remove(commContextId);
                }
            } catch (Throwable th) {
                Log.e(Constants.TAG, String.format("%1$s REAUTHORIZATION FINISHED %2$s", getLoggingPrefix(), format));
                synchronized (commContext) {
                    _ReauthorizingCommContextIDs.remove(commContextId);
                    throw th;
                }
            }
        } else {
            Log.e(Constants.TAG, String.format("%1$s Waiting on authorization %2$s", getLoggingPrefix(), format));
            while (_ReauthorizingCommContextIDs.contains(commContextId)) {
                Thread.sleep(200);
            }
            Log.e(Constants.TAG, String.format("%1$s Done waiting on authorization %2$s", getLoggingPrefix(), format));
        }
    }

    protected static void reauthorizeContext(String str) throws Exception {
        reauthorizeContext(retrieveContext(str));
    }

    public static CommContext retrieveContext(String str) {
        return _IdentifierToCommContextMap.get(str);
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x007e, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0082, code lost:
        r1.close();
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x007e A[ExcHandler: all (th java.lang.Throwable), Splitter:B:1:0x0002] */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:35:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void sendUsedEvent(com.getjar.sdk.comm.CommContext r9) {
        /*
            r2 = 0
            r0 = 0
            android.content.Context r3 = r9.getApplicationContext()     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            java.lang.String r4 = r3.getPackageName()     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            java.lang.String r1 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            java.lang.String r5 = "%1$s OPEN EVENT - ReportUsage - packageName=%2$s"
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            r7 = 0
            java.lang.String r8 = getLoggingPrefix()     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            r6[r7] = r8     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            r7 = 1
            r6[r7] = r4     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            java.lang.String r5 = java.lang.String.format(r5, r6)     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            android.util.Log.d(r1, r5)     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            android.content.pm.PackageManager r1 = r3.getPackageManager()     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            r5 = 128(0x80, float:1.794E-43)
            android.content.pm.ApplicationInfo r1 = r1.getApplicationInfo(r4, r5)     // Catch:{ Exception -> 0x0086, all -> 0x007e }
            if (r1 == 0) goto L_0x0030
            int r0 = r1.flags     // Catch:{ Exception -> 0x0086, all -> 0x007e }
        L_0x0030:
            com.getjar.sdk.data.DBAdapterAppData r1 = new com.getjar.sdk.data.DBAdapterAppData     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            r1.<init>(r3)     // Catch:{ Exception -> 0x0061, all -> 0x007e }
            com.getjar.sdk.rewards.AppData r2 = r1.appDataLoad(r4)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            if (r2 != 0) goto L_0x0047
            com.getjar.sdk.rewards.AppData$AppStatus r2 = com.getjar.sdk.rewards.AppData.AppStatus.INSTALLED     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            com.getjar.sdk.rewards.AppData r2 = com.getjar.sdk.utilities.Utility.getApplicationInfo(r3, r4, r2)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r2.setFlags(r0)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r1.appDataUpsert(r2)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
        L_0x0047:
            java.util.Date r0 = new java.util.Date     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r0.<init>()     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            long r6 = r0.getTime()     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r1.usageIncrementLaunchCount(r4, r6)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            com.getjar.sdk.data.ReportManager r0 = new com.getjar.sdk.data.ReportManager     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r0.<init>(r3, r9)     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            r0.sendUnsyncedUsageData()     // Catch:{ Exception -> 0x0088, all -> 0x008a }
            if (r1 == 0) goto L_0x0060
            r1.close()
        L_0x0060:
            return
        L_0x0061:
            r0 = move-exception
            r1 = r2
        L_0x0063:
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x008c }
            java.lang.String r3 = "%1$s failed"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x008c }
            r5 = 0
            java.lang.String r6 = getLoggingPrefix()     // Catch:{ all -> 0x008c }
            r4[r5] = r6     // Catch:{ all -> 0x008c }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x008c }
            android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x008c }
            if (r1 == 0) goto L_0x0060
            r1.close()
            goto L_0x0060
        L_0x007e:
            r0 = move-exception
        L_0x007f:
            r1 = r2
        L_0x0080:
            if (r1 == 0) goto L_0x0085
            r1.close()
        L_0x0085:
            throw r0
        L_0x0086:
            r1 = move-exception
            goto L_0x0030
        L_0x0088:
            r0 = move-exception
            goto L_0x0063
        L_0x008a:
            r0 = move-exception
            goto L_0x0080
        L_0x008c:
            r0 = move-exception
            r2 = r1
            goto L_0x007f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CommManager.sendUsedEvent(com.getjar.sdk.comm.CommContext):void");
    }

    private void startWorker() {
        Log.i(Constants.TAG, String.format("%1$s startWorker()", getLoggingPrefix()));
        synchronized (_WorkerThreadLock) {
            _WorkerThreadStopping = false;
            if (_WorkerThread == null) {
                _WorkerThread = new Thread(new RequestPipelineManagementRunnable(), "CommManager Worker Thread");
            }
            if (!_WorkerThread.isAlive()) {
                _WorkerThread.start();
                Log.i(Constants.TAG, String.format("%1$s Thread started", getLoggingPrefix()));
            } else {
                Log.v(Constants.TAG, String.format("%1$s Thread already running", getLoggingPrefix()));
            }
        }
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void stopWorker() {
        /*
            r7 = this;
            r2 = 1
            r4 = 0
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG
            java.lang.String r1 = "%1$s stopWorker()"
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.String r3 = getLoggingPrefix()
            r2[r4] = r3
            java.lang.String r1 = java.lang.String.format(r1, r2)
            android.util.Log.i(r0, r1)
            java.lang.Object r1 = com.getjar.sdk.comm.CommManager._WorkerThreadLock
            monitor-enter(r1)
            java.lang.Thread r0 = com.getjar.sdk.comm.CommManager._WorkerThread     // Catch:{ all -> 0x007f }
            if (r0 != 0) goto L_0x0033
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r2 = "%1$s Thread already stopped"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x007f }
            r4 = 0
            java.lang.String r5 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r3[r4] = r5     // Catch:{ all -> 0x007f }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x007f }
            android.util.Log.v(r0, r2)     // Catch:{ all -> 0x007f }
            monitor-exit(r1)     // Catch:{ all -> 0x007f }
        L_0x0032:
            return
        L_0x0033:
            r0 = 1
            com.getjar.sdk.comm.CommManager._WorkerThreadStopping = r0     // Catch:{ all -> 0x007f }
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r2 = "%1$s kicking worker thread"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x007f }
            r4 = 0
            java.lang.String r5 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r3[r4] = r5     // Catch:{ all -> 0x007f }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x007f }
            android.util.Log.v(r0, r2)     // Catch:{ all -> 0x007f }
            java.lang.Object r2 = com.getjar.sdk.comm.CommManager._RequestPipelineLock     // Catch:{ all -> 0x007f }
            monitor-enter(r2)     // Catch:{ all -> 0x007f }
            java.lang.Object r0 = com.getjar.sdk.comm.CommManager._RequestPipelineLock     // Catch:{ all -> 0x0082 }
            r0.notify()     // Catch:{ all -> 0x0082 }
            monitor-exit(r2)     // Catch:{ all -> 0x0082 }
            java.lang.Thread r0 = com.getjar.sdk.comm.CommManager._WorkerThread     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            r2 = 2000(0x7d0, double:9.88E-321)
            r0.join(r2)     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            java.lang.Thread r0 = com.getjar.sdk.comm.CommManager._WorkerThread     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            r0.interrupt()     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            java.lang.Thread r0 = com.getjar.sdk.comm.CommManager._WorkerThread     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            r0.join()     // Catch:{ InterruptedException -> 0x0085, Exception -> 0x00c6 }
            r0 = 0
            com.getjar.sdk.comm.CommManager._WorkerThread = r0     // Catch:{ all -> 0x007f }
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r2 = "%1$s Thread stopped"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x007f }
            r4 = 0
            java.lang.String r5 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r3[r4] = r5     // Catch:{ all -> 0x007f }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x007f }
            android.util.Log.i(r0, r2)     // Catch:{ all -> 0x007f }
        L_0x007d:
            monitor-exit(r1)     // Catch:{ all -> 0x007f }
            goto L_0x0032
        L_0x007f:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x007f }
            throw r0
        L_0x0082:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x0082 }
            throw r0     // Catch:{ all -> 0x007f }
        L_0x0085:
            r0 = move-exception
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = "%1$s Thread '%2$s' recieved an interrupt"
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x00fc }
            r5 = 0
            java.lang.String r6 = getLoggingPrefix()     // Catch:{ all -> 0x00fc }
            r4[r5] = r6     // Catch:{ all -> 0x00fc }
            r5 = 1
            java.lang.Thread r6 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x00fc }
            java.lang.String r6 = r6.getName()     // Catch:{ all -> 0x00fc }
            r4[r5] = r6     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x00fc }
            r4 = 0
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x00fc }
            android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x00fc }
            r0 = 0
            com.getjar.sdk.comm.CommManager._WorkerThread = r0     // Catch:{ all -> 0x007f }
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r2 = "%1$s Thread stopped"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x007f }
            r4 = 0
            java.lang.String r5 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r3[r4] = r5     // Catch:{ all -> 0x007f }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x007f }
            android.util.Log.i(r0, r2)     // Catch:{ all -> 0x007f }
            goto L_0x007d
        L_0x00c6:
            r0 = move-exception
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = "%1$s failed"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x00fc }
            r5 = 0
            java.lang.String r6 = getLoggingPrefix()     // Catch:{ all -> 0x00fc }
            r4[r5] = r6     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x00fc }
            r4 = 0
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x00fc }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x00fc }
            android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x00fc }
            r0 = 0
            com.getjar.sdk.comm.CommManager._WorkerThread = r0     // Catch:{ all -> 0x007f }
            java.lang.String r0 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r2 = "%1$s Thread stopped"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x007f }
            r4 = 0
            java.lang.String r5 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r3[r4] = r5     // Catch:{ all -> 0x007f }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x007f }
            android.util.Log.i(r0, r2)     // Catch:{ all -> 0x007f }
            goto L_0x007d
        L_0x00fc:
            r0 = move-exception
            r2 = 0
            com.getjar.sdk.comm.CommManager._WorkerThread = r2     // Catch:{ all -> 0x007f }
            java.lang.String r2 = com.getjar.sdk.utilities.Constants.TAG     // Catch:{ all -> 0x007f }
            java.lang.String r3 = "%1$s Thread stopped"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x007f }
            r5 = 0
            java.lang.String r6 = getLoggingPrefix()     // Catch:{ all -> 0x007f }
            r4[r5] = r6     // Catch:{ all -> 0x007f }
            java.lang.String r3 = java.lang.String.format(r3, r4)     // Catch:{ all -> 0x007f }
            android.util.Log.i(r2, r3)     // Catch:{ all -> 0x007f }
            throw r0     // Catch:{ all -> 0x007f }
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CommManager.stopWorker():void");
    }

    /* access modifiers changed from: private */
    public void updateOperationStateFromResult(Operation operation) throws Exception {
        if (operation == null) {
            throw new IllegalArgumentException("'operation' can not be NULL");
        } else if (operation.getResult() != null) {
            if (operation.getRetryAfterCount() < 5 && (operation.getResult().getResponseCode() == 202 || operation.getResult().getResponseCode() == 503)) {
                operation.setState(Operation.Status.RETRYING);
            } else if (operation.getResult().getResponseCode() == 304) {
                this._cachingManager.refreshCacheEntry(operation);
                operation.setState(Operation.Status.COMPLETED);
            } else if (operation.getResult().getResponseCode() == 200) {
                operation.setState(Operation.Status.COMPLETED);
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0014, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean cancelRequest(com.getjar.sdk.comm.Operation r4) {
        /*
            r3 = this;
            java.lang.Object r1 = com.getjar.sdk.comm.CommManager._RequestPipelineLock
            monitor-enter(r1)
            com.getjar.sdk.comm.Operation$Status r0 = r4.getState()     // Catch:{ all -> 0x002d }
            com.getjar.sdk.comm.Operation$Status r2 = com.getjar.sdk.comm.Operation.Status.RUNNING     // Catch:{ all -> 0x002d }
            if (r0 == r2) goto L_0x0013
            com.getjar.sdk.comm.Operation$Status r0 = r4.getState()     // Catch:{ all -> 0x002d }
            com.getjar.sdk.comm.Operation$Status r2 = com.getjar.sdk.comm.Operation.Status.COMPLETED     // Catch:{ all -> 0x002d }
            if (r0 != r2) goto L_0x0016
        L_0x0013:
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            r0 = 0
        L_0x0015:
            return r0
        L_0x0016:
            java.util.ArrayList<com.getjar.sdk.comm.Operation> r0 = com.getjar.sdk.comm.CommManager._ActiveRequests     // Catch:{ all -> 0x002d }
            r0.remove(r4)     // Catch:{ all -> 0x002d }
            java.util.LinkedList<com.getjar.sdk.comm.Operation> r0 = com.getjar.sdk.comm.CommManager._RequestQueue     // Catch:{ all -> 0x002d }
            r0.remove(r4)     // Catch:{ all -> 0x002d }
            java.util.ArrayList<com.getjar.sdk.comm.Operation> r0 = com.getjar.sdk.comm.CommManager._RetryRequests     // Catch:{ all -> 0x002d }
            r0.remove(r4)     // Catch:{ all -> 0x002d }
            com.getjar.sdk.comm.Operation$Status r0 = com.getjar.sdk.comm.Operation.Status.CANCELLED     // Catch:{ all -> 0x002d }
            r4.setState(r0)     // Catch:{ all -> 0x002d }
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            r0 = 1
            goto L_0x0015
        L_0x002d:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getjar.sdk.comm.CommManager.cancelRequest(com.getjar.sdk.comm.Operation):boolean");
    }

    public Operation enqueueOperation(Request.ServiceName serviceName, String str, URI uri, Request.HttpMethod httpMethod, Map<String, String> map, Operation.Priority priority, CommContext commContext, ServiceContextInterface serviceContextInterface, boolean z) {
        return enqueueRequest(new Operation(serviceName, str, uri, httpMethod, map, priority, commContext, serviceContextInterface, z), false);
    }

    /* access modifiers changed from: protected */
    public Result waitOnOperation(Operation operation) throws Exception {
        Result result;
        if (operation == null) {
            throw new IllegalArgumentException("'operation' can not be NULL");
        } else if (operation.getState() == Operation.Status.COMPLETED || operation.getState() == Operation.Status.CANCELLED) {
            return operation.getResult();
        } else {
            if (operation.getState() == Operation.Status.RETRYING || operation.getState() == Operation.Status.RUNNING || operation.getState() == Operation.Status.WAITING) {
                synchronized (operation.getFuture()) {
                    operation.getFuture().get();
                    updateOperationStateFromResult(operation);
                    result = operation.getResult();
                    while (operation.getState() == Operation.Status.RETRYING) {
                        long j = 2;
                        if (result.getHeaders() != null && result.getHeaders().containsKey("Retry-After")) {
                            try {
                                j = Long.parseLong(result.getHeaders().get("Retry-After").get(0));
                            } catch (Exception e) {
                                Log.e(Constants.TAG, "'Retry-After' header found, but failed to parse as long (as delta in seconds)", e);
                            }
                        }
                        Log.v(Constants.TAG, String.format("Request %1$d resulted in a %2$d, retrying in %3$d seconds", Integer.valueOf(hashCode()), Integer.valueOf(result.getResponseCode()), Long.valueOf(j)));
                        operation.tickRetryAfterCount();
                        operation.updateRetryAfterTimestamp(1000 * j);
                        enqueueOperationForRetry(operation);
                        result = operation.getFuture().get();
                    }
                }
                return result;
            }
            throw new IllegalStateException(String.format("waitOnOperation() for an operation in the %1$s state", operation.getState().name()));
        }
    }
}

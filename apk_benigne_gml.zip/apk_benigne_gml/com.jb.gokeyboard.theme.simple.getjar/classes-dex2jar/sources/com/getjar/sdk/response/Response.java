package com.getjar.sdk.response;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.getjar.sdk.utilities.Constants;

public abstract class Response implements Parcelable {
    protected Response() {
    }

    public Response(Parcel parcel) {
        Log.v(Constants.TAG, String.format("Reconstructing parceled object [%1$s]", getClass().getName()));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        Log.v(Constants.TAG, String.format("writeToParcel() [%1$s] [flags:%2$d]", getClass().getName(), Integer.valueOf(i)));
    }
}

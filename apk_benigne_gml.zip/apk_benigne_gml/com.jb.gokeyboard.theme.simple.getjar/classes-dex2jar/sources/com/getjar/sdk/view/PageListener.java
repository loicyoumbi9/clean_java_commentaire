package com.getjar.sdk.view;

public interface PageListener {
    void onPageCanceled();

    void onPageClose();

    void onPageOpen();
}

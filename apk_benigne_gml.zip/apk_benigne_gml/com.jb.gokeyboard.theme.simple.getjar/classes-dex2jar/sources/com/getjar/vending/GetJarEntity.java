package com.getjar.vending;

public class GetJarEntity {
    long base;
    boolean getjar;
    long price;

    public long getBase() {
        return this.base;
    }

    public long getPrice() {
        return this.price;
    }

    public boolean isGetjar() {
        return this.getjar;
    }

    public void setBase(long j) {
        this.base = j;
    }

    public void setGetjar(boolean z) {
        this.getjar = z;
    }

    public void setPrice(long j) {
        this.price = j;
    }
}

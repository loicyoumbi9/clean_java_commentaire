package com.getjar.vending;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.getjar.sdk.utilities.Constants;
import com.jb.gokeyboard.theme.simple.getjar.R;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class GetJarUtils {
    public static final int GETJAR_DEFAULT_PRICE = 70;
    public static final String PVERSION = "1";

    public static final DefaultHttpClient createHttpClient() {
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setStaleCheckingEnabled(basicHttpParams, false);
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, 5000);
        HttpConnectionParams.setSoTimeout(basicHttpParams, 5000);
        HttpConnectionParams.setSocketBufferSize(basicHttpParams, 8192);
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        return new DefaultHttpClient(new ThreadSafeClientConnManager(basicHttpParams, schemeRegistry), basicHttpParams);
    }

    private static String getCountry(Context context) {
        String str;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            str = telephonyManager != null ? telephonyManager.getSimCountryIso() : null;
        } catch (Throwable th) {
            str = null;
        }
        if (str == null || str.equals("")) {
            str = Locale.getDefault().getCountry().toLowerCase();
        }
        return str == null ? "error" : str;
    }

    public static HashMap<String, Integer> getPriceByCountry(Context context) {
        HashMap<String, Integer> hashMap = null;
        try {
            XmlResourceParser xml = context.getResources().getXml(R.xml.countries);
            if (xml != null) {
                for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                    switch (eventType) {
                        case 0:
                            try {
                                hashMap = new HashMap<>();
                                break;
                            } catch (XmlPullParserException e) {
                                e = e;
                                e.printStackTrace();
                                return hashMap;
                            } catch (IOException e2) {
                                e = e2;
                                e.printStackTrace();
                                return hashMap;
                            }
                        case 2:
                            if (!xml.getName().equals("country")) {
                                break;
                            } else {
                                hashMap.put(xml.getAttributeValue(null, "language"), Integer.valueOf(xml.getAttributeIntValue(null, Constants.APP_COST, 100)));
                                break;
                            }
                    }
                }
            }
        } catch (XmlPullParserException e3) {
            e = e3;
            e.printStackTrace();
            return hashMap;
        } catch (IOException e4) {
            e = e4;
            e.printStackTrace();
            return hashMap;
        }
        return hashMap;
    }

    public static Reader getReaderForNet(String str, List<NameValuePair> list) {
        HttpPost httpPost = new HttpPost(str);
        DefaultHttpClient createHttpClient = createHttpClient();
        try {
            httpPost.setEntity(new UrlEncodedFormEntity(list, Constants.ENCODING_CHARSET));
            HttpResponse execute = createHttpClient.execute(httpPost);
            if (execute.getStatusLine().getStatusCode() == 200) {
                return new StringReader(EntityUtils.toString(execute.getEntity()));
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        return null;
    }

    public static int getThemePrice(Context context) {
        String country = getCountry(context);
        HashMap<String, Integer> priceByCountry = getPriceByCountry(context);
        if (priceByCountry != null) {
            Integer num = priceByCountry.get(country);
            if (num == null) {
                num = priceByCountry.get("others");
            }
            if (num != null) {
                return num.intValue();
            }
        }
        return 70;
    }

    private static String language(Context context) {
        String str;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            if (telephonyManager != null) {
                str = telephonyManager.getSimCountryIso();
                if (str != null) {
                    try {
                        if (!str.equals("")) {
                            str = String.format("%s_%s", Locale.getDefault().getLanguage().toLowerCase(), str.toLowerCase());
                        }
                    } catch (Throwable th) {
                    }
                }
            } else {
                str = null;
            }
        } catch (Throwable th2) {
            str = null;
        }
        if (str == null || str.equals("")) {
            str = String.format("%s_%s", Locale.getDefault().getLanguage().toLowerCase(), Locale.getDefault().getCountry().toLowerCase());
        }
        Log.d("zj", "language :" + str);
        return str == null ? "error" : str;
    }

    public static GetJarEntity parseGetJarPrice(Context context, String str) {
        try {
            XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
            newInstance.setNamespaceAware(true);
            XmlPullParser newPullParser = newInstance.newPullParser();
            ArrayList arrayList = new ArrayList();
            arrayList.add(new BasicNameValuePair("pversion", PVERSION));
            arrayList.add(new BasicNameValuePair("package", context.getPackageName()));
            arrayList.add(new BasicNameValuePair("region", getCountry(context)));
            newPullParser.setInput(getReaderForNet(str, arrayList));
            GetJarEntity getJarEntity = null;
            for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.next()) {
                switch (eventType) {
                    case 0:
                        try {
                            getJarEntity = new GetJarEntity();
                            break;
                        } catch (Exception e) {
                            return null;
                        }
                    case 2:
                        if (!newPullParser.getName().equals("data")) {
                            if (!newPullParser.getName().equals(Constants.APP_COST)) {
                                if (!newPullParser.getName().equals("base")) {
                                    if (!newPullParser.getName().equals("getjar")) {
                                        if (!newPullParser.getName().equals("error")) {
                                            break;
                                        } else {
                                            return null;
                                        }
                                    } else {
                                        getJarEntity.setGetjar(Boolean.parseBoolean(newPullParser.nextText()));
                                        break;
                                    }
                                } else {
                                    getJarEntity.setBase(Long.parseLong(newPullParser.nextText()));
                                    break;
                                }
                            } else {
                                getJarEntity.setPrice(Long.parseLong(newPullParser.nextText()));
                                break;
                            }
                        } else {
                            getJarEntity = new GetJarEntity();
                            break;
                        }
                }
            }
            return getJarEntity;
        } catch (Exception e2) {
            return null;
        }
    }
}

package com.getjar.vending;

public class Constants {
    public static String APP_TOKEN = "aa428474-d2a5-453c-a97b-f79d430b0760";
    public static final String TAG = "PeacefulPenguinsAdvanced";
}

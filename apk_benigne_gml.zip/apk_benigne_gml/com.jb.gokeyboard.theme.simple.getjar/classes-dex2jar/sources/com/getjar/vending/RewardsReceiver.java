package com.getjar.vending;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.android.vending.InAppActivity;
import com.getjar.sdk.response.BlacklistedResponse;
import com.getjar.sdk.response.CloseResponse;
import com.getjar.sdk.response.DeviceUnsupportedResponse;
import com.getjar.sdk.response.PurchaseResponse;
import com.getjar.sdk.response.PurchaseSucceededResponse;
import java.util.Map;

public class RewardsReceiver extends ResultReceiver {
    Activity activity;

    public RewardsReceiver(Activity activity2) {
        super(null);
        this.activity = activity2;
    }

    /* access modifiers changed from: protected */
    public void onReceiveResult(int i, Bundle bundle) {
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            if (obj instanceof PurchaseSucceededResponse) {
                PurchaseSucceededResponse purchaseSucceededResponse = (PurchaseSucceededResponse) obj;
                purchaseSucceededResponse.getProductName();
                purchaseSucceededResponse.getAmount();
                InAppActivity.saveBillDataAndSetResult(this.activity, true);
                Intent intent = new Intent();
                Bundle bundle2 = new Bundle();
                bundle2.putString("package", this.activity.getPackageName());
                intent.putExtras(bundle2);
                this.activity.setResult(-1, intent);
                this.activity.finish();
                return;
            } else if (!(obj instanceof BlacklistedResponse)) {
                if (obj instanceof CloseResponse) {
                    if (this.activity != null) {
                    }
                    return;
                } else if (!PurchaseResponse.class.isAssignableFrom(obj.getClass()) && (obj instanceof DeviceUnsupportedResponse)) {
                    StringBuilder sb = new StringBuilder();
                    Map<String, String> deviceMetadata = ((DeviceUnsupportedResponse) obj).getDeviceMetadata();
                    if (deviceMetadata != null) {
                        sb.append("\r\ndeviceMetadata:");
                        for (String str2 : deviceMetadata.keySet()) {
                            sb.append("\r\n");
                            sb.append(str2);
                            sb.append("=");
                            sb.append(deviceMetadata.get(str2));
                        }
                    }
                }
            }
        }
    }
}

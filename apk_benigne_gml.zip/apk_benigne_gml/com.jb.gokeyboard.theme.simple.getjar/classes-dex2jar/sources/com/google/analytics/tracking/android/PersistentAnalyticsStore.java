package com.google.analytics.tracking.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.text.TextUtils;
import com.getjar.sdk.utilities.Utility;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentAnalyticsStore implements AnalyticsStore {
    /* access modifiers changed from: private */
    public static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL, '%s' TEXT NOT NULL, '%s' INTEGER);", HITS_TABLE, HIT_ID, HIT_TIME, HIT_URL, HIT_STRING, HIT_APP_ID);
    private static final String DATABASE_FILENAME = "google_analytics_v2.db";
    @VisibleForTesting
    static final String HITS_TABLE = "hits2";
    @VisibleForTesting
    static final String HIT_APP_ID = "hit_app_id";
    @VisibleForTesting
    static final String HIT_ID = "hit_id";
    @VisibleForTesting
    static final String HIT_STRING = "hit_string";
    @VisibleForTesting
    static final String HIT_TIME = "hit_time";
    @VisibleForTesting
    static final String HIT_URL = "hit_url";
    /* access modifiers changed from: private */
    public Clock mClock;
    /* access modifiers changed from: private */
    public final Context mContext;
    /* access modifiers changed from: private */
    public final String mDatabaseName;
    private final AnalyticsDatabaseHelper mDbHelper;
    private volatile Dispatcher mDispatcher;
    private long mLastDeleteStaleHitsTime;
    private final AnalyticsStoreStateListener mListener;

    @VisibleForTesting
    class AnalyticsDatabaseHelper extends SQLiteOpenHelper {
        private boolean mBadDatabase;
        private long mLastDatabaseCheckTime = 0;

        AnalyticsDatabaseHelper(Context context, String str) {
            super(context, str, (SQLiteDatabase.CursorFactory) null, 1);
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x0049  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private boolean tablePresent(java.lang.String r11, android.database.sqlite.SQLiteDatabase r12) {
            /*
                r10 = this;
                r8 = 0
                r9 = 0
                java.lang.String r1 = "SQLITE_MASTER"
                r0 = 1
                java.lang.String[] r2 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r0 = 0
                java.lang.String r3 = "name"
                r2[r0] = r3     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                java.lang.String r3 = "name=?"
                r0 = 1
                java.lang.String[] r4 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r0 = 0
                r4[r0] = r11     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r5 = 0
                r6 = 0
                r7 = 0
                r0 = r12
                android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                boolean r0 = r1.moveToFirst()     // Catch:{ SQLiteException -> 0x0055, all -> 0x004d }
                if (r1 == 0) goto L_0x0025
                r1.close()
            L_0x0025:
                return r0
            L_0x0026:
                r0 = move-exception
                r0 = r9
            L_0x0028:
                java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0051 }
                r1.<init>()     // Catch:{ all -> 0x0051 }
                java.lang.String r2 = "Error querying for table "
                java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x0051 }
                java.lang.StringBuilder r1 = r1.append(r11)     // Catch:{ all -> 0x0051 }
                java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0051 }
                com.google.analytics.tracking.android.Log.w(r1)     // Catch:{ all -> 0x0051 }
                if (r0 == 0) goto L_0x0043
                r0.close()
            L_0x0043:
                r0 = r8
                goto L_0x0025
            L_0x0045:
                r0 = move-exception
                r2 = r0
            L_0x0047:
                if (r9 == 0) goto L_0x004c
                r9.close()
            L_0x004c:
                throw r2
            L_0x004d:
                r0 = move-exception
                r2 = r0
                r9 = r1
                goto L_0x0047
            L_0x0051:
                r1 = move-exception
                r2 = r1
                r9 = r0
                goto L_0x0047
            L_0x0055:
                r0 = move-exception
                r0 = r1
                goto L_0x0028
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.tracking.android.PersistentAnalyticsStore.AnalyticsDatabaseHelper.tablePresent(java.lang.String, android.database.sqlite.SQLiteDatabase):boolean");
        }

        /* JADX INFO: finally extract failed */
        private void validateColumnsPresent(SQLiteDatabase sQLiteDatabase) {
            String[] columnNames;
            boolean z = false;
            Cursor rawQuery = sQLiteDatabase.rawQuery("SELECT * FROM hits2 WHERE 0", null);
            HashSet hashSet = new HashSet();
            try {
                for (String str : rawQuery.getColumnNames()) {
                    hashSet.add(str);
                }
                rawQuery.close();
                if (!hashSet.remove(PersistentAnalyticsStore.HIT_ID) || !hashSet.remove(PersistentAnalyticsStore.HIT_URL) || !hashSet.remove(PersistentAnalyticsStore.HIT_STRING) || !hashSet.remove(PersistentAnalyticsStore.HIT_TIME)) {
                    throw new SQLiteException("Database column missing");
                }
                if (!hashSet.remove(PersistentAnalyticsStore.HIT_APP_ID)) {
                    z = true;
                }
                if (!hashSet.isEmpty()) {
                    throw new SQLiteException("Database has extra columns");
                } else if (z) {
                    sQLiteDatabase.execSQL("ALTER TABLE hits2 ADD COLUMN hit_app_id");
                }
            } catch (Throwable th) {
                rawQuery.close();
                throw th;
            }
        }

        public SQLiteDatabase getWritableDatabase() {
            if (!this.mBadDatabase || this.mLastDatabaseCheckTime + 3600000 <= PersistentAnalyticsStore.this.mClock.currentTimeMillis()) {
                SQLiteDatabase sQLiteDatabase = null;
                this.mBadDatabase = true;
                this.mLastDatabaseCheckTime = PersistentAnalyticsStore.this.mClock.currentTimeMillis();
                try {
                    sQLiteDatabase = super.getWritableDatabase();
                } catch (SQLiteException e) {
                    PersistentAnalyticsStore.this.mContext.getDatabasePath(PersistentAnalyticsStore.this.mDatabaseName).delete();
                }
                if (sQLiteDatabase == null) {
                    sQLiteDatabase = super.getWritableDatabase();
                }
                this.mBadDatabase = false;
                return sQLiteDatabase;
            }
            throw new SQLiteException("Database creation failed");
        }

        /* access modifiers changed from: package-private */
        public boolean isBadDatabase() {
            return this.mBadDatabase;
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            FutureApis.setOwnerOnlyReadWrite(sQLiteDatabase.getPath());
        }

        public void onOpen(SQLiteDatabase sQLiteDatabase) {
            if (Build.VERSION.SDK_INT < 15) {
                Cursor rawQuery = sQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
                try {
                    rawQuery.moveToFirst();
                } finally {
                    rawQuery.close();
                }
            }
            if (!tablePresent(PersistentAnalyticsStore.HITS_TABLE, sQLiteDatabase)) {
                sQLiteDatabase.execSQL(PersistentAnalyticsStore.CREATE_HITS_TABLE);
            } else {
                validateColumnsPresent(sQLiteDatabase);
            }
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        }

        /* access modifiers changed from: package-private */
        public void setBadDatabase(boolean z) {
            this.mBadDatabase = z;
        }
    }

    PersistentAnalyticsStore(AnalyticsStoreStateListener analyticsStoreStateListener, Context context) {
        this(analyticsStoreStateListener, context, DATABASE_FILENAME);
    }

    @VisibleForTesting
    PersistentAnalyticsStore(AnalyticsStoreStateListener analyticsStoreStateListener, Context context, String str) {
        this.mContext = context.getApplicationContext();
        this.mDatabaseName = str;
        this.mListener = analyticsStoreStateListener;
        this.mClock = new Clock() {
            /* class com.google.analytics.tracking.android.PersistentAnalyticsStore.AnonymousClass1 */

            @Override // com.google.analytics.tracking.android.Clock
            public long currentTimeMillis() {
                return System.currentTimeMillis();
            }
        };
        this.mDbHelper = new AnalyticsDatabaseHelper(this.mContext, this.mDatabaseName);
        this.mDispatcher = new SimpleNetworkDispatcher(new DefaultHttpClient(), this.mContext);
        this.mLastDeleteStaleHitsTime = 0;
    }

    private void fillVersionParameter(Map<String, String> map, Collection<Command> collection) {
        String substring = "&_v".substring(1);
        if (collection != null) {
            for (Command command : collection) {
                if (Command.APPEND_VERSION.equals(command.getId())) {
                    map.put(substring, command.getValue());
                    return;
                }
            }
        }
    }

    static String generateHitString(Map<String, String> map) {
        ArrayList arrayList = new ArrayList(map.size());
        for (Map.Entry<String, String> entry : map.entrySet()) {
            arrayList.add(HitBuilder.encode(entry.getKey()) + "=" + HitBuilder.encode(entry.getValue()));
        }
        return TextUtils.join(Utility.QUERY_APPENDIX, arrayList);
    }

    private SQLiteDatabase getWritableDatabase(String str) {
        try {
            return this.mDbHelper.getWritableDatabase();
        } catch (SQLiteException e) {
            Log.w(str);
            return null;
        }
    }

    private void removeOldHitIfFull() {
        int numStoredHits = (getNumStoredHits() - 2000) + 1;
        if (numStoredHits > 0) {
            List<String> peekHitIds = peekHitIds(numStoredHits);
            Log.v("Store full, deleting " + peekHitIds.size() + " hits to make room.");
            deleteHits((String[]) peekHitIds.toArray(new String[0]));
        }
    }

    private void writeHitToDatabase(Map<String, String> map, long j, String str) {
        long j2;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for putHit");
        if (writableDatabase != null) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(HIT_STRING, generateHitString(map));
            contentValues.put(HIT_TIME, Long.valueOf(j));
            if (map.containsKey(Fields.ANDROID_APP_UID)) {
                try {
                    j2 = Long.parseLong(map.get(Fields.ANDROID_APP_UID));
                } catch (NumberFormatException e) {
                    j2 = 0;
                }
            } else {
                j2 = 0;
            }
            contentValues.put(HIT_APP_ID, Long.valueOf(j2));
            if (str == null) {
                str = "http://www.google-analytics.com/collect";
            }
            if (str.length() == 0) {
                Log.w("Empty path: not sending hit");
                return;
            }
            contentValues.put(HIT_URL, str);
            try {
                writableDatabase.insert(HITS_TABLE, null, contentValues);
                this.mListener.reportStoreIsEmpty(false);
            } catch (SQLiteException e2) {
                Log.w("Error storing hit");
            }
        }
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public void clearHits(long j) {
        boolean z = false;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for clearHits");
        if (writableDatabase != null) {
            if (j == 0) {
                writableDatabase.delete(HITS_TABLE, null, null);
            } else {
                writableDatabase.delete(HITS_TABLE, "hit_app_id = ?", new String[]{Long.valueOf(j).toString()});
            }
            AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
            if (getNumStoredHits() == 0) {
                z = true;
            }
            analyticsStoreStateListener.reportStoreIsEmpty(z);
        }
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public void close() {
        try {
            this.mDbHelper.getWritableDatabase().close();
            this.mDispatcher.close();
        } catch (SQLiteException e) {
            Log.w("Error opening database for close");
        }
    }

    /* access modifiers changed from: package-private */
    @Deprecated
    public void deleteHits(Collection<Hit> collection) {
        if (collection == null || collection.isEmpty()) {
            Log.w("Empty/Null collection passed to deleteHits.");
            return;
        }
        String[] strArr = new String[collection.size()];
        int i = 0;
        Iterator<Hit> it = collection.iterator();
        while (true) {
            int i2 = i;
            if (it.hasNext()) {
                strArr[i2] = String.valueOf(it.next().getHitId());
                i = i2 + 1;
            } else {
                deleteHits(strArr);
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void deleteHits(String[] strArr) {
        boolean z = false;
        if (strArr == null || strArr.length == 0) {
            Log.w("Empty hitIds passed to deleteHits.");
            return;
        }
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for deleteHits.");
        if (writableDatabase != null) {
            try {
                writableDatabase.delete(HITS_TABLE, String.format("HIT_ID in (%s)", TextUtils.join(",", Collections.nCopies(strArr.length, Utility.QUERY_START))), strArr);
                AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
                if (getNumStoredHits() == 0) {
                    z = true;
                }
                analyticsStoreStateListener.reportStoreIsEmpty(z);
            } catch (SQLiteException e) {
                Log.w("Error deleting hits " + strArr);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int deleteStaleHits() {
        boolean z = false;
        long currentTimeMillis = this.mClock.currentTimeMillis();
        if (currentTimeMillis <= this.mLastDeleteStaleHitsTime + 86400000) {
            return 0;
        }
        this.mLastDeleteStaleHitsTime = currentTimeMillis;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for deleteStaleHits.");
        if (writableDatabase == null) {
            return 0;
        }
        int delete = writableDatabase.delete(HITS_TABLE, "HIT_TIME < ?", new String[]{Long.toString(this.mClock.currentTimeMillis() - 2592000000L)});
        AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
        if (getNumStoredHits() == 0) {
            z = true;
        }
        analyticsStoreStateListener.reportStoreIsEmpty(z);
        return delete;
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public void dispatch() {
        Log.v("Dispatch running...");
        if (this.mDispatcher.okToDispatch()) {
            List<Hit> peekHits = peekHits(40);
            if (peekHits.isEmpty()) {
                Log.v("...nothing to dispatch");
                this.mListener.reportStoreIsEmpty(true);
                return;
            }
            int dispatchHits = this.mDispatcher.dispatchHits(peekHits);
            Log.v("sent " + dispatchHits + " of " + peekHits.size() + " hits");
            deleteHits(peekHits.subList(0, Math.min(dispatchHits, peekHits.size())));
            if (dispatchHits == peekHits.size() && getNumStoredHits() > 0) {
                GAServiceManager.getInstance().dispatchLocalHits();
            }
        }
    }

    @VisibleForTesting
    public AnalyticsDatabaseHelper getDbHelper() {
        return this.mDbHelper;
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public Dispatcher getDispatcher() {
        return this.mDispatcher;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public AnalyticsDatabaseHelper getHelper() {
        return this.mDbHelper;
    }

    /* access modifiers changed from: package-private */
    public int getNumStoredHits() {
        Cursor cursor = null;
        int i = 0;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for getNumStoredHits.");
        if (writableDatabase != null) {
            try {
                Cursor rawQuery = writableDatabase.rawQuery("SELECT COUNT(*) from hits2", null);
                if (rawQuery.moveToFirst()) {
                    i = (int) rawQuery.getLong(0);
                }
                if (rawQuery != null) {
                    rawQuery.close();
                }
            } catch (SQLiteException e) {
                Log.w("Error getting numStoredHits");
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (cursor != null) {
                    cursor.close();
                }
                throw th;
            }
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0081  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<java.lang.String> peekHitIds(int r12) {
        /*
            r11 = this;
            r10 = 0
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            if (r12 > 0) goto L_0x000f
            java.lang.String r0 = "Invalid maxHits specified. Skipping"
            com.google.analytics.tracking.android.Log.w(r0)
        L_0x000d:
            r0 = r9
        L_0x000e:
            return r0
        L_0x000f:
            java.lang.String r0 = "Error opening database for peekHitIds."
            android.database.sqlite.SQLiteDatabase r0 = r11.getWritableDatabase(r0)
            if (r0 == 0) goto L_0x000d
            java.lang.String r1 = "%s ASC"
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            java.lang.String r4 = "hit_id"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r7 = java.lang.String.format(r1, r2)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r8 = java.lang.Integer.toString(r12)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r1 = "hits2"
            r2 = 1
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            java.lang.String r4 = "hit_id"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            boolean r0 = r1.moveToFirst()     // Catch:{ SQLiteException -> 0x0087 }
            if (r0 == 0) goto L_0x0053
        L_0x0041:
            r0 = 0
            long r2 = r1.getLong(r0)     // Catch:{ SQLiteException -> 0x0087 }
            java.lang.String r0 = java.lang.String.valueOf(r2)     // Catch:{ SQLiteException -> 0x0087 }
            r9.add(r0)     // Catch:{ SQLiteException -> 0x0087 }
            boolean r0 = r1.moveToNext()     // Catch:{ SQLiteException -> 0x0087 }
            if (r0 != 0) goto L_0x0041
        L_0x0053:
            if (r1 == 0) goto L_0x000d
            r1.close()
            r0 = r9
            goto L_0x000e
        L_0x005a:
            r0 = move-exception
            r1 = r10
        L_0x005c:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0085 }
            r2.<init>()     // Catch:{ all -> 0x0085 }
            java.lang.String r3 = "Error in peekHits fetching hitIds: "
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x0085 }
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x0085 }
            java.lang.StringBuilder r0 = r2.append(r0)     // Catch:{ all -> 0x0085 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0085 }
            com.google.analytics.tracking.android.Log.w(r0)     // Catch:{ all -> 0x0085 }
            if (r1 == 0) goto L_0x000d
            r1.close()
            r0 = r9
            goto L_0x000e
        L_0x007d:
            r0 = move-exception
            r1 = r10
        L_0x007f:
            if (r1 == 0) goto L_0x0084
            r1.close()
        L_0x0084:
            throw r0
        L_0x0085:
            r0 = move-exception
            goto L_0x007f
        L_0x0087:
            r0 = move-exception
            goto L_0x005c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.tracking.android.PersistentAnalyticsStore.peekHitIds(int):java.util.List");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0179, code lost:
        r2 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x017f, code lost:
        r3 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0180, code lost:
        r4 = r14;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00fc  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0179 A[ExcHandler: all (th java.lang.Throwable), Splitter:B:3:0x0016] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<com.google.analytics.tracking.android.Hit> peekHits(int r17) {
        /*
            r16 = this;
            r15 = 1
            r11 = 0
            r14 = 0
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            java.lang.String r2 = "Error opening database for peekHits"
            r0 = r16
            android.database.sqlite.SQLiteDatabase r2 = r0.getWritableDatabase(r2)
            if (r2 != 0) goto L_0x0013
        L_0x0012:
            return r13
        L_0x0013:
            java.lang.String r3 = "%s ASC"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            java.lang.String r9 = java.lang.String.format(r3, r4)     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            java.lang.String r10 = java.lang.Integer.toString(r17)     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            java.lang.String r3 = "hits2"
            r4 = 2
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            r5 = 1
            java.lang.String r6 = "hit_time"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r14 = r2.query(r3, r4, r5, r6, r7, r8, r9, r10)     // Catch:{ SQLiteException -> 0x00d4, all -> 0x0179 }
            java.util.ArrayList r12 = new java.util.ArrayList     // Catch:{ SQLiteException -> 0x017f, all -> 0x0179 }
            r12.<init>()     // Catch:{ SQLiteException -> 0x017f, all -> 0x0179 }
            boolean r3 = r14.moveToFirst()     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            if (r3 == 0) goto L_0x0060
        L_0x0047:
            com.google.analytics.tracking.android.Hit r4 = new com.google.analytics.tracking.android.Hit     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            r5 = 0
            r3 = 0
            long r6 = r14.getLong(r3)     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            r3 = 1
            long r8 = r14.getLong(r3)     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            r4.<init>(r5, r6, r8)     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            r12.add(r4)     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            boolean r3 = r14.moveToNext()     // Catch:{ SQLiteException -> 0x016f, all -> 0x00f9 }
            if (r3 != 0) goto L_0x0047
        L_0x0060:
            if (r14 == 0) goto L_0x0065
            r14.close()
        L_0x0065:
            java.lang.String r3 = "%s ASC"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ SQLiteException -> 0x0177 }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x0177 }
            java.lang.String r9 = java.lang.String.format(r3, r4)     // Catch:{ SQLiteException -> 0x0177 }
            java.lang.String r10 = java.lang.Integer.toString(r17)     // Catch:{ SQLiteException -> 0x0177 }
            java.lang.String r3 = "hits2"
            r4 = 3
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x0177 }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x0177 }
            r5 = 1
            java.lang.String r6 = "hit_string"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x0177 }
            r5 = 2
            java.lang.String r6 = "hit_url"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x0177 }
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r3 = r2.query(r3, r4, r5, r6, r7, r8, r9, r10)     // Catch:{ SQLiteException -> 0x0177 }
            boolean r2 = r3.moveToFirst()     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            if (r2 == 0) goto L_0x00cc
            r4 = r11
        L_0x009a:
            r0 = r3
            android.database.sqlite.SQLiteCursor r0 = (android.database.sqlite.SQLiteCursor) r0     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r2 = r0
            android.database.CursorWindow r2 = r2.getWindow()     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            int r2 = r2.getNumRows()     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            if (r2 <= 0) goto L_0x0100
            java.lang.Object r2 = r12.get(r4)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            com.google.analytics.tracking.android.Hit r2 = (com.google.analytics.tracking.android.Hit) r2     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r5 = 1
            java.lang.String r5 = r3.getString(r5)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r2.setHitString(r5)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            java.lang.Object r2 = r12.get(r4)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            com.google.analytics.tracking.android.Hit r2 = (com.google.analytics.tracking.android.Hit) r2     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r5 = 2
            java.lang.String r5 = r3.getString(r5)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r2.setHitUrl(r5)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
        L_0x00c4:
            int r2 = r4 + 1
            boolean r4 = r3.moveToNext()     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            if (r4 != 0) goto L_0x0183
        L_0x00cc:
            if (r3 == 0) goto L_0x00d1
            r3.close()
        L_0x00d1:
            r13 = r12
            goto L_0x0012
        L_0x00d4:
            r3 = move-exception
            r4 = r14
        L_0x00d6:
            r2 = r13
        L_0x00d7:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x017b }
            r5.<init>()     // Catch:{ all -> 0x017b }
            java.lang.String r6 = "Error in peekHits fetching hitIds: "
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ all -> 0x017b }
            java.lang.String r3 = r3.getMessage()     // Catch:{ all -> 0x017b }
            java.lang.StringBuilder r3 = r5.append(r3)     // Catch:{ all -> 0x017b }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x017b }
            com.google.analytics.tracking.android.Log.w(r3)     // Catch:{ all -> 0x017b }
            if (r4 == 0) goto L_0x00f6
            r4.close()
        L_0x00f6:
            r13 = r2
            goto L_0x0012
        L_0x00f9:
            r2 = move-exception
        L_0x00fa:
            if (r14 == 0) goto L_0x00ff
            r14.close()
        L_0x00ff:
            throw r2
        L_0x0100:
            java.lang.String r5 = "HitString for hitId %d too large.  Hit will be deleted."
            r2 = 1
            java.lang.Object[] r6 = new java.lang.Object[r2]     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r7 = 0
            java.lang.Object r2 = r12.get(r4)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            com.google.analytics.tracking.android.Hit r2 = (com.google.analytics.tracking.android.Hit) r2     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            long r8 = r2.getHitId()     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            java.lang.Long r2 = java.lang.Long.valueOf(r8)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            r6[r7] = r2     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            java.lang.String r2 = java.lang.String.format(r5, r6)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            com.google.analytics.tracking.android.Log.w(r2)     // Catch:{ SQLiteException -> 0x011e, all -> 0x0174 }
            goto L_0x00c4
        L_0x011e:
            r2 = move-exception
            r14 = r3
        L_0x0120:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0168 }
            r3.<init>()     // Catch:{ all -> 0x0168 }
            java.lang.String r4 = "Error in peekHits fetching hitString: "
            java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0168 }
            java.lang.String r2 = r2.getMessage()     // Catch:{ all -> 0x0168 }
            java.lang.StringBuilder r2 = r3.append(r2)     // Catch:{ all -> 0x0168 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0168 }
            com.google.analytics.tracking.android.Log.w(r2)     // Catch:{ all -> 0x0168 }
            java.util.ArrayList r13 = new java.util.ArrayList     // Catch:{ all -> 0x0168 }
            r13.<init>()     // Catch:{ all -> 0x0168 }
            java.util.Iterator r4 = r12.iterator()     // Catch:{ all -> 0x0168 }
            r3 = r11
        L_0x0144:
            boolean r2 = r4.hasNext()     // Catch:{ all -> 0x0168 }
            if (r2 == 0) goto L_0x015c
            java.lang.Object r2 = r4.next()     // Catch:{ all -> 0x0168 }
            com.google.analytics.tracking.android.Hit r2 = (com.google.analytics.tracking.android.Hit) r2     // Catch:{ all -> 0x0168 }
            java.lang.String r5 = r2.getHitParams()     // Catch:{ all -> 0x0168 }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x0168 }
            if (r5 == 0) goto L_0x0164
            if (r3 == 0) goto L_0x0163
        L_0x015c:
            if (r14 == 0) goto L_0x0012
            r14.close()
            goto L_0x0012
        L_0x0163:
            r3 = r15
        L_0x0164:
            r13.add(r2)     // Catch:{ all -> 0x0168 }
            goto L_0x0144
        L_0x0168:
            r2 = move-exception
        L_0x0169:
            if (r14 == 0) goto L_0x016e
            r14.close()
        L_0x016e:
            throw r2
        L_0x016f:
            r3 = move-exception
            r2 = r12
            r4 = r14
            goto L_0x00d7
        L_0x0174:
            r2 = move-exception
            r14 = r3
            goto L_0x0169
        L_0x0177:
            r2 = move-exception
            goto L_0x0120
        L_0x0179:
            r2 = move-exception
            goto L_0x00fa
        L_0x017b:
            r2 = move-exception
            r14 = r4
            goto L_0x00fa
        L_0x017f:
            r3 = move-exception
            r4 = r14
            goto L_0x00d6
        L_0x0183:
            r4 = r2
            goto L_0x009a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.tracking.android.PersistentAnalyticsStore.peekHits(int):java.util.List");
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public void putHit(Map<String, String> map, long j, String str, Collection<Command> collection) {
        deleteStaleHits();
        removeOldHitIfFull();
        fillVersionParameter(map, collection);
        writeHitToDatabase(map, j, str);
    }

    @VisibleForTesting
    public void setClock(Clock clock) {
        this.mClock = clock;
    }

    @Override // com.google.analytics.tracking.android.AnalyticsStore
    public void setDispatch(boolean z) {
        this.mDispatcher = z ? new SimpleNetworkDispatcher(new DefaultHttpClient(), this.mContext) : new NoopDispatcher();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setDispatcher(Dispatcher dispatcher) {
        this.mDispatcher = dispatcher;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setLastDeleteStaleHitsTime(long j) {
        this.mLastDeleteStaleHitsTime = j;
    }
}

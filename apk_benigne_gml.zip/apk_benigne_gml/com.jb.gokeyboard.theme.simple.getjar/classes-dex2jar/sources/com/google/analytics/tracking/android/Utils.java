package com.google.analytics.tracking.android;

import android.text.TextUtils;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Utility;
import com.getjar.vending.GetJarUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

class Utils {
    private static final char[] HEXBYTES = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    Utils() {
    }

    public static String filterCampaign(String str) {
        int i = 0;
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.contains(Utility.QUERY_START)) {
            String[] split = str.split("[\\?]");
            if (split.length > 1) {
                str = split[1];
            }
        }
        if (str.contains("%3D")) {
            try {
                str = URLDecoder.decode(str, Constants.ENCODING_CHARSET);
            } catch (UnsupportedEncodingException e) {
                return null;
            }
        } else if (!str.contains("=")) {
            return null;
        }
        Map<String, String> parseURLParameters = parseURLParameters(str);
        String[] strArr = {"dclid", "utm_source", "gclid", "utm_campaign", "utm_medium", "utm_term", "utm_content", "utm_id", "gmob_t"};
        StringBuilder sb = new StringBuilder();
        while (true) {
            int i2 = i;
            if (i2 >= strArr.length) {
                return sb.toString();
            }
            if (!TextUtils.isEmpty(parseURLParameters.get(strArr[i2]))) {
                if (sb.length() > 0) {
                    sb.append(Utility.QUERY_APPENDIX);
                }
                sb.append(strArr[i2]).append("=").append(parseURLParameters.get(strArr[i2]));
            }
            i = i2 + 1;
        }
    }

    static int fromHexDigit(char c) {
        int i = c - '0';
        return i > 9 ? i - 7 : i;
    }

    static String getLanguage(Locale locale) {
        if (locale == null || TextUtils.isEmpty(locale.getLanguage())) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(locale.getLanguage().toLowerCase());
        if (!TextUtils.isEmpty(locale.getCountry())) {
            sb.append("-").append(locale.getCountry().toLowerCase());
        }
        return sb.toString();
    }

    static byte[] hexDecode(String str) {
        byte[] bArr = new byte[(str.length() / 2)];
        for (int i = 0; i < bArr.length; i++) {
            bArr[i] = (byte) ((fromHexDigit(str.charAt(i * 2)) << 4) | fromHexDigit(str.charAt((i * 2) + 1)));
        }
        return bArr;
    }

    static String hexEncode(byte[] bArr) {
        char[] cArr = new char[(bArr.length * 2)];
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i] & 255;
            cArr[i * 2] = HEXBYTES[b >> 4];
            cArr[(i * 2) + 1] = HEXBYTES[b & 15];
        }
        return new String(cArr);
    }

    public static Map<String, String> parseURLParameters(String str) {
        HashMap hashMap = new HashMap();
        for (String str2 : str.split(Utility.QUERY_APPENDIX)) {
            String[] split = str2.split("=");
            if (split.length > 1) {
                hashMap.put(split[0], split[1]);
            } else if (split.length == 1 && split[0].length() != 0) {
                hashMap.put(split[0], null);
            }
        }
        return hashMap;
    }

    public static void putIfAbsent(Map<String, String> map, String str, String str2) {
        if (!map.containsKey(str)) {
            map.put(str, str2);
        }
    }

    public static boolean safeParseBoolean(String str, boolean z) {
        if (str == null) {
            return z;
        }
        if (str.equalsIgnoreCase("true") || str.equalsIgnoreCase("yes") || str.equalsIgnoreCase(GetJarUtils.PVERSION)) {
            return true;
        }
        if (str.equalsIgnoreCase("false") || str.equalsIgnoreCase("no") || str.equalsIgnoreCase("0")) {
            return false;
        }
        return z;
    }

    public static double safeParseDouble(String str) {
        return safeParseDouble(str, 0.0d);
    }

    public static double safeParseDouble(String str, double d) {
        if (str == null) {
            return d;
        }
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return d;
        }
    }

    public static long safeParseLong(String str) {
        if (str == null) {
            return 0;
        }
        try {
            return Long.parseLong(str);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}

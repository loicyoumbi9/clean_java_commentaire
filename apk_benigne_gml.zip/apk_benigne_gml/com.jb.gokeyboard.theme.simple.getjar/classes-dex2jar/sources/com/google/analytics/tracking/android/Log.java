package com.google.analytics.tracking.android;

import com.google.analytics.tracking.android.Logger;
import com.google.android.gms.common.util.VisibleForTesting;

public class Log {
    private static GoogleAnalytics sGaInstance;

    private Log() {
    }

    @VisibleForTesting
    static void clearGaInstance() {
        sGaInstance = null;
    }

    public static void e(Exception exc) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.error(exc);
        }
    }

    public static void e(String str) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.error(str);
        }
    }

    private static Logger getLogger() {
        if (sGaInstance == null) {
            sGaInstance = GoogleAnalytics.getInstance();
        }
        if (sGaInstance != null) {
            return sGaInstance.getLogger();
        }
        return null;
    }

    public static void i(String str) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.info(str);
        }
    }

    public static boolean isVerbose() {
        if (getLogger() != null) {
            return Logger.LogLevel.VERBOSE.equals(getLogger().getLogLevel());
        }
        return false;
    }

    public static void v(String str) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.verbose(str);
        }
    }

    public static void w(String str) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.warn(str);
        }
    }
}

package com.google.analytics.containertag.proto;

import com.google.ads.AdSize;
import com.google.analytics.midtier.proto.containertag.MutableTypeSystem;
import com.google.tagmanager.protobuf.AbstractMutableMessageLite;
import com.google.tagmanager.protobuf.ByteString;
import com.google.tagmanager.protobuf.CodedInputStream;
import com.google.tagmanager.protobuf.CodedOutputStream;
import com.google.tagmanager.protobuf.ExtensionRegistryLite;
import com.google.tagmanager.protobuf.GeneratedMessageLite;
import com.google.tagmanager.protobuf.GeneratedMutableMessageLite;
import com.google.tagmanager.protobuf.Internal;
import com.google.tagmanager.protobuf.MessageLite;
import com.google.tagmanager.protobuf.MutableMessageLite;
import com.google.tagmanager.protobuf.Parser;
import com.google.tagmanager.protobuf.WireFormat;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class MutableDebug {

    public static final class DataLayerEventEvaluationInfo extends GeneratedMutableMessageLite<DataLayerEventEvaluationInfo> implements MutableMessageLite {
        public static Parser<DataLayerEventEvaluationInfo> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int RESULTS_FIELD_NUMBER = 2;
        public static final int RULES_EVALUATION_FIELD_NUMBER = 1;
        private static final DataLayerEventEvaluationInfo defaultInstance = new DataLayerEventEvaluationInfo(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private List<ResolvedFunctionCall> results_ = null;
        private RuleEvaluationStepInfo rulesEvaluation_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private DataLayerEventEvaluationInfo() {
            initFields();
        }

        private DataLayerEventEvaluationInfo(boolean z) {
        }

        private void ensureResultsInitialized() {
            if (this.results_ == null) {
                this.results_ = new ArrayList();
            }
        }

        private void ensureRulesEvaluationInitialized() {
            if (this.rulesEvaluation_ == RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_ = RuleEvaluationStepInfo.newMessage();
            }
        }

        public static DataLayerEventEvaluationInfo getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.rulesEvaluation_ = RuleEvaluationStepInfo.getDefaultInstance();
        }

        public static DataLayerEventEvaluationInfo newMessage() {
            return new DataLayerEventEvaluationInfo();
        }

        public DataLayerEventEvaluationInfo addAllResults(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureResultsInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.results_);
            return this;
        }

        public DataLayerEventEvaluationInfo addResults(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureResultsInitialized();
            this.results_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedFunctionCall addResults() {
            assertMutable();
            ensureResultsInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.results_.add(newMessage);
            return newMessage;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public DataLayerEventEvaluationInfo clear() {
            assertMutable();
            super.clear();
            if (this.rulesEvaluation_ != RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_.clear();
            }
            this.bitField0_ &= -2;
            this.results_ = null;
            return this;
        }

        public DataLayerEventEvaluationInfo clearResults() {
            assertMutable();
            this.results_ = null;
            return this;
        }

        public DataLayerEventEvaluationInfo clearRulesEvaluation() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.rulesEvaluation_ != RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public DataLayerEventEvaluationInfo clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof DataLayerEventEvaluationInfo)) {
                return super.equals(obj);
            }
            DataLayerEventEvaluationInfo dataLayerEventEvaluationInfo = (DataLayerEventEvaluationInfo) obj;
            boolean z = hasRulesEvaluation() == dataLayerEventEvaluationInfo.hasRulesEvaluation();
            if (hasRulesEvaluation()) {
                z = z && getRulesEvaluation().equals(dataLayerEventEvaluationInfo.getRulesEvaluation());
            }
            return z && getResultsList().equals(dataLayerEventEvaluationInfo.getResultsList());
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final DataLayerEventEvaluationInfo getDefaultInstanceForType() {
            return defaultInstance;
        }

        public ResolvedFunctionCall getMutableResults(int i) {
            return this.results_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableResultsList() {
            assertMutable();
            ensureResultsInitialized();
            return this.results_;
        }

        public RuleEvaluationStepInfo getMutableRulesEvaluation() {
            assertMutable();
            ensureRulesEvaluationInitialized();
            this.bitField0_ |= 1;
            return this.rulesEvaluation_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<DataLayerEventEvaluationInfo> getParserForType() {
            return PARSER;
        }

        public ResolvedFunctionCall getResults(int i) {
            return this.results_.get(i);
        }

        public int getResultsCount() {
            if (this.results_ == null) {
                return 0;
            }
            return this.results_.size();
        }

        public List<ResolvedFunctionCall> getResultsList() {
            return this.results_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.results_);
        }

        public RuleEvaluationStepInfo getRulesEvaluation() {
            return this.rulesEvaluation_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            int i2 = 0;
            int computeMessageSize = (this.bitField0_ & 1) == 1 ? CodedOutputStream.computeMessageSize(1, this.rulesEvaluation_) + 0 : 0;
            if (this.results_ != null) {
                while (true) {
                    i = computeMessageSize;
                    if (i2 >= this.results_.size()) {
                        break;
                    }
                    computeMessageSize = CodedOutputStream.computeMessageSize(2, this.results_.get(i2)) + i;
                    i2++;
                }
            } else {
                i = computeMessageSize;
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public boolean hasRulesEvaluation() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (hasRulesEvaluation()) {
                i = 80454 + getRulesEvaluation().hashCode();
            }
            if (getResultsCount() > 0) {
                i = (((i * 37) + 2) * 53) + getResultsList().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$DataLayerEventEvaluationInfo");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            if (hasRulesEvaluation() && !getRulesEvaluation().isInitialized()) {
                return false;
            }
            for (int i = 0; i < getResultsCount(); i++) {
                if (!getResults(i).isInitialized()) {
                    return false;
                }
            }
            return true;
        }

        public DataLayerEventEvaluationInfo mergeFrom(DataLayerEventEvaluationInfo dataLayerEventEvaluationInfo) {
            if (this == dataLayerEventEvaluationInfo) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (dataLayerEventEvaluationInfo != getDefaultInstance()) {
                if (dataLayerEventEvaluationInfo.hasRulesEvaluation()) {
                    ensureRulesEvaluationInitialized();
                    this.rulesEvaluation_.mergeFrom(dataLayerEventEvaluationInfo.getRulesEvaluation());
                    this.bitField0_ |= 1;
                }
                if (dataLayerEventEvaluationInfo.results_ != null && !dataLayerEventEvaluationInfo.results_.isEmpty()) {
                    ensureResultsInitialized();
                    AbstractMutableMessageLite.addAll(dataLayerEventEvaluationInfo.results_, this.results_);
                }
                this.unknownFields = this.unknownFields.concat(dataLayerEventEvaluationInfo.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            if (this.rulesEvaluation_ == RuleEvaluationStepInfo.getDefaultInstance()) {
                                this.rulesEvaluation_ = RuleEvaluationStepInfo.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.rulesEvaluation_, extensionRegistryLite);
                            break;
                        case 18:
                            codedInputStream.readMessage(addResults(), extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public DataLayerEventEvaluationInfo newMessageForType() {
            return new DataLayerEventEvaluationInfo();
        }

        public DataLayerEventEvaluationInfo setResults(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureResultsInitialized();
            this.results_.set(i, resolvedFunctionCall);
            return this;
        }

        public DataLayerEventEvaluationInfo setRulesEvaluation(RuleEvaluationStepInfo ruleEvaluationStepInfo) {
            assertMutable();
            if (ruleEvaluationStepInfo == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.rulesEvaluation_ = ruleEvaluationStepInfo;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessageWithCachedSizes(1, this.rulesEvaluation_);
            }
            if (this.results_ != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= this.results_.size()) {
                        break;
                    }
                    codedOutputStream.writeMessageWithCachedSizes(2, this.results_.get(i2));
                    i = i2 + 1;
                }
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class DebugEvents extends GeneratedMutableMessageLite<DebugEvents> implements MutableMessageLite {
        public static final int EVENT_FIELD_NUMBER = 1;
        public static Parser<DebugEvents> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        private static final DebugEvents defaultInstance = new DebugEvents(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private List<EventInfo> event_ = null;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private DebugEvents() {
            initFields();
        }

        private DebugEvents(boolean z) {
        }

        private void ensureEventInitialized() {
            if (this.event_ == null) {
                this.event_ = new ArrayList();
            }
        }

        public static DebugEvents getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static DebugEvents newMessage() {
            return new DebugEvents();
        }

        public DebugEvents addAllEvent(Iterable<? extends EventInfo> iterable) {
            assertMutable();
            ensureEventInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.event_);
            return this;
        }

        public DebugEvents addEvent(EventInfo eventInfo) {
            assertMutable();
            if (eventInfo == null) {
                throw new NullPointerException();
            }
            ensureEventInitialized();
            this.event_.add(eventInfo);
            return this;
        }

        public EventInfo addEvent() {
            assertMutable();
            ensureEventInitialized();
            EventInfo newMessage = EventInfo.newMessage();
            this.event_.add(newMessage);
            return newMessage;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public DebugEvents clear() {
            assertMutable();
            super.clear();
            this.event_ = null;
            return this;
        }

        public DebugEvents clearEvent() {
            assertMutable();
            this.event_ = null;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public DebugEvents clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            return !(obj instanceof DebugEvents) ? super.equals(obj) : getEventList().equals(((DebugEvents) obj).getEventList());
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final DebugEvents getDefaultInstanceForType() {
            return defaultInstance;
        }

        public EventInfo getEvent(int i) {
            return this.event_.get(i);
        }

        public int getEventCount() {
            if (this.event_ == null) {
                return 0;
            }
            return this.event_.size();
        }

        public List<EventInfo> getEventList() {
            return this.event_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.event_);
        }

        public EventInfo getMutableEvent(int i) {
            return this.event_.get(i);
        }

        public List<EventInfo> getMutableEventList() {
            assertMutable();
            ensureEventInitialized();
            return this.event_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<DebugEvents> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.event_ != null) {
                i = 0;
                for (int i2 = 0; i2 < this.event_.size(); i2++) {
                    i += CodedOutputStream.computeMessageSize(1, this.event_.get(i2));
                }
            } else {
                i = 0;
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public int hashCode() {
            int i = 41;
            if (getEventCount() > 0) {
                i = 80454 + getEventList().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$DebugEvents");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            for (int i = 0; i < getEventCount(); i++) {
                if (!getEvent(i).isInitialized()) {
                    return false;
                }
            }
            return true;
        }

        public DebugEvents mergeFrom(DebugEvents debugEvents) {
            if (this == debugEvents) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (debugEvents != getDefaultInstance()) {
                if (debugEvents.event_ != null && !debugEvents.event_.isEmpty()) {
                    ensureEventInitialized();
                    AbstractMutableMessageLite.addAll(debugEvents.event_, this.event_);
                }
                this.unknownFields = this.unknownFields.concat(debugEvents.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            codedInputStream.readMessage(addEvent(), extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public DebugEvents newMessageForType() {
            return new DebugEvents();
        }

        public DebugEvents setEvent(int i, EventInfo eventInfo) {
            assertMutable();
            if (eventInfo == null) {
                throw new NullPointerException();
            }
            ensureEventInitialized();
            this.event_.set(i, eventInfo);
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.event_ != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= this.event_.size()) {
                        break;
                    }
                    codedOutputStream.writeMessageWithCachedSizes(1, this.event_.get(i2));
                    i = i2 + 1;
                }
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class EventInfo extends GeneratedMutableMessageLite<EventInfo> implements MutableMessageLite {
        public static final int CONTAINER_ID_FIELD_NUMBER = 3;
        public static final int CONTAINER_VERSION_FIELD_NUMBER = 2;
        public static final int DATA_LAYER_EVENT_RESULT_FIELD_NUMBER = 7;
        public static final int EVENT_TYPE_FIELD_NUMBER = 1;
        public static final int KEY_FIELD_NUMBER = 4;
        public static final int MACRO_RESULT_FIELD_NUMBER = 6;
        public static Parser<EventInfo> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        private static final EventInfo defaultInstance = new EventInfo(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private Object containerId_ = Internal.EMPTY_BYTE_ARRAY;
        private Object containerVersion_ = Internal.EMPTY_BYTE_ARRAY;
        private DataLayerEventEvaluationInfo dataLayerEventResult_;
        private EventType eventType_ = EventType.DATA_LAYER_EVENT;
        private Object key_ = Internal.EMPTY_BYTE_ARRAY;
        private MacroEvaluationInfo macroResult_;

        public enum EventType implements Internal.EnumLite {
            DATA_LAYER_EVENT(0, 1),
            MACRO_REFERENCE(1, 2);
            
            public static final int DATA_LAYER_EVENT_VALUE = 1;
            public static final int MACRO_REFERENCE_VALUE = 2;
            private static Internal.EnumLiteMap<EventType> internalValueMap = new Internal.EnumLiteMap<EventType>() {
                /* class com.google.analytics.containertag.proto.MutableDebug.EventInfo.EventType.AnonymousClass1 */

                @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
                public EventType findValueByNumber(int i) {
                    return EventType.valueOf(i);
                }
            };
            private final int value;

            private EventType(int i, int i2) {
                this.value = i2;
            }

            public static Internal.EnumLiteMap<EventType> internalGetValueMap() {
                return internalValueMap;
            }

            public static EventType valueOf(int i) {
                switch (i) {
                    case 1:
                        return DATA_LAYER_EVENT;
                    case 2:
                        return MACRO_REFERENCE;
                    default:
                        return null;
                }
            }

            @Override // com.google.tagmanager.protobuf.Internal.EnumLite
            public final int getNumber() {
                return this.value;
            }
        }

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private EventInfo() {
            initFields();
        }

        private EventInfo(boolean z) {
        }

        private void ensureDataLayerEventResultInitialized() {
            if (this.dataLayerEventResult_ == DataLayerEventEvaluationInfo.getDefaultInstance()) {
                this.dataLayerEventResult_ = DataLayerEventEvaluationInfo.newMessage();
            }
        }

        private void ensureMacroResultInitialized() {
            if (this.macroResult_ == MacroEvaluationInfo.getDefaultInstance()) {
                this.macroResult_ = MacroEvaluationInfo.newMessage();
            }
        }

        public static EventInfo getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.eventType_ = EventType.DATA_LAYER_EVENT;
            this.macroResult_ = MacroEvaluationInfo.getDefaultInstance();
            this.dataLayerEventResult_ = DataLayerEventEvaluationInfo.getDefaultInstance();
        }

        public static EventInfo newMessage() {
            return new EventInfo();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public EventInfo clear() {
            assertMutable();
            super.clear();
            this.eventType_ = EventType.DATA_LAYER_EVENT;
            this.bitField0_ &= -2;
            this.containerVersion_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -3;
            this.containerId_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -5;
            this.key_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -9;
            if (this.macroResult_ != MacroEvaluationInfo.getDefaultInstance()) {
                this.macroResult_.clear();
            }
            this.bitField0_ &= -17;
            if (this.dataLayerEventResult_ != DataLayerEventEvaluationInfo.getDefaultInstance()) {
                this.dataLayerEventResult_.clear();
            }
            this.bitField0_ &= -33;
            return this;
        }

        public EventInfo clearContainerId() {
            assertMutable();
            this.bitField0_ &= -5;
            this.containerId_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public EventInfo clearContainerVersion() {
            assertMutable();
            this.bitField0_ &= -3;
            this.containerVersion_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public EventInfo clearDataLayerEventResult() {
            assertMutable();
            this.bitField0_ &= -33;
            if (this.dataLayerEventResult_ != DataLayerEventEvaluationInfo.getDefaultInstance()) {
                this.dataLayerEventResult_.clear();
            }
            return this;
        }

        public EventInfo clearEventType() {
            assertMutable();
            this.bitField0_ &= -2;
            this.eventType_ = EventType.DATA_LAYER_EVENT;
            return this;
        }

        public EventInfo clearKey() {
            assertMutable();
            this.bitField0_ &= -9;
            this.key_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public EventInfo clearMacroResult() {
            assertMutable();
            this.bitField0_ &= -17;
            if (this.macroResult_ != MacroEvaluationInfo.getDefaultInstance()) {
                this.macroResult_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public EventInfo clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof EventInfo)) {
                return super.equals(obj);
            }
            EventInfo eventInfo = (EventInfo) obj;
            boolean z = hasEventType() == eventInfo.hasEventType();
            if (hasEventType()) {
                z = z && getEventType() == eventInfo.getEventType();
            }
            boolean z2 = z && hasContainerVersion() == eventInfo.hasContainerVersion();
            if (hasContainerVersion()) {
                z2 = z2 && getContainerVersion().equals(eventInfo.getContainerVersion());
            }
            boolean z3 = z2 && hasContainerId() == eventInfo.hasContainerId();
            if (hasContainerId()) {
                z3 = z3 && getContainerId().equals(eventInfo.getContainerId());
            }
            boolean z4 = z3 && hasKey() == eventInfo.hasKey();
            if (hasKey()) {
                z4 = z4 && getKey().equals(eventInfo.getKey());
            }
            boolean z5 = z4 && hasMacroResult() == eventInfo.hasMacroResult();
            if (hasMacroResult()) {
                z5 = z5 && getMacroResult().equals(eventInfo.getMacroResult());
            }
            boolean z6 = z5 && hasDataLayerEventResult() == eventInfo.hasDataLayerEventResult();
            return hasDataLayerEventResult() ? z6 && getDataLayerEventResult().equals(eventInfo.getDataLayerEventResult()) : z6;
        }

        public String getContainerId() {
            Object obj = this.containerId_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.containerId_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getContainerIdAsBytes() {
            Object obj = this.containerId_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.containerId_ = byteArray;
            return byteArray;
        }

        public String getContainerVersion() {
            Object obj = this.containerVersion_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.containerVersion_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getContainerVersionAsBytes() {
            Object obj = this.containerVersion_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.containerVersion_ = byteArray;
            return byteArray;
        }

        public DataLayerEventEvaluationInfo getDataLayerEventResult() {
            return this.dataLayerEventResult_;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final EventInfo getDefaultInstanceForType() {
            return defaultInstance;
        }

        public EventType getEventType() {
            return this.eventType_;
        }

        public String getKey() {
            Object obj = this.key_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.key_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getKeyAsBytes() {
            Object obj = this.key_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.key_ = byteArray;
            return byteArray;
        }

        public MacroEvaluationInfo getMacroResult() {
            return this.macroResult_;
        }

        public DataLayerEventEvaluationInfo getMutableDataLayerEventResult() {
            assertMutable();
            ensureDataLayerEventResultInitialized();
            this.bitField0_ |= 32;
            return this.dataLayerEventResult_;
        }

        public MacroEvaluationInfo getMutableMacroResult() {
            assertMutable();
            ensureMacroResultInitialized();
            this.bitField0_ |= 16;
            return this.macroResult_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<EventInfo> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if ((this.bitField0_ & 1) == 1) {
                i = CodedOutputStream.computeEnumSize(1, this.eventType_.getNumber()) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeByteArraySize(2, getContainerVersionAsBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                i += CodedOutputStream.computeByteArraySize(3, getContainerIdAsBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                i += CodedOutputStream.computeByteArraySize(4, getKeyAsBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                i += CodedOutputStream.computeMessageSize(6, this.macroResult_);
            }
            if ((this.bitField0_ & 32) == 32) {
                i += CodedOutputStream.computeMessageSize(7, this.dataLayerEventResult_);
            }
            int size = i + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public boolean hasContainerId() {
            return (this.bitField0_ & 4) == 4;
        }

        public boolean hasContainerVersion() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasDataLayerEventResult() {
            return (this.bitField0_ & 32) == 32;
        }

        public boolean hasEventType() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasKey() {
            return (this.bitField0_ & 8) == 8;
        }

        public boolean hasMacroResult() {
            return (this.bitField0_ & 16) == 16;
        }

        public int hashCode() {
            int i = 41;
            if (hasEventType()) {
                i = 80454 + Internal.hashEnum(getEventType());
            }
            if (hasContainerVersion()) {
                i = (((i * 37) + 2) * 53) + getContainerVersion().hashCode();
            }
            if (hasContainerId()) {
                i = (((i * 37) + 3) * 53) + getContainerId().hashCode();
            }
            if (hasKey()) {
                i = (((i * 37) + 4) * 53) + getKey().hashCode();
            }
            if (hasMacroResult()) {
                i = (((i * 37) + 6) * 53) + getMacroResult().hashCode();
            }
            if (hasDataLayerEventResult()) {
                i = (((i * 37) + 7) * 53) + getDataLayerEventResult().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$EventInfo");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return (!hasMacroResult() || getMacroResult().isInitialized()) && (!hasDataLayerEventResult() || getDataLayerEventResult().isInitialized());
        }

        public EventInfo mergeFrom(EventInfo eventInfo) {
            if (this == eventInfo) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (eventInfo != getDefaultInstance()) {
                if (eventInfo.hasEventType()) {
                    setEventType(eventInfo.getEventType());
                }
                if (eventInfo.hasContainerVersion()) {
                    this.bitField0_ |= 2;
                    if (eventInfo.containerVersion_ instanceof String) {
                        this.containerVersion_ = eventInfo.containerVersion_;
                    } else {
                        byte[] bArr = (byte[]) eventInfo.containerVersion_;
                        this.containerVersion_ = Arrays.copyOf(bArr, bArr.length);
                    }
                }
                if (eventInfo.hasContainerId()) {
                    this.bitField0_ |= 4;
                    if (eventInfo.containerId_ instanceof String) {
                        this.containerId_ = eventInfo.containerId_;
                    } else {
                        byte[] bArr2 = (byte[]) eventInfo.containerId_;
                        this.containerId_ = Arrays.copyOf(bArr2, bArr2.length);
                    }
                }
                if (eventInfo.hasKey()) {
                    this.bitField0_ |= 8;
                    if (eventInfo.key_ instanceof String) {
                        this.key_ = eventInfo.key_;
                    } else {
                        byte[] bArr3 = (byte[]) eventInfo.key_;
                        this.key_ = Arrays.copyOf(bArr3, bArr3.length);
                    }
                }
                if (eventInfo.hasMacroResult()) {
                    ensureMacroResultInitialized();
                    this.macroResult_.mergeFrom(eventInfo.getMacroResult());
                    this.bitField0_ |= 16;
                }
                if (eventInfo.hasDataLayerEventResult()) {
                    ensureDataLayerEventResultInitialized();
                    this.dataLayerEventResult_.mergeFrom(eventInfo.getDataLayerEventResult());
                    this.bitField0_ |= 32;
                }
                this.unknownFields = this.unknownFields.concat(eventInfo.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            int readEnum = codedInputStream.readEnum();
                            EventType valueOf = EventType.valueOf(readEnum);
                            if (valueOf != null) {
                                this.bitField0_ |= 1;
                                this.eventType_ = valueOf;
                                break;
                            } else {
                                newInstance.writeRawVarint32(readTag);
                                newInstance.writeRawVarint32(readEnum);
                                break;
                            }
                        case 18:
                            this.bitField0_ |= 2;
                            this.containerVersion_ = codedInputStream.readByteArray();
                            break;
                        case 26:
                            this.bitField0_ |= 4;
                            this.containerId_ = codedInputStream.readByteArray();
                            break;
                        case 34:
                            this.bitField0_ |= 8;
                            this.key_ = codedInputStream.readByteArray();
                            break;
                        case AdSize.PORTRAIT_AD_HEIGHT:
                            if (this.macroResult_ == MacroEvaluationInfo.getDefaultInstance()) {
                                this.macroResult_ = MacroEvaluationInfo.newMessage();
                            }
                            this.bitField0_ |= 16;
                            codedInputStream.readMessage(this.macroResult_, extensionRegistryLite);
                            break;
                        case 58:
                            if (this.dataLayerEventResult_ == DataLayerEventEvaluationInfo.getDefaultInstance()) {
                                this.dataLayerEventResult_ = DataLayerEventEvaluationInfo.newMessage();
                            }
                            this.bitField0_ |= 32;
                            codedInputStream.readMessage(this.dataLayerEventResult_, extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public EventInfo newMessageForType() {
            return new EventInfo();
        }

        public EventInfo setContainerId(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 4;
            this.containerId_ = str;
            return this;
        }

        public EventInfo setContainerIdAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 4;
            this.containerId_ = bArr;
            return this;
        }

        public EventInfo setContainerVersion(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.containerVersion_ = str;
            return this;
        }

        public EventInfo setContainerVersionAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.containerVersion_ = bArr;
            return this;
        }

        public EventInfo setDataLayerEventResult(DataLayerEventEvaluationInfo dataLayerEventEvaluationInfo) {
            assertMutable();
            if (dataLayerEventEvaluationInfo == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 32;
            this.dataLayerEventResult_ = dataLayerEventEvaluationInfo;
            return this;
        }

        public EventInfo setEventType(EventType eventType) {
            assertMutable();
            if (eventType == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.eventType_ = eventType;
            return this;
        }

        public EventInfo setKey(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.key_ = str;
            return this;
        }

        public EventInfo setKeyAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.key_ = bArr;
            return this;
        }

        public EventInfo setMacroResult(MacroEvaluationInfo macroEvaluationInfo) {
            assertMutable();
            if (macroEvaluationInfo == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 16;
            this.macroResult_ = macroEvaluationInfo;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeEnum(1, this.eventType_.getNumber());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeByteArray(2, getContainerVersionAsBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeByteArray(3, getContainerIdAsBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeByteArray(4, getKeyAsBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                codedOutputStream.writeMessageWithCachedSizes(6, this.macroResult_);
            }
            if ((this.bitField0_ & 32) == 32) {
                codedOutputStream.writeMessageWithCachedSizes(7, this.dataLayerEventResult_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class MacroEvaluationInfo extends GeneratedMutableMessageLite<MacroEvaluationInfo> implements MutableMessageLite {
        public static final int MACRO_FIELD_NUMBER = 47497405;
        public static Parser<MacroEvaluationInfo> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int RESULT_FIELD_NUMBER = 3;
        public static final int RULES_EVALUATION_FIELD_NUMBER = 1;
        private static final MacroEvaluationInfo defaultInstance = new MacroEvaluationInfo(true);
        private static volatile MessageLite immutableDefault = null;
        public static final GeneratedMessageLite.GeneratedExtension<MutableTypeSystem.Value, MacroEvaluationInfo> macro = GeneratedMessageLite.newSingularGeneratedExtension(MutableTypeSystem.Value.getDefaultInstance(), getDefaultInstance(), getDefaultInstance(), null, 47497405, WireFormat.FieldType.MESSAGE, MacroEvaluationInfo.class);
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private ResolvedFunctionCall result_;
        private RuleEvaluationStepInfo rulesEvaluation_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private MacroEvaluationInfo() {
            initFields();
        }

        private MacroEvaluationInfo(boolean z) {
        }

        private void ensureResultInitialized() {
            if (this.result_ == ResolvedFunctionCall.getDefaultInstance()) {
                this.result_ = ResolvedFunctionCall.newMessage();
            }
        }

        private void ensureRulesEvaluationInitialized() {
            if (this.rulesEvaluation_ == RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_ = RuleEvaluationStepInfo.newMessage();
            }
        }

        public static MacroEvaluationInfo getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.rulesEvaluation_ = RuleEvaluationStepInfo.getDefaultInstance();
            this.result_ = ResolvedFunctionCall.getDefaultInstance();
        }

        public static MacroEvaluationInfo newMessage() {
            return new MacroEvaluationInfo();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MacroEvaluationInfo clear() {
            assertMutable();
            super.clear();
            if (this.rulesEvaluation_ != RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_.clear();
            }
            this.bitField0_ &= -2;
            if (this.result_ != ResolvedFunctionCall.getDefaultInstance()) {
                this.result_.clear();
            }
            this.bitField0_ &= -3;
            return this;
        }

        public MacroEvaluationInfo clearResult() {
            assertMutable();
            this.bitField0_ &= -3;
            if (this.result_ != ResolvedFunctionCall.getDefaultInstance()) {
                this.result_.clear();
            }
            return this;
        }

        public MacroEvaluationInfo clearRulesEvaluation() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.rulesEvaluation_ != RuleEvaluationStepInfo.getDefaultInstance()) {
                this.rulesEvaluation_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public MacroEvaluationInfo clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof MacroEvaluationInfo)) {
                return super.equals(obj);
            }
            MacroEvaluationInfo macroEvaluationInfo = (MacroEvaluationInfo) obj;
            boolean z = hasRulesEvaluation() == macroEvaluationInfo.hasRulesEvaluation();
            if (hasRulesEvaluation()) {
                z = z && getRulesEvaluation().equals(macroEvaluationInfo.getRulesEvaluation());
            }
            boolean z2 = z && hasResult() == macroEvaluationInfo.hasResult();
            return hasResult() ? z2 && getResult().equals(macroEvaluationInfo.getResult()) : z2;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final MacroEvaluationInfo getDefaultInstanceForType() {
            return defaultInstance;
        }

        public ResolvedFunctionCall getMutableResult() {
            assertMutable();
            ensureResultInitialized();
            this.bitField0_ |= 2;
            return this.result_;
        }

        public RuleEvaluationStepInfo getMutableRulesEvaluation() {
            assertMutable();
            ensureRulesEvaluationInitialized();
            this.bitField0_ |= 1;
            return this.rulesEvaluation_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<MacroEvaluationInfo> getParserForType() {
            return PARSER;
        }

        public ResolvedFunctionCall getResult() {
            return this.result_;
        }

        public RuleEvaluationStepInfo getRulesEvaluation() {
            return this.rulesEvaluation_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if ((this.bitField0_ & 1) == 1) {
                i = CodedOutputStream.computeMessageSize(1, this.rulesEvaluation_) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeMessageSize(3, this.result_);
            }
            int size = i + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public boolean hasResult() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasRulesEvaluation() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (hasRulesEvaluation()) {
                i = 80454 + getRulesEvaluation().hashCode();
            }
            if (hasResult()) {
                i = (((i * 37) + 3) * 53) + getResult().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$MacroEvaluationInfo");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return (!hasRulesEvaluation() || getRulesEvaluation().isInitialized()) && (!hasResult() || getResult().isInitialized());
        }

        public MacroEvaluationInfo mergeFrom(MacroEvaluationInfo macroEvaluationInfo) {
            if (this == macroEvaluationInfo) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (macroEvaluationInfo != getDefaultInstance()) {
                if (macroEvaluationInfo.hasRulesEvaluation()) {
                    ensureRulesEvaluationInitialized();
                    this.rulesEvaluation_.mergeFrom(macroEvaluationInfo.getRulesEvaluation());
                    this.bitField0_ |= 1;
                }
                if (macroEvaluationInfo.hasResult()) {
                    ensureResultInitialized();
                    this.result_.mergeFrom(macroEvaluationInfo.getResult());
                    this.bitField0_ |= 2;
                }
                this.unknownFields = this.unknownFields.concat(macroEvaluationInfo.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            if (this.rulesEvaluation_ == RuleEvaluationStepInfo.getDefaultInstance()) {
                                this.rulesEvaluation_ = RuleEvaluationStepInfo.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.rulesEvaluation_, extensionRegistryLite);
                            break;
                        case 26:
                            if (this.result_ == ResolvedFunctionCall.getDefaultInstance()) {
                                this.result_ = ResolvedFunctionCall.newMessage();
                            }
                            this.bitField0_ |= 2;
                            codedInputStream.readMessage(this.result_, extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public MacroEvaluationInfo newMessageForType() {
            return new MacroEvaluationInfo();
        }

        public MacroEvaluationInfo setResult(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.result_ = resolvedFunctionCall;
            return this;
        }

        public MacroEvaluationInfo setRulesEvaluation(RuleEvaluationStepInfo ruleEvaluationStepInfo) {
            assertMutable();
            if (ruleEvaluationStepInfo == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.rulesEvaluation_ = ruleEvaluationStepInfo;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessageWithCachedSizes(1, this.rulesEvaluation_);
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeMessageWithCachedSizes(3, this.result_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class ResolvedFunctionCall extends GeneratedMutableMessageLite<ResolvedFunctionCall> implements MutableMessageLite {
        public static final int ASSOCIATED_RULE_NAME_FIELD_NUMBER = 3;
        public static Parser<ResolvedFunctionCall> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int PROPERTIES_FIELD_NUMBER = 1;
        public static final int RESULT_FIELD_NUMBER = 2;
        private static final ResolvedFunctionCall defaultInstance = new ResolvedFunctionCall(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private Object associatedRuleName_ = Internal.EMPTY_BYTE_ARRAY;
        private int bitField0_;
        private List<ResolvedProperty> properties_ = null;
        private MutableTypeSystem.Value result_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private ResolvedFunctionCall() {
            initFields();
        }

        private ResolvedFunctionCall(boolean z) {
        }

        private void ensurePropertiesInitialized() {
            if (this.properties_ == null) {
                this.properties_ = new ArrayList();
            }
        }

        private void ensureResultInitialized() {
            if (this.result_ == MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_ = MutableTypeSystem.Value.newMessage();
            }
        }

        public static ResolvedFunctionCall getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.result_ = MutableTypeSystem.Value.getDefaultInstance();
        }

        public static ResolvedFunctionCall newMessage() {
            return new ResolvedFunctionCall();
        }

        public ResolvedFunctionCall addAllProperties(Iterable<? extends ResolvedProperty> iterable) {
            assertMutable();
            ensurePropertiesInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.properties_);
            return this;
        }

        public ResolvedFunctionCall addProperties(ResolvedProperty resolvedProperty) {
            assertMutable();
            if (resolvedProperty == null) {
                throw new NullPointerException();
            }
            ensurePropertiesInitialized();
            this.properties_.add(resolvedProperty);
            return this;
        }

        public ResolvedProperty addProperties() {
            assertMutable();
            ensurePropertiesInitialized();
            ResolvedProperty newMessage = ResolvedProperty.newMessage();
            this.properties_.add(newMessage);
            return newMessage;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public ResolvedFunctionCall clear() {
            assertMutable();
            super.clear();
            this.properties_ = null;
            if (this.result_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_.clear();
            }
            this.bitField0_ &= -2;
            this.associatedRuleName_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -3;
            return this;
        }

        public ResolvedFunctionCall clearAssociatedRuleName() {
            assertMutable();
            this.bitField0_ &= -3;
            this.associatedRuleName_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public ResolvedFunctionCall clearProperties() {
            assertMutable();
            this.properties_ = null;
            return this;
        }

        public ResolvedFunctionCall clearResult() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.result_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public ResolvedFunctionCall clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ResolvedFunctionCall)) {
                return super.equals(obj);
            }
            ResolvedFunctionCall resolvedFunctionCall = (ResolvedFunctionCall) obj;
            boolean z = (getPropertiesList().equals(resolvedFunctionCall.getPropertiesList())) && hasResult() == resolvedFunctionCall.hasResult();
            if (hasResult()) {
                z = z && getResult().equals(resolvedFunctionCall.getResult());
            }
            boolean z2 = z && hasAssociatedRuleName() == resolvedFunctionCall.hasAssociatedRuleName();
            return hasAssociatedRuleName() ? z2 && getAssociatedRuleName().equals(resolvedFunctionCall.getAssociatedRuleName()) : z2;
        }

        public String getAssociatedRuleName() {
            Object obj = this.associatedRuleName_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.associatedRuleName_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getAssociatedRuleNameAsBytes() {
            Object obj = this.associatedRuleName_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.associatedRuleName_ = byteArray;
            return byteArray;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final ResolvedFunctionCall getDefaultInstanceForType() {
            return defaultInstance;
        }

        public ResolvedProperty getMutableProperties(int i) {
            return this.properties_.get(i);
        }

        public List<ResolvedProperty> getMutablePropertiesList() {
            assertMutable();
            ensurePropertiesInitialized();
            return this.properties_;
        }

        public MutableTypeSystem.Value getMutableResult() {
            assertMutable();
            ensureResultInitialized();
            this.bitField0_ |= 1;
            return this.result_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<ResolvedFunctionCall> getParserForType() {
            return PARSER;
        }

        public ResolvedProperty getProperties(int i) {
            return this.properties_.get(i);
        }

        public int getPropertiesCount() {
            if (this.properties_ == null) {
                return 0;
            }
            return this.properties_.size();
        }

        public List<ResolvedProperty> getPropertiesList() {
            return this.properties_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.properties_);
        }

        public MutableTypeSystem.Value getResult() {
            return this.result_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.properties_ != null) {
                i = 0;
                for (int i2 = 0; i2 < this.properties_.size(); i2++) {
                    i += CodedOutputStream.computeMessageSize(1, this.properties_.get(i2));
                }
            } else {
                i = 0;
            }
            if ((this.bitField0_ & 1) == 1) {
                i += CodedOutputStream.computeMessageSize(2, this.result_);
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeByteArraySize(3, getAssociatedRuleNameAsBytes());
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public boolean hasAssociatedRuleName() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasResult() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (getPropertiesCount() > 0) {
                i = 80454 + getPropertiesList().hashCode();
            }
            if (hasResult()) {
                i = (((i * 37) + 2) * 53) + getResult().hashCode();
            }
            if (hasAssociatedRuleName()) {
                i = (((i * 37) + 3) * 53) + getAssociatedRuleName().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$ResolvedFunctionCall");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            for (int i = 0; i < getPropertiesCount(); i++) {
                if (!getProperties(i).isInitialized()) {
                    return false;
                }
            }
            return !hasResult() || getResult().isInitialized();
        }

        public ResolvedFunctionCall mergeFrom(ResolvedFunctionCall resolvedFunctionCall) {
            if (this == resolvedFunctionCall) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (resolvedFunctionCall != getDefaultInstance()) {
                if (resolvedFunctionCall.properties_ != null && !resolvedFunctionCall.properties_.isEmpty()) {
                    ensurePropertiesInitialized();
                    AbstractMutableMessageLite.addAll(resolvedFunctionCall.properties_, this.properties_);
                }
                if (resolvedFunctionCall.hasResult()) {
                    ensureResultInitialized();
                    this.result_.mergeFrom(resolvedFunctionCall.getResult());
                    this.bitField0_ |= 1;
                }
                if (resolvedFunctionCall.hasAssociatedRuleName()) {
                    this.bitField0_ |= 2;
                    if (resolvedFunctionCall.associatedRuleName_ instanceof String) {
                        this.associatedRuleName_ = resolvedFunctionCall.associatedRuleName_;
                    } else {
                        byte[] bArr = (byte[]) resolvedFunctionCall.associatedRuleName_;
                        this.associatedRuleName_ = Arrays.copyOf(bArr, bArr.length);
                    }
                }
                this.unknownFields = this.unknownFields.concat(resolvedFunctionCall.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            codedInputStream.readMessage(addProperties(), extensionRegistryLite);
                            break;
                        case 18:
                            if (this.result_ == MutableTypeSystem.Value.getDefaultInstance()) {
                                this.result_ = MutableTypeSystem.Value.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.result_, extensionRegistryLite);
                            break;
                        case 26:
                            this.bitField0_ |= 2;
                            this.associatedRuleName_ = codedInputStream.readByteArray();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public ResolvedFunctionCall newMessageForType() {
            return new ResolvedFunctionCall();
        }

        public ResolvedFunctionCall setAssociatedRuleName(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.associatedRuleName_ = str;
            return this;
        }

        public ResolvedFunctionCall setAssociatedRuleNameAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.associatedRuleName_ = bArr;
            return this;
        }

        public ResolvedFunctionCall setProperties(int i, ResolvedProperty resolvedProperty) {
            assertMutable();
            if (resolvedProperty == null) {
                throw new NullPointerException();
            }
            ensurePropertiesInitialized();
            this.properties_.set(i, resolvedProperty);
            return this;
        }

        public ResolvedFunctionCall setResult(MutableTypeSystem.Value value) {
            assertMutable();
            if (value == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.result_ = value;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.properties_ != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= this.properties_.size()) {
                        break;
                    }
                    codedOutputStream.writeMessageWithCachedSizes(1, this.properties_.get(i2));
                    i = i2 + 1;
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessageWithCachedSizes(2, this.result_);
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeByteArray(3, getAssociatedRuleNameAsBytes());
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class ResolvedProperty extends GeneratedMutableMessageLite<ResolvedProperty> implements MutableMessageLite {
        public static final int KEY_FIELD_NUMBER = 1;
        public static Parser<ResolvedProperty> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int VALUE_FIELD_NUMBER = 2;
        private static final ResolvedProperty defaultInstance = new ResolvedProperty(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private Object key_ = Internal.EMPTY_BYTE_ARRAY;
        private MutableTypeSystem.Value value_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private ResolvedProperty() {
            initFields();
        }

        private ResolvedProperty(boolean z) {
        }

        private void ensureValueInitialized() {
            if (this.value_ == MutableTypeSystem.Value.getDefaultInstance()) {
                this.value_ = MutableTypeSystem.Value.newMessage();
            }
        }

        public static ResolvedProperty getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.value_ = MutableTypeSystem.Value.getDefaultInstance();
        }

        public static ResolvedProperty newMessage() {
            return new ResolvedProperty();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public ResolvedProperty clear() {
            assertMutable();
            super.clear();
            this.key_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -2;
            if (this.value_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.value_.clear();
            }
            this.bitField0_ &= -3;
            return this;
        }

        public ResolvedProperty clearKey() {
            assertMutable();
            this.bitField0_ &= -2;
            this.key_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public ResolvedProperty clearValue() {
            assertMutable();
            this.bitField0_ &= -3;
            if (this.value_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.value_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public ResolvedProperty clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ResolvedProperty)) {
                return super.equals(obj);
            }
            ResolvedProperty resolvedProperty = (ResolvedProperty) obj;
            boolean z = hasKey() == resolvedProperty.hasKey();
            if (hasKey()) {
                z = z && getKey().equals(resolvedProperty.getKey());
            }
            boolean z2 = z && hasValue() == resolvedProperty.hasValue();
            return hasValue() ? z2 && getValue().equals(resolvedProperty.getValue()) : z2;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final ResolvedProperty getDefaultInstanceForType() {
            return defaultInstance;
        }

        public String getKey() {
            Object obj = this.key_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.key_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getKeyAsBytes() {
            Object obj = this.key_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.key_ = byteArray;
            return byteArray;
        }

        public MutableTypeSystem.Value getMutableValue() {
            assertMutable();
            ensureValueInitialized();
            this.bitField0_ |= 2;
            return this.value_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<ResolvedProperty> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if ((this.bitField0_ & 1) == 1) {
                i = CodedOutputStream.computeByteArraySize(1, getKeyAsBytes()) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeMessageSize(2, this.value_);
            }
            int size = i + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public MutableTypeSystem.Value getValue() {
            return this.value_;
        }

        public boolean hasKey() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasValue() {
            return (this.bitField0_ & 2) == 2;
        }

        public int hashCode() {
            int i = 41;
            if (hasKey()) {
                i = 80454 + getKey().hashCode();
            }
            if (hasValue()) {
                i = (((i * 37) + 2) * 53) + getValue().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$ResolvedProperty");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return !hasValue() || getValue().isInitialized();
        }

        public ResolvedProperty mergeFrom(ResolvedProperty resolvedProperty) {
            if (this == resolvedProperty) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (resolvedProperty != getDefaultInstance()) {
                if (resolvedProperty.hasKey()) {
                    this.bitField0_ |= 1;
                    if (resolvedProperty.key_ instanceof String) {
                        this.key_ = resolvedProperty.key_;
                    } else {
                        byte[] bArr = (byte[]) resolvedProperty.key_;
                        this.key_ = Arrays.copyOf(bArr, bArr.length);
                    }
                }
                if (resolvedProperty.hasValue()) {
                    ensureValueInitialized();
                    this.value_.mergeFrom(resolvedProperty.getValue());
                    this.bitField0_ |= 2;
                }
                this.unknownFields = this.unknownFields.concat(resolvedProperty.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            this.bitField0_ |= 1;
                            this.key_ = codedInputStream.readByteArray();
                            break;
                        case 18:
                            if (this.value_ == MutableTypeSystem.Value.getDefaultInstance()) {
                                this.value_ = MutableTypeSystem.Value.newMessage();
                            }
                            this.bitField0_ |= 2;
                            codedInputStream.readMessage(this.value_, extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public ResolvedProperty newMessageForType() {
            return new ResolvedProperty();
        }

        public ResolvedProperty setKey(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.key_ = str;
            return this;
        }

        public ResolvedProperty setKeyAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.key_ = bArr;
            return this;
        }

        public ResolvedProperty setValue(MutableTypeSystem.Value value) {
            assertMutable();
            if (value == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.value_ = value;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeByteArray(1, getKeyAsBytes());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeMessageWithCachedSizes(2, this.value_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class ResolvedRule extends GeneratedMutableMessageLite<ResolvedRule> implements MutableMessageLite {
        public static final int ADD_MACROS_FIELD_NUMBER = 5;
        public static final int ADD_TAGS_FIELD_NUMBER = 3;
        public static final int NEGATIVE_PREDICATES_FIELD_NUMBER = 2;
        public static Parser<ResolvedRule> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int POSITIVE_PREDICATES_FIELD_NUMBER = 1;
        public static final int REMOVE_MACROS_FIELD_NUMBER = 6;
        public static final int REMOVE_TAGS_FIELD_NUMBER = 4;
        public static final int RESULT_FIELD_NUMBER = 7;
        private static final ResolvedRule defaultInstance = new ResolvedRule(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private List<ResolvedFunctionCall> addMacros_ = null;
        private List<ResolvedFunctionCall> addTags_ = null;
        private int bitField0_;
        private List<ResolvedFunctionCall> negativePredicates_ = null;
        private List<ResolvedFunctionCall> positivePredicates_ = null;
        private List<ResolvedFunctionCall> removeMacros_ = null;
        private List<ResolvedFunctionCall> removeTags_ = null;
        private MutableTypeSystem.Value result_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private ResolvedRule() {
            initFields();
        }

        private ResolvedRule(boolean z) {
        }

        private void ensureAddMacrosInitialized() {
            if (this.addMacros_ == null) {
                this.addMacros_ = new ArrayList();
            }
        }

        private void ensureAddTagsInitialized() {
            if (this.addTags_ == null) {
                this.addTags_ = new ArrayList();
            }
        }

        private void ensureNegativePredicatesInitialized() {
            if (this.negativePredicates_ == null) {
                this.negativePredicates_ = new ArrayList();
            }
        }

        private void ensurePositivePredicatesInitialized() {
            if (this.positivePredicates_ == null) {
                this.positivePredicates_ = new ArrayList();
            }
        }

        private void ensureRemoveMacrosInitialized() {
            if (this.removeMacros_ == null) {
                this.removeMacros_ = new ArrayList();
            }
        }

        private void ensureRemoveTagsInitialized() {
            if (this.removeTags_ == null) {
                this.removeTags_ = new ArrayList();
            }
        }

        private void ensureResultInitialized() {
            if (this.result_ == MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_ = MutableTypeSystem.Value.newMessage();
            }
        }

        public static ResolvedRule getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.result_ = MutableTypeSystem.Value.getDefaultInstance();
        }

        public static ResolvedRule newMessage() {
            return new ResolvedRule();
        }

        public ResolvedFunctionCall addAddMacros() {
            assertMutable();
            ensureAddMacrosInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.addMacros_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addAddMacros(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureAddMacrosInitialized();
            this.addMacros_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedFunctionCall addAddTags() {
            assertMutable();
            ensureAddTagsInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.addTags_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addAddTags(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureAddTagsInitialized();
            this.addTags_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedRule addAllAddMacros(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureAddMacrosInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addMacros_);
            return this;
        }

        public ResolvedRule addAllAddTags(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureAddTagsInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addTags_);
            return this;
        }

        public ResolvedRule addAllNegativePredicates(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureNegativePredicatesInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.negativePredicates_);
            return this;
        }

        public ResolvedRule addAllPositivePredicates(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensurePositivePredicatesInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.positivePredicates_);
            return this;
        }

        public ResolvedRule addAllRemoveMacros(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureRemoveMacrosInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeMacros_);
            return this;
        }

        public ResolvedRule addAllRemoveTags(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureRemoveTagsInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeTags_);
            return this;
        }

        public ResolvedFunctionCall addNegativePredicates() {
            assertMutable();
            ensureNegativePredicatesInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.negativePredicates_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addNegativePredicates(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureNegativePredicatesInitialized();
            this.negativePredicates_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedFunctionCall addPositivePredicates() {
            assertMutable();
            ensurePositivePredicatesInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.positivePredicates_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addPositivePredicates(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensurePositivePredicatesInitialized();
            this.positivePredicates_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedFunctionCall addRemoveMacros() {
            assertMutable();
            ensureRemoveMacrosInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.removeMacros_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addRemoveMacros(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureRemoveMacrosInitialized();
            this.removeMacros_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedFunctionCall addRemoveTags() {
            assertMutable();
            ensureRemoveTagsInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.removeTags_.add(newMessage);
            return newMessage;
        }

        public ResolvedRule addRemoveTags(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureRemoveTagsInitialized();
            this.removeTags_.add(resolvedFunctionCall);
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public ResolvedRule clear() {
            assertMutable();
            super.clear();
            this.positivePredicates_ = null;
            this.negativePredicates_ = null;
            this.addTags_ = null;
            this.removeTags_ = null;
            this.addMacros_ = null;
            this.removeMacros_ = null;
            if (this.result_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_.clear();
            }
            this.bitField0_ &= -2;
            return this;
        }

        public ResolvedRule clearAddMacros() {
            assertMutable();
            this.addMacros_ = null;
            return this;
        }

        public ResolvedRule clearAddTags() {
            assertMutable();
            this.addTags_ = null;
            return this;
        }

        public ResolvedRule clearNegativePredicates() {
            assertMutable();
            this.negativePredicates_ = null;
            return this;
        }

        public ResolvedRule clearPositivePredicates() {
            assertMutable();
            this.positivePredicates_ = null;
            return this;
        }

        public ResolvedRule clearRemoveMacros() {
            assertMutable();
            this.removeMacros_ = null;
            return this;
        }

        public ResolvedRule clearRemoveTags() {
            assertMutable();
            this.removeTags_ = null;
            return this;
        }

        public ResolvedRule clearResult() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.result_ != MutableTypeSystem.Value.getDefaultInstance()) {
                this.result_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public ResolvedRule clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ResolvedRule)) {
                return super.equals(obj);
            }
            ResolvedRule resolvedRule = (ResolvedRule) obj;
            boolean z = ((((((getPositivePredicatesList().equals(resolvedRule.getPositivePredicatesList())) && getNegativePredicatesList().equals(resolvedRule.getNegativePredicatesList())) && getAddTagsList().equals(resolvedRule.getAddTagsList())) && getRemoveTagsList().equals(resolvedRule.getRemoveTagsList())) && getAddMacrosList().equals(resolvedRule.getAddMacrosList())) && getRemoveMacrosList().equals(resolvedRule.getRemoveMacrosList())) && hasResult() == resolvedRule.hasResult();
            return hasResult() ? z && getResult().equals(resolvedRule.getResult()) : z;
        }

        public ResolvedFunctionCall getAddMacros(int i) {
            return this.addMacros_.get(i);
        }

        public int getAddMacrosCount() {
            if (this.addMacros_ == null) {
                return 0;
            }
            return this.addMacros_.size();
        }

        public List<ResolvedFunctionCall> getAddMacrosList() {
            return this.addMacros_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addMacros_);
        }

        public ResolvedFunctionCall getAddTags(int i) {
            return this.addTags_.get(i);
        }

        public int getAddTagsCount() {
            if (this.addTags_ == null) {
                return 0;
            }
            return this.addTags_.size();
        }

        public List<ResolvedFunctionCall> getAddTagsList() {
            return this.addTags_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addTags_);
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final ResolvedRule getDefaultInstanceForType() {
            return defaultInstance;
        }

        public ResolvedFunctionCall getMutableAddMacros(int i) {
            return this.addMacros_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableAddMacrosList() {
            assertMutable();
            ensureAddMacrosInitialized();
            return this.addMacros_;
        }

        public ResolvedFunctionCall getMutableAddTags(int i) {
            return this.addTags_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableAddTagsList() {
            assertMutable();
            ensureAddTagsInitialized();
            return this.addTags_;
        }

        public ResolvedFunctionCall getMutableNegativePredicates(int i) {
            return this.negativePredicates_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableNegativePredicatesList() {
            assertMutable();
            ensureNegativePredicatesInitialized();
            return this.negativePredicates_;
        }

        public ResolvedFunctionCall getMutablePositivePredicates(int i) {
            return this.positivePredicates_.get(i);
        }

        public List<ResolvedFunctionCall> getMutablePositivePredicatesList() {
            assertMutable();
            ensurePositivePredicatesInitialized();
            return this.positivePredicates_;
        }

        public ResolvedFunctionCall getMutableRemoveMacros(int i) {
            return this.removeMacros_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableRemoveMacrosList() {
            assertMutable();
            ensureRemoveMacrosInitialized();
            return this.removeMacros_;
        }

        public ResolvedFunctionCall getMutableRemoveTags(int i) {
            return this.removeTags_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableRemoveTagsList() {
            assertMutable();
            ensureRemoveTagsInitialized();
            return this.removeTags_;
        }

        public MutableTypeSystem.Value getMutableResult() {
            assertMutable();
            ensureResultInitialized();
            this.bitField0_ |= 1;
            return this.result_;
        }

        public ResolvedFunctionCall getNegativePredicates(int i) {
            return this.negativePredicates_.get(i);
        }

        public int getNegativePredicatesCount() {
            if (this.negativePredicates_ == null) {
                return 0;
            }
            return this.negativePredicates_.size();
        }

        public List<ResolvedFunctionCall> getNegativePredicatesList() {
            return this.negativePredicates_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.negativePredicates_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<ResolvedRule> getParserForType() {
            return PARSER;
        }

        public ResolvedFunctionCall getPositivePredicates(int i) {
            return this.positivePredicates_.get(i);
        }

        public int getPositivePredicatesCount() {
            if (this.positivePredicates_ == null) {
                return 0;
            }
            return this.positivePredicates_.size();
        }

        public List<ResolvedFunctionCall> getPositivePredicatesList() {
            return this.positivePredicates_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.positivePredicates_);
        }

        public ResolvedFunctionCall getRemoveMacros(int i) {
            return this.removeMacros_.get(i);
        }

        public int getRemoveMacrosCount() {
            if (this.removeMacros_ == null) {
                return 0;
            }
            return this.removeMacros_.size();
        }

        public List<ResolvedFunctionCall> getRemoveMacrosList() {
            return this.removeMacros_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeMacros_);
        }

        public ResolvedFunctionCall getRemoveTags(int i) {
            return this.removeTags_.get(i);
        }

        public int getRemoveTagsCount() {
            if (this.removeTags_ == null) {
                return 0;
            }
            return this.removeTags_.size();
        }

        public List<ResolvedFunctionCall> getRemoveTagsList() {
            return this.removeTags_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeTags_);
        }

        public MutableTypeSystem.Value getResult() {
            return this.result_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.positivePredicates_ != null) {
                i = 0;
                for (int i2 = 0; i2 < this.positivePredicates_.size(); i2++) {
                    i += CodedOutputStream.computeMessageSize(1, this.positivePredicates_.get(i2));
                }
            } else {
                i = 0;
            }
            if (this.negativePredicates_ != null) {
                for (int i3 = 0; i3 < this.negativePredicates_.size(); i3++) {
                    i += CodedOutputStream.computeMessageSize(2, this.negativePredicates_.get(i3));
                }
            }
            if (this.addTags_ != null) {
                for (int i4 = 0; i4 < this.addTags_.size(); i4++) {
                    i += CodedOutputStream.computeMessageSize(3, this.addTags_.get(i4));
                }
            }
            if (this.removeTags_ != null) {
                for (int i5 = 0; i5 < this.removeTags_.size(); i5++) {
                    i += CodedOutputStream.computeMessageSize(4, this.removeTags_.get(i5));
                }
            }
            if (this.addMacros_ != null) {
                for (int i6 = 0; i6 < this.addMacros_.size(); i6++) {
                    i += CodedOutputStream.computeMessageSize(5, this.addMacros_.get(i6));
                }
            }
            if (this.removeMacros_ != null) {
                for (int i7 = 0; i7 < this.removeMacros_.size(); i7++) {
                    i += CodedOutputStream.computeMessageSize(6, this.removeMacros_.get(i7));
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                i += CodedOutputStream.computeMessageSize(7, this.result_);
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public boolean hasResult() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (getPositivePredicatesCount() > 0) {
                i = 80454 + getPositivePredicatesList().hashCode();
            }
            if (getNegativePredicatesCount() > 0) {
                i = (((i * 37) + 2) * 53) + getNegativePredicatesList().hashCode();
            }
            if (getAddTagsCount() > 0) {
                i = (((i * 37) + 3) * 53) + getAddTagsList().hashCode();
            }
            if (getRemoveTagsCount() > 0) {
                i = (((i * 37) + 4) * 53) + getRemoveTagsList().hashCode();
            }
            if (getAddMacrosCount() > 0) {
                i = (((i * 37) + 5) * 53) + getAddMacrosList().hashCode();
            }
            if (getRemoveMacrosCount() > 0) {
                i = (((i * 37) + 6) * 53) + getRemoveMacrosList().hashCode();
            }
            if (hasResult()) {
                i = (((i * 37) + 7) * 53) + getResult().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$ResolvedRule");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            for (int i = 0; i < getPositivePredicatesCount(); i++) {
                if (!getPositivePredicates(i).isInitialized()) {
                    return false;
                }
            }
            for (int i2 = 0; i2 < getNegativePredicatesCount(); i2++) {
                if (!getNegativePredicates(i2).isInitialized()) {
                    return false;
                }
            }
            for (int i3 = 0; i3 < getAddTagsCount(); i3++) {
                if (!getAddTags(i3).isInitialized()) {
                    return false;
                }
            }
            for (int i4 = 0; i4 < getRemoveTagsCount(); i4++) {
                if (!getRemoveTags(i4).isInitialized()) {
                    return false;
                }
            }
            for (int i5 = 0; i5 < getAddMacrosCount(); i5++) {
                if (!getAddMacros(i5).isInitialized()) {
                    return false;
                }
            }
            for (int i6 = 0; i6 < getRemoveMacrosCount(); i6++) {
                if (!getRemoveMacros(i6).isInitialized()) {
                    return false;
                }
            }
            return !hasResult() || getResult().isInitialized();
        }

        public ResolvedRule mergeFrom(ResolvedRule resolvedRule) {
            if (this == resolvedRule) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (resolvedRule != getDefaultInstance()) {
                if (resolvedRule.positivePredicates_ != null && !resolvedRule.positivePredicates_.isEmpty()) {
                    ensurePositivePredicatesInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.positivePredicates_, this.positivePredicates_);
                }
                if (resolvedRule.negativePredicates_ != null && !resolvedRule.negativePredicates_.isEmpty()) {
                    ensureNegativePredicatesInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.negativePredicates_, this.negativePredicates_);
                }
                if (resolvedRule.addTags_ != null && !resolvedRule.addTags_.isEmpty()) {
                    ensureAddTagsInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.addTags_, this.addTags_);
                }
                if (resolvedRule.removeTags_ != null && !resolvedRule.removeTags_.isEmpty()) {
                    ensureRemoveTagsInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.removeTags_, this.removeTags_);
                }
                if (resolvedRule.addMacros_ != null && !resolvedRule.addMacros_.isEmpty()) {
                    ensureAddMacrosInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.addMacros_, this.addMacros_);
                }
                if (resolvedRule.removeMacros_ != null && !resolvedRule.removeMacros_.isEmpty()) {
                    ensureRemoveMacrosInitialized();
                    AbstractMutableMessageLite.addAll(resolvedRule.removeMacros_, this.removeMacros_);
                }
                if (resolvedRule.hasResult()) {
                    ensureResultInitialized();
                    this.result_.mergeFrom(resolvedRule.getResult());
                    this.bitField0_ |= 1;
                }
                this.unknownFields = this.unknownFields.concat(resolvedRule.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            codedInputStream.readMessage(addPositivePredicates(), extensionRegistryLite);
                            break;
                        case 18:
                            codedInputStream.readMessage(addNegativePredicates(), extensionRegistryLite);
                            break;
                        case 26:
                            codedInputStream.readMessage(addAddTags(), extensionRegistryLite);
                            break;
                        case 34:
                            codedInputStream.readMessage(addRemoveTags(), extensionRegistryLite);
                            break;
                        case 42:
                            codedInputStream.readMessage(addAddMacros(), extensionRegistryLite);
                            break;
                        case AdSize.PORTRAIT_AD_HEIGHT:
                            codedInputStream.readMessage(addRemoveMacros(), extensionRegistryLite);
                            break;
                        case 58:
                            if (this.result_ == MutableTypeSystem.Value.getDefaultInstance()) {
                                this.result_ = MutableTypeSystem.Value.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.result_, extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public ResolvedRule newMessageForType() {
            return new ResolvedRule();
        }

        public ResolvedRule setAddMacros(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureAddMacrosInitialized();
            this.addMacros_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setAddTags(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureAddTagsInitialized();
            this.addTags_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setNegativePredicates(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureNegativePredicatesInitialized();
            this.negativePredicates_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setPositivePredicates(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensurePositivePredicatesInitialized();
            this.positivePredicates_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setRemoveMacros(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureRemoveMacrosInitialized();
            this.removeMacros_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setRemoveTags(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureRemoveTagsInitialized();
            this.removeTags_.set(i, resolvedFunctionCall);
            return this;
        }

        public ResolvedRule setResult(MutableTypeSystem.Value value) {
            assertMutable();
            if (value == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.result_ = value;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.positivePredicates_ != null) {
                for (int i = 0; i < this.positivePredicates_.size(); i++) {
                    codedOutputStream.writeMessageWithCachedSizes(1, this.positivePredicates_.get(i));
                }
            }
            if (this.negativePredicates_ != null) {
                for (int i2 = 0; i2 < this.negativePredicates_.size(); i2++) {
                    codedOutputStream.writeMessageWithCachedSizes(2, this.negativePredicates_.get(i2));
                }
            }
            if (this.addTags_ != null) {
                for (int i3 = 0; i3 < this.addTags_.size(); i3++) {
                    codedOutputStream.writeMessageWithCachedSizes(3, this.addTags_.get(i3));
                }
            }
            if (this.removeTags_ != null) {
                for (int i4 = 0; i4 < this.removeTags_.size(); i4++) {
                    codedOutputStream.writeMessageWithCachedSizes(4, this.removeTags_.get(i4));
                }
            }
            if (this.addMacros_ != null) {
                for (int i5 = 0; i5 < this.addMacros_.size(); i5++) {
                    codedOutputStream.writeMessageWithCachedSizes(5, this.addMacros_.get(i5));
                }
            }
            if (this.removeMacros_ != null) {
                for (int i6 = 0; i6 < this.removeMacros_.size(); i6++) {
                    codedOutputStream.writeMessageWithCachedSizes(6, this.removeMacros_.get(i6));
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessageWithCachedSizes(7, this.result_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class RuleEvaluationStepInfo extends GeneratedMutableMessageLite<RuleEvaluationStepInfo> implements MutableMessageLite {
        public static final int ENABLED_FUNCTIONS_FIELD_NUMBER = 2;
        public static Parser<RuleEvaluationStepInfo> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int RULES_FIELD_NUMBER = 1;
        private static final RuleEvaluationStepInfo defaultInstance = new RuleEvaluationStepInfo(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private List<ResolvedFunctionCall> enabledFunctions_ = null;
        private List<ResolvedRule> rules_ = null;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private RuleEvaluationStepInfo() {
            initFields();
        }

        private RuleEvaluationStepInfo(boolean z) {
        }

        private void ensureEnabledFunctionsInitialized() {
            if (this.enabledFunctions_ == null) {
                this.enabledFunctions_ = new ArrayList();
            }
        }

        private void ensureRulesInitialized() {
            if (this.rules_ == null) {
                this.rules_ = new ArrayList();
            }
        }

        public static RuleEvaluationStepInfo getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static RuleEvaluationStepInfo newMessage() {
            return new RuleEvaluationStepInfo();
        }

        public RuleEvaluationStepInfo addAllEnabledFunctions(Iterable<? extends ResolvedFunctionCall> iterable) {
            assertMutable();
            ensureEnabledFunctionsInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.enabledFunctions_);
            return this;
        }

        public RuleEvaluationStepInfo addAllRules(Iterable<? extends ResolvedRule> iterable) {
            assertMutable();
            ensureRulesInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.rules_);
            return this;
        }

        public ResolvedFunctionCall addEnabledFunctions() {
            assertMutable();
            ensureEnabledFunctionsInitialized();
            ResolvedFunctionCall newMessage = ResolvedFunctionCall.newMessage();
            this.enabledFunctions_.add(newMessage);
            return newMessage;
        }

        public RuleEvaluationStepInfo addEnabledFunctions(ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureEnabledFunctionsInitialized();
            this.enabledFunctions_.add(resolvedFunctionCall);
            return this;
        }

        public ResolvedRule addRules() {
            assertMutable();
            ensureRulesInitialized();
            ResolvedRule newMessage = ResolvedRule.newMessage();
            this.rules_.add(newMessage);
            return newMessage;
        }

        public RuleEvaluationStepInfo addRules(ResolvedRule resolvedRule) {
            assertMutable();
            if (resolvedRule == null) {
                throw new NullPointerException();
            }
            ensureRulesInitialized();
            this.rules_.add(resolvedRule);
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public RuleEvaluationStepInfo clear() {
            assertMutable();
            super.clear();
            this.rules_ = null;
            this.enabledFunctions_ = null;
            return this;
        }

        public RuleEvaluationStepInfo clearEnabledFunctions() {
            assertMutable();
            this.enabledFunctions_ = null;
            return this;
        }

        public RuleEvaluationStepInfo clearRules() {
            assertMutable();
            this.rules_ = null;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public RuleEvaluationStepInfo clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof RuleEvaluationStepInfo)) {
                return super.equals(obj);
            }
            RuleEvaluationStepInfo ruleEvaluationStepInfo = (RuleEvaluationStepInfo) obj;
            return (getRulesList().equals(ruleEvaluationStepInfo.getRulesList())) && getEnabledFunctionsList().equals(ruleEvaluationStepInfo.getEnabledFunctionsList());
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final RuleEvaluationStepInfo getDefaultInstanceForType() {
            return defaultInstance;
        }

        public ResolvedFunctionCall getEnabledFunctions(int i) {
            return this.enabledFunctions_.get(i);
        }

        public int getEnabledFunctionsCount() {
            if (this.enabledFunctions_ == null) {
                return 0;
            }
            return this.enabledFunctions_.size();
        }

        public List<ResolvedFunctionCall> getEnabledFunctionsList() {
            return this.enabledFunctions_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.enabledFunctions_);
        }

        public ResolvedFunctionCall getMutableEnabledFunctions(int i) {
            return this.enabledFunctions_.get(i);
        }

        public List<ResolvedFunctionCall> getMutableEnabledFunctionsList() {
            assertMutable();
            ensureEnabledFunctionsInitialized();
            return this.enabledFunctions_;
        }

        public ResolvedRule getMutableRules(int i) {
            return this.rules_.get(i);
        }

        public List<ResolvedRule> getMutableRulesList() {
            assertMutable();
            ensureRulesInitialized();
            return this.rules_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<RuleEvaluationStepInfo> getParserForType() {
            return PARSER;
        }

        public ResolvedRule getRules(int i) {
            return this.rules_.get(i);
        }

        public int getRulesCount() {
            if (this.rules_ == null) {
                return 0;
            }
            return this.rules_.size();
        }

        public List<ResolvedRule> getRulesList() {
            return this.rules_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.rules_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.rules_ != null) {
                i = 0;
                for (int i2 = 0; i2 < this.rules_.size(); i2++) {
                    i += CodedOutputStream.computeMessageSize(1, this.rules_.get(i2));
                }
            } else {
                i = 0;
            }
            if (this.enabledFunctions_ != null) {
                for (int i3 = 0; i3 < this.enabledFunctions_.size(); i3++) {
                    i += CodedOutputStream.computeMessageSize(2, this.enabledFunctions_.get(i3));
                }
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public int hashCode() {
            int i = 41;
            if (getRulesCount() > 0) {
                i = 80454 + getRulesList().hashCode();
            }
            if (getEnabledFunctionsCount() > 0) {
                i = (((i * 37) + 2) * 53) + getEnabledFunctionsList().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Debug$RuleEvaluationStepInfo");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            for (int i = 0; i < getRulesCount(); i++) {
                if (!getRules(i).isInitialized()) {
                    return false;
                }
            }
            for (int i2 = 0; i2 < getEnabledFunctionsCount(); i2++) {
                if (!getEnabledFunctions(i2).isInitialized()) {
                    return false;
                }
            }
            return true;
        }

        public RuleEvaluationStepInfo mergeFrom(RuleEvaluationStepInfo ruleEvaluationStepInfo) {
            if (this == ruleEvaluationStepInfo) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (ruleEvaluationStepInfo != getDefaultInstance()) {
                if (ruleEvaluationStepInfo.rules_ != null && !ruleEvaluationStepInfo.rules_.isEmpty()) {
                    ensureRulesInitialized();
                    AbstractMutableMessageLite.addAll(ruleEvaluationStepInfo.rules_, this.rules_);
                }
                if (ruleEvaluationStepInfo.enabledFunctions_ != null && !ruleEvaluationStepInfo.enabledFunctions_.isEmpty()) {
                    ensureEnabledFunctionsInitialized();
                    AbstractMutableMessageLite.addAll(ruleEvaluationStepInfo.enabledFunctions_, this.enabledFunctions_);
                }
                this.unknownFields = this.unknownFields.concat(ruleEvaluationStepInfo.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            codedInputStream.readMessage(addRules(), extensionRegistryLite);
                            break;
                        case 18:
                            codedInputStream.readMessage(addEnabledFunctions(), extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public RuleEvaluationStepInfo newMessageForType() {
            return new RuleEvaluationStepInfo();
        }

        public RuleEvaluationStepInfo setEnabledFunctions(int i, ResolvedFunctionCall resolvedFunctionCall) {
            assertMutable();
            if (resolvedFunctionCall == null) {
                throw new NullPointerException();
            }
            ensureEnabledFunctionsInitialized();
            this.enabledFunctions_.set(i, resolvedFunctionCall);
            return this;
        }

        public RuleEvaluationStepInfo setRules(int i, ResolvedRule resolvedRule) {
            assertMutable();
            if (resolvedRule == null) {
                throw new NullPointerException();
            }
            ensureRulesInitialized();
            this.rules_.set(i, resolvedRule);
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.rules_ != null) {
                for (int i = 0; i < this.rules_.size(); i++) {
                    codedOutputStream.writeMessageWithCachedSizes(1, this.rules_.get(i));
                }
            }
            if (this.enabledFunctions_ != null) {
                for (int i2 = 0; i2 < this.enabledFunctions_.size(); i2++) {
                    codedOutputStream.writeMessageWithCachedSizes(2, this.enabledFunctions_.get(i2));
                }
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    private MutableDebug() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
        extensionRegistryLite.add(MacroEvaluationInfo.macro);
    }
}

package com.google.analytics.tracking.android;

import android.text.TextUtils;
import com.getjar.vending.GetJarUtils;
import com.google.analytics.tracking.android.GAUsage;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Tracker {
    static final long MAX_TOKENS = 120000;
    static final long NUM_TOKENS_PER_HIT = 2000;
    private final AppFieldsDefaultProvider mAppFieldsDefaultProvider;
    private final ClientIdDefaultProvider mClientIdDefaultProvider;
    private final TrackerHandler mHandler;
    private long mLastTrackTime;
    private final String mName;
    private final Map<String, String> mParams;
    private final ScreenResolutionDefaultProvider mScreenResolutionDefaultProvider;
    private long mTokens;

    Tracker(String str, String str2, TrackerHandler trackerHandler) {
        this(str, str2, trackerHandler, ClientIdDefaultProvider.getProvider(), ScreenResolutionDefaultProvider.getProvider(), AppFieldsDefaultProvider.getProvider());
    }

    @VisibleForTesting
    Tracker(String str, String str2, TrackerHandler trackerHandler, ClientIdDefaultProvider clientIdDefaultProvider, ScreenResolutionDefaultProvider screenResolutionDefaultProvider, AppFieldsDefaultProvider appFieldsDefaultProvider) {
        this.mParams = new HashMap();
        this.mTokens = MAX_TOKENS;
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Tracker name cannot be empty.");
        }
        this.mName = str;
        this.mHandler = trackerHandler;
        this.mParams.put(Fields.TRACKING_ID, str2);
        this.mParams.put(Fields.USE_SECURE, GetJarUtils.PVERSION);
        this.mClientIdDefaultProvider = clientIdDefaultProvider;
        this.mScreenResolutionDefaultProvider = screenResolutionDefaultProvider;
        this.mAppFieldsDefaultProvider = appFieldsDefaultProvider;
    }

    public String get(String str) {
        GAUsage.getInstance().setUsage(GAUsage.Field.GET);
        if (!TextUtils.isEmpty(str)) {
            if (this.mParams.containsKey(str)) {
                return this.mParams.get(str);
            }
            if (str.equals(Fields.LANGUAGE)) {
                return Utils.getLanguage(Locale.getDefault());
            }
            if (this.mClientIdDefaultProvider != null && this.mClientIdDefaultProvider.providesField(str)) {
                return this.mClientIdDefaultProvider.getValue(str);
            }
            if (this.mScreenResolutionDefaultProvider != null && this.mScreenResolutionDefaultProvider.providesField(str)) {
                return this.mScreenResolutionDefaultProvider.getValue(str);
            }
            if (this.mAppFieldsDefaultProvider != null && this.mAppFieldsDefaultProvider.providesField(str)) {
                return this.mAppFieldsDefaultProvider.getValue(str);
            }
        }
        return null;
    }

    public String getName() {
        GAUsage.getInstance().setUsage(GAUsage.Field.GET_TRACKER_NAME);
        return this.mName;
    }

    public void send(Map<String, String> map) {
        GAUsage.getInstance().setUsage(GAUsage.Field.SEND);
        HashMap hashMap = new HashMap();
        hashMap.putAll(this.mParams);
        if (map != null) {
            hashMap.putAll(map);
        }
        if (TextUtils.isEmpty((CharSequence) hashMap.get(Fields.TRACKING_ID))) {
            Log.w(String.format("Missing tracking id (%s) parameter.", Fields.TRACKING_ID));
        }
        String str = (String) hashMap.get(Fields.HIT_TYPE);
        if (TextUtils.isEmpty(str)) {
            Log.w(String.format("Missing hit type (%s) parameter.", Fields.HIT_TYPE));
            str = "";
        }
        if (str.equals(HitTypes.TRANSACTION) || str.equals(HitTypes.ITEM) || tokensAvailable()) {
            this.mHandler.sendHit(hashMap);
        } else {
            Log.w("Too many hits sent too quickly, rate limiting invoked.");
        }
    }

    public void set(String str, String str2) {
        GAUsage.getInstance().setUsage(GAUsage.Field.SET);
        if (str2 == null) {
            this.mParams.remove(str);
        } else {
            this.mParams.put(str, str2);
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setLastTrackTime(long j) {
        this.mLastTrackTime = j;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setTokens(long j) {
        this.mTokens = j;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public boolean tokensAvailable() {
        boolean z;
        synchronized (this) {
            long currentTimeMillis = System.currentTimeMillis();
            if (this.mTokens < MAX_TOKENS) {
                long j = currentTimeMillis - this.mLastTrackTime;
                if (j > 0) {
                    this.mTokens = Math.min((long) MAX_TOKENS, j + this.mTokens);
                }
            }
            this.mLastTrackTime = currentTimeMillis;
            if (this.mTokens >= 2000) {
                this.mTokens -= 2000;
                z = true;
            } else {
                Log.w("Excessive tracking detected.  Tracking call ignored.");
                z = false;
            }
        }
        return z;
    }
}

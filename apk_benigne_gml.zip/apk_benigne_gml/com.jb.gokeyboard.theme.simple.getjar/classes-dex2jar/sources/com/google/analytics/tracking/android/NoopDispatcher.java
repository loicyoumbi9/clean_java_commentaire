package com.google.analytics.tracking.android;

import android.text.TextUtils;
import java.util.List;

class NoopDispatcher implements Dispatcher {
    NoopDispatcher() {
    }

    @Override // com.google.analytics.tracking.android.Dispatcher
    public void close() {
    }

    @Override // com.google.analytics.tracking.android.Dispatcher
    public int dispatchHits(List<Hit> list) {
        if (list == null) {
            return 0;
        }
        int min = Math.min(list.size(), 40);
        if (Log.isVerbose()) {
            Log.v("Hits not actually being sent as dispatch is false...");
            for (int i = 0; i < min; i++) {
                String postProcessHit = TextUtils.isEmpty(list.get(i).getHitParams()) ? "" : HitBuilder.postProcessHit(list.get(i), System.currentTimeMillis());
                Log.v((TextUtils.isEmpty(postProcessHit) ? "Hit couldn't be read, wouldn't be sent:" : postProcessHit.length() <= 2036 ? "GET would be sent:" : postProcessHit.length() > 8192 ? "Would be too big:" : "POST would be sent:") + postProcessHit);
            }
        }
        return min;
    }

    @Override // com.google.analytics.tracking.android.Dispatcher
    public boolean okToDispatch() {
        return true;
    }

    @Override // com.google.analytics.tracking.android.Dispatcher
    public void overrideHostUrl(String str) {
    }
}

package com.google.analytics.tracking.android;

interface AnalyticsStoreStateListener {
    void reportStoreIsEmpty(boolean z);
}

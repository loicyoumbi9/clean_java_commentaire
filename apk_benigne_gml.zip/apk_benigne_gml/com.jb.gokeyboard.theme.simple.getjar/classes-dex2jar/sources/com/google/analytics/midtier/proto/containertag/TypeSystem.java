package com.google.analytics.midtier.proto.containertag;

import com.google.tagmanager.protobuf.AbstractMessageLite;
import com.google.tagmanager.protobuf.AbstractParser;
import com.google.tagmanager.protobuf.ByteString;
import com.google.tagmanager.protobuf.CodedInputStream;
import com.google.tagmanager.protobuf.CodedOutputStream;
import com.google.tagmanager.protobuf.ExtensionRegistryLite;
import com.google.tagmanager.protobuf.GeneratedMessageLite;
import com.google.tagmanager.protobuf.Internal;
import com.google.tagmanager.protobuf.InvalidProtocolBufferException;
import com.google.tagmanager.protobuf.MutableMessageLite;
import com.google.tagmanager.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class TypeSystem {

    public static final class Value extends GeneratedMessageLite.ExtendableMessage<Value> implements ValueOrBuilder {
        public static final int BOOLEAN_FIELD_NUMBER = 12;
        public static final int CONTAINS_REFERENCES_FIELD_NUMBER = 9;
        public static final int ESCAPING_FIELD_NUMBER = 10;
        public static final int FUNCTION_ID_FIELD_NUMBER = 7;
        public static final int INTEGER_FIELD_NUMBER = 8;
        public static final int LIST_ITEM_FIELD_NUMBER = 3;
        public static final int MACRO_REFERENCE_FIELD_NUMBER = 6;
        public static final int MAP_KEY_FIELD_NUMBER = 4;
        public static final int MAP_VALUE_FIELD_NUMBER = 5;
        public static Parser<Value> PARSER = new AbstractParser<Value>() {
            /* class com.google.analytics.midtier.proto.containertag.TypeSystem.Value.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public Value parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new Value(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int STRING_FIELD_NUMBER = 2;
        public static final int TEMPLATE_TOKEN_FIELD_NUMBER = 11;
        public static final int TYPE_FIELD_NUMBER = 1;
        private static final Value defaultInstance = new Value(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public boolean boolean_;
        /* access modifiers changed from: private */
        public boolean containsReferences_;
        /* access modifiers changed from: private */
        public List<Escaping> escaping_;
        /* access modifiers changed from: private */
        public Object functionId_;
        /* access modifiers changed from: private */
        public long integer_;
        /* access modifiers changed from: private */
        public List<Value> listItem_;
        /* access modifiers changed from: private */
        public Object macroReference_;
        /* access modifiers changed from: private */
        public List<Value> mapKey_;
        /* access modifiers changed from: private */
        public List<Value> mapValue_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public Object string_;
        /* access modifiers changed from: private */
        public List<Value> templateToken_;
        /* access modifiers changed from: private */
        public Type type_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.ExtendableBuilder<Value, Builder> implements ValueOrBuilder {
            private int bitField0_;
            private boolean boolean_;
            private boolean containsReferences_;
            private List<Escaping> escaping_ = Collections.emptyList();
            private Object functionId_ = "";
            private long integer_;
            private List<Value> listItem_ = Collections.emptyList();
            private Object macroReference_ = "";
            private List<Value> mapKey_ = Collections.emptyList();
            private List<Value> mapValue_ = Collections.emptyList();
            private Object string_ = "";
            private List<Value> templateToken_ = Collections.emptyList();
            private Type type_ = Type.STRING;

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void ensureEscapingIsMutable() {
                if ((this.bitField0_ & 1024) != 1024) {
                    this.escaping_ = new ArrayList(this.escaping_);
                    this.bitField0_ |= 1024;
                }
            }

            private void ensureListItemIsMutable() {
                if ((this.bitField0_ & 4) != 4) {
                    this.listItem_ = new ArrayList(this.listItem_);
                    this.bitField0_ |= 4;
                }
            }

            private void ensureMapKeyIsMutable() {
                if ((this.bitField0_ & 8) != 8) {
                    this.mapKey_ = new ArrayList(this.mapKey_);
                    this.bitField0_ |= 8;
                }
            }

            private void ensureMapValueIsMutable() {
                if ((this.bitField0_ & 16) != 16) {
                    this.mapValue_ = new ArrayList(this.mapValue_);
                    this.bitField0_ |= 16;
                }
            }

            private void ensureTemplateTokenIsMutable() {
                if ((this.bitField0_ & 512) != 512) {
                    this.templateToken_ = new ArrayList(this.templateToken_);
                    this.bitField0_ |= 512;
                }
            }

            private void maybeForceBuilderInitialization() {
            }

            public Builder addAllEscaping(Iterable<? extends Escaping> iterable) {
                ensureEscapingIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.escaping_);
                return this;
            }

            public Builder addAllListItem(Iterable<? extends Value> iterable) {
                ensureListItemIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.listItem_);
                return this;
            }

            public Builder addAllMapKey(Iterable<? extends Value> iterable) {
                ensureMapKeyIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.mapKey_);
                return this;
            }

            public Builder addAllMapValue(Iterable<? extends Value> iterable) {
                ensureMapValueIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.mapValue_);
                return this;
            }

            public Builder addAllTemplateToken(Iterable<? extends Value> iterable) {
                ensureTemplateTokenIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.templateToken_);
                return this;
            }

            public Builder addEscaping(Escaping escaping) {
                if (escaping == null) {
                    throw new NullPointerException();
                }
                ensureEscapingIsMutable();
                this.escaping_.add(escaping);
                return this;
            }

            public Builder addListItem(int i, Builder builder) {
                ensureListItemIsMutable();
                this.listItem_.add(i, builder.build());
                return this;
            }

            public Builder addListItem(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureListItemIsMutable();
                this.listItem_.add(i, value);
                return this;
            }

            public Builder addListItem(Builder builder) {
                ensureListItemIsMutable();
                this.listItem_.add(builder.build());
                return this;
            }

            public Builder addListItem(Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureListItemIsMutable();
                this.listItem_.add(value);
                return this;
            }

            public Builder addMapKey(int i, Builder builder) {
                ensureMapKeyIsMutable();
                this.mapKey_.add(i, builder.build());
                return this;
            }

            public Builder addMapKey(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapKeyIsMutable();
                this.mapKey_.add(i, value);
                return this;
            }

            public Builder addMapKey(Builder builder) {
                ensureMapKeyIsMutable();
                this.mapKey_.add(builder.build());
                return this;
            }

            public Builder addMapKey(Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapKeyIsMutable();
                this.mapKey_.add(value);
                return this;
            }

            public Builder addMapValue(int i, Builder builder) {
                ensureMapValueIsMutable();
                this.mapValue_.add(i, builder.build());
                return this;
            }

            public Builder addMapValue(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapValueIsMutable();
                this.mapValue_.add(i, value);
                return this;
            }

            public Builder addMapValue(Builder builder) {
                ensureMapValueIsMutable();
                this.mapValue_.add(builder.build());
                return this;
            }

            public Builder addMapValue(Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapValueIsMutable();
                this.mapValue_.add(value);
                return this;
            }

            public Builder addTemplateToken(int i, Builder builder) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.add(i, builder.build());
                return this;
            }

            public Builder addTemplateToken(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureTemplateTokenIsMutable();
                this.templateToken_.add(i, value);
                return this;
            }

            public Builder addTemplateToken(Builder builder) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.add(builder.build());
                return this;
            }

            public Builder addTemplateToken(Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureTemplateTokenIsMutable();
                this.templateToken_.add(value);
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Value build() {
                Value buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Value buildPartial() {
                int i = 1;
                Value value = new Value(this);
                int i2 = this.bitField0_;
                if ((i2 & 1) != 1) {
                    i = 0;
                }
                Type unused = value.type_ = this.type_;
                if ((i2 & 2) == 2) {
                    i |= 2;
                }
                Object unused2 = value.string_ = this.string_;
                if ((this.bitField0_ & 4) == 4) {
                    this.listItem_ = Collections.unmodifiableList(this.listItem_);
                    this.bitField0_ &= -5;
                }
                List unused3 = value.listItem_ = this.listItem_;
                if ((this.bitField0_ & 8) == 8) {
                    this.mapKey_ = Collections.unmodifiableList(this.mapKey_);
                    this.bitField0_ &= -9;
                }
                List unused4 = value.mapKey_ = this.mapKey_;
                if ((this.bitField0_ & 16) == 16) {
                    this.mapValue_ = Collections.unmodifiableList(this.mapValue_);
                    this.bitField0_ &= -17;
                }
                List unused5 = value.mapValue_ = this.mapValue_;
                if ((i2 & 32) == 32) {
                    i |= 4;
                }
                Object unused6 = value.macroReference_ = this.macroReference_;
                if ((i2 & 64) == 64) {
                    i |= 8;
                }
                Object unused7 = value.functionId_ = this.functionId_;
                if ((i2 & 128) == 128) {
                    i |= 16;
                }
                long unused8 = value.integer_ = this.integer_;
                if ((i2 & 256) == 256) {
                    i |= 32;
                }
                boolean unused9 = value.boolean_ = this.boolean_;
                if ((this.bitField0_ & 512) == 512) {
                    this.templateToken_ = Collections.unmodifiableList(this.templateToken_);
                    this.bitField0_ &= -513;
                }
                List unused10 = value.templateToken_ = this.templateToken_;
                if ((this.bitField0_ & 1024) == 1024) {
                    this.escaping_ = Collections.unmodifiableList(this.escaping_);
                    this.bitField0_ &= -1025;
                }
                List unused11 = value.escaping_ = this.escaping_;
                if ((i2 & 2048) == 2048) {
                    i |= 64;
                }
                boolean unused12 = value.containsReferences_ = this.containsReferences_;
                int unused13 = value.bitField0_ = i;
                return value;
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.type_ = Type.STRING;
                this.bitField0_ &= -2;
                this.string_ = "";
                this.bitField0_ &= -3;
                this.listItem_ = Collections.emptyList();
                this.bitField0_ &= -5;
                this.mapKey_ = Collections.emptyList();
                this.bitField0_ &= -9;
                this.mapValue_ = Collections.emptyList();
                this.bitField0_ &= -17;
                this.macroReference_ = "";
                this.bitField0_ &= -33;
                this.functionId_ = "";
                this.bitField0_ &= -65;
                this.integer_ = 0;
                this.bitField0_ &= -129;
                this.boolean_ = false;
                this.bitField0_ &= -257;
                this.templateToken_ = Collections.emptyList();
                this.bitField0_ &= -513;
                this.escaping_ = Collections.emptyList();
                this.bitField0_ &= -1025;
                this.containsReferences_ = false;
                this.bitField0_ &= -2049;
                return this;
            }

            public Builder clearBoolean() {
                this.bitField0_ &= -257;
                this.boolean_ = false;
                return this;
            }

            public Builder clearContainsReferences() {
                this.bitField0_ &= -2049;
                this.containsReferences_ = false;
                return this;
            }

            public Builder clearEscaping() {
                this.escaping_ = Collections.emptyList();
                this.bitField0_ &= -1025;
                return this;
            }

            public Builder clearFunctionId() {
                this.bitField0_ &= -65;
                this.functionId_ = Value.getDefaultInstance().getFunctionId();
                return this;
            }

            public Builder clearInteger() {
                this.bitField0_ &= -129;
                this.integer_ = 0;
                return this;
            }

            public Builder clearListItem() {
                this.listItem_ = Collections.emptyList();
                this.bitField0_ &= -5;
                return this;
            }

            public Builder clearMacroReference() {
                this.bitField0_ &= -33;
                this.macroReference_ = Value.getDefaultInstance().getMacroReference();
                return this;
            }

            public Builder clearMapKey() {
                this.mapKey_ = Collections.emptyList();
                this.bitField0_ &= -9;
                return this;
            }

            public Builder clearMapValue() {
                this.mapValue_ = Collections.emptyList();
                this.bitField0_ &= -17;
                return this;
            }

            public Builder clearString() {
                this.bitField0_ &= -3;
                this.string_ = Value.getDefaultInstance().getString();
                return this;
            }

            public Builder clearTemplateToken() {
                this.templateToken_ = Collections.emptyList();
                this.bitField0_ &= -513;
                return this;
            }

            public Builder clearType() {
                this.bitField0_ &= -2;
                this.type_ = Type.STRING;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.GeneratedMessageLite.ExtendableBuilder, com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean getBoolean() {
                return this.boolean_;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean getContainsReferences() {
                return this.containsReferences_;
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public Value getDefaultInstanceForType() {
                return Value.getDefaultInstance();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Escaping getEscaping(int i) {
                return this.escaping_.get(i);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public int getEscapingCount() {
                return this.escaping_.size();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public List<Escaping> getEscapingList() {
                return Collections.unmodifiableList(this.escaping_);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public String getFunctionId() {
                Object obj = this.functionId_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.functionId_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public ByteString getFunctionIdBytes() {
                Object obj = this.functionId_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.functionId_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public long getInteger() {
                return this.integer_;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Value getListItem(int i) {
                return this.listItem_.get(i);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public int getListItemCount() {
                return this.listItem_.size();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public List<Value> getListItemList() {
                return Collections.unmodifiableList(this.listItem_);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public String getMacroReference() {
                Object obj = this.macroReference_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.macroReference_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public ByteString getMacroReferenceBytes() {
                Object obj = this.macroReference_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.macroReference_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Value getMapKey(int i) {
                return this.mapKey_.get(i);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public int getMapKeyCount() {
                return this.mapKey_.size();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public List<Value> getMapKeyList() {
                return Collections.unmodifiableList(this.mapKey_);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Value getMapValue(int i) {
                return this.mapValue_.get(i);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public int getMapValueCount() {
                return this.mapValue_.size();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public List<Value> getMapValueList() {
                return Collections.unmodifiableList(this.mapValue_);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public String getString() {
                Object obj = this.string_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.string_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public ByteString getStringBytes() {
                Object obj = this.string_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.string_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Value getTemplateToken(int i) {
                return this.templateToken_.get(i);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public int getTemplateTokenCount() {
                return this.templateToken_.size();
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public List<Value> getTemplateTokenList() {
                return Collections.unmodifiableList(this.templateToken_);
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public Type getType() {
                return this.type_;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasBoolean() {
                return (this.bitField0_ & 256) == 256;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasContainsReferences() {
                return (this.bitField0_ & 2048) == 2048;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasFunctionId() {
                return (this.bitField0_ & 64) == 64;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasInteger() {
                return (this.bitField0_ & 128) == 128;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasMacroReference() {
                return (this.bitField0_ & 32) == 32;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasString() {
                return (this.bitField0_ & 2) == 2;
            }

            @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
            public boolean hasType() {
                return (this.bitField0_ & 1) == 1;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                if (!hasType()) {
                    return false;
                }
                for (int i = 0; i < getListItemCount(); i++) {
                    if (!getListItem(i).isInitialized()) {
                        return false;
                    }
                }
                for (int i2 = 0; i2 < getMapKeyCount(); i2++) {
                    if (!getMapKey(i2).isInitialized()) {
                        return false;
                    }
                }
                for (int i3 = 0; i3 < getMapValueCount(); i3++) {
                    if (!getMapValue(i3).isInitialized()) {
                        return false;
                    }
                }
                for (int i4 = 0; i4 < getTemplateTokenCount(); i4++) {
                    if (!getTemplateToken(i4).isInitialized()) {
                        return false;
                    }
                }
                return extensionsAreInitialized();
            }

            public Builder mergeFrom(Value value) {
                if (value != Value.getDefaultInstance()) {
                    if (value.hasType()) {
                        setType(value.getType());
                    }
                    if (value.hasString()) {
                        this.bitField0_ |= 2;
                        this.string_ = value.string_;
                    }
                    if (!value.listItem_.isEmpty()) {
                        if (this.listItem_.isEmpty()) {
                            this.listItem_ = value.listItem_;
                            this.bitField0_ &= -5;
                        } else {
                            ensureListItemIsMutable();
                            this.listItem_.addAll(value.listItem_);
                        }
                    }
                    if (!value.mapKey_.isEmpty()) {
                        if (this.mapKey_.isEmpty()) {
                            this.mapKey_ = value.mapKey_;
                            this.bitField0_ &= -9;
                        } else {
                            ensureMapKeyIsMutable();
                            this.mapKey_.addAll(value.mapKey_);
                        }
                    }
                    if (!value.mapValue_.isEmpty()) {
                        if (this.mapValue_.isEmpty()) {
                            this.mapValue_ = value.mapValue_;
                            this.bitField0_ &= -17;
                        } else {
                            ensureMapValueIsMutable();
                            this.mapValue_.addAll(value.mapValue_);
                        }
                    }
                    if (value.hasMacroReference()) {
                        this.bitField0_ |= 32;
                        this.macroReference_ = value.macroReference_;
                    }
                    if (value.hasFunctionId()) {
                        this.bitField0_ |= 64;
                        this.functionId_ = value.functionId_;
                    }
                    if (value.hasInteger()) {
                        setInteger(value.getInteger());
                    }
                    if (value.hasBoolean()) {
                        setBoolean(value.getBoolean());
                    }
                    if (!value.templateToken_.isEmpty()) {
                        if (this.templateToken_.isEmpty()) {
                            this.templateToken_ = value.templateToken_;
                            this.bitField0_ &= -513;
                        } else {
                            ensureTemplateTokenIsMutable();
                            this.templateToken_.addAll(value.templateToken_);
                        }
                    }
                    if (!value.escaping_.isEmpty()) {
                        if (this.escaping_.isEmpty()) {
                            this.escaping_ = value.escaping_;
                            this.bitField0_ &= -1025;
                        } else {
                            ensureEscapingIsMutable();
                            this.escaping_.addAll(value.escaping_);
                        }
                    }
                    if (value.hasContainsReferences()) {
                        setContainsReferences(value.getContainsReferences());
                    }
                    mergeExtensionFields(value);
                    setUnknownFields(getUnknownFields().concat(value.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                Value value;
                Value value2 = null;
                try {
                    Value parsePartialFrom = Value.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    value = (Value) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    value2 = value;
                }
                if (value2 != null) {
                    mergeFrom(value2);
                }
                throw th;
            }

            public Builder removeListItem(int i) {
                ensureListItemIsMutable();
                this.listItem_.remove(i);
                return this;
            }

            public Builder removeMapKey(int i) {
                ensureMapKeyIsMutable();
                this.mapKey_.remove(i);
                return this;
            }

            public Builder removeMapValue(int i) {
                ensureMapValueIsMutable();
                this.mapValue_.remove(i);
                return this;
            }

            public Builder removeTemplateToken(int i) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.remove(i);
                return this;
            }

            public Builder setBoolean(boolean z) {
                this.bitField0_ |= 256;
                this.boolean_ = z;
                return this;
            }

            public Builder setContainsReferences(boolean z) {
                this.bitField0_ |= 2048;
                this.containsReferences_ = z;
                return this;
            }

            public Builder setEscaping(int i, Escaping escaping) {
                if (escaping == null) {
                    throw new NullPointerException();
                }
                ensureEscapingIsMutable();
                this.escaping_.set(i, escaping);
                return this;
            }

            public Builder setFunctionId(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 64;
                this.functionId_ = str;
                return this;
            }

            public Builder setFunctionIdBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 64;
                this.functionId_ = byteString;
                return this;
            }

            public Builder setInteger(long j) {
                this.bitField0_ |= 128;
                this.integer_ = j;
                return this;
            }

            public Builder setListItem(int i, Builder builder) {
                ensureListItemIsMutable();
                this.listItem_.set(i, builder.build());
                return this;
            }

            public Builder setListItem(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureListItemIsMutable();
                this.listItem_.set(i, value);
                return this;
            }

            public Builder setMacroReference(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 32;
                this.macroReference_ = str;
                return this;
            }

            public Builder setMacroReferenceBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 32;
                this.macroReference_ = byteString;
                return this;
            }

            public Builder setMapKey(int i, Builder builder) {
                ensureMapKeyIsMutable();
                this.mapKey_.set(i, builder.build());
                return this;
            }

            public Builder setMapKey(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapKeyIsMutable();
                this.mapKey_.set(i, value);
                return this;
            }

            public Builder setMapValue(int i, Builder builder) {
                ensureMapValueIsMutable();
                this.mapValue_.set(i, builder.build());
                return this;
            }

            public Builder setMapValue(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureMapValueIsMutable();
                this.mapValue_.set(i, value);
                return this;
            }

            public Builder setString(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 2;
                this.string_ = str;
                return this;
            }

            public Builder setStringBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 2;
                this.string_ = byteString;
                return this;
            }

            public Builder setTemplateToken(int i, Builder builder) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.set(i, builder.build());
                return this;
            }

            public Builder setTemplateToken(int i, Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureTemplateTokenIsMutable();
                this.templateToken_.set(i, value);
                return this;
            }

            public Builder setType(Type type) {
                if (type == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 1;
                this.type_ = type;
                return this;
            }
        }

        public enum Escaping implements Internal.EnumLite {
            ESCAPE_HTML(0, 1),
            ESCAPE_HTML_RCDATA(1, 2),
            ESCAPE_HTML_ATTRIBUTE(2, 3),
            ESCAPE_HTML_ATTRIBUTE_NOSPACE(3, 4),
            FILTER_HTML_ELEMENT_NAME(4, 5),
            FILTER_HTML_ATTRIBUTES(5, 6),
            ESCAPE_JS_STRING(6, 7),
            ESCAPE_JS_VALUE(7, 8),
            ESCAPE_JS_REGEX(8, 9),
            ESCAPE_CSS_STRING(9, 10),
            FILTER_CSS_VALUE(10, 11),
            ESCAPE_URI(11, 12),
            NORMALIZE_URI(12, 13),
            FILTER_NORMALIZE_URI(13, 14),
            NO_AUTOESCAPE(14, 15),
            TEXT(15, 17),
            CONVERT_JS_VALUE_TO_EXPRESSION(16, 16);
            
            public static final int CONVERT_JS_VALUE_TO_EXPRESSION_VALUE = 16;
            public static final int ESCAPE_CSS_STRING_VALUE = 10;
            public static final int ESCAPE_HTML_ATTRIBUTE_NOSPACE_VALUE = 4;
            public static final int ESCAPE_HTML_ATTRIBUTE_VALUE = 3;
            public static final int ESCAPE_HTML_RCDATA_VALUE = 2;
            public static final int ESCAPE_HTML_VALUE = 1;
            public static final int ESCAPE_JS_REGEX_VALUE = 9;
            public static final int ESCAPE_JS_STRING_VALUE = 7;
            public static final int ESCAPE_JS_VALUE_VALUE = 8;
            public static final int ESCAPE_URI_VALUE = 12;
            public static final int FILTER_CSS_VALUE_VALUE = 11;
            public static final int FILTER_HTML_ATTRIBUTES_VALUE = 6;
            public static final int FILTER_HTML_ELEMENT_NAME_VALUE = 5;
            public static final int FILTER_NORMALIZE_URI_VALUE = 14;
            public static final int NORMALIZE_URI_VALUE = 13;
            public static final int NO_AUTOESCAPE_VALUE = 15;
            public static final int TEXT_VALUE = 17;
            private static Internal.EnumLiteMap<Escaping> internalValueMap = new Internal.EnumLiteMap<Escaping>() {
                /* class com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping.AnonymousClass1 */

                @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
                public Escaping findValueByNumber(int i) {
                    return Escaping.valueOf(i);
                }
            };
            private final int value;

            private Escaping(int i, int i2) {
                this.value = i2;
            }

            public static Internal.EnumLiteMap<Escaping> internalGetValueMap() {
                return internalValueMap;
            }

            public static Escaping valueOf(int i) {
                switch (i) {
                    case 1:
                        return ESCAPE_HTML;
                    case 2:
                        return ESCAPE_HTML_RCDATA;
                    case 3:
                        return ESCAPE_HTML_ATTRIBUTE;
                    case 4:
                        return ESCAPE_HTML_ATTRIBUTE_NOSPACE;
                    case 5:
                        return FILTER_HTML_ELEMENT_NAME;
                    case 6:
                        return FILTER_HTML_ATTRIBUTES;
                    case 7:
                        return ESCAPE_JS_STRING;
                    case 8:
                        return ESCAPE_JS_VALUE;
                    case 9:
                        return ESCAPE_JS_REGEX;
                    case 10:
                        return ESCAPE_CSS_STRING;
                    case 11:
                        return FILTER_CSS_VALUE;
                    case 12:
                        return ESCAPE_URI;
                    case 13:
                        return NORMALIZE_URI;
                    case 14:
                        return FILTER_NORMALIZE_URI;
                    case 15:
                        return NO_AUTOESCAPE;
                    case 16:
                        return CONVERT_JS_VALUE_TO_EXPRESSION;
                    case 17:
                        return TEXT;
                    default:
                        return null;
                }
            }

            @Override // com.google.tagmanager.protobuf.Internal.EnumLite
            public final int getNumber() {
                return this.value;
            }
        }

        public enum Type implements Internal.EnumLite {
            STRING(0, 1),
            LIST(1, 2),
            MAP(2, 3),
            MACRO_REFERENCE(3, 4),
            FUNCTION_ID(4, 5),
            INTEGER(5, 6),
            TEMPLATE(6, 7),
            BOOLEAN(7, 8);
            
            public static final int BOOLEAN_VALUE = 8;
            public static final int FUNCTION_ID_VALUE = 5;
            public static final int INTEGER_VALUE = 6;
            public static final int LIST_VALUE = 2;
            public static final int MACRO_REFERENCE_VALUE = 4;
            public static final int MAP_VALUE = 3;
            public static final int STRING_VALUE = 1;
            public static final int TEMPLATE_VALUE = 7;
            private static Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap<Type>() {
                /* class com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Type.AnonymousClass1 */

                @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
                public Type findValueByNumber(int i) {
                    return Type.valueOf(i);
                }
            };
            private final int value;

            private Type(int i, int i2) {
                this.value = i2;
            }

            public static Internal.EnumLiteMap<Type> internalGetValueMap() {
                return internalValueMap;
            }

            public static Type valueOf(int i) {
                switch (i) {
                    case 1:
                        return STRING;
                    case 2:
                        return LIST;
                    case 3:
                        return MAP;
                    case 4:
                        return MACRO_REFERENCE;
                    case 5:
                        return FUNCTION_ID;
                    case 6:
                        return INTEGER;
                    case 7:
                        return TEMPLATE;
                    case 8:
                        return BOOLEAN;
                    default:
                        return null;
                }
            }

            @Override // com.google.tagmanager.protobuf.Internal.EnumLite
            public final int getNumber() {
                return this.value;
            }
        }

        static {
            defaultInstance.initFields();
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v21, resolved type: java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v24, resolved type: java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v27, resolved type: java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:19:0x004d  */
        /* JADX WARNING: Removed duplicated region for block: B:22:0x0059  */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x0065  */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x0071  */
        /* JADX WARNING: Removed duplicated region for block: B:31:0x007d  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private Value(com.google.tagmanager.protobuf.CodedInputStream r14, com.google.tagmanager.protobuf.ExtensionRegistryLite r15) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
            /*
                r13 = this;
                r12 = 512(0x200, float:7.175E-43)
                r11 = 16
                r10 = 8
                r9 = 4
                r8 = 1024(0x400, float:1.435E-42)
                r13.<init>()
                r0 = -1
                r13.memoizedIsInitialized = r0
                r0 = -1
                r13.memoizedSerializedSize = r0
                r13.initFields()
                r0 = 0
                com.google.tagmanager.protobuf.ByteString$Output r3 = com.google.tagmanager.protobuf.ByteString.newOutput()
                com.google.tagmanager.protobuf.CodedOutputStream r4 = com.google.tagmanager.protobuf.CodedOutputStream.newInstance(r3)
                r1 = 0
            L_0x001f:
                if (r1 != 0) goto L_0x01c7
                int r2 = r14.readTag()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                switch(r2) {
                    case 0: goto L_0x0231;
                    case 8: goto L_0x0030;
                    case 18: goto L_0x00ae;
                    case 26: goto L_0x00bc;
                    case 34: goto L_0x00d6;
                    case 42: goto L_0x00f0;
                    case 50: goto L_0x010a;
                    case 58: goto L_0x0118;
                    case 64: goto L_0x0126;
                    case 72: goto L_0x0134;
                    case 80: goto L_0x0142;
                    case 82: goto L_0x0168;
                    case 90: goto L_0x019f;
                    case 96: goto L_0x01b9;
                    default: goto L_0x0028;
                }     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
            L_0x0028:
                boolean r2 = r13.parseUnknownField(r14, r4, r15, r2)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                if (r2 != 0) goto L_0x001f
                r1 = 1
                goto L_0x001f
            L_0x0030:
                int r5 = r14.readEnum()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Type r6 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Type.valueOf(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                if (r6 != 0) goto L_0x0092
                r4.writeRawVarint32(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r4.writeRawVarint32(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0041:
                r1 = move-exception
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r1 = r1.setUnfinishedMessage(r13)     // Catch:{ all -> 0x0047 }
                throw r1     // Catch:{ all -> 0x0047 }
            L_0x0047:
                r1 = move-exception
                r2 = r0
            L_0x0049:
                r0 = r2 & 4
                if (r0 != r9) goto L_0x0055
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r13.listItem_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.listItem_ = r0
            L_0x0055:
                r0 = r2 & 8
                if (r0 != r10) goto L_0x0061
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r13.mapKey_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.mapKey_ = r0
            L_0x0061:
                r0 = r2 & 16
                if (r0 != r11) goto L_0x006d
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r13.mapValue_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.mapValue_ = r0
            L_0x006d:
                r0 = r2 & 1024(0x400, float:1.435E-42)
                if (r0 != r8) goto L_0x0079
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping> r0 = r13.escaping_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.escaping_ = r0
            L_0x0079:
                r0 = r2 & 512(0x200, float:7.175E-43)
                if (r0 != r12) goto L_0x0085
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r13.templateToken_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.templateToken_ = r0
            L_0x0085:
                r4.flush()     // Catch:{ IOException -> 0x0220, all -> 0x0229 }
                com.google.tagmanager.protobuf.ByteString r0 = r3.toByteString()
                r13.unknownFields = r0
            L_0x008e:
                r13.makeExtensionsImmutable()
                throw r1
            L_0x0092:
                int r2 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2 = r2 | 1
                r13.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.type_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x009b:
                r1 = move-exception
                r2 = r0
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = new com.google.tagmanager.protobuf.InvalidProtocolBufferException     // Catch:{ all -> 0x00ab }
                java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x00ab }
                r0.<init>(r1)     // Catch:{ all -> 0x00ab }
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r0.setUnfinishedMessage(r13)     // Catch:{ all -> 0x00ab }
                throw r0     // Catch:{ all -> 0x00ab }
            L_0x00ab:
                r0 = move-exception
                r1 = r0
                goto L_0x0049
            L_0x00ae:
                com.google.tagmanager.protobuf.ByteString r2 = r14.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                int r5 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r5 = r5 | 2
                r13.bitField0_ = r5     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.string_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x00bc:
                r2 = r0 & 4
                if (r2 == r9) goto L_0x00c9
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.listItem_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 4
            L_0x00c9:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r2 = r13.listItem_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r5 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.MessageLite r5 = r14.readMessage(r5, r15)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.add(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x00d6:
                r2 = r0 & 8
                if (r2 == r10) goto L_0x00e3
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.mapKey_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 8
            L_0x00e3:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r2 = r13.mapKey_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r5 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.MessageLite r5 = r14.readMessage(r5, r15)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.add(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x00f0:
                r2 = r0 & 16
                if (r2 == r11) goto L_0x00fd
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.mapValue_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 16
            L_0x00fd:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r2 = r13.mapValue_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r5 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.MessageLite r5 = r14.readMessage(r5, r15)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.add(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x010a:
                com.google.tagmanager.protobuf.ByteString r2 = r14.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                int r5 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r5 = r5 | 4
                r13.bitField0_ = r5     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.macroReference_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0118:
                com.google.tagmanager.protobuf.ByteString r2 = r14.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                int r5 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r5 = r5 | 8
                r13.bitField0_ = r5     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.functionId_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0126:
                int r2 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2 = r2 | 16
                r13.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                long r6 = r14.readInt64()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.integer_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0134:
                int r2 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2 = r2 | 64
                r13.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                boolean r2 = r14.readBool()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.containsReferences_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0142:
                int r5 = r14.readEnum()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping r6 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping.valueOf(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                if (r6 != 0) goto L_0x0154
                r4.writeRawVarint32(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r4.writeRawVarint32(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0154:
                r2 = r0 & 1024(0x400, float:1.435E-42)
                if (r2 == r8) goto L_0x0161
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.escaping_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 1024(0x400, float:1.435E-42)
            L_0x0161:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping> r2 = r13.escaping_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x0168:
                int r5 = r14.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                int r5 = r14.pushLimit(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
            L_0x0170:
                int r6 = r14.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                if (r6 <= 0) goto L_0x019a
                int r6 = r14.readEnum()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping r7 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                if (r7 != 0) goto L_0x0187
                r4.writeRawVarint32(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r4.writeRawVarint32(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x0170
            L_0x0187:
                r6 = r0 & 1024(0x400, float:1.435E-42)
                if (r6 == r8) goto L_0x0194
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.escaping_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 1024(0x400, float:1.435E-42)
            L_0x0194:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping> r6 = r13.escaping_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x0170
            L_0x019a:
                r14.popLimit(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x019f:
                r2 = r0 & 512(0x200, float:7.175E-43)
                if (r2 == r12) goto L_0x01ac
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.templateToken_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r0 = r0 | 512(0x200, float:7.175E-43)
            L_0x01ac:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r2 = r13.templateToken_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r5 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                com.google.tagmanager.protobuf.MessageLite r5 = r14.readMessage(r5, r15)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2.add(r5)     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x01b9:
                int r2 = r13.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r2 = r2 | 32
                r13.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                boolean r2 = r14.readBool()     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                r13.boolean_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0041, IOException -> 0x009b }
                goto L_0x001f
            L_0x01c7:
                r1 = r0 & 4
                if (r1 != r9) goto L_0x01d3
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r1 = r13.listItem_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r13.listItem_ = r1
            L_0x01d3:
                r1 = r0 & 8
                if (r1 != r10) goto L_0x01df
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r1 = r13.mapKey_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r13.mapKey_ = r1
            L_0x01df:
                r1 = r0 & 16
                if (r1 != r11) goto L_0x01eb
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r1 = r13.mapValue_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r13.mapValue_ = r1
            L_0x01eb:
                r1 = r0 & 1024(0x400, float:1.435E-42)
                if (r1 != r8) goto L_0x01f7
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value$Escaping> r1 = r13.escaping_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r13.escaping_ = r1
            L_0x01f7:
                r0 = r0 & 512(0x200, float:7.175E-43)
                if (r0 != r12) goto L_0x0203
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r13.templateToken_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r13.templateToken_ = r0
            L_0x0203:
                r4.flush()     // Catch:{ IOException -> 0x0210, all -> 0x0218 }
                com.google.tagmanager.protobuf.ByteString r0 = r3.toByteString()
                r13.unknownFields = r0
            L_0x020c:
                r13.makeExtensionsImmutable()
                return
            L_0x0210:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r3.toByteString()
                r13.unknownFields = r0
                goto L_0x020c
            L_0x0218:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r3.toByteString()
                r13.unknownFields = r1
                throw r0
            L_0x0220:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r3.toByteString()
                r13.unknownFields = r0
                goto L_0x008e
            L_0x0229:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r3.toByteString()
                r13.unknownFields = r1
                throw r0
            L_0x0231:
                r1 = 1
                goto L_0x001f
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.midtier.proto.containertag.TypeSystem.Value.<init>(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):void");
        }

        private Value(GeneratedMessageLite.ExtendableBuilder<Value, ?> extendableBuilder) {
            super(extendableBuilder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = extendableBuilder.getUnknownFields();
        }

        private Value(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static Value getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.type_ = Type.STRING;
            this.string_ = "";
            this.listItem_ = Collections.emptyList();
            this.mapKey_ = Collections.emptyList();
            this.mapValue_ = Collections.emptyList();
            this.macroReference_ = "";
            this.functionId_ = "";
            this.integer_ = 0;
            this.boolean_ = false;
            this.templateToken_ = Collections.emptyList();
            this.escaping_ = Collections.emptyList();
            this.containsReferences_ = false;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(Value value) {
            return newBuilder().mergeFrom(value);
        }

        public static Value parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static Value parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static Value parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static Value parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static Value parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static Value parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static Value parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static Value parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static Value parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static Value parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Value)) {
                return super.equals(obj);
            }
            Value value = (Value) obj;
            boolean z = hasType() == value.hasType();
            if (hasType()) {
                z = z && getType() == value.getType();
            }
            boolean z2 = z && hasString() == value.hasString();
            if (hasString()) {
                z2 = z2 && getString().equals(value.getString());
            }
            boolean z3 = (((z2 && getListItemList().equals(value.getListItemList())) && getMapKeyList().equals(value.getMapKeyList())) && getMapValueList().equals(value.getMapValueList())) && hasMacroReference() == value.hasMacroReference();
            if (hasMacroReference()) {
                z3 = z3 && getMacroReference().equals(value.getMacroReference());
            }
            boolean z4 = z3 && hasFunctionId() == value.hasFunctionId();
            if (hasFunctionId()) {
                z4 = z4 && getFunctionId().equals(value.getFunctionId());
            }
            boolean z5 = z4 && hasInteger() == value.hasInteger();
            if (hasInteger()) {
                z5 = z5 && getInteger() == value.getInteger();
            }
            boolean z6 = z5 && hasBoolean() == value.hasBoolean();
            if (hasBoolean()) {
                z6 = z6 && getBoolean() == value.getBoolean();
            }
            boolean z7 = ((z6 && getTemplateTokenList().equals(value.getTemplateTokenList())) && getEscapingList().equals(value.getEscapingList())) && hasContainsReferences() == value.hasContainsReferences();
            return hasContainsReferences() ? z7 && getContainsReferences() == value.getContainsReferences() : z7;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean getBoolean() {
            return this.boolean_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean getContainsReferences() {
            return this.containsReferences_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public Value getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Escaping getEscaping(int i) {
            return this.escaping_.get(i);
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public int getEscapingCount() {
            return this.escaping_.size();
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public List<Escaping> getEscapingList() {
            return this.escaping_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public String getFunctionId() {
            Object obj = this.functionId_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.functionId_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public ByteString getFunctionIdBytes() {
            Object obj = this.functionId_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.functionId_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public long getInteger() {
            return this.integer_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Value getListItem(int i) {
            return this.listItem_.get(i);
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public int getListItemCount() {
            return this.listItem_.size();
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public List<Value> getListItemList() {
            return this.listItem_;
        }

        public ValueOrBuilder getListItemOrBuilder(int i) {
            return this.listItem_.get(i);
        }

        public List<? extends ValueOrBuilder> getListItemOrBuilderList() {
            return this.listItem_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public String getMacroReference() {
            Object obj = this.macroReference_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.macroReference_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public ByteString getMacroReferenceBytes() {
            Object obj = this.macroReference_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.macroReference_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Value getMapKey(int i) {
            return this.mapKey_.get(i);
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public int getMapKeyCount() {
            return this.mapKey_.size();
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public List<Value> getMapKeyList() {
            return this.mapKey_;
        }

        public ValueOrBuilder getMapKeyOrBuilder(int i) {
            return this.mapKey_.get(i);
        }

        public List<? extends ValueOrBuilder> getMapKeyOrBuilderList() {
            return this.mapKey_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Value getMapValue(int i) {
            return this.mapValue_.get(i);
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public int getMapValueCount() {
            return this.mapValue_.size();
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public List<Value> getMapValueList() {
            return this.mapValue_;
        }

        public ValueOrBuilder getMapValueOrBuilder(int i) {
            return this.mapValue_.get(i);
        }

        public List<? extends ValueOrBuilder> getMapValueOrBuilderList() {
            return this.mapValue_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<Value> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            int i2 = 0;
            int i3 = this.memoizedSerializedSize;
            if (i3 != -1) {
                return i3;
            }
            int computeEnumSize = (this.bitField0_ & 1) == 1 ? CodedOutputStream.computeEnumSize(1, this.type_.getNumber()) + 0 : 0;
            if ((this.bitField0_ & 2) == 2) {
                computeEnumSize += CodedOutputStream.computeBytesSize(2, getStringBytes());
            }
            int i4 = computeEnumSize;
            for (int i5 = 0; i5 < this.listItem_.size(); i5++) {
                i4 += CodedOutputStream.computeMessageSize(3, this.listItem_.get(i5));
            }
            for (int i6 = 0; i6 < this.mapKey_.size(); i6++) {
                i4 += CodedOutputStream.computeMessageSize(4, this.mapKey_.get(i6));
            }
            for (int i7 = 0; i7 < this.mapValue_.size(); i7++) {
                i4 += CodedOutputStream.computeMessageSize(5, this.mapValue_.get(i7));
            }
            if ((this.bitField0_ & 4) == 4) {
                i4 += CodedOutputStream.computeBytesSize(6, getMacroReferenceBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                i4 += CodedOutputStream.computeBytesSize(7, getFunctionIdBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                i4 += CodedOutputStream.computeInt64Size(8, this.integer_);
            }
            if ((this.bitField0_ & 64) == 64) {
                i4 += CodedOutputStream.computeBoolSize(9, this.containsReferences_);
            }
            int i8 = 0;
            int i9 = 0;
            while (i9 < this.escaping_.size()) {
                i9++;
                i8 = CodedOutputStream.computeEnumSizeNoTag(this.escaping_.get(i9).getNumber()) + i8;
            }
            int size = i4 + i8 + (this.escaping_.size() * 1);
            while (true) {
                i = size;
                if (i2 >= this.templateToken_.size()) {
                    break;
                }
                size = CodedOutputStream.computeMessageSize(11, this.templateToken_.get(i2)) + i;
                i2++;
            }
            if ((this.bitField0_ & 32) == 32) {
                i += CodedOutputStream.computeBoolSize(12, this.boolean_);
            }
            int extensionsSerializedSize = extensionsSerializedSize() + i + this.unknownFields.size();
            this.memoizedSerializedSize = extensionsSerializedSize;
            return extensionsSerializedSize;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public String getString() {
            Object obj = this.string_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.string_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public ByteString getStringBytes() {
            Object obj = this.string_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.string_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Value getTemplateToken(int i) {
            return this.templateToken_.get(i);
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public int getTemplateTokenCount() {
            return this.templateToken_.size();
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public List<Value> getTemplateTokenList() {
            return this.templateToken_;
        }

        public ValueOrBuilder getTemplateTokenOrBuilder(int i) {
            return this.templateToken_.get(i);
        }

        public List<? extends ValueOrBuilder> getTemplateTokenOrBuilderList() {
            return this.templateToken_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public Type getType() {
            return this.type_;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasBoolean() {
            return (this.bitField0_ & 32) == 32;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasContainsReferences() {
            return (this.bitField0_ & 64) == 64;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasFunctionId() {
            return (this.bitField0_ & 8) == 8;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasInteger() {
            return (this.bitField0_ & 16) == 16;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasMacroReference() {
            return (this.bitField0_ & 4) == 4;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasString() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.midtier.proto.containertag.TypeSystem.ValueOrBuilder
        public boolean hasType() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = Value.class.hashCode() + 779;
            if (hasType()) {
                hashCode = (((hashCode * 37) + 1) * 53) + Internal.hashEnum(getType());
            }
            if (hasString()) {
                hashCode = (((hashCode * 37) + 2) * 53) + getString().hashCode();
            }
            if (getListItemCount() > 0) {
                hashCode = (((hashCode * 37) + 3) * 53) + getListItemList().hashCode();
            }
            if (getMapKeyCount() > 0) {
                hashCode = (((hashCode * 37) + 4) * 53) + getMapKeyList().hashCode();
            }
            if (getMapValueCount() > 0) {
                hashCode = (((hashCode * 37) + 5) * 53) + getMapValueList().hashCode();
            }
            if (hasMacroReference()) {
                hashCode = (((hashCode * 37) + 6) * 53) + getMacroReference().hashCode();
            }
            if (hasFunctionId()) {
                hashCode = (((hashCode * 37) + 7) * 53) + getFunctionId().hashCode();
            }
            if (hasInteger()) {
                hashCode = (((hashCode * 37) + 8) * 53) + Internal.hashLong(getInteger());
            }
            if (hasBoolean()) {
                hashCode = (((hashCode * 37) + 12) * 53) + Internal.hashBoolean(getBoolean());
            }
            if (getTemplateTokenCount() > 0) {
                hashCode = (((hashCode * 37) + 11) * 53) + getTemplateTokenList().hashCode();
            }
            if (getEscapingCount() > 0) {
                hashCode = (((hashCode * 37) + 10) * 53) + Internal.hashEnumList(getEscapingList());
            }
            if (hasContainsReferences()) {
                hashCode = (((hashCode * 37) + 9) * 53) + Internal.hashBoolean(getContainsReferences());
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.midtier.proto.containertag.MutableTypeSystem$Value");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            if (!hasType()) {
                this.memoizedIsInitialized = 0;
                return false;
            }
            for (int i = 0; i < getListItemCount(); i++) {
                if (!getListItem(i).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i2 = 0; i2 < getMapKeyCount(); i2++) {
                if (!getMapKey(i2).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i3 = 0; i3 < getMapValueCount(); i3++) {
                if (!getMapValue(i3).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i4 = 0; i4 < getTemplateTokenCount(); i4++) {
                if (!getTemplateToken(i4).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            if (!extensionsAreInitialized()) {
                this.memoizedIsInitialized = 0;
                return false;
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            GeneratedMessageLite.ExtendableMessage<MessageType>.ExtensionWriter newExtensionWriter = newExtensionWriter();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeEnum(1, this.type_.getNumber());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeBytes(2, getStringBytes());
            }
            for (int i = 0; i < this.listItem_.size(); i++) {
                codedOutputStream.writeMessage(3, this.listItem_.get(i));
            }
            for (int i2 = 0; i2 < this.mapKey_.size(); i2++) {
                codedOutputStream.writeMessage(4, this.mapKey_.get(i2));
            }
            for (int i3 = 0; i3 < this.mapValue_.size(); i3++) {
                codedOutputStream.writeMessage(5, this.mapValue_.get(i3));
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeBytes(6, getMacroReferenceBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeBytes(7, getFunctionIdBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                codedOutputStream.writeInt64(8, this.integer_);
            }
            if ((this.bitField0_ & 64) == 64) {
                codedOutputStream.writeBool(9, this.containsReferences_);
            }
            for (int i4 = 0; i4 < this.escaping_.size(); i4++) {
                codedOutputStream.writeEnum(10, this.escaping_.get(i4).getNumber());
            }
            for (int i5 = 0; i5 < this.templateToken_.size(); i5++) {
                codedOutputStream.writeMessage(11, this.templateToken_.get(i5));
            }
            if ((this.bitField0_ & 32) == 32) {
                codedOutputStream.writeBool(12, this.boolean_);
            }
            newExtensionWriter.writeUntil(536870912, codedOutputStream);
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface ValueOrBuilder extends GeneratedMessageLite.ExtendableMessageOrBuilder<Value> {
        boolean getBoolean();

        boolean getContainsReferences();

        Value.Escaping getEscaping(int i);

        int getEscapingCount();

        List<Value.Escaping> getEscapingList();

        String getFunctionId();

        ByteString getFunctionIdBytes();

        long getInteger();

        Value getListItem(int i);

        int getListItemCount();

        List<Value> getListItemList();

        String getMacroReference();

        ByteString getMacroReferenceBytes();

        Value getMapKey(int i);

        int getMapKeyCount();

        List<Value> getMapKeyList();

        Value getMapValue(int i);

        int getMapValueCount();

        List<Value> getMapValueList();

        String getString();

        ByteString getStringBytes();

        Value getTemplateToken(int i);

        int getTemplateTokenCount();

        List<Value> getTemplateTokenList();

        Value.Type getType();

        boolean hasBoolean();

        boolean hasContainsReferences();

        boolean hasFunctionId();

        boolean hasInteger();

        boolean hasMacroReference();

        boolean hasString();

        boolean hasType();
    }

    private TypeSystem() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}

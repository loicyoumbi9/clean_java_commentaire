package com.google.analytics.containertag.proto;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import com.google.tagmanager.protobuf.AbstractMessageLite;
import com.google.tagmanager.protobuf.AbstractParser;
import com.google.tagmanager.protobuf.ByteString;
import com.google.tagmanager.protobuf.CodedInputStream;
import com.google.tagmanager.protobuf.CodedOutputStream;
import com.google.tagmanager.protobuf.ExtensionRegistryLite;
import com.google.tagmanager.protobuf.GeneratedMessageLite;
import com.google.tagmanager.protobuf.Internal;
import com.google.tagmanager.protobuf.InvalidProtocolBufferException;
import com.google.tagmanager.protobuf.LazyStringArrayList;
import com.google.tagmanager.protobuf.LazyStringList;
import com.google.tagmanager.protobuf.MessageLiteOrBuilder;
import com.google.tagmanager.protobuf.MutableMessageLite;
import com.google.tagmanager.protobuf.Parser;
import com.google.tagmanager.protobuf.UnmodifiableLazyStringList;
import com.google.tagmanager.protobuf.WireFormat;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Serving {

    public static final class CacheOption extends GeneratedMessageLite implements CacheOptionOrBuilder {
        public static final int EXPIRATION_SECONDS_FIELD_NUMBER = 2;
        public static final int GCACHE_EXPIRATION_SECONDS_FIELD_NUMBER = 3;
        public static final int LEVEL_FIELD_NUMBER = 1;
        public static Parser<CacheOption> PARSER = new AbstractParser<CacheOption>() {
            /* class com.google.analytics.containertag.proto.Serving.CacheOption.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public CacheOption parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new CacheOption(codedInputStream, extensionRegistryLite);
            }
        };
        private static final CacheOption defaultInstance = new CacheOption(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public int expirationSeconds_;
        /* access modifiers changed from: private */
        public int gcacheExpirationSeconds_;
        /* access modifiers changed from: private */
        public CacheLevel level_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.Builder<CacheOption, Builder> implements CacheOptionOrBuilder {
            private int bitField0_;
            private int expirationSeconds_;
            private int gcacheExpirationSeconds_;
            private CacheLevel level_ = CacheLevel.NO_CACHE;

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void maybeForceBuilderInitialization() {
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public CacheOption build() {
                CacheOption buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public CacheOption buildPartial() {
                int i = 1;
                CacheOption cacheOption = new CacheOption(this);
                int i2 = this.bitField0_;
                if ((i2 & 1) != 1) {
                    i = 0;
                }
                CacheLevel unused = cacheOption.level_ = this.level_;
                if ((i2 & 2) == 2) {
                    i |= 2;
                }
                int unused2 = cacheOption.expirationSeconds_ = this.expirationSeconds_;
                if ((i2 & 4) == 4) {
                    i |= 4;
                }
                int unused3 = cacheOption.gcacheExpirationSeconds_ = this.gcacheExpirationSeconds_;
                int unused4 = cacheOption.bitField0_ = i;
                return cacheOption;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.level_ = CacheLevel.NO_CACHE;
                this.bitField0_ &= -2;
                this.expirationSeconds_ = 0;
                this.bitField0_ &= -3;
                this.gcacheExpirationSeconds_ = 0;
                this.bitField0_ &= -5;
                return this;
            }

            public Builder clearExpirationSeconds() {
                this.bitField0_ &= -3;
                this.expirationSeconds_ = 0;
                return this;
            }

            public Builder clearGcacheExpirationSeconds() {
                this.bitField0_ &= -5;
                this.gcacheExpirationSeconds_ = 0;
                return this;
            }

            public Builder clearLevel() {
                this.bitField0_ &= -2;
                this.level_ = CacheLevel.NO_CACHE;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public CacheOption getDefaultInstanceForType() {
                return CacheOption.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public int getExpirationSeconds() {
                return this.expirationSeconds_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public int getGcacheExpirationSeconds() {
                return this.gcacheExpirationSeconds_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public CacheLevel getLevel() {
                return this.level_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public boolean hasExpirationSeconds() {
                return (this.bitField0_ & 2) == 2;
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public boolean hasGcacheExpirationSeconds() {
                return (this.bitField0_ & 4) == 4;
            }

            @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
            public boolean hasLevel() {
                return (this.bitField0_ & 1) == 1;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(CacheOption cacheOption) {
                if (cacheOption != CacheOption.getDefaultInstance()) {
                    if (cacheOption.hasLevel()) {
                        setLevel(cacheOption.getLevel());
                    }
                    if (cacheOption.hasExpirationSeconds()) {
                        setExpirationSeconds(cacheOption.getExpirationSeconds());
                    }
                    if (cacheOption.hasGcacheExpirationSeconds()) {
                        setGcacheExpirationSeconds(cacheOption.getGcacheExpirationSeconds());
                    }
                    setUnknownFields(getUnknownFields().concat(cacheOption.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                CacheOption cacheOption;
                CacheOption cacheOption2 = null;
                try {
                    CacheOption parsePartialFrom = CacheOption.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    cacheOption = (CacheOption) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    cacheOption2 = cacheOption;
                }
                if (cacheOption2 != null) {
                    mergeFrom(cacheOption2);
                }
                throw th;
            }

            public Builder setExpirationSeconds(int i) {
                this.bitField0_ |= 2;
                this.expirationSeconds_ = i;
                return this;
            }

            public Builder setGcacheExpirationSeconds(int i) {
                this.bitField0_ |= 4;
                this.gcacheExpirationSeconds_ = i;
                return this;
            }

            public Builder setLevel(CacheLevel cacheLevel) {
                if (cacheLevel == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 1;
                this.level_ = cacheLevel;
                return this;
            }
        }

        public enum CacheLevel implements Internal.EnumLite {
            NO_CACHE(0, 1),
            PRIVATE(1, 2),
            PUBLIC(2, 3);
            
            public static final int NO_CACHE_VALUE = 1;
            public static final int PRIVATE_VALUE = 2;
            public static final int PUBLIC_VALUE = 3;
            private static Internal.EnumLiteMap<CacheLevel> internalValueMap = new Internal.EnumLiteMap<CacheLevel>() {
                /* class com.google.analytics.containertag.proto.Serving.CacheOption.CacheLevel.AnonymousClass1 */

                @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
                public CacheLevel findValueByNumber(int i) {
                    return CacheLevel.valueOf(i);
                }
            };
            private final int value;

            private CacheLevel(int i, int i2) {
                this.value = i2;
            }

            public static Internal.EnumLiteMap<CacheLevel> internalGetValueMap() {
                return internalValueMap;
            }

            public static CacheLevel valueOf(int i) {
                switch (i) {
                    case 1:
                        return NO_CACHE;
                    case 2:
                        return PRIVATE;
                    case 3:
                        return PUBLIC;
                    default:
                        return null;
                }
            }

            @Override // com.google.tagmanager.protobuf.Internal.EnumLite
            public final int getNumber() {
                return this.value;
            }
        }

        static {
            defaultInstance.initFields();
        }

        private CacheOption(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            initFields();
            ByteString.Output newOutput = ByteString.newOutput();
            CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
            boolean z = false;
            while (!z) {
                try {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            int readEnum = codedInputStream.readEnum();
                            CacheLevel valueOf = CacheLevel.valueOf(readEnum);
                            if (valueOf != null) {
                                this.bitField0_ |= 1;
                                this.level_ = valueOf;
                                break;
                            } else {
                                newInstance.writeRawVarint32(readTag);
                                newInstance.writeRawVarint32(readEnum);
                                break;
                            }
                        case 16:
                            this.bitField0_ |= 2;
                            this.expirationSeconds_ = codedInputStream.readInt32();
                            break;
                        case 24:
                            this.bitField0_ |= 4;
                            this.gcacheExpirationSeconds_ = codedInputStream.readInt32();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                } catch (InvalidProtocolBufferException e) {
                    throw e.setUnfinishedMessage(this);
                } catch (IOException e2) {
                    throw new InvalidProtocolBufferException(e2.getMessage()).setUnfinishedMessage(this);
                } catch (Throwable th) {
                    try {
                        newInstance.flush();
                    } catch (IOException e3) {
                    } finally {
                        this.unknownFields = newOutput.toByteString();
                    }
                    makeExtensionsImmutable();
                    throw th;
                }
            }
            try {
                newInstance.flush();
            } catch (IOException e4) {
            } finally {
                this.unknownFields = newOutput.toByteString();
            }
            makeExtensionsImmutable();
        }

        private CacheOption(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private CacheOption(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static CacheOption getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.level_ = CacheLevel.NO_CACHE;
            this.expirationSeconds_ = 0;
            this.gcacheExpirationSeconds_ = 0;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(CacheOption cacheOption) {
            return newBuilder().mergeFrom(cacheOption);
        }

        public static CacheOption parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static CacheOption parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static CacheOption parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static CacheOption parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static CacheOption parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static CacheOption parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static CacheOption parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static CacheOption parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static CacheOption parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static CacheOption parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof CacheOption)) {
                return super.equals(obj);
            }
            CacheOption cacheOption = (CacheOption) obj;
            boolean z = hasLevel() == cacheOption.hasLevel();
            if (hasLevel()) {
                z = z && getLevel() == cacheOption.getLevel();
            }
            boolean z2 = z && hasExpirationSeconds() == cacheOption.hasExpirationSeconds();
            if (hasExpirationSeconds()) {
                z2 = z2 && getExpirationSeconds() == cacheOption.getExpirationSeconds();
            }
            boolean z3 = z2 && hasGcacheExpirationSeconds() == cacheOption.hasGcacheExpirationSeconds();
            return hasGcacheExpirationSeconds() ? z3 && getGcacheExpirationSeconds() == cacheOption.getGcacheExpirationSeconds() : z3;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public CacheOption getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public int getExpirationSeconds() {
            return this.expirationSeconds_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public int getGcacheExpirationSeconds() {
            return this.gcacheExpirationSeconds_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public CacheLevel getLevel() {
            return this.level_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<CacheOption> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            if ((this.bitField0_ & 1) == 1) {
                i2 = CodedOutputStream.computeEnumSize(1, this.level_.getNumber()) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i2 += CodedOutputStream.computeInt32Size(2, this.expirationSeconds_);
            }
            if ((this.bitField0_ & 4) == 4) {
                i2 += CodedOutputStream.computeInt32Size(3, this.gcacheExpirationSeconds_);
            }
            int size = i2 + this.unknownFields.size();
            this.memoizedSerializedSize = size;
            return size;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public boolean hasExpirationSeconds() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public boolean hasGcacheExpirationSeconds() {
            return (this.bitField0_ & 4) == 4;
        }

        @Override // com.google.analytics.containertag.proto.Serving.CacheOptionOrBuilder
        public boolean hasLevel() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = CacheOption.class.hashCode() + 779;
            if (hasLevel()) {
                hashCode = (((hashCode * 37) + 1) * 53) + Internal.hashEnum(getLevel());
            }
            if (hasExpirationSeconds()) {
                hashCode = (((hashCode * 37) + 2) * 53) + getExpirationSeconds();
            }
            if (hasGcacheExpirationSeconds()) {
                hashCode = (((hashCode * 37) + 3) * 53) + getGcacheExpirationSeconds();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$CacheOption");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeEnum(1, this.level_.getNumber());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(2, this.expirationSeconds_);
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeInt32(3, this.gcacheExpirationSeconds_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface CacheOptionOrBuilder extends MessageLiteOrBuilder {
        int getExpirationSeconds();

        int getGcacheExpirationSeconds();

        CacheOption.CacheLevel getLevel();

        boolean hasExpirationSeconds();

        boolean hasGcacheExpirationSeconds();

        boolean hasLevel();
    }

    public static final class Container extends GeneratedMessageLite implements ContainerOrBuilder {
        public static final int CONTAINER_ID_FIELD_NUMBER = 3;
        public static final int JS_RESOURCE_FIELD_NUMBER = 1;
        public static Parser<Container> PARSER = new AbstractParser<Container>() {
            /* class com.google.analytics.containertag.proto.Serving.Container.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public Container parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new Container(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int STATE_FIELD_NUMBER = 4;
        public static final int VERSION_FIELD_NUMBER = 5;
        private static final Container defaultInstance = new Container(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public Object containerId_;
        /* access modifiers changed from: private */
        public Resource jsResource_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public ResourceState state_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;
        /* access modifiers changed from: private */
        public Object version_;

        public static final class Builder extends GeneratedMessageLite.Builder<Container, Builder> implements ContainerOrBuilder {
            private int bitField0_;
            private Object containerId_ = "";
            private Resource jsResource_ = Resource.getDefaultInstance();
            private ResourceState state_ = ResourceState.PREVIEW;
            private Object version_ = "";

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void maybeForceBuilderInitialization() {
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Container build() {
                Container buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Container buildPartial() {
                int i = 1;
                Container container = new Container(this);
                int i2 = this.bitField0_;
                if ((i2 & 1) != 1) {
                    i = 0;
                }
                Resource unused = container.jsResource_ = this.jsResource_;
                if ((i2 & 2) == 2) {
                    i |= 2;
                }
                Object unused2 = container.containerId_ = this.containerId_;
                if ((i2 & 4) == 4) {
                    i |= 4;
                }
                ResourceState unused3 = container.state_ = this.state_;
                if ((i2 & 8) == 8) {
                    i |= 8;
                }
                Object unused4 = container.version_ = this.version_;
                int unused5 = container.bitField0_ = i;
                return container;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.jsResource_ = Resource.getDefaultInstance();
                this.bitField0_ &= -2;
                this.containerId_ = "";
                this.bitField0_ &= -3;
                this.state_ = ResourceState.PREVIEW;
                this.bitField0_ &= -5;
                this.version_ = "";
                this.bitField0_ &= -9;
                return this;
            }

            public Builder clearContainerId() {
                this.bitField0_ &= -3;
                this.containerId_ = Container.getDefaultInstance().getContainerId();
                return this;
            }

            public Builder clearJsResource() {
                this.jsResource_ = Resource.getDefaultInstance();
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearState() {
                this.bitField0_ &= -5;
                this.state_ = ResourceState.PREVIEW;
                return this;
            }

            public Builder clearVersion() {
                this.bitField0_ &= -9;
                this.version_ = Container.getDefaultInstance().getVersion();
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public String getContainerId() {
                Object obj = this.containerId_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.containerId_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public ByteString getContainerIdBytes() {
                Object obj = this.containerId_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.containerId_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public Container getDefaultInstanceForType() {
                return Container.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public Resource getJsResource() {
                return this.jsResource_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public ResourceState getState() {
                return this.state_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public String getVersion() {
                Object obj = this.version_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.version_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public ByteString getVersionBytes() {
                Object obj = this.version_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.version_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public boolean hasContainerId() {
                return (this.bitField0_ & 2) == 2;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public boolean hasJsResource() {
                return (this.bitField0_ & 1) == 1;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public boolean hasState() {
                return (this.bitField0_ & 4) == 4;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
            public boolean hasVersion() {
                return (this.bitField0_ & 8) == 8;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return hasJsResource() && hasContainerId() && hasState() && getJsResource().isInitialized();
            }

            public Builder mergeFrom(Container container) {
                if (container != Container.getDefaultInstance()) {
                    if (container.hasJsResource()) {
                        mergeJsResource(container.getJsResource());
                    }
                    if (container.hasContainerId()) {
                        this.bitField0_ |= 2;
                        this.containerId_ = container.containerId_;
                    }
                    if (container.hasState()) {
                        setState(container.getState());
                    }
                    if (container.hasVersion()) {
                        this.bitField0_ |= 8;
                        this.version_ = container.version_;
                    }
                    setUnknownFields(getUnknownFields().concat(container.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                Container container;
                Container container2 = null;
                try {
                    Container parsePartialFrom = Container.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    container = (Container) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    container2 = container;
                }
                if (container2 != null) {
                    mergeFrom(container2);
                }
                throw th;
            }

            public Builder mergeJsResource(Resource resource) {
                if ((this.bitField0_ & 1) != 1 || this.jsResource_ == Resource.getDefaultInstance()) {
                    this.jsResource_ = resource;
                } else {
                    this.jsResource_ = Resource.newBuilder(this.jsResource_).mergeFrom(resource).buildPartial();
                }
                this.bitField0_ |= 1;
                return this;
            }

            public Builder setContainerId(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 2;
                this.containerId_ = str;
                return this;
            }

            public Builder setContainerIdBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 2;
                this.containerId_ = byteString;
                return this;
            }

            public Builder setJsResource(Resource.Builder builder) {
                this.jsResource_ = builder.build();
                this.bitField0_ |= 1;
                return this;
            }

            public Builder setJsResource(Resource resource) {
                if (resource == null) {
                    throw new NullPointerException();
                }
                this.jsResource_ = resource;
                this.bitField0_ |= 1;
                return this;
            }

            public Builder setState(ResourceState resourceState) {
                if (resourceState == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 4;
                this.state_ = resourceState;
                return this;
            }

            public Builder setVersion(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 8;
                this.version_ = str;
                return this;
            }

            public Builder setVersionBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 8;
                this.version_ = byteString;
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        private Container(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            initFields();
            ByteString.Output newOutput = ByteString.newOutput();
            CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
            boolean z = false;
            while (!z) {
                try {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            Resource.Builder builder = (this.bitField0_ & 1) == 1 ? this.jsResource_.toBuilder() : null;
                            this.jsResource_ = (Resource) codedInputStream.readMessage(Resource.PARSER, extensionRegistryLite);
                            if (builder != null) {
                                builder.mergeFrom(this.jsResource_);
                                this.jsResource_ = builder.buildPartial();
                            }
                            this.bitField0_ |= 1;
                            break;
                        case 26:
                            ByteString readBytes = codedInputStream.readBytes();
                            this.bitField0_ |= 2;
                            this.containerId_ = readBytes;
                            break;
                        case 32:
                            int readEnum = codedInputStream.readEnum();
                            ResourceState valueOf = ResourceState.valueOf(readEnum);
                            if (valueOf != null) {
                                this.bitField0_ |= 4;
                                this.state_ = valueOf;
                                break;
                            } else {
                                newInstance.writeRawVarint32(readTag);
                                newInstance.writeRawVarint32(readEnum);
                                break;
                            }
                        case 42:
                            ByteString readBytes2 = codedInputStream.readBytes();
                            this.bitField0_ |= 8;
                            this.version_ = readBytes2;
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                } catch (InvalidProtocolBufferException e) {
                    throw e.setUnfinishedMessage(this);
                } catch (IOException e2) {
                    throw new InvalidProtocolBufferException(e2.getMessage()).setUnfinishedMessage(this);
                } catch (Throwable th) {
                    try {
                        newInstance.flush();
                    } catch (IOException e3) {
                    } finally {
                        this.unknownFields = newOutput.toByteString();
                    }
                    makeExtensionsImmutable();
                    throw th;
                }
            }
            try {
                newInstance.flush();
            } catch (IOException e4) {
            } finally {
                this.unknownFields = newOutput.toByteString();
            }
            makeExtensionsImmutable();
        }

        private Container(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private Container(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static Container getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.jsResource_ = Resource.getDefaultInstance();
            this.containerId_ = "";
            this.state_ = ResourceState.PREVIEW;
            this.version_ = "";
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(Container container) {
            return newBuilder().mergeFrom(container);
        }

        public static Container parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static Container parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static Container parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static Container parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static Container parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static Container parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static Container parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static Container parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static Container parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static Container parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Container)) {
                return super.equals(obj);
            }
            Container container = (Container) obj;
            boolean z = hasJsResource() == container.hasJsResource();
            if (hasJsResource()) {
                z = z && getJsResource().equals(container.getJsResource());
            }
            boolean z2 = z && hasContainerId() == container.hasContainerId();
            if (hasContainerId()) {
                z2 = z2 && getContainerId().equals(container.getContainerId());
            }
            boolean z3 = z2 && hasState() == container.hasState();
            if (hasState()) {
                z3 = z3 && getState() == container.getState();
            }
            boolean z4 = z3 && hasVersion() == container.hasVersion();
            return hasVersion() ? z4 && getVersion().equals(container.getVersion()) : z4;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public String getContainerId() {
            Object obj = this.containerId_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.containerId_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public ByteString getContainerIdBytes() {
            Object obj = this.containerId_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.containerId_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public Container getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public Resource getJsResource() {
            return this.jsResource_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<Container> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            if ((this.bitField0_ & 1) == 1) {
                i2 = CodedOutputStream.computeMessageSize(1, this.jsResource_) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i2 += CodedOutputStream.computeBytesSize(3, getContainerIdBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                i2 += CodedOutputStream.computeEnumSize(4, this.state_.getNumber());
            }
            if ((this.bitField0_ & 8) == 8) {
                i2 += CodedOutputStream.computeBytesSize(5, getVersionBytes());
            }
            int size = i2 + this.unknownFields.size();
            this.memoizedSerializedSize = size;
            return size;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public ResourceState getState() {
            return this.state_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public String getVersion() {
            Object obj = this.version_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.version_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public ByteString getVersionBytes() {
            Object obj = this.version_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.version_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public boolean hasContainerId() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public boolean hasJsResource() {
            return (this.bitField0_ & 1) == 1;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public boolean hasState() {
            return (this.bitField0_ & 4) == 4;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ContainerOrBuilder
        public boolean hasVersion() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = Container.class.hashCode() + 779;
            if (hasJsResource()) {
                hashCode = (((hashCode * 37) + 1) * 53) + getJsResource().hashCode();
            }
            if (hasContainerId()) {
                hashCode = (((hashCode * 37) + 3) * 53) + getContainerId().hashCode();
            }
            if (hasState()) {
                hashCode = (((hashCode * 37) + 4) * 53) + Internal.hashEnum(getState());
            }
            if (hasVersion()) {
                hashCode = (((hashCode * 37) + 5) * 53) + getVersion().hashCode();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$Container");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            if (!hasJsResource()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else if (!hasContainerId()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else if (!hasState()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else if (!getJsResource().isInitialized()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else {
                this.memoizedIsInitialized = 1;
                return true;
            }
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessage(1, this.jsResource_);
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeBytes(3, getContainerIdBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeEnum(4, this.state_.getNumber());
            }
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeBytes(5, getVersionBytes());
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface ContainerOrBuilder extends MessageLiteOrBuilder {
        String getContainerId();

        ByteString getContainerIdBytes();

        Resource getJsResource();

        ResourceState getState();

        String getVersion();

        ByteString getVersionBytes();

        boolean hasContainerId();

        boolean hasJsResource();

        boolean hasState();

        boolean hasVersion();
    }

    public static final class FunctionCall extends GeneratedMessageLite implements FunctionCallOrBuilder {
        public static final int FUNCTION_FIELD_NUMBER = 2;
        public static final int LIVE_ONLY_FIELD_NUMBER = 6;
        public static final int NAME_FIELD_NUMBER = 4;
        public static Parser<FunctionCall> PARSER = new AbstractParser<FunctionCall>() {
            /* class com.google.analytics.containertag.proto.Serving.FunctionCall.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public FunctionCall parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new FunctionCall(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int PROPERTY_FIELD_NUMBER = 3;
        public static final int SERVER_SIDE_FIELD_NUMBER = 1;
        private static final FunctionCall defaultInstance = new FunctionCall(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public int function_;
        /* access modifiers changed from: private */
        public boolean liveOnly_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public int name_;
        /* access modifiers changed from: private */
        public List<Integer> property_;
        /* access modifiers changed from: private */
        public boolean serverSide_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.Builder<FunctionCall, Builder> implements FunctionCallOrBuilder {
            private int bitField0_;
            private int function_;
            private boolean liveOnly_;
            private int name_;
            private List<Integer> property_ = Collections.emptyList();
            private boolean serverSide_;

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void ensurePropertyIsMutable() {
                if ((this.bitField0_ & 1) != 1) {
                    this.property_ = new ArrayList(this.property_);
                    this.bitField0_ |= 1;
                }
            }

            private void maybeForceBuilderInitialization() {
            }

            public Builder addAllProperty(Iterable<? extends Integer> iterable) {
                ensurePropertyIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.property_);
                return this;
            }

            public Builder addProperty(int i) {
                ensurePropertyIsMutable();
                this.property_.add(Integer.valueOf(i));
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public FunctionCall build() {
                FunctionCall buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public FunctionCall buildPartial() {
                int i = 1;
                FunctionCall functionCall = new FunctionCall(this);
                int i2 = this.bitField0_;
                if ((this.bitField0_ & 1) == 1) {
                    this.property_ = Collections.unmodifiableList(this.property_);
                    this.bitField0_ &= -2;
                }
                List unused = functionCall.property_ = this.property_;
                if ((i2 & 2) != 2) {
                    i = 0;
                }
                int unused2 = functionCall.function_ = this.function_;
                if ((i2 & 4) == 4) {
                    i |= 2;
                }
                int unused3 = functionCall.name_ = this.name_;
                if ((i2 & 8) == 8) {
                    i |= 4;
                }
                boolean unused4 = functionCall.liveOnly_ = this.liveOnly_;
                if ((i2 & 16) == 16) {
                    i |= 8;
                }
                boolean unused5 = functionCall.serverSide_ = this.serverSide_;
                int unused6 = functionCall.bitField0_ = i;
                return functionCall;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.property_ = Collections.emptyList();
                this.bitField0_ &= -2;
                this.function_ = 0;
                this.bitField0_ &= -3;
                this.name_ = 0;
                this.bitField0_ &= -5;
                this.liveOnly_ = false;
                this.bitField0_ &= -9;
                this.serverSide_ = false;
                this.bitField0_ &= -17;
                return this;
            }

            public Builder clearFunction() {
                this.bitField0_ &= -3;
                this.function_ = 0;
                return this;
            }

            public Builder clearLiveOnly() {
                this.bitField0_ &= -9;
                this.liveOnly_ = false;
                return this;
            }

            public Builder clearName() {
                this.bitField0_ &= -5;
                this.name_ = 0;
                return this;
            }

            public Builder clearProperty() {
                this.property_ = Collections.emptyList();
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearServerSide() {
                this.bitField0_ &= -17;
                this.serverSide_ = false;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public FunctionCall getDefaultInstanceForType() {
                return FunctionCall.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public int getFunction() {
                return this.function_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean getLiveOnly() {
                return this.liveOnly_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public int getName() {
                return this.name_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public int getProperty(int i) {
                return this.property_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public int getPropertyCount() {
                return this.property_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public List<Integer> getPropertyList() {
                return Collections.unmodifiableList(this.property_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean getServerSide() {
                return this.serverSide_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean hasFunction() {
                return (this.bitField0_ & 2) == 2;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean hasLiveOnly() {
                return (this.bitField0_ & 8) == 8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean hasName() {
                return (this.bitField0_ & 4) == 4;
            }

            @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
            public boolean hasServerSide() {
                return (this.bitField0_ & 16) == 16;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return hasFunction();
            }

            public Builder mergeFrom(FunctionCall functionCall) {
                if (functionCall != FunctionCall.getDefaultInstance()) {
                    if (!functionCall.property_.isEmpty()) {
                        if (this.property_.isEmpty()) {
                            this.property_ = functionCall.property_;
                            this.bitField0_ &= -2;
                        } else {
                            ensurePropertyIsMutable();
                            this.property_.addAll(functionCall.property_);
                        }
                    }
                    if (functionCall.hasFunction()) {
                        setFunction(functionCall.getFunction());
                    }
                    if (functionCall.hasName()) {
                        setName(functionCall.getName());
                    }
                    if (functionCall.hasLiveOnly()) {
                        setLiveOnly(functionCall.getLiveOnly());
                    }
                    if (functionCall.hasServerSide()) {
                        setServerSide(functionCall.getServerSide());
                    }
                    setUnknownFields(getUnknownFields().concat(functionCall.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                FunctionCall functionCall;
                FunctionCall functionCall2 = null;
                try {
                    FunctionCall parsePartialFrom = FunctionCall.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    functionCall = (FunctionCall) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    functionCall2 = functionCall;
                }
                if (functionCall2 != null) {
                    mergeFrom(functionCall2);
                }
                throw th;
            }

            public Builder setFunction(int i) {
                this.bitField0_ |= 2;
                this.function_ = i;
                return this;
            }

            public Builder setLiveOnly(boolean z) {
                this.bitField0_ |= 8;
                this.liveOnly_ = z;
                return this;
            }

            public Builder setName(int i) {
                this.bitField0_ |= 4;
                this.name_ = i;
                return this;
            }

            public Builder setProperty(int i, int i2) {
                ensurePropertyIsMutable();
                this.property_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setServerSide(boolean z) {
                this.bitField0_ |= 16;
                this.serverSide_ = z;
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x0041  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private FunctionCall(com.google.tagmanager.protobuf.CodedInputStream r9, com.google.tagmanager.protobuf.ExtensionRegistryLite r10) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
            /*
                r8 = this;
                r2 = 0
                r0 = -1
                r3 = 1
                r8.<init>()
                r8.memoizedIsInitialized = r0
                r8.memoizedSerializedSize = r0
                r8.initFields()
                com.google.tagmanager.protobuf.ByteString$Output r4 = com.google.tagmanager.protobuf.ByteString.newOutput()
                com.google.tagmanager.protobuf.CodedOutputStream r5 = com.google.tagmanager.protobuf.CodedOutputStream.newInstance(r4)
                r1 = r2
                r0 = r2
            L_0x0017:
                if (r1 != 0) goto L_0x00e1
                int r2 = r9.readTag()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                switch(r2) {
                    case 0: goto L_0x011b;
                    case 8: goto L_0x0028;
                    case 16: goto L_0x0056;
                    case 24: goto L_0x0076;
                    case 26: goto L_0x0091;
                    case 32: goto L_0x00c5;
                    case 48: goto L_0x00d3;
                    default: goto L_0x0020;
                }     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
            L_0x0020:
                boolean r2 = r8.parseUnknownField(r9, r5, r10, r2)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                if (r2 != 0) goto L_0x0017
                r1 = r3
                goto L_0x0017
            L_0x0028:
                int r2 = r8.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2 = r2 | 8
                r8.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                boolean r2 = r9.readBool()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.serverSide_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x0035:
                r1 = move-exception
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r1 = r1.setUnfinishedMessage(r8)     // Catch:{ all -> 0x003b }
                throw r1     // Catch:{ all -> 0x003b }
            L_0x003b:
                r1 = move-exception
                r2 = r0
            L_0x003d:
                r0 = r2 & 1
                if (r0 != r3) goto L_0x0049
                java.util.List<java.lang.Integer> r0 = r8.property_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r8.property_ = r0
            L_0x0049:
                r5.flush()     // Catch:{ IOException -> 0x010a, all -> 0x0113 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r8.unknownFields = r0
            L_0x0052:
                r8.makeExtensionsImmutable()
                throw r1
            L_0x0056:
                int r2 = r8.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2 = r2 | 1
                r8.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                int r2 = r9.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.function_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x0063:
                r1 = move-exception
                r2 = r0
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = new com.google.tagmanager.protobuf.InvalidProtocolBufferException     // Catch:{ all -> 0x0073 }
                java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0073 }
                r0.<init>(r1)     // Catch:{ all -> 0x0073 }
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r0.setUnfinishedMessage(r8)     // Catch:{ all -> 0x0073 }
                throw r0     // Catch:{ all -> 0x0073 }
            L_0x0073:
                r0 = move-exception
                r1 = r0
                goto L_0x003d
            L_0x0076:
                r2 = r0 & 1
                if (r2 == r3) goto L_0x0083
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.property_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r0 = r0 | 1
            L_0x0083:
                java.util.List<java.lang.Integer> r2 = r8.property_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                int r6 = r9.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x0091:
                int r2 = r9.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                int r2 = r9.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r6 = r0 & 1
                if (r6 == r3) goto L_0x00ac
                int r6 = r9.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                if (r6 <= 0) goto L_0x00ac
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.property_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r0 = r0 | 1
            L_0x00ac:
                int r6 = r9.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                if (r6 <= 0) goto L_0x00c0
                java.util.List<java.lang.Integer> r6 = r8.property_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                int r7 = r9.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x00ac
            L_0x00c0:
                r9.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x00c5:
                int r2 = r8.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2 = r2 | 2
                r8.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                int r2 = r9.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.name_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x00d3:
                int r2 = r8.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r2 = r2 | 4
                r8.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                boolean r2 = r9.readBool()     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                r8.liveOnly_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0035, IOException -> 0x0063 }
                goto L_0x0017
            L_0x00e1:
                r0 = r0 & 1
                if (r0 != r3) goto L_0x00ed
                java.util.List<java.lang.Integer> r0 = r8.property_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r8.property_ = r0
            L_0x00ed:
                r5.flush()     // Catch:{ IOException -> 0x00fa, all -> 0x0102 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r8.unknownFields = r0
            L_0x00f6:
                r8.makeExtensionsImmutable()
                return
            L_0x00fa:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r8.unknownFields = r0
                goto L_0x00f6
            L_0x0102:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r8.unknownFields = r1
                throw r0
            L_0x010a:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r8.unknownFields = r0
                goto L_0x0052
            L_0x0113:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r8.unknownFields = r1
                throw r0
            L_0x011b:
                r1 = r3
                goto L_0x0017
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.containertag.proto.Serving.FunctionCall.<init>(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):void");
        }

        private FunctionCall(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private FunctionCall(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static FunctionCall getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.property_ = Collections.emptyList();
            this.function_ = 0;
            this.name_ = 0;
            this.liveOnly_ = false;
            this.serverSide_ = false;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(FunctionCall functionCall) {
            return newBuilder().mergeFrom(functionCall);
        }

        public static FunctionCall parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static FunctionCall parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static FunctionCall parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static FunctionCall parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static FunctionCall parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static FunctionCall parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static FunctionCall parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static FunctionCall parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static FunctionCall parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static FunctionCall parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof FunctionCall)) {
                return super.equals(obj);
            }
            FunctionCall functionCall = (FunctionCall) obj;
            boolean z = (getPropertyList().equals(functionCall.getPropertyList())) && hasFunction() == functionCall.hasFunction();
            if (hasFunction()) {
                z = z && getFunction() == functionCall.getFunction();
            }
            boolean z2 = z && hasName() == functionCall.hasName();
            if (hasName()) {
                z2 = z2 && getName() == functionCall.getName();
            }
            boolean z3 = z2 && hasLiveOnly() == functionCall.hasLiveOnly();
            if (hasLiveOnly()) {
                z3 = z3 && getLiveOnly() == functionCall.getLiveOnly();
            }
            boolean z4 = z3 && hasServerSide() == functionCall.hasServerSide();
            return hasServerSide() ? z4 && getServerSide() == functionCall.getServerSide() : z4;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public FunctionCall getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public int getFunction() {
            return this.function_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean getLiveOnly() {
            return this.liveOnly_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public int getName() {
            return this.name_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<FunctionCall> getParserForType() {
            return PARSER;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public int getProperty(int i) {
            return this.property_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public int getPropertyCount() {
            return this.property_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public List<Integer> getPropertyList() {
            return this.property_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int computeBoolSize = (this.bitField0_ & 8) == 8 ? CodedOutputStream.computeBoolSize(1, this.serverSide_) + 0 : 0;
            int computeInt32Size = (this.bitField0_ & 1) == 1 ? computeBoolSize + CodedOutputStream.computeInt32Size(2, this.function_) : computeBoolSize;
            int i2 = 0;
            for (int i3 = 0; i3 < this.property_.size(); i3++) {
                i2 += CodedOutputStream.computeInt32SizeNoTag(this.property_.get(i3).intValue());
            }
            int size = computeInt32Size + i2 + (getPropertyList().size() * 1);
            if ((this.bitField0_ & 2) == 2) {
                size += CodedOutputStream.computeInt32Size(4, this.name_);
            }
            if ((this.bitField0_ & 4) == 4) {
                size += CodedOutputStream.computeBoolSize(6, this.liveOnly_);
            }
            int size2 = size + this.unknownFields.size();
            this.memoizedSerializedSize = size2;
            return size2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean getServerSide() {
            return this.serverSide_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean hasFunction() {
            return (this.bitField0_ & 1) == 1;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean hasLiveOnly() {
            return (this.bitField0_ & 4) == 4;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean hasName() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.FunctionCallOrBuilder
        public boolean hasServerSide() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = FunctionCall.class.hashCode() + 779;
            if (getPropertyCount() > 0) {
                hashCode = (((hashCode * 37) + 3) * 53) + getPropertyList().hashCode();
            }
            if (hasFunction()) {
                hashCode = (((hashCode * 37) + 2) * 53) + getFunction();
            }
            if (hasName()) {
                hashCode = (((hashCode * 37) + 4) * 53) + getName();
            }
            if (hasLiveOnly()) {
                hashCode = (((hashCode * 37) + 6) * 53) + Internal.hashBoolean(getLiveOnly());
            }
            if (hasServerSide()) {
                hashCode = (((hashCode * 37) + 1) * 53) + Internal.hashBoolean(getServerSide());
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$FunctionCall");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            if (!hasFunction()) {
                this.memoizedIsInitialized = 0;
                return false;
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeBool(1, this.serverSide_);
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeInt32(2, this.function_);
            }
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.property_.size()) {
                    break;
                }
                codedOutputStream.writeInt32(3, this.property_.get(i2).intValue());
                i = i2 + 1;
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(4, this.name_);
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeBool(6, this.liveOnly_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface FunctionCallOrBuilder extends MessageLiteOrBuilder {
        int getFunction();

        boolean getLiveOnly();

        int getName();

        int getProperty(int i);

        int getPropertyCount();

        List<Integer> getPropertyList();

        boolean getServerSide();

        boolean hasFunction();

        boolean hasLiveOnly();

        boolean hasName();

        boolean hasServerSide();
    }

    public static final class OptionalResource extends GeneratedMessageLite implements OptionalResourceOrBuilder {
        public static Parser<OptionalResource> PARSER = new AbstractParser<OptionalResource>() {
            /* class com.google.analytics.containertag.proto.Serving.OptionalResource.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public OptionalResource parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new OptionalResource(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int RESOURCE_FIELD_NUMBER = 2;
        private static final OptionalResource defaultInstance = new OptionalResource(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public Resource resource_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.Builder<OptionalResource, Builder> implements OptionalResourceOrBuilder {
            private int bitField0_;
            private Resource resource_ = Resource.getDefaultInstance();

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void maybeForceBuilderInitialization() {
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public OptionalResource build() {
                OptionalResource buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public OptionalResource buildPartial() {
                int i = 1;
                OptionalResource optionalResource = new OptionalResource(this);
                if ((this.bitField0_ & 1) != 1) {
                    i = 0;
                }
                Resource unused = optionalResource.resource_ = this.resource_;
                int unused2 = optionalResource.bitField0_ = i;
                return optionalResource;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.resource_ = Resource.getDefaultInstance();
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearResource() {
                this.resource_ = Resource.getDefaultInstance();
                this.bitField0_ &= -2;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public OptionalResource getDefaultInstanceForType() {
                return OptionalResource.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.OptionalResourceOrBuilder
            public Resource getResource() {
                return this.resource_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.OptionalResourceOrBuilder
            public boolean hasResource() {
                return (this.bitField0_ & 1) == 1;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return !hasResource() || getResource().isInitialized();
            }

            public Builder mergeFrom(OptionalResource optionalResource) {
                if (optionalResource != OptionalResource.getDefaultInstance()) {
                    if (optionalResource.hasResource()) {
                        mergeResource(optionalResource.getResource());
                    }
                    setUnknownFields(getUnknownFields().concat(optionalResource.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                OptionalResource optionalResource;
                OptionalResource optionalResource2 = null;
                try {
                    OptionalResource parsePartialFrom = OptionalResource.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    optionalResource = (OptionalResource) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    optionalResource2 = optionalResource;
                }
                if (optionalResource2 != null) {
                    mergeFrom(optionalResource2);
                }
                throw th;
            }

            public Builder mergeResource(Resource resource) {
                if ((this.bitField0_ & 1) != 1 || this.resource_ == Resource.getDefaultInstance()) {
                    this.resource_ = resource;
                } else {
                    this.resource_ = Resource.newBuilder(this.resource_).mergeFrom(resource).buildPartial();
                }
                this.bitField0_ |= 1;
                return this;
            }

            public Builder setResource(Resource.Builder builder) {
                this.resource_ = builder.build();
                this.bitField0_ |= 1;
                return this;
            }

            public Builder setResource(Resource resource) {
                if (resource == null) {
                    throw new NullPointerException();
                }
                this.resource_ = resource;
                this.bitField0_ |= 1;
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        private OptionalResource(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            initFields();
            ByteString.Output newOutput = ByteString.newOutput();
            CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
            boolean z = false;
            while (!z) {
                try {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 18:
                            Resource.Builder builder = (this.bitField0_ & 1) == 1 ? this.resource_.toBuilder() : null;
                            this.resource_ = (Resource) codedInputStream.readMessage(Resource.PARSER, extensionRegistryLite);
                            if (builder != null) {
                                builder.mergeFrom(this.resource_);
                                this.resource_ = builder.buildPartial();
                            }
                            this.bitField0_ |= 1;
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                } catch (InvalidProtocolBufferException e) {
                    throw e.setUnfinishedMessage(this);
                } catch (IOException e2) {
                    throw new InvalidProtocolBufferException(e2.getMessage()).setUnfinishedMessage(this);
                } catch (Throwable th) {
                    try {
                        newInstance.flush();
                    } catch (IOException e3) {
                    } finally {
                        this.unknownFields = newOutput.toByteString();
                    }
                    makeExtensionsImmutable();
                    throw th;
                }
            }
            try {
                newInstance.flush();
            } catch (IOException e4) {
            } finally {
                this.unknownFields = newOutput.toByteString();
            }
            makeExtensionsImmutable();
        }

        private OptionalResource(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private OptionalResource(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static OptionalResource getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.resource_ = Resource.getDefaultInstance();
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(OptionalResource optionalResource) {
            return newBuilder().mergeFrom(optionalResource);
        }

        public static OptionalResource parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static OptionalResource parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static OptionalResource parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static OptionalResource parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static OptionalResource parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static OptionalResource parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static OptionalResource parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static OptionalResource parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static OptionalResource parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static OptionalResource parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof OptionalResource)) {
                return super.equals(obj);
            }
            OptionalResource optionalResource = (OptionalResource) obj;
            boolean z = hasResource() == optionalResource.hasResource();
            return hasResource() ? z && getResource().equals(optionalResource.getResource()) : z;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public OptionalResource getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<OptionalResource> getParserForType() {
            return PARSER;
        }

        @Override // com.google.analytics.containertag.proto.Serving.OptionalResourceOrBuilder
        public Resource getResource() {
            return this.resource_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            if ((this.bitField0_ & 1) == 1) {
                i2 = CodedOutputStream.computeMessageSize(2, this.resource_) + 0;
            }
            int size = i2 + this.unknownFields.size();
            this.memoizedSerializedSize = size;
            return size;
        }

        @Override // com.google.analytics.containertag.proto.Serving.OptionalResourceOrBuilder
        public boolean hasResource() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = OptionalResource.class.hashCode() + 779;
            if (hasResource()) {
                hashCode = (((hashCode * 37) + 2) * 53) + getResource().hashCode();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$OptionalResource");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            if (!hasResource() || getResource().isInitialized()) {
                this.memoizedIsInitialized = 1;
                return true;
            }
            this.memoizedIsInitialized = 0;
            return false;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessage(2, this.resource_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface OptionalResourceOrBuilder extends MessageLiteOrBuilder {
        Resource getResource();

        boolean hasResource();
    }

    public static final class Property extends GeneratedMessageLite implements PropertyOrBuilder {
        public static final int KEY_FIELD_NUMBER = 1;
        public static Parser<Property> PARSER = new AbstractParser<Property>() {
            /* class com.google.analytics.containertag.proto.Serving.Property.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public Property parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new Property(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int VALUE_FIELD_NUMBER = 2;
        private static final Property defaultInstance = new Property(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public int key_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;
        /* access modifiers changed from: private */
        public int value_;

        public static final class Builder extends GeneratedMessageLite.Builder<Property, Builder> implements PropertyOrBuilder {
            private int bitField0_;
            private int key_;
            private int value_;

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void maybeForceBuilderInitialization() {
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Property build() {
                Property buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Property buildPartial() {
                int i = 1;
                Property property = new Property(this);
                int i2 = this.bitField0_;
                if ((i2 & 1) != 1) {
                    i = 0;
                }
                int unused = property.key_ = this.key_;
                if ((i2 & 2) == 2) {
                    i |= 2;
                }
                int unused2 = property.value_ = this.value_;
                int unused3 = property.bitField0_ = i;
                return property;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.key_ = 0;
                this.bitField0_ &= -2;
                this.value_ = 0;
                this.bitField0_ &= -3;
                return this;
            }

            public Builder clearKey() {
                this.bitField0_ &= -2;
                this.key_ = 0;
                return this;
            }

            public Builder clearValue() {
                this.bitField0_ &= -3;
                this.value_ = 0;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public Property getDefaultInstanceForType() {
                return Property.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
            public int getKey() {
                return this.key_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
            public int getValue() {
                return this.value_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
            public boolean hasKey() {
                return (this.bitField0_ & 1) == 1;
            }

            @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
            public boolean hasValue() {
                return (this.bitField0_ & 2) == 2;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return hasKey() && hasValue();
            }

            public Builder mergeFrom(Property property) {
                if (property != Property.getDefaultInstance()) {
                    if (property.hasKey()) {
                        setKey(property.getKey());
                    }
                    if (property.hasValue()) {
                        setValue(property.getValue());
                    }
                    setUnknownFields(getUnknownFields().concat(property.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                Property property;
                Property property2 = null;
                try {
                    Property parsePartialFrom = Property.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    property = (Property) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    property2 = property;
                }
                if (property2 != null) {
                    mergeFrom(property2);
                }
                throw th;
            }

            public Builder setKey(int i) {
                this.bitField0_ |= 1;
                this.key_ = i;
                return this;
            }

            public Builder setValue(int i) {
                this.bitField0_ |= 2;
                this.value_ = i;
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        private Property(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            initFields();
            ByteString.Output newOutput = ByteString.newOutput();
            CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
            boolean z = false;
            while (!z) {
                try {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            this.bitField0_ |= 1;
                            this.key_ = codedInputStream.readInt32();
                            break;
                        case 16:
                            this.bitField0_ |= 2;
                            this.value_ = codedInputStream.readInt32();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                } catch (InvalidProtocolBufferException e) {
                    throw e.setUnfinishedMessage(this);
                } catch (IOException e2) {
                    throw new InvalidProtocolBufferException(e2.getMessage()).setUnfinishedMessage(this);
                } catch (Throwable th) {
                    try {
                        newInstance.flush();
                    } catch (IOException e3) {
                    } finally {
                        this.unknownFields = newOutput.toByteString();
                    }
                    makeExtensionsImmutable();
                    throw th;
                }
            }
            try {
                newInstance.flush();
            } catch (IOException e4) {
            } finally {
                this.unknownFields = newOutput.toByteString();
            }
            makeExtensionsImmutable();
        }

        private Property(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private Property(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static Property getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.key_ = 0;
            this.value_ = 0;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(Property property) {
            return newBuilder().mergeFrom(property);
        }

        public static Property parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static Property parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static Property parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static Property parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static Property parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static Property parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static Property parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static Property parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static Property parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static Property parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Property)) {
                return super.equals(obj);
            }
            Property property = (Property) obj;
            boolean z = hasKey() == property.hasKey();
            if (hasKey()) {
                z = z && getKey() == property.getKey();
            }
            boolean z2 = z && hasValue() == property.hasValue();
            return hasValue() ? z2 && getValue() == property.getValue() : z2;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public Property getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
        public int getKey() {
            return this.key_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<Property> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            if ((this.bitField0_ & 1) == 1) {
                i2 = CodedOutputStream.computeInt32Size(1, this.key_) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i2 += CodedOutputStream.computeInt32Size(2, this.value_);
            }
            int size = i2 + this.unknownFields.size();
            this.memoizedSerializedSize = size;
            return size;
        }

        @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
        public int getValue() {
            return this.value_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
        public boolean hasKey() {
            return (this.bitField0_ & 1) == 1;
        }

        @Override // com.google.analytics.containertag.proto.Serving.PropertyOrBuilder
        public boolean hasValue() {
            return (this.bitField0_ & 2) == 2;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = Property.class.hashCode() + 779;
            if (hasKey()) {
                hashCode = (((hashCode * 37) + 1) * 53) + getKey();
            }
            if (hasValue()) {
                hashCode = (((hashCode * 37) + 2) * 53) + getValue();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$Property");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            if (!hasKey()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else if (!hasValue()) {
                this.memoizedIsInitialized = 0;
                return false;
            } else {
                this.memoizedIsInitialized = 1;
                return true;
            }
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeInt32(1, this.key_);
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(2, this.value_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface PropertyOrBuilder extends MessageLiteOrBuilder {
        int getKey();

        int getValue();

        boolean hasKey();

        boolean hasValue();
    }

    public static final class Resource extends GeneratedMessageLite implements ResourceOrBuilder {
        public static final int ENABLE_AUTO_EVENT_TRACKING_FIELD_NUMBER = 18;
        public static final int KEY_FIELD_NUMBER = 1;
        public static final int LIVE_JS_CACHE_OPTION_FIELD_NUMBER = 14;
        public static final int MACRO_FIELD_NUMBER = 4;
        public static final int MALWARE_SCAN_AUTH_CODE_FIELD_NUMBER = 10;
        public static Parser<Resource> PARSER = new AbstractParser<Resource>() {
            /* class com.google.analytics.containertag.proto.Serving.Resource.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public Resource parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new Resource(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int PREDICATE_FIELD_NUMBER = 6;
        public static final int PREVIEW_AUTH_CODE_FIELD_NUMBER = 9;
        public static final int PROPERTY_FIELD_NUMBER = 3;
        public static final int REPORTING_SAMPLE_RATE_FIELD_NUMBER = 15;
        public static final int RESOURCE_FORMAT_VERSION_FIELD_NUMBER = 17;
        public static final int RULE_FIELD_NUMBER = 7;
        public static final int TAG_FIELD_NUMBER = 5;
        public static final int TEMPLATE_VERSION_SET_FIELD_NUMBER = 12;
        public static final int USAGE_CONTEXT_FIELD_NUMBER = 16;
        public static final int VALUE_FIELD_NUMBER = 2;
        public static final int VERSION_FIELD_NUMBER = 13;
        private static final Resource defaultInstance = new Resource(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public boolean enableAutoEventTracking_;
        /* access modifiers changed from: private */
        public LazyStringList key_;
        /* access modifiers changed from: private */
        public CacheOption liveJsCacheOption_;
        /* access modifiers changed from: private */
        public List<FunctionCall> macro_;
        /* access modifiers changed from: private */
        public Object malwareScanAuthCode_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public List<FunctionCall> predicate_;
        /* access modifiers changed from: private */
        public Object previewAuthCode_;
        /* access modifiers changed from: private */
        public List<Property> property_;
        /* access modifiers changed from: private */
        public float reportingSampleRate_;
        /* access modifiers changed from: private */
        public int resourceFormatVersion_;
        /* access modifiers changed from: private */
        public List<Rule> rule_;
        /* access modifiers changed from: private */
        public List<FunctionCall> tag_;
        /* access modifiers changed from: private */
        public Object templateVersionSet_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;
        /* access modifiers changed from: private */
        public LazyStringList usageContext_;
        /* access modifiers changed from: private */
        public List<TypeSystem.Value> value_;
        /* access modifiers changed from: private */
        public Object version_;

        public static final class Builder extends GeneratedMessageLite.Builder<Resource, Builder> implements ResourceOrBuilder {
            private int bitField0_;
            private boolean enableAutoEventTracking_;
            private LazyStringList key_ = LazyStringArrayList.EMPTY;
            private CacheOption liveJsCacheOption_ = CacheOption.getDefaultInstance();
            private List<FunctionCall> macro_ = Collections.emptyList();
            private Object malwareScanAuthCode_ = "";
            private List<FunctionCall> predicate_ = Collections.emptyList();
            private Object previewAuthCode_ = "";
            private List<Property> property_ = Collections.emptyList();
            private float reportingSampleRate_;
            private int resourceFormatVersion_;
            private List<Rule> rule_ = Collections.emptyList();
            private List<FunctionCall> tag_ = Collections.emptyList();
            private Object templateVersionSet_ = "0";
            private LazyStringList usageContext_ = LazyStringArrayList.EMPTY;
            private List<TypeSystem.Value> value_ = Collections.emptyList();
            private Object version_ = "";

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void ensureKeyIsMutable() {
                if ((this.bitField0_ & 1) != 1) {
                    this.key_ = new LazyStringArrayList(this.key_);
                    this.bitField0_ |= 1;
                }
            }

            private void ensureMacroIsMutable() {
                if ((this.bitField0_ & 8) != 8) {
                    this.macro_ = new ArrayList(this.macro_);
                    this.bitField0_ |= 8;
                }
            }

            private void ensurePredicateIsMutable() {
                if ((this.bitField0_ & 32) != 32) {
                    this.predicate_ = new ArrayList(this.predicate_);
                    this.bitField0_ |= 32;
                }
            }

            private void ensurePropertyIsMutable() {
                if ((this.bitField0_ & 4) != 4) {
                    this.property_ = new ArrayList(this.property_);
                    this.bitField0_ |= 4;
                }
            }

            private void ensureRuleIsMutable() {
                if ((this.bitField0_ & 64) != 64) {
                    this.rule_ = new ArrayList(this.rule_);
                    this.bitField0_ |= 64;
                }
            }

            private void ensureTagIsMutable() {
                if ((this.bitField0_ & 16) != 16) {
                    this.tag_ = new ArrayList(this.tag_);
                    this.bitField0_ |= 16;
                }
            }

            private void ensureUsageContextIsMutable() {
                if ((this.bitField0_ & 16384) != 16384) {
                    this.usageContext_ = new LazyStringArrayList(this.usageContext_);
                    this.bitField0_ |= 16384;
                }
            }

            private void ensureValueIsMutable() {
                if ((this.bitField0_ & 2) != 2) {
                    this.value_ = new ArrayList(this.value_);
                    this.bitField0_ |= 2;
                }
            }

            private void maybeForceBuilderInitialization() {
            }

            public Builder addAllKey(Iterable<String> iterable) {
                ensureKeyIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.key_);
                return this;
            }

            public Builder addAllMacro(Iterable<? extends FunctionCall> iterable) {
                ensureMacroIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.macro_);
                return this;
            }

            public Builder addAllPredicate(Iterable<? extends FunctionCall> iterable) {
                ensurePredicateIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.predicate_);
                return this;
            }

            public Builder addAllProperty(Iterable<? extends Property> iterable) {
                ensurePropertyIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.property_);
                return this;
            }

            public Builder addAllRule(Iterable<? extends Rule> iterable) {
                ensureRuleIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.rule_);
                return this;
            }

            public Builder addAllTag(Iterable<? extends FunctionCall> iterable) {
                ensureTagIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.tag_);
                return this;
            }

            public Builder addAllUsageContext(Iterable<String> iterable) {
                ensureUsageContextIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.usageContext_);
                return this;
            }

            public Builder addAllValue(Iterable<? extends TypeSystem.Value> iterable) {
                ensureValueIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.value_);
                return this;
            }

            public Builder addKey(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                ensureKeyIsMutable();
                this.key_.add(str);
                return this;
            }

            public Builder addKeyBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                ensureKeyIsMutable();
                this.key_.add(byteString);
                return this;
            }

            public Builder addMacro(int i, FunctionCall.Builder builder) {
                ensureMacroIsMutable();
                this.macro_.add(i, builder.build());
                return this;
            }

            public Builder addMacro(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureMacroIsMutable();
                this.macro_.add(i, functionCall);
                return this;
            }

            public Builder addMacro(FunctionCall.Builder builder) {
                ensureMacroIsMutable();
                this.macro_.add(builder.build());
                return this;
            }

            public Builder addMacro(FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureMacroIsMutable();
                this.macro_.add(functionCall);
                return this;
            }

            public Builder addPredicate(int i, FunctionCall.Builder builder) {
                ensurePredicateIsMutable();
                this.predicate_.add(i, builder.build());
                return this;
            }

            public Builder addPredicate(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensurePredicateIsMutable();
                this.predicate_.add(i, functionCall);
                return this;
            }

            public Builder addPredicate(FunctionCall.Builder builder) {
                ensurePredicateIsMutable();
                this.predicate_.add(builder.build());
                return this;
            }

            public Builder addPredicate(FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensurePredicateIsMutable();
                this.predicate_.add(functionCall);
                return this;
            }

            public Builder addProperty(int i, Property.Builder builder) {
                ensurePropertyIsMutable();
                this.property_.add(i, builder.build());
                return this;
            }

            public Builder addProperty(int i, Property property) {
                if (property == null) {
                    throw new NullPointerException();
                }
                ensurePropertyIsMutable();
                this.property_.add(i, property);
                return this;
            }

            public Builder addProperty(Property.Builder builder) {
                ensurePropertyIsMutable();
                this.property_.add(builder.build());
                return this;
            }

            public Builder addProperty(Property property) {
                if (property == null) {
                    throw new NullPointerException();
                }
                ensurePropertyIsMutable();
                this.property_.add(property);
                return this;
            }

            public Builder addRule(int i, Rule.Builder builder) {
                ensureRuleIsMutable();
                this.rule_.add(i, builder.build());
                return this;
            }

            public Builder addRule(int i, Rule rule) {
                if (rule == null) {
                    throw new NullPointerException();
                }
                ensureRuleIsMutable();
                this.rule_.add(i, rule);
                return this;
            }

            public Builder addRule(Rule.Builder builder) {
                ensureRuleIsMutable();
                this.rule_.add(builder.build());
                return this;
            }

            public Builder addRule(Rule rule) {
                if (rule == null) {
                    throw new NullPointerException();
                }
                ensureRuleIsMutable();
                this.rule_.add(rule);
                return this;
            }

            public Builder addTag(int i, FunctionCall.Builder builder) {
                ensureTagIsMutable();
                this.tag_.add(i, builder.build());
                return this;
            }

            public Builder addTag(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureTagIsMutable();
                this.tag_.add(i, functionCall);
                return this;
            }

            public Builder addTag(FunctionCall.Builder builder) {
                ensureTagIsMutable();
                this.tag_.add(builder.build());
                return this;
            }

            public Builder addTag(FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureTagIsMutable();
                this.tag_.add(functionCall);
                return this;
            }

            public Builder addUsageContext(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                ensureUsageContextIsMutable();
                this.usageContext_.add(str);
                return this;
            }

            public Builder addUsageContextBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                ensureUsageContextIsMutable();
                this.usageContext_.add(byteString);
                return this;
            }

            public Builder addValue(int i, TypeSystem.Value.Builder builder) {
                ensureValueIsMutable();
                this.value_.add(i, builder.build());
                return this;
            }

            public Builder addValue(int i, TypeSystem.Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureValueIsMutable();
                this.value_.add(i, value);
                return this;
            }

            public Builder addValue(TypeSystem.Value.Builder builder) {
                ensureValueIsMutable();
                this.value_.add(builder.build());
                return this;
            }

            public Builder addValue(TypeSystem.Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureValueIsMutable();
                this.value_.add(value);
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Resource build() {
                Resource buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Resource buildPartial() {
                int i = 1;
                Resource resource = new Resource(this);
                int i2 = this.bitField0_;
                if ((this.bitField0_ & 1) == 1) {
                    this.key_ = new UnmodifiableLazyStringList(this.key_);
                    this.bitField0_ &= -2;
                }
                LazyStringList unused = resource.key_ = this.key_;
                if ((this.bitField0_ & 2) == 2) {
                    this.value_ = Collections.unmodifiableList(this.value_);
                    this.bitField0_ &= -3;
                }
                List unused2 = resource.value_ = this.value_;
                if ((this.bitField0_ & 4) == 4) {
                    this.property_ = Collections.unmodifiableList(this.property_);
                    this.bitField0_ &= -5;
                }
                List unused3 = resource.property_ = this.property_;
                if ((this.bitField0_ & 8) == 8) {
                    this.macro_ = Collections.unmodifiableList(this.macro_);
                    this.bitField0_ &= -9;
                }
                List unused4 = resource.macro_ = this.macro_;
                if ((this.bitField0_ & 16) == 16) {
                    this.tag_ = Collections.unmodifiableList(this.tag_);
                    this.bitField0_ &= -17;
                }
                List unused5 = resource.tag_ = this.tag_;
                if ((this.bitField0_ & 32) == 32) {
                    this.predicate_ = Collections.unmodifiableList(this.predicate_);
                    this.bitField0_ &= -33;
                }
                List unused6 = resource.predicate_ = this.predicate_;
                if ((this.bitField0_ & 64) == 64) {
                    this.rule_ = Collections.unmodifiableList(this.rule_);
                    this.bitField0_ &= -65;
                }
                List unused7 = resource.rule_ = this.rule_;
                if ((i2 & 128) != 128) {
                    i = 0;
                }
                Object unused8 = resource.previewAuthCode_ = this.previewAuthCode_;
                if ((i2 & 256) == 256) {
                    i |= 2;
                }
                Object unused9 = resource.malwareScanAuthCode_ = this.malwareScanAuthCode_;
                if ((i2 & 512) == 512) {
                    i |= 4;
                }
                Object unused10 = resource.templateVersionSet_ = this.templateVersionSet_;
                if ((i2 & 1024) == 1024) {
                    i |= 8;
                }
                Object unused11 = resource.version_ = this.version_;
                if ((i2 & 2048) == 2048) {
                    i |= 16;
                }
                CacheOption unused12 = resource.liveJsCacheOption_ = this.liveJsCacheOption_;
                if ((i2 & 4096) == 4096) {
                    i |= 32;
                }
                float unused13 = resource.reportingSampleRate_ = this.reportingSampleRate_;
                if ((i2 & 8192) == 8192) {
                    i |= 64;
                }
                boolean unused14 = resource.enableAutoEventTracking_ = this.enableAutoEventTracking_;
                if ((this.bitField0_ & 16384) == 16384) {
                    this.usageContext_ = new UnmodifiableLazyStringList(this.usageContext_);
                    this.bitField0_ &= -16385;
                }
                LazyStringList unused15 = resource.usageContext_ = this.usageContext_;
                if ((i2 & 32768) == 32768) {
                    i |= 128;
                }
                int unused16 = resource.resourceFormatVersion_ = this.resourceFormatVersion_;
                int unused17 = resource.bitField0_ = i;
                return resource;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.key_ = LazyStringArrayList.EMPTY;
                this.bitField0_ &= -2;
                this.value_ = Collections.emptyList();
                this.bitField0_ &= -3;
                this.property_ = Collections.emptyList();
                this.bitField0_ &= -5;
                this.macro_ = Collections.emptyList();
                this.bitField0_ &= -9;
                this.tag_ = Collections.emptyList();
                this.bitField0_ &= -17;
                this.predicate_ = Collections.emptyList();
                this.bitField0_ &= -33;
                this.rule_ = Collections.emptyList();
                this.bitField0_ &= -65;
                this.previewAuthCode_ = "";
                this.bitField0_ &= -129;
                this.malwareScanAuthCode_ = "";
                this.bitField0_ &= -257;
                this.templateVersionSet_ = "0";
                this.bitField0_ &= -513;
                this.version_ = "";
                this.bitField0_ &= -1025;
                this.liveJsCacheOption_ = CacheOption.getDefaultInstance();
                this.bitField0_ &= -2049;
                this.reportingSampleRate_ = 0.0f;
                this.bitField0_ &= -4097;
                this.enableAutoEventTracking_ = false;
                this.bitField0_ &= -8193;
                this.usageContext_ = LazyStringArrayList.EMPTY;
                this.bitField0_ &= -16385;
                this.resourceFormatVersion_ = 0;
                this.bitField0_ &= -32769;
                return this;
            }

            public Builder clearEnableAutoEventTracking() {
                this.bitField0_ &= -8193;
                this.enableAutoEventTracking_ = false;
                return this;
            }

            public Builder clearKey() {
                this.key_ = LazyStringArrayList.EMPTY;
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearLiveJsCacheOption() {
                this.liveJsCacheOption_ = CacheOption.getDefaultInstance();
                this.bitField0_ &= -2049;
                return this;
            }

            public Builder clearMacro() {
                this.macro_ = Collections.emptyList();
                this.bitField0_ &= -9;
                return this;
            }

            public Builder clearMalwareScanAuthCode() {
                this.bitField0_ &= -257;
                this.malwareScanAuthCode_ = Resource.getDefaultInstance().getMalwareScanAuthCode();
                return this;
            }

            public Builder clearPredicate() {
                this.predicate_ = Collections.emptyList();
                this.bitField0_ &= -33;
                return this;
            }

            public Builder clearPreviewAuthCode() {
                this.bitField0_ &= -129;
                this.previewAuthCode_ = Resource.getDefaultInstance().getPreviewAuthCode();
                return this;
            }

            public Builder clearProperty() {
                this.property_ = Collections.emptyList();
                this.bitField0_ &= -5;
                return this;
            }

            public Builder clearReportingSampleRate() {
                this.bitField0_ &= -4097;
                this.reportingSampleRate_ = 0.0f;
                return this;
            }

            public Builder clearResourceFormatVersion() {
                this.bitField0_ &= -32769;
                this.resourceFormatVersion_ = 0;
                return this;
            }

            public Builder clearRule() {
                this.rule_ = Collections.emptyList();
                this.bitField0_ &= -65;
                return this;
            }

            public Builder clearTag() {
                this.tag_ = Collections.emptyList();
                this.bitField0_ &= -17;
                return this;
            }

            public Builder clearTemplateVersionSet() {
                this.bitField0_ &= -513;
                this.templateVersionSet_ = Resource.getDefaultInstance().getTemplateVersionSet();
                return this;
            }

            public Builder clearUsageContext() {
                this.usageContext_ = LazyStringArrayList.EMPTY;
                this.bitField0_ &= -16385;
                return this;
            }

            public Builder clearValue() {
                this.value_ = Collections.emptyList();
                this.bitField0_ &= -3;
                return this;
            }

            public Builder clearVersion() {
                this.bitField0_ &= -1025;
                this.version_ = Resource.getDefaultInstance().getVersion();
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public Resource getDefaultInstanceForType() {
                return Resource.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean getEnableAutoEventTracking() {
                return this.enableAutoEventTracking_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getKey(int i) {
                return (String) this.key_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getKeyBytes(int i) {
                return this.key_.getByteString(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getKeyCount() {
                return this.key_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<String> getKeyList() {
                return Collections.unmodifiableList(this.key_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public CacheOption getLiveJsCacheOption() {
                return this.liveJsCacheOption_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public FunctionCall getMacro(int i) {
                return this.macro_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getMacroCount() {
                return this.macro_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<FunctionCall> getMacroList() {
                return Collections.unmodifiableList(this.macro_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getMalwareScanAuthCode() {
                Object obj = this.malwareScanAuthCode_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.malwareScanAuthCode_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getMalwareScanAuthCodeBytes() {
                Object obj = this.malwareScanAuthCode_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.malwareScanAuthCode_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public FunctionCall getPredicate(int i) {
                return this.predicate_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getPredicateCount() {
                return this.predicate_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<FunctionCall> getPredicateList() {
                return Collections.unmodifiableList(this.predicate_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getPreviewAuthCode() {
                Object obj = this.previewAuthCode_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.previewAuthCode_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getPreviewAuthCodeBytes() {
                Object obj = this.previewAuthCode_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.previewAuthCode_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public Property getProperty(int i) {
                return this.property_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getPropertyCount() {
                return this.property_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<Property> getPropertyList() {
                return Collections.unmodifiableList(this.property_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public float getReportingSampleRate() {
                return this.reportingSampleRate_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getResourceFormatVersion() {
                return this.resourceFormatVersion_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public Rule getRule(int i) {
                return this.rule_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getRuleCount() {
                return this.rule_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<Rule> getRuleList() {
                return Collections.unmodifiableList(this.rule_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public FunctionCall getTag(int i) {
                return this.tag_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getTagCount() {
                return this.tag_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<FunctionCall> getTagList() {
                return Collections.unmodifiableList(this.tag_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getTemplateVersionSet() {
                Object obj = this.templateVersionSet_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.templateVersionSet_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getTemplateVersionSetBytes() {
                Object obj = this.templateVersionSet_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.templateVersionSet_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getUsageContext(int i) {
                return (String) this.usageContext_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getUsageContextBytes(int i) {
                return this.usageContext_.getByteString(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getUsageContextCount() {
                return this.usageContext_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<String> getUsageContextList() {
                return Collections.unmodifiableList(this.usageContext_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public TypeSystem.Value getValue(int i) {
                return this.value_.get(i);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public int getValueCount() {
                return this.value_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public List<TypeSystem.Value> getValueList() {
                return Collections.unmodifiableList(this.value_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public String getVersion() {
                Object obj = this.version_;
                if (obj instanceof String) {
                    return (String) obj;
                }
                ByteString byteString = (ByteString) obj;
                String stringUtf8 = byteString.toStringUtf8();
                if (byteString.isValidUtf8()) {
                    this.version_ = stringUtf8;
                }
                return stringUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public ByteString getVersionBytes() {
                Object obj = this.version_;
                if (!(obj instanceof String)) {
                    return (ByteString) obj;
                }
                ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
                this.version_ = copyFromUtf8;
                return copyFromUtf8;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasEnableAutoEventTracking() {
                return (this.bitField0_ & 8192) == 8192;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasLiveJsCacheOption() {
                return (this.bitField0_ & 2048) == 2048;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasMalwareScanAuthCode() {
                return (this.bitField0_ & 256) == 256;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasPreviewAuthCode() {
                return (this.bitField0_ & 128) == 128;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasReportingSampleRate() {
                return (this.bitField0_ & 4096) == 4096;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasResourceFormatVersion() {
                return (this.bitField0_ & 32768) == 32768;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasTemplateVersionSet() {
                return (this.bitField0_ & 512) == 512;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
            public boolean hasVersion() {
                return (this.bitField0_ & 1024) == 1024;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                for (int i = 0; i < getValueCount(); i++) {
                    if (!getValue(i).isInitialized()) {
                        return false;
                    }
                }
                for (int i2 = 0; i2 < getPropertyCount(); i2++) {
                    if (!getProperty(i2).isInitialized()) {
                        return false;
                    }
                }
                for (int i3 = 0; i3 < getMacroCount(); i3++) {
                    if (!getMacro(i3).isInitialized()) {
                        return false;
                    }
                }
                for (int i4 = 0; i4 < getTagCount(); i4++) {
                    if (!getTag(i4).isInitialized()) {
                        return false;
                    }
                }
                for (int i5 = 0; i5 < getPredicateCount(); i5++) {
                    if (!getPredicate(i5).isInitialized()) {
                        return false;
                    }
                }
                return true;
            }

            public Builder mergeFrom(Resource resource) {
                if (resource != Resource.getDefaultInstance()) {
                    if (!resource.key_.isEmpty()) {
                        if (this.key_.isEmpty()) {
                            this.key_ = resource.key_;
                            this.bitField0_ &= -2;
                        } else {
                            ensureKeyIsMutable();
                            this.key_.addAll(resource.key_);
                        }
                    }
                    if (!resource.value_.isEmpty()) {
                        if (this.value_.isEmpty()) {
                            this.value_ = resource.value_;
                            this.bitField0_ &= -3;
                        } else {
                            ensureValueIsMutable();
                            this.value_.addAll(resource.value_);
                        }
                    }
                    if (!resource.property_.isEmpty()) {
                        if (this.property_.isEmpty()) {
                            this.property_ = resource.property_;
                            this.bitField0_ &= -5;
                        } else {
                            ensurePropertyIsMutable();
                            this.property_.addAll(resource.property_);
                        }
                    }
                    if (!resource.macro_.isEmpty()) {
                        if (this.macro_.isEmpty()) {
                            this.macro_ = resource.macro_;
                            this.bitField0_ &= -9;
                        } else {
                            ensureMacroIsMutable();
                            this.macro_.addAll(resource.macro_);
                        }
                    }
                    if (!resource.tag_.isEmpty()) {
                        if (this.tag_.isEmpty()) {
                            this.tag_ = resource.tag_;
                            this.bitField0_ &= -17;
                        } else {
                            ensureTagIsMutable();
                            this.tag_.addAll(resource.tag_);
                        }
                    }
                    if (!resource.predicate_.isEmpty()) {
                        if (this.predicate_.isEmpty()) {
                            this.predicate_ = resource.predicate_;
                            this.bitField0_ &= -33;
                        } else {
                            ensurePredicateIsMutable();
                            this.predicate_.addAll(resource.predicate_);
                        }
                    }
                    if (!resource.rule_.isEmpty()) {
                        if (this.rule_.isEmpty()) {
                            this.rule_ = resource.rule_;
                            this.bitField0_ &= -65;
                        } else {
                            ensureRuleIsMutable();
                            this.rule_.addAll(resource.rule_);
                        }
                    }
                    if (resource.hasPreviewAuthCode()) {
                        this.bitField0_ |= 128;
                        this.previewAuthCode_ = resource.previewAuthCode_;
                    }
                    if (resource.hasMalwareScanAuthCode()) {
                        this.bitField0_ |= 256;
                        this.malwareScanAuthCode_ = resource.malwareScanAuthCode_;
                    }
                    if (resource.hasTemplateVersionSet()) {
                        this.bitField0_ |= 512;
                        this.templateVersionSet_ = resource.templateVersionSet_;
                    }
                    if (resource.hasVersion()) {
                        this.bitField0_ |= 1024;
                        this.version_ = resource.version_;
                    }
                    if (resource.hasLiveJsCacheOption()) {
                        mergeLiveJsCacheOption(resource.getLiveJsCacheOption());
                    }
                    if (resource.hasReportingSampleRate()) {
                        setReportingSampleRate(resource.getReportingSampleRate());
                    }
                    if (resource.hasEnableAutoEventTracking()) {
                        setEnableAutoEventTracking(resource.getEnableAutoEventTracking());
                    }
                    if (!resource.usageContext_.isEmpty()) {
                        if (this.usageContext_.isEmpty()) {
                            this.usageContext_ = resource.usageContext_;
                            this.bitField0_ &= -16385;
                        } else {
                            ensureUsageContextIsMutable();
                            this.usageContext_.addAll(resource.usageContext_);
                        }
                    }
                    if (resource.hasResourceFormatVersion()) {
                        setResourceFormatVersion(resource.getResourceFormatVersion());
                    }
                    setUnknownFields(getUnknownFields().concat(resource.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                Resource resource;
                Resource resource2 = null;
                try {
                    Resource parsePartialFrom = Resource.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    resource = (Resource) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    resource2 = resource;
                }
                if (resource2 != null) {
                    mergeFrom(resource2);
                }
                throw th;
            }

            public Builder mergeLiveJsCacheOption(CacheOption cacheOption) {
                if ((this.bitField0_ & 2048) != 2048 || this.liveJsCacheOption_ == CacheOption.getDefaultInstance()) {
                    this.liveJsCacheOption_ = cacheOption;
                } else {
                    this.liveJsCacheOption_ = CacheOption.newBuilder(this.liveJsCacheOption_).mergeFrom(cacheOption).buildPartial();
                }
                this.bitField0_ |= 2048;
                return this;
            }

            public Builder removeMacro(int i) {
                ensureMacroIsMutable();
                this.macro_.remove(i);
                return this;
            }

            public Builder removePredicate(int i) {
                ensurePredicateIsMutable();
                this.predicate_.remove(i);
                return this;
            }

            public Builder removeProperty(int i) {
                ensurePropertyIsMutable();
                this.property_.remove(i);
                return this;
            }

            public Builder removeRule(int i) {
                ensureRuleIsMutable();
                this.rule_.remove(i);
                return this;
            }

            public Builder removeTag(int i) {
                ensureTagIsMutable();
                this.tag_.remove(i);
                return this;
            }

            public Builder removeValue(int i) {
                ensureValueIsMutable();
                this.value_.remove(i);
                return this;
            }

            public Builder setEnableAutoEventTracking(boolean z) {
                this.bitField0_ |= 8192;
                this.enableAutoEventTracking_ = z;
                return this;
            }

            public Builder setKey(int i, String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                ensureKeyIsMutable();
                this.key_.set(i, str);
                return this;
            }

            public Builder setLiveJsCacheOption(CacheOption.Builder builder) {
                this.liveJsCacheOption_ = builder.build();
                this.bitField0_ |= 2048;
                return this;
            }

            public Builder setLiveJsCacheOption(CacheOption cacheOption) {
                if (cacheOption == null) {
                    throw new NullPointerException();
                }
                this.liveJsCacheOption_ = cacheOption;
                this.bitField0_ |= 2048;
                return this;
            }

            public Builder setMacro(int i, FunctionCall.Builder builder) {
                ensureMacroIsMutable();
                this.macro_.set(i, builder.build());
                return this;
            }

            public Builder setMacro(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureMacroIsMutable();
                this.macro_.set(i, functionCall);
                return this;
            }

            public Builder setMalwareScanAuthCode(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 256;
                this.malwareScanAuthCode_ = str;
                return this;
            }

            public Builder setMalwareScanAuthCodeBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 256;
                this.malwareScanAuthCode_ = byteString;
                return this;
            }

            public Builder setPredicate(int i, FunctionCall.Builder builder) {
                ensurePredicateIsMutable();
                this.predicate_.set(i, builder.build());
                return this;
            }

            public Builder setPredicate(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensurePredicateIsMutable();
                this.predicate_.set(i, functionCall);
                return this;
            }

            public Builder setPreviewAuthCode(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 128;
                this.previewAuthCode_ = str;
                return this;
            }

            public Builder setPreviewAuthCodeBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 128;
                this.previewAuthCode_ = byteString;
                return this;
            }

            public Builder setProperty(int i, Property.Builder builder) {
                ensurePropertyIsMutable();
                this.property_.set(i, builder.build());
                return this;
            }

            public Builder setProperty(int i, Property property) {
                if (property == null) {
                    throw new NullPointerException();
                }
                ensurePropertyIsMutable();
                this.property_.set(i, property);
                return this;
            }

            public Builder setReportingSampleRate(float f) {
                this.bitField0_ |= 4096;
                this.reportingSampleRate_ = f;
                return this;
            }

            public Builder setResourceFormatVersion(int i) {
                this.bitField0_ |= 32768;
                this.resourceFormatVersion_ = i;
                return this;
            }

            public Builder setRule(int i, Rule.Builder builder) {
                ensureRuleIsMutable();
                this.rule_.set(i, builder.build());
                return this;
            }

            public Builder setRule(int i, Rule rule) {
                if (rule == null) {
                    throw new NullPointerException();
                }
                ensureRuleIsMutable();
                this.rule_.set(i, rule);
                return this;
            }

            public Builder setTag(int i, FunctionCall.Builder builder) {
                ensureTagIsMutable();
                this.tag_.set(i, builder.build());
                return this;
            }

            public Builder setTag(int i, FunctionCall functionCall) {
                if (functionCall == null) {
                    throw new NullPointerException();
                }
                ensureTagIsMutable();
                this.tag_.set(i, functionCall);
                return this;
            }

            public Builder setTemplateVersionSet(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 512;
                this.templateVersionSet_ = str;
                return this;
            }

            public Builder setTemplateVersionSetBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 512;
                this.templateVersionSet_ = byteString;
                return this;
            }

            public Builder setUsageContext(int i, String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                ensureUsageContextIsMutable();
                this.usageContext_.set(i, str);
                return this;
            }

            public Builder setValue(int i, TypeSystem.Value.Builder builder) {
                ensureValueIsMutable();
                this.value_.set(i, builder.build());
                return this;
            }

            public Builder setValue(int i, TypeSystem.Value value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                ensureValueIsMutable();
                this.value_.set(i, value);
                return this;
            }

            public Builder setVersion(String str) {
                if (str == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 1024;
                this.version_ = str;
                return this;
            }

            public Builder setVersionBytes(ByteString byteString) {
                if (byteString == null) {
                    throw new NullPointerException();
                }
                this.bitField0_ |= 1024;
                this.version_ = byteString;
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v88, resolved type: java.util.List<com.google.analytics.containertag.proto.Serving$Rule>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v91, resolved type: java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v94, resolved type: java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v97, resolved type: java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v100, resolved type: java.util.List<com.google.analytics.containertag.proto.Serving$Property>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v103, resolved type: java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:24:0x0055  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x0062  */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x006e  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x007a  */
        /* JADX WARNING: Removed duplicated region for block: B:36:0x0086  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x0094  */
        /* JADX WARNING: Removed duplicated region for block: B:42:0x00a2  */
        /* JADX WARNING: Removed duplicated region for block: B:45:0x00b0  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private Resource(com.google.tagmanager.protobuf.CodedInputStream r13, com.google.tagmanager.protobuf.ExtensionRegistryLite r14) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
            /*
                r12 = this;
                r11 = 8
                r10 = 4
                r9 = 2
                r8 = 16
                r4 = 1
                r12.<init>()
                r0 = -1
                r12.memoizedIsInitialized = r0
                r0 = -1
                r12.memoizedSerializedSize = r0
                r12.initFields()
                r1 = 0
                com.google.tagmanager.protobuf.ByteString$Output r5 = com.google.tagmanager.protobuf.ByteString.newOutput()
                com.google.tagmanager.protobuf.CodedOutputStream r6 = com.google.tagmanager.protobuf.CodedOutputStream.newInstance(r5)
                r0 = 0
                r3 = r0
            L_0x001e:
                if (r3 != 0) goto L_0x0224
                int r0 = r13.readTag()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                switch(r0) {
                    case 0: goto L_0x02ba;
                    case 10: goto L_0x002f;
                    case 18: goto L_0x00c6;
                    case 26: goto L_0x00f5;
                    case 34: goto L_0x010f;
                    case 42: goto L_0x0129;
                    case 50: goto L_0x0143;
                    case 58: goto L_0x015f;
                    case 74: goto L_0x017b;
                    case 82: goto L_0x0189;
                    case 98: goto L_0x0197;
                    case 106: goto L_0x01a5;
                    case 114: goto L_0x01b3;
                    case 125: goto L_0x01e0;
                    case 130: goto L_0x01ee;
                    case 136: goto L_0x0208;
                    case 144: goto L_0x0216;
                    default: goto L_0x0027;
                }     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
            L_0x0027:
                boolean r0 = r12.parseUnknownField(r13, r6, r14, r0)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                if (r0 != 0) goto L_0x001e
                r3 = r4
                goto L_0x001e
            L_0x002f:
                com.google.tagmanager.protobuf.ByteString r2 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r1 & 1
                if (r0 == r4) goto L_0x02ce
                com.google.tagmanager.protobuf.LazyStringArrayList r0 = new com.google.tagmanager.protobuf.LazyStringArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.key_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r1 | 1
            L_0x0040:
                com.google.tagmanager.protobuf.LazyStringList r1 = r12.key_     // Catch:{ InvalidProtocolBufferException -> 0x02c6, IOException -> 0x02bd, all -> 0x02c1 }
                r1.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x02c6, IOException -> 0x02bd, all -> 0x02c1 }
                r1 = r0
                goto L_0x001e
            L_0x0047:
                r0 = move-exception
                r2 = r0
                r3 = r1
            L_0x004a:
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r2.setUnfinishedMessage(r12)     // Catch:{ all -> 0x004f }
                throw r0     // Catch:{ all -> 0x004f }
            L_0x004f:
                r0 = move-exception
                r2 = r0
            L_0x0051:
                r0 = r3 & 1
                if (r0 != r4) goto L_0x005e
                com.google.tagmanager.protobuf.UnmodifiableLazyStringList r0 = new com.google.tagmanager.protobuf.UnmodifiableLazyStringList
                com.google.tagmanager.protobuf.LazyStringList r1 = r12.key_
                r0.<init>(r1)
                r12.key_ = r0
            L_0x005e:
                r0 = r3 & 2
                if (r0 != r9) goto L_0x006a
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r12.value_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.value_ = r0
            L_0x006a:
                r0 = r3 & 4
                if (r0 != r10) goto L_0x0076
                java.util.List<com.google.analytics.containertag.proto.Serving$Property> r0 = r12.property_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.property_ = r0
            L_0x0076:
                r0 = r3 & 8
                if (r0 != r11) goto L_0x0082
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.macro_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.macro_ = r0
            L_0x0082:
                r0 = r3 & 16
                if (r0 != r8) goto L_0x008e
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.tag_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.tag_ = r0
            L_0x008e:
                r0 = r3 & 32
                r1 = 32
                if (r0 != r1) goto L_0x009c
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.predicate_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.predicate_ = r0
            L_0x009c:
                r0 = r3 & 64
                r1 = 64
                if (r0 != r1) goto L_0x00aa
                java.util.List<com.google.analytics.containertag.proto.Serving$Rule> r0 = r12.rule_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.rule_ = r0
            L_0x00aa:
                r0 = r3 & 16384(0x4000, float:2.2959E-41)
                r1 = 16384(0x4000, float:2.2959E-41)
                if (r0 != r1) goto L_0x00b9
                com.google.tagmanager.protobuf.UnmodifiableLazyStringList r0 = new com.google.tagmanager.protobuf.UnmodifiableLazyStringList
                com.google.tagmanager.protobuf.LazyStringList r1 = r12.usageContext_
                r0.<init>(r1)
                r12.usageContext_ = r0
            L_0x00b9:
                r6.flush()     // Catch:{ IOException -> 0x02a9, all -> 0x02b2 }
                com.google.tagmanager.protobuf.ByteString r0 = r5.toByteString()
                r12.unknownFields = r0
            L_0x00c2:
                r12.makeExtensionsImmutable()
                throw r2
            L_0x00c6:
                r0 = r1 & 2
                if (r0 == r9) goto L_0x00d3
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.value_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 2
            L_0x00d3:
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r12.value_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r2 = com.google.analytics.midtier.proto.containertag.TypeSystem.Value.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x00e0:
                r0 = move-exception
                r2 = r0
            L_0x00e2:
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = new com.google.tagmanager.protobuf.InvalidProtocolBufferException     // Catch:{ all -> 0x00f0 }
                java.lang.String r2 = r2.getMessage()     // Catch:{ all -> 0x00f0 }
                r0.<init>(r2)     // Catch:{ all -> 0x00f0 }
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r0.setUnfinishedMessage(r12)     // Catch:{ all -> 0x00f0 }
                throw r0     // Catch:{ all -> 0x00f0 }
            L_0x00f0:
                r0 = move-exception
                r2 = r0
                r3 = r1
                goto L_0x0051
            L_0x00f5:
                r0 = r1 & 4
                if (r0 == r10) goto L_0x0102
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.property_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 4
            L_0x0102:
                java.util.List<com.google.analytics.containertag.proto.Serving$Property> r0 = r12.property_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$Property> r2 = com.google.analytics.containertag.proto.Serving.Property.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x010f:
                r0 = r1 & 8
                if (r0 == r11) goto L_0x011c
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.macro_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 8
            L_0x011c:
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.macro_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$FunctionCall> r2 = com.google.analytics.containertag.proto.Serving.FunctionCall.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0129:
                r0 = r1 & 16
                if (r0 == r8) goto L_0x0136
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.tag_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 16
            L_0x0136:
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.tag_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$FunctionCall> r2 = com.google.analytics.containertag.proto.Serving.FunctionCall.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0143:
                r0 = r1 & 32
                r2 = 32
                if (r0 == r2) goto L_0x0152
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.predicate_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 32
            L_0x0152:
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.predicate_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$FunctionCall> r2 = com.google.analytics.containertag.proto.Serving.FunctionCall.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x015f:
                r0 = r1 & 64
                r2 = 64
                if (r0 == r2) goto L_0x016e
                java.util.ArrayList r0 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.rule_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 64
            L_0x016e:
                java.util.List<com.google.analytics.containertag.proto.Serving$Rule> r0 = r12.rule_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$Rule> r2 = com.google.analytics.containertag.proto.Serving.Rule.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r2 = r13.readMessage(r2, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0.add(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x017b:
                com.google.tagmanager.protobuf.ByteString r0 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                int r2 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r2 | 1
                r12.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.previewAuthCode_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0189:
                com.google.tagmanager.protobuf.ByteString r0 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                int r2 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r2 | 2
                r12.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.malwareScanAuthCode_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0197:
                com.google.tagmanager.protobuf.ByteString r0 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                int r2 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r2 | 4
                r12.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.templateVersionSet_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x01a5:
                com.google.tagmanager.protobuf.ByteString r0 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                int r2 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r2 | 8
                r12.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.version_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x01b3:
                r0 = 0
                int r2 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r2 & 16
                if (r2 != r8) goto L_0x02cb
                com.google.analytics.containertag.proto.Serving$CacheOption r0 = r12.liveJsCacheOption_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.analytics.containertag.proto.Serving$CacheOption$Builder r0 = r0.toBuilder()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r0
            L_0x01c1:
                com.google.tagmanager.protobuf.Parser<com.google.analytics.containertag.proto.Serving$CacheOption> r0 = com.google.analytics.containertag.proto.Serving.CacheOption.PARSER     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.tagmanager.protobuf.MessageLite r0 = r13.readMessage(r0, r14)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.analytics.containertag.proto.Serving$CacheOption r0 = (com.google.analytics.containertag.proto.Serving.CacheOption) r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.liveJsCacheOption_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                if (r2 == 0) goto L_0x01d8
                com.google.analytics.containertag.proto.Serving$CacheOption r0 = r12.liveJsCacheOption_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2.mergeFrom(r0)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                com.google.analytics.containertag.proto.Serving$CacheOption r0 = r2.buildPartial()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.liveJsCacheOption_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
            L_0x01d8:
                int r0 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r0 | 16
                r12.bitField0_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x01e0:
                int r0 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r0 | 32
                r12.bitField0_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                float r0 = r13.readFloat()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.reportingSampleRate_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x01ee:
                com.google.tagmanager.protobuf.ByteString r0 = r13.readBytes()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2 = r1 & 16384(0x4000, float:2.2959E-41)
                r7 = 16384(0x4000, float:2.2959E-41)
                if (r2 == r7) goto L_0x0201
                com.google.tagmanager.protobuf.LazyStringArrayList r2 = new com.google.tagmanager.protobuf.LazyStringArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.usageContext_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r1 = r1 | 16384(0x4000, float:2.2959E-41)
            L_0x0201:
                com.google.tagmanager.protobuf.LazyStringList r2 = r12.usageContext_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r2.add(r0)     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0208:
                int r0 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r0 | 128(0x80, float:1.794E-43)
                r12.bitField0_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                int r0 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.resourceFormatVersion_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0216:
                int r0 = r12.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r0 = r0 | 64
                r12.bitField0_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                boolean r0 = r13.readBool()     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                r12.enableAutoEventTracking_ = r0     // Catch:{ InvalidProtocolBufferException -> 0x0047, IOException -> 0x00e0 }
                goto L_0x001e
            L_0x0224:
                r0 = r1 & 1
                if (r0 != r4) goto L_0x0231
                com.google.tagmanager.protobuf.UnmodifiableLazyStringList r0 = new com.google.tagmanager.protobuf.UnmodifiableLazyStringList
                com.google.tagmanager.protobuf.LazyStringList r2 = r12.key_
                r0.<init>(r2)
                r12.key_ = r0
            L_0x0231:
                r0 = r1 & 2
                if (r0 != r9) goto L_0x023d
                java.util.List<com.google.analytics.midtier.proto.containertag.TypeSystem$Value> r0 = r12.value_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.value_ = r0
            L_0x023d:
                r0 = r1 & 4
                if (r0 != r10) goto L_0x0249
                java.util.List<com.google.analytics.containertag.proto.Serving$Property> r0 = r12.property_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.property_ = r0
            L_0x0249:
                r0 = r1 & 8
                if (r0 != r11) goto L_0x0255
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.macro_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.macro_ = r0
            L_0x0255:
                r0 = r1 & 16
                if (r0 != r8) goto L_0x0261
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.tag_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.tag_ = r0
            L_0x0261:
                r0 = r1 & 32
                r2 = 32
                if (r0 != r2) goto L_0x026f
                java.util.List<com.google.analytics.containertag.proto.Serving$FunctionCall> r0 = r12.predicate_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.predicate_ = r0
            L_0x026f:
                r0 = r1 & 64
                r2 = 64
                if (r0 != r2) goto L_0x027d
                java.util.List<com.google.analytics.containertag.proto.Serving$Rule> r0 = r12.rule_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.rule_ = r0
            L_0x027d:
                r0 = r1 & 16384(0x4000, float:2.2959E-41)
                r1 = 16384(0x4000, float:2.2959E-41)
                if (r0 != r1) goto L_0x028c
                com.google.tagmanager.protobuf.UnmodifiableLazyStringList r0 = new com.google.tagmanager.protobuf.UnmodifiableLazyStringList
                com.google.tagmanager.protobuf.LazyStringList r1 = r12.usageContext_
                r0.<init>(r1)
                r12.usageContext_ = r0
            L_0x028c:
                r6.flush()     // Catch:{ IOException -> 0x0299, all -> 0x02a1 }
                com.google.tagmanager.protobuf.ByteString r0 = r5.toByteString()
                r12.unknownFields = r0
            L_0x0295:
                r12.makeExtensionsImmutable()
                return
            L_0x0299:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r5.toByteString()
                r12.unknownFields = r0
                goto L_0x0295
            L_0x02a1:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r5.toByteString()
                r12.unknownFields = r1
                throw r0
            L_0x02a9:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r5.toByteString()
                r12.unknownFields = r0
                goto L_0x00c2
            L_0x02b2:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r5.toByteString()
                r12.unknownFields = r1
                throw r0
            L_0x02ba:
                r3 = r4
                goto L_0x001e
            L_0x02bd:
                r2 = move-exception
                r1 = r0
                goto L_0x00e2
            L_0x02c1:
                r1 = move-exception
                r2 = r1
                r3 = r0
                goto L_0x0051
            L_0x02c6:
                r1 = move-exception
                r2 = r1
                r3 = r0
                goto L_0x004a
            L_0x02cb:
                r2 = r0
                goto L_0x01c1
            L_0x02ce:
                r0 = r1
                goto L_0x0040
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.containertag.proto.Serving.Resource.<init>(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):void");
        }

        private Resource(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private Resource(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static Resource getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.key_ = LazyStringArrayList.EMPTY;
            this.value_ = Collections.emptyList();
            this.property_ = Collections.emptyList();
            this.macro_ = Collections.emptyList();
            this.tag_ = Collections.emptyList();
            this.predicate_ = Collections.emptyList();
            this.rule_ = Collections.emptyList();
            this.previewAuthCode_ = "";
            this.malwareScanAuthCode_ = "";
            this.templateVersionSet_ = "0";
            this.version_ = "";
            this.liveJsCacheOption_ = CacheOption.getDefaultInstance();
            this.reportingSampleRate_ = 0.0f;
            this.enableAutoEventTracking_ = false;
            this.usageContext_ = LazyStringArrayList.EMPTY;
            this.resourceFormatVersion_ = 0;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(Resource resource) {
            return newBuilder().mergeFrom(resource);
        }

        public static Resource parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static Resource parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static Resource parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static Resource parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static Resource parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static Resource parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static Resource parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static Resource parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static Resource parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static Resource parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Resource)) {
                return super.equals(obj);
            }
            Resource resource = (Resource) obj;
            boolean z = (((((((getKeyList().equals(resource.getKeyList())) && getValueList().equals(resource.getValueList())) && getPropertyList().equals(resource.getPropertyList())) && getMacroList().equals(resource.getMacroList())) && getTagList().equals(resource.getTagList())) && getPredicateList().equals(resource.getPredicateList())) && getRuleList().equals(resource.getRuleList())) && hasPreviewAuthCode() == resource.hasPreviewAuthCode();
            if (hasPreviewAuthCode()) {
                z = z && getPreviewAuthCode().equals(resource.getPreviewAuthCode());
            }
            boolean z2 = z && hasMalwareScanAuthCode() == resource.hasMalwareScanAuthCode();
            if (hasMalwareScanAuthCode()) {
                z2 = z2 && getMalwareScanAuthCode().equals(resource.getMalwareScanAuthCode());
            }
            boolean z3 = z2 && hasTemplateVersionSet() == resource.hasTemplateVersionSet();
            if (hasTemplateVersionSet()) {
                z3 = z3 && getTemplateVersionSet().equals(resource.getTemplateVersionSet());
            }
            boolean z4 = z3 && hasVersion() == resource.hasVersion();
            if (hasVersion()) {
                z4 = z4 && getVersion().equals(resource.getVersion());
            }
            boolean z5 = z4 && hasLiveJsCacheOption() == resource.hasLiveJsCacheOption();
            if (hasLiveJsCacheOption()) {
                z5 = z5 && getLiveJsCacheOption().equals(resource.getLiveJsCacheOption());
            }
            boolean z6 = z5 && hasReportingSampleRate() == resource.hasReportingSampleRate();
            if (hasReportingSampleRate()) {
                z6 = z6 && Float.floatToIntBits(getReportingSampleRate()) == Float.floatToIntBits(resource.getReportingSampleRate());
            }
            boolean z7 = z6 && hasEnableAutoEventTracking() == resource.hasEnableAutoEventTracking();
            if (hasEnableAutoEventTracking()) {
                z7 = z7 && getEnableAutoEventTracking() == resource.getEnableAutoEventTracking();
            }
            boolean z8 = (z7 && getUsageContextList().equals(resource.getUsageContextList())) && hasResourceFormatVersion() == resource.hasResourceFormatVersion();
            return hasResourceFormatVersion() ? z8 && getResourceFormatVersion() == resource.getResourceFormatVersion() : z8;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public Resource getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean getEnableAutoEventTracking() {
            return this.enableAutoEventTracking_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getKey(int i) {
            return (String) this.key_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getKeyBytes(int i) {
            return this.key_.getByteString(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getKeyCount() {
            return this.key_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<String> getKeyList() {
            return this.key_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public CacheOption getLiveJsCacheOption() {
            return this.liveJsCacheOption_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public FunctionCall getMacro(int i) {
            return this.macro_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getMacroCount() {
            return this.macro_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<FunctionCall> getMacroList() {
            return this.macro_;
        }

        public FunctionCallOrBuilder getMacroOrBuilder(int i) {
            return this.macro_.get(i);
        }

        public List<? extends FunctionCallOrBuilder> getMacroOrBuilderList() {
            return this.macro_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getMalwareScanAuthCode() {
            Object obj = this.malwareScanAuthCode_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.malwareScanAuthCode_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getMalwareScanAuthCodeBytes() {
            Object obj = this.malwareScanAuthCode_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.malwareScanAuthCode_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<Resource> getParserForType() {
            return PARSER;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public FunctionCall getPredicate(int i) {
            return this.predicate_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getPredicateCount() {
            return this.predicate_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<FunctionCall> getPredicateList() {
            return this.predicate_;
        }

        public FunctionCallOrBuilder getPredicateOrBuilder(int i) {
            return this.predicate_.get(i);
        }

        public List<? extends FunctionCallOrBuilder> getPredicateOrBuilderList() {
            return this.predicate_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getPreviewAuthCode() {
            Object obj = this.previewAuthCode_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.previewAuthCode_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getPreviewAuthCodeBytes() {
            Object obj = this.previewAuthCode_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.previewAuthCode_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public Property getProperty(int i) {
            return this.property_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getPropertyCount() {
            return this.property_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<Property> getPropertyList() {
            return this.property_;
        }

        public PropertyOrBuilder getPropertyOrBuilder(int i) {
            return this.property_.get(i);
        }

        public List<? extends PropertyOrBuilder> getPropertyOrBuilderList() {
            return this.property_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public float getReportingSampleRate() {
            return this.reportingSampleRate_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getResourceFormatVersion() {
            return this.resourceFormatVersion_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public Rule getRule(int i) {
            return this.rule_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getRuleCount() {
            return this.rule_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<Rule> getRuleList() {
            return this.rule_;
        }

        public RuleOrBuilder getRuleOrBuilder(int i) {
            return this.rule_.get(i);
        }

        public List<? extends RuleOrBuilder> getRuleOrBuilderList() {
            return this.rule_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            for (int i3 = 0; i3 < this.key_.size(); i3++) {
                i2 += CodedOutputStream.computeBytesSizeNoTag(this.key_.getByteString(i3));
            }
            int size = i2 + 0 + (getKeyList().size() * 1);
            for (int i4 = 0; i4 < this.value_.size(); i4++) {
                size += CodedOutputStream.computeMessageSize(2, this.value_.get(i4));
            }
            for (int i5 = 0; i5 < this.property_.size(); i5++) {
                size += CodedOutputStream.computeMessageSize(3, this.property_.get(i5));
            }
            for (int i6 = 0; i6 < this.macro_.size(); i6++) {
                size += CodedOutputStream.computeMessageSize(4, this.macro_.get(i6));
            }
            for (int i7 = 0; i7 < this.tag_.size(); i7++) {
                size += CodedOutputStream.computeMessageSize(5, this.tag_.get(i7));
            }
            for (int i8 = 0; i8 < this.predicate_.size(); i8++) {
                size += CodedOutputStream.computeMessageSize(6, this.predicate_.get(i8));
            }
            for (int i9 = 0; i9 < this.rule_.size(); i9++) {
                size += CodedOutputStream.computeMessageSize(7, this.rule_.get(i9));
            }
            if ((this.bitField0_ & 1) == 1) {
                size += CodedOutputStream.computeBytesSize(9, getPreviewAuthCodeBytes());
            }
            if ((this.bitField0_ & 2) == 2) {
                size += CodedOutputStream.computeBytesSize(10, getMalwareScanAuthCodeBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                size += CodedOutputStream.computeBytesSize(12, getTemplateVersionSetBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                size += CodedOutputStream.computeBytesSize(13, getVersionBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                size += CodedOutputStream.computeMessageSize(14, this.liveJsCacheOption_);
            }
            if ((this.bitField0_ & 32) == 32) {
                size += CodedOutputStream.computeFloatSize(15, this.reportingSampleRate_);
            }
            int i10 = 0;
            int i11 = 0;
            while (i11 < this.usageContext_.size()) {
                i11++;
                i10 = CodedOutputStream.computeBytesSizeNoTag(this.usageContext_.getByteString(i11)) + i10;
            }
            int size2 = i10 + size + (getUsageContextList().size() * 2);
            if ((this.bitField0_ & 128) == 128) {
                size2 += CodedOutputStream.computeInt32Size(17, this.resourceFormatVersion_);
            }
            if ((this.bitField0_ & 64) == 64) {
                size2 += CodedOutputStream.computeBoolSize(18, this.enableAutoEventTracking_);
            }
            int size3 = size2 + this.unknownFields.size();
            this.memoizedSerializedSize = size3;
            return size3;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public FunctionCall getTag(int i) {
            return this.tag_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getTagCount() {
            return this.tag_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<FunctionCall> getTagList() {
            return this.tag_;
        }

        public FunctionCallOrBuilder getTagOrBuilder(int i) {
            return this.tag_.get(i);
        }

        public List<? extends FunctionCallOrBuilder> getTagOrBuilderList() {
            return this.tag_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getTemplateVersionSet() {
            Object obj = this.templateVersionSet_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.templateVersionSet_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getTemplateVersionSetBytes() {
            Object obj = this.templateVersionSet_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.templateVersionSet_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getUsageContext(int i) {
            return (String) this.usageContext_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getUsageContextBytes(int i) {
            return this.usageContext_.getByteString(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getUsageContextCount() {
            return this.usageContext_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<String> getUsageContextList() {
            return this.usageContext_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public TypeSystem.Value getValue(int i) {
            return this.value_.get(i);
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public int getValueCount() {
            return this.value_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public List<TypeSystem.Value> getValueList() {
            return this.value_;
        }

        public TypeSystem.ValueOrBuilder getValueOrBuilder(int i) {
            return this.value_.get(i);
        }

        public List<? extends TypeSystem.ValueOrBuilder> getValueOrBuilderList() {
            return this.value_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public String getVersion() {
            Object obj = this.version_;
            if (obj instanceof String) {
                return (String) obj;
            }
            ByteString byteString = (ByteString) obj;
            String stringUtf8 = byteString.toStringUtf8();
            if (byteString.isValidUtf8()) {
                this.version_ = stringUtf8;
            }
            return stringUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public ByteString getVersionBytes() {
            Object obj = this.version_;
            if (!(obj instanceof String)) {
                return (ByteString) obj;
            }
            ByteString copyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.version_ = copyFromUtf8;
            return copyFromUtf8;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasEnableAutoEventTracking() {
            return (this.bitField0_ & 64) == 64;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasLiveJsCacheOption() {
            return (this.bitField0_ & 16) == 16;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasMalwareScanAuthCode() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasPreviewAuthCode() {
            return (this.bitField0_ & 1) == 1;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasReportingSampleRate() {
            return (this.bitField0_ & 32) == 32;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasResourceFormatVersion() {
            return (this.bitField0_ & 128) == 128;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasTemplateVersionSet() {
            return (this.bitField0_ & 4) == 4;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ResourceOrBuilder
        public boolean hasVersion() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = Resource.class.hashCode() + 779;
            if (getKeyCount() > 0) {
                hashCode = (((hashCode * 37) + 1) * 53) + getKeyList().hashCode();
            }
            if (getValueCount() > 0) {
                hashCode = (((hashCode * 37) + 2) * 53) + getValueList().hashCode();
            }
            if (getPropertyCount() > 0) {
                hashCode = (((hashCode * 37) + 3) * 53) + getPropertyList().hashCode();
            }
            if (getMacroCount() > 0) {
                hashCode = (((hashCode * 37) + 4) * 53) + getMacroList().hashCode();
            }
            if (getTagCount() > 0) {
                hashCode = (((hashCode * 37) + 5) * 53) + getTagList().hashCode();
            }
            if (getPredicateCount() > 0) {
                hashCode = (((hashCode * 37) + 6) * 53) + getPredicateList().hashCode();
            }
            if (getRuleCount() > 0) {
                hashCode = (((hashCode * 37) + 7) * 53) + getRuleList().hashCode();
            }
            if (hasPreviewAuthCode()) {
                hashCode = (((hashCode * 37) + 9) * 53) + getPreviewAuthCode().hashCode();
            }
            if (hasMalwareScanAuthCode()) {
                hashCode = (((hashCode * 37) + 10) * 53) + getMalwareScanAuthCode().hashCode();
            }
            if (hasTemplateVersionSet()) {
                hashCode = (((hashCode * 37) + 12) * 53) + getTemplateVersionSet().hashCode();
            }
            if (hasVersion()) {
                hashCode = (((hashCode * 37) + 13) * 53) + getVersion().hashCode();
            }
            if (hasLiveJsCacheOption()) {
                hashCode = (((hashCode * 37) + 14) * 53) + getLiveJsCacheOption().hashCode();
            }
            if (hasReportingSampleRate()) {
                hashCode = (((hashCode * 37) + 15) * 53) + Float.floatToIntBits(getReportingSampleRate());
            }
            if (hasEnableAutoEventTracking()) {
                hashCode = (((hashCode * 37) + 18) * 53) + Internal.hashBoolean(getEnableAutoEventTracking());
            }
            if (getUsageContextCount() > 0) {
                hashCode = (((hashCode * 37) + 16) * 53) + getUsageContextList().hashCode();
            }
            if (hasResourceFormatVersion()) {
                hashCode = (((hashCode * 37) + 17) * 53) + getResourceFormatVersion();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$Resource");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            for (int i = 0; i < getValueCount(); i++) {
                if (!getValue(i).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i2 = 0; i2 < getPropertyCount(); i2++) {
                if (!getProperty(i2).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i3 = 0; i3 < getMacroCount(); i3++) {
                if (!getMacro(i3).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i4 = 0; i4 < getTagCount(); i4++) {
                if (!getTag(i4).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            for (int i5 = 0; i5 < getPredicateCount(); i5++) {
                if (!getPredicate(i5).isInitialized()) {
                    this.memoizedIsInitialized = 0;
                    return false;
                }
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            for (int i = 0; i < this.key_.size(); i++) {
                codedOutputStream.writeBytes(1, this.key_.getByteString(i));
            }
            for (int i2 = 0; i2 < this.value_.size(); i2++) {
                codedOutputStream.writeMessage(2, this.value_.get(i2));
            }
            for (int i3 = 0; i3 < this.property_.size(); i3++) {
                codedOutputStream.writeMessage(3, this.property_.get(i3));
            }
            for (int i4 = 0; i4 < this.macro_.size(); i4++) {
                codedOutputStream.writeMessage(4, this.macro_.get(i4));
            }
            for (int i5 = 0; i5 < this.tag_.size(); i5++) {
                codedOutputStream.writeMessage(5, this.tag_.get(i5));
            }
            for (int i6 = 0; i6 < this.predicate_.size(); i6++) {
                codedOutputStream.writeMessage(6, this.predicate_.get(i6));
            }
            for (int i7 = 0; i7 < this.rule_.size(); i7++) {
                codedOutputStream.writeMessage(7, this.rule_.get(i7));
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeBytes(9, getPreviewAuthCodeBytes());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeBytes(10, getMalwareScanAuthCodeBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeBytes(12, getTemplateVersionSetBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeBytes(13, getVersionBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                codedOutputStream.writeMessage(14, this.liveJsCacheOption_);
            }
            if ((this.bitField0_ & 32) == 32) {
                codedOutputStream.writeFloat(15, this.reportingSampleRate_);
            }
            for (int i8 = 0; i8 < this.usageContext_.size(); i8++) {
                codedOutputStream.writeBytes(16, this.usageContext_.getByteString(i8));
            }
            if ((this.bitField0_ & 128) == 128) {
                codedOutputStream.writeInt32(17, this.resourceFormatVersion_);
            }
            if ((this.bitField0_ & 64) == 64) {
                codedOutputStream.writeBool(18, this.enableAutoEventTracking_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface ResourceOrBuilder extends MessageLiteOrBuilder {
        boolean getEnableAutoEventTracking();

        String getKey(int i);

        ByteString getKeyBytes(int i);

        int getKeyCount();

        List<String> getKeyList();

        CacheOption getLiveJsCacheOption();

        FunctionCall getMacro(int i);

        int getMacroCount();

        List<FunctionCall> getMacroList();

        String getMalwareScanAuthCode();

        ByteString getMalwareScanAuthCodeBytes();

        FunctionCall getPredicate(int i);

        int getPredicateCount();

        List<FunctionCall> getPredicateList();

        String getPreviewAuthCode();

        ByteString getPreviewAuthCodeBytes();

        Property getProperty(int i);

        int getPropertyCount();

        List<Property> getPropertyList();

        float getReportingSampleRate();

        int getResourceFormatVersion();

        Rule getRule(int i);

        int getRuleCount();

        List<Rule> getRuleList();

        FunctionCall getTag(int i);

        int getTagCount();

        List<FunctionCall> getTagList();

        String getTemplateVersionSet();

        ByteString getTemplateVersionSetBytes();

        String getUsageContext(int i);

        ByteString getUsageContextBytes(int i);

        int getUsageContextCount();

        List<String> getUsageContextList();

        TypeSystem.Value getValue(int i);

        int getValueCount();

        List<TypeSystem.Value> getValueList();

        String getVersion();

        ByteString getVersionBytes();

        boolean hasEnableAutoEventTracking();

        boolean hasLiveJsCacheOption();

        boolean hasMalwareScanAuthCode();

        boolean hasPreviewAuthCode();

        boolean hasReportingSampleRate();

        boolean hasResourceFormatVersion();

        boolean hasTemplateVersionSet();

        boolean hasVersion();
    }

    public enum ResourceState implements Internal.EnumLite {
        PREVIEW(0, 1),
        LIVE(1, 2);
        
        public static final int LIVE_VALUE = 2;
        public static final int PREVIEW_VALUE = 1;
        private static Internal.EnumLiteMap<ResourceState> internalValueMap = new Internal.EnumLiteMap<ResourceState>() {
            /* class com.google.analytics.containertag.proto.Serving.ResourceState.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
            public ResourceState findValueByNumber(int i) {
                return ResourceState.valueOf(i);
            }
        };
        private final int value;

        private ResourceState(int i, int i2) {
            this.value = i2;
        }

        public static Internal.EnumLiteMap<ResourceState> internalGetValueMap() {
            return internalValueMap;
        }

        public static ResourceState valueOf(int i) {
            switch (i) {
                case 1:
                    return PREVIEW;
                case 2:
                    return LIVE;
                default:
                    return null;
            }
        }

        @Override // com.google.tagmanager.protobuf.Internal.EnumLite
        public final int getNumber() {
            return this.value;
        }
    }

    public enum ResourceType implements Internal.EnumLite {
        JS_RESOURCE(0, 1),
        NS_RESOURCE(1, 2),
        PIXEL_COLLECTION(2, 3),
        SET_COOKIE(3, 4),
        GET_COOKIE(4, 5),
        CLEAR_CACHE(5, 6),
        RAW_PROTO(6, 7);
        
        public static final int CLEAR_CACHE_VALUE = 6;
        public static final int GET_COOKIE_VALUE = 5;
        public static final int JS_RESOURCE_VALUE = 1;
        public static final int NS_RESOURCE_VALUE = 2;
        public static final int PIXEL_COLLECTION_VALUE = 3;
        public static final int RAW_PROTO_VALUE = 7;
        public static final int SET_COOKIE_VALUE = 4;
        private static Internal.EnumLiteMap<ResourceType> internalValueMap = new Internal.EnumLiteMap<ResourceType>() {
            /* class com.google.analytics.containertag.proto.Serving.ResourceType.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
            public ResourceType findValueByNumber(int i) {
                return ResourceType.valueOf(i);
            }
        };
        private final int value;

        private ResourceType(int i, int i2) {
            this.value = i2;
        }

        public static Internal.EnumLiteMap<ResourceType> internalGetValueMap() {
            return internalValueMap;
        }

        public static ResourceType valueOf(int i) {
            switch (i) {
                case 1:
                    return JS_RESOURCE;
                case 2:
                    return NS_RESOURCE;
                case 3:
                    return PIXEL_COLLECTION;
                case 4:
                    return SET_COOKIE;
                case 5:
                    return GET_COOKIE;
                case 6:
                    return CLEAR_CACHE;
                case 7:
                    return RAW_PROTO;
                default:
                    return null;
            }
        }

        @Override // com.google.tagmanager.protobuf.Internal.EnumLite
        public final int getNumber() {
            return this.value;
        }
    }

    public static final class Rule extends GeneratedMessageLite implements RuleOrBuilder {
        public static final int ADD_MACRO_FIELD_NUMBER = 7;
        public static final int ADD_MACRO_RULE_NAME_FIELD_NUMBER = 9;
        public static final int ADD_TAG_FIELD_NUMBER = 3;
        public static final int ADD_TAG_RULE_NAME_FIELD_NUMBER = 5;
        public static final int NEGATIVE_PREDICATE_FIELD_NUMBER = 2;
        public static Parser<Rule> PARSER = new AbstractParser<Rule>() {
            /* class com.google.analytics.containertag.proto.Serving.Rule.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public Rule parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new Rule(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int POSITIVE_PREDICATE_FIELD_NUMBER = 1;
        public static final int REMOVE_MACRO_FIELD_NUMBER = 8;
        public static final int REMOVE_MACRO_RULE_NAME_FIELD_NUMBER = 10;
        public static final int REMOVE_TAG_FIELD_NUMBER = 4;
        public static final int REMOVE_TAG_RULE_NAME_FIELD_NUMBER = 6;
        private static final Rule defaultInstance = new Rule(true);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public List<Integer> addMacroRuleName_;
        /* access modifiers changed from: private */
        public List<Integer> addMacro_;
        /* access modifiers changed from: private */
        public List<Integer> addTagRuleName_;
        /* access modifiers changed from: private */
        public List<Integer> addTag_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public List<Integer> negativePredicate_;
        /* access modifiers changed from: private */
        public List<Integer> positivePredicate_;
        /* access modifiers changed from: private */
        public List<Integer> removeMacroRuleName_;
        /* access modifiers changed from: private */
        public List<Integer> removeMacro_;
        /* access modifiers changed from: private */
        public List<Integer> removeTagRuleName_;
        /* access modifiers changed from: private */
        public List<Integer> removeTag_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.Builder<Rule, Builder> implements RuleOrBuilder {
            private List<Integer> addMacroRuleName_ = Collections.emptyList();
            private List<Integer> addMacro_ = Collections.emptyList();
            private List<Integer> addTagRuleName_ = Collections.emptyList();
            private List<Integer> addTag_ = Collections.emptyList();
            private int bitField0_;
            private List<Integer> negativePredicate_ = Collections.emptyList();
            private List<Integer> positivePredicate_ = Collections.emptyList();
            private List<Integer> removeMacroRuleName_ = Collections.emptyList();
            private List<Integer> removeMacro_ = Collections.emptyList();
            private List<Integer> removeTagRuleName_ = Collections.emptyList();
            private List<Integer> removeTag_ = Collections.emptyList();

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void ensureAddMacroIsMutable() {
                if ((this.bitField0_ & 64) != 64) {
                    this.addMacro_ = new ArrayList(this.addMacro_);
                    this.bitField0_ |= 64;
                }
            }

            private void ensureAddMacroRuleNameIsMutable() {
                if ((this.bitField0_ & 256) != 256) {
                    this.addMacroRuleName_ = new ArrayList(this.addMacroRuleName_);
                    this.bitField0_ |= 256;
                }
            }

            private void ensureAddTagIsMutable() {
                if ((this.bitField0_ & 4) != 4) {
                    this.addTag_ = new ArrayList(this.addTag_);
                    this.bitField0_ |= 4;
                }
            }

            private void ensureAddTagRuleNameIsMutable() {
                if ((this.bitField0_ & 16) != 16) {
                    this.addTagRuleName_ = new ArrayList(this.addTagRuleName_);
                    this.bitField0_ |= 16;
                }
            }

            private void ensureNegativePredicateIsMutable() {
                if ((this.bitField0_ & 2) != 2) {
                    this.negativePredicate_ = new ArrayList(this.negativePredicate_);
                    this.bitField0_ |= 2;
                }
            }

            private void ensurePositivePredicateIsMutable() {
                if ((this.bitField0_ & 1) != 1) {
                    this.positivePredicate_ = new ArrayList(this.positivePredicate_);
                    this.bitField0_ |= 1;
                }
            }

            private void ensureRemoveMacroIsMutable() {
                if ((this.bitField0_ & 128) != 128) {
                    this.removeMacro_ = new ArrayList(this.removeMacro_);
                    this.bitField0_ |= 128;
                }
            }

            private void ensureRemoveMacroRuleNameIsMutable() {
                if ((this.bitField0_ & 512) != 512) {
                    this.removeMacroRuleName_ = new ArrayList(this.removeMacroRuleName_);
                    this.bitField0_ |= 512;
                }
            }

            private void ensureRemoveTagIsMutable() {
                if ((this.bitField0_ & 8) != 8) {
                    this.removeTag_ = new ArrayList(this.removeTag_);
                    this.bitField0_ |= 8;
                }
            }

            private void ensureRemoveTagRuleNameIsMutable() {
                if ((this.bitField0_ & 32) != 32) {
                    this.removeTagRuleName_ = new ArrayList(this.removeTagRuleName_);
                    this.bitField0_ |= 32;
                }
            }

            private void maybeForceBuilderInitialization() {
            }

            public Builder addAddMacro(int i) {
                ensureAddMacroIsMutable();
                this.addMacro_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addAddMacroRuleName(int i) {
                ensureAddMacroRuleNameIsMutable();
                this.addMacroRuleName_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addAddTag(int i) {
                ensureAddTagIsMutable();
                this.addTag_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addAddTagRuleName(int i) {
                ensureAddTagRuleNameIsMutable();
                this.addTagRuleName_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addAllAddMacro(Iterable<? extends Integer> iterable) {
                ensureAddMacroIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.addMacro_);
                return this;
            }

            public Builder addAllAddMacroRuleName(Iterable<? extends Integer> iterable) {
                ensureAddMacroRuleNameIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.addMacroRuleName_);
                return this;
            }

            public Builder addAllAddTag(Iterable<? extends Integer> iterable) {
                ensureAddTagIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.addTag_);
                return this;
            }

            public Builder addAllAddTagRuleName(Iterable<? extends Integer> iterable) {
                ensureAddTagRuleNameIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.addTagRuleName_);
                return this;
            }

            public Builder addAllNegativePredicate(Iterable<? extends Integer> iterable) {
                ensureNegativePredicateIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.negativePredicate_);
                return this;
            }

            public Builder addAllPositivePredicate(Iterable<? extends Integer> iterable) {
                ensurePositivePredicateIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.positivePredicate_);
                return this;
            }

            public Builder addAllRemoveMacro(Iterable<? extends Integer> iterable) {
                ensureRemoveMacroIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.removeMacro_);
                return this;
            }

            public Builder addAllRemoveMacroRuleName(Iterable<? extends Integer> iterable) {
                ensureRemoveMacroRuleNameIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.removeMacroRuleName_);
                return this;
            }

            public Builder addAllRemoveTag(Iterable<? extends Integer> iterable) {
                ensureRemoveTagIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.removeTag_);
                return this;
            }

            public Builder addAllRemoveTagRuleName(Iterable<? extends Integer> iterable) {
                ensureRemoveTagRuleNameIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.removeTagRuleName_);
                return this;
            }

            public Builder addNegativePredicate(int i) {
                ensureNegativePredicateIsMutable();
                this.negativePredicate_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addPositivePredicate(int i) {
                ensurePositivePredicateIsMutable();
                this.positivePredicate_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addRemoveMacro(int i) {
                ensureRemoveMacroIsMutable();
                this.removeMacro_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addRemoveMacroRuleName(int i) {
                ensureRemoveMacroRuleNameIsMutable();
                this.removeMacroRuleName_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addRemoveTag(int i) {
                ensureRemoveTagIsMutable();
                this.removeTag_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addRemoveTagRuleName(int i) {
                ensureRemoveTagRuleNameIsMutable();
                this.removeTagRuleName_.add(Integer.valueOf(i));
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Rule build() {
                Rule buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public Rule buildPartial() {
                Rule rule = new Rule(this);
                int i = this.bitField0_;
                if ((this.bitField0_ & 1) == 1) {
                    this.positivePredicate_ = Collections.unmodifiableList(this.positivePredicate_);
                    this.bitField0_ &= -2;
                }
                List unused = rule.positivePredicate_ = this.positivePredicate_;
                if ((this.bitField0_ & 2) == 2) {
                    this.negativePredicate_ = Collections.unmodifiableList(this.negativePredicate_);
                    this.bitField0_ &= -3;
                }
                List unused2 = rule.negativePredicate_ = this.negativePredicate_;
                if ((this.bitField0_ & 4) == 4) {
                    this.addTag_ = Collections.unmodifiableList(this.addTag_);
                    this.bitField0_ &= -5;
                }
                List unused3 = rule.addTag_ = this.addTag_;
                if ((this.bitField0_ & 8) == 8) {
                    this.removeTag_ = Collections.unmodifiableList(this.removeTag_);
                    this.bitField0_ &= -9;
                }
                List unused4 = rule.removeTag_ = this.removeTag_;
                if ((this.bitField0_ & 16) == 16) {
                    this.addTagRuleName_ = Collections.unmodifiableList(this.addTagRuleName_);
                    this.bitField0_ &= -17;
                }
                List unused5 = rule.addTagRuleName_ = this.addTagRuleName_;
                if ((this.bitField0_ & 32) == 32) {
                    this.removeTagRuleName_ = Collections.unmodifiableList(this.removeTagRuleName_);
                    this.bitField0_ &= -33;
                }
                List unused6 = rule.removeTagRuleName_ = this.removeTagRuleName_;
                if ((this.bitField0_ & 64) == 64) {
                    this.addMacro_ = Collections.unmodifiableList(this.addMacro_);
                    this.bitField0_ &= -65;
                }
                List unused7 = rule.addMacro_ = this.addMacro_;
                if ((this.bitField0_ & 128) == 128) {
                    this.removeMacro_ = Collections.unmodifiableList(this.removeMacro_);
                    this.bitField0_ &= -129;
                }
                List unused8 = rule.removeMacro_ = this.removeMacro_;
                if ((this.bitField0_ & 256) == 256) {
                    this.addMacroRuleName_ = Collections.unmodifiableList(this.addMacroRuleName_);
                    this.bitField0_ &= -257;
                }
                List unused9 = rule.addMacroRuleName_ = this.addMacroRuleName_;
                if ((this.bitField0_ & 512) == 512) {
                    this.removeMacroRuleName_ = Collections.unmodifiableList(this.removeMacroRuleName_);
                    this.bitField0_ &= -513;
                }
                List unused10 = rule.removeMacroRuleName_ = this.removeMacroRuleName_;
                return rule;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.positivePredicate_ = Collections.emptyList();
                this.bitField0_ &= -2;
                this.negativePredicate_ = Collections.emptyList();
                this.bitField0_ &= -3;
                this.addTag_ = Collections.emptyList();
                this.bitField0_ &= -5;
                this.removeTag_ = Collections.emptyList();
                this.bitField0_ &= -9;
                this.addTagRuleName_ = Collections.emptyList();
                this.bitField0_ &= -17;
                this.removeTagRuleName_ = Collections.emptyList();
                this.bitField0_ &= -33;
                this.addMacro_ = Collections.emptyList();
                this.bitField0_ &= -65;
                this.removeMacro_ = Collections.emptyList();
                this.bitField0_ &= -129;
                this.addMacroRuleName_ = Collections.emptyList();
                this.bitField0_ &= -257;
                this.removeMacroRuleName_ = Collections.emptyList();
                this.bitField0_ &= -513;
                return this;
            }

            public Builder clearAddMacro() {
                this.addMacro_ = Collections.emptyList();
                this.bitField0_ &= -65;
                return this;
            }

            public Builder clearAddMacroRuleName() {
                this.addMacroRuleName_ = Collections.emptyList();
                this.bitField0_ &= -257;
                return this;
            }

            public Builder clearAddTag() {
                this.addTag_ = Collections.emptyList();
                this.bitField0_ &= -5;
                return this;
            }

            public Builder clearAddTagRuleName() {
                this.addTagRuleName_ = Collections.emptyList();
                this.bitField0_ &= -17;
                return this;
            }

            public Builder clearNegativePredicate() {
                this.negativePredicate_ = Collections.emptyList();
                this.bitField0_ &= -3;
                return this;
            }

            public Builder clearPositivePredicate() {
                this.positivePredicate_ = Collections.emptyList();
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearRemoveMacro() {
                this.removeMacro_ = Collections.emptyList();
                this.bitField0_ &= -129;
                return this;
            }

            public Builder clearRemoveMacroRuleName() {
                this.removeMacroRuleName_ = Collections.emptyList();
                this.bitField0_ &= -513;
                return this;
            }

            public Builder clearRemoveTag() {
                this.removeTag_ = Collections.emptyList();
                this.bitField0_ &= -9;
                return this;
            }

            public Builder clearRemoveTagRuleName() {
                this.removeTagRuleName_ = Collections.emptyList();
                this.bitField0_ &= -33;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddMacro(int i) {
                return this.addMacro_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddMacroCount() {
                return this.addMacro_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getAddMacroList() {
                return Collections.unmodifiableList(this.addMacro_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddMacroRuleName(int i) {
                return this.addMacroRuleName_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddMacroRuleNameCount() {
                return this.addMacroRuleName_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getAddMacroRuleNameList() {
                return Collections.unmodifiableList(this.addMacroRuleName_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddTag(int i) {
                return this.addTag_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddTagCount() {
                return this.addTag_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getAddTagList() {
                return Collections.unmodifiableList(this.addTag_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddTagRuleName(int i) {
                return this.addTagRuleName_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getAddTagRuleNameCount() {
                return this.addTagRuleName_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getAddTagRuleNameList() {
                return Collections.unmodifiableList(this.addTagRuleName_);
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public Rule getDefaultInstanceForType() {
                return Rule.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getNegativePredicate(int i) {
                return this.negativePredicate_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getNegativePredicateCount() {
                return this.negativePredicate_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getNegativePredicateList() {
                return Collections.unmodifiableList(this.negativePredicate_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getPositivePredicate(int i) {
                return this.positivePredicate_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getPositivePredicateCount() {
                return this.positivePredicate_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getPositivePredicateList() {
                return Collections.unmodifiableList(this.positivePredicate_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveMacro(int i) {
                return this.removeMacro_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveMacroCount() {
                return this.removeMacro_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getRemoveMacroList() {
                return Collections.unmodifiableList(this.removeMacro_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveMacroRuleName(int i) {
                return this.removeMacroRuleName_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveMacroRuleNameCount() {
                return this.removeMacroRuleName_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getRemoveMacroRuleNameList() {
                return Collections.unmodifiableList(this.removeMacroRuleName_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveTag(int i) {
                return this.removeTag_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveTagCount() {
                return this.removeTag_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getRemoveTagList() {
                return Collections.unmodifiableList(this.removeTag_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveTagRuleName(int i) {
                return this.removeTagRuleName_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public int getRemoveTagRuleNameCount() {
                return this.removeTagRuleName_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
            public List<Integer> getRemoveTagRuleNameList() {
                return Collections.unmodifiableList(this.removeTagRuleName_);
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(Rule rule) {
                if (rule != Rule.getDefaultInstance()) {
                    if (!rule.positivePredicate_.isEmpty()) {
                        if (this.positivePredicate_.isEmpty()) {
                            this.positivePredicate_ = rule.positivePredicate_;
                            this.bitField0_ &= -2;
                        } else {
                            ensurePositivePredicateIsMutable();
                            this.positivePredicate_.addAll(rule.positivePredicate_);
                        }
                    }
                    if (!rule.negativePredicate_.isEmpty()) {
                        if (this.negativePredicate_.isEmpty()) {
                            this.negativePredicate_ = rule.negativePredicate_;
                            this.bitField0_ &= -3;
                        } else {
                            ensureNegativePredicateIsMutable();
                            this.negativePredicate_.addAll(rule.negativePredicate_);
                        }
                    }
                    if (!rule.addTag_.isEmpty()) {
                        if (this.addTag_.isEmpty()) {
                            this.addTag_ = rule.addTag_;
                            this.bitField0_ &= -5;
                        } else {
                            ensureAddTagIsMutable();
                            this.addTag_.addAll(rule.addTag_);
                        }
                    }
                    if (!rule.removeTag_.isEmpty()) {
                        if (this.removeTag_.isEmpty()) {
                            this.removeTag_ = rule.removeTag_;
                            this.bitField0_ &= -9;
                        } else {
                            ensureRemoveTagIsMutable();
                            this.removeTag_.addAll(rule.removeTag_);
                        }
                    }
                    if (!rule.addTagRuleName_.isEmpty()) {
                        if (this.addTagRuleName_.isEmpty()) {
                            this.addTagRuleName_ = rule.addTagRuleName_;
                            this.bitField0_ &= -17;
                        } else {
                            ensureAddTagRuleNameIsMutable();
                            this.addTagRuleName_.addAll(rule.addTagRuleName_);
                        }
                    }
                    if (!rule.removeTagRuleName_.isEmpty()) {
                        if (this.removeTagRuleName_.isEmpty()) {
                            this.removeTagRuleName_ = rule.removeTagRuleName_;
                            this.bitField0_ &= -33;
                        } else {
                            ensureRemoveTagRuleNameIsMutable();
                            this.removeTagRuleName_.addAll(rule.removeTagRuleName_);
                        }
                    }
                    if (!rule.addMacro_.isEmpty()) {
                        if (this.addMacro_.isEmpty()) {
                            this.addMacro_ = rule.addMacro_;
                            this.bitField0_ &= -65;
                        } else {
                            ensureAddMacroIsMutable();
                            this.addMacro_.addAll(rule.addMacro_);
                        }
                    }
                    if (!rule.removeMacro_.isEmpty()) {
                        if (this.removeMacro_.isEmpty()) {
                            this.removeMacro_ = rule.removeMacro_;
                            this.bitField0_ &= -129;
                        } else {
                            ensureRemoveMacroIsMutable();
                            this.removeMacro_.addAll(rule.removeMacro_);
                        }
                    }
                    if (!rule.addMacroRuleName_.isEmpty()) {
                        if (this.addMacroRuleName_.isEmpty()) {
                            this.addMacroRuleName_ = rule.addMacroRuleName_;
                            this.bitField0_ &= -257;
                        } else {
                            ensureAddMacroRuleNameIsMutable();
                            this.addMacroRuleName_.addAll(rule.addMacroRuleName_);
                        }
                    }
                    if (!rule.removeMacroRuleName_.isEmpty()) {
                        if (this.removeMacroRuleName_.isEmpty()) {
                            this.removeMacroRuleName_ = rule.removeMacroRuleName_;
                            this.bitField0_ &= -513;
                        } else {
                            ensureRemoveMacroRuleNameIsMutable();
                            this.removeMacroRuleName_.addAll(rule.removeMacroRuleName_);
                        }
                    }
                    setUnknownFields(getUnknownFields().concat(rule.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                Rule rule;
                Rule rule2 = null;
                try {
                    Rule parsePartialFrom = Rule.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    rule = (Rule) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    rule2 = rule;
                }
                if (rule2 != null) {
                    mergeFrom(rule2);
                }
                throw th;
            }

            public Builder setAddMacro(int i, int i2) {
                ensureAddMacroIsMutable();
                this.addMacro_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setAddMacroRuleName(int i, int i2) {
                ensureAddMacroRuleNameIsMutable();
                this.addMacroRuleName_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setAddTag(int i, int i2) {
                ensureAddTagIsMutable();
                this.addTag_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setAddTagRuleName(int i, int i2) {
                ensureAddTagRuleNameIsMutable();
                this.addTagRuleName_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setNegativePredicate(int i, int i2) {
                ensureNegativePredicateIsMutable();
                this.negativePredicate_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setPositivePredicate(int i, int i2) {
                ensurePositivePredicateIsMutable();
                this.positivePredicate_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setRemoveMacro(int i, int i2) {
                ensureRemoveMacroIsMutable();
                this.removeMacro_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setRemoveMacroRuleName(int i, int i2) {
                ensureRemoveMacroRuleNameIsMutable();
                this.removeMacroRuleName_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setRemoveTag(int i, int i2) {
                ensureRemoveTagIsMutable();
                this.removeTag_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setRemoveTagRuleName(int i, int i2) {
                ensureRemoveTagRuleNameIsMutable();
                this.removeTagRuleName_.set(i, Integer.valueOf(i2));
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        /* JADX WARNING: Removed duplicated region for block: B:20:0x0055  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0061  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x006d  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0079  */
        /* JADX WARNING: Removed duplicated region for block: B:32:0x0085  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x0093  */
        /* JADX WARNING: Removed duplicated region for block: B:38:0x00a1  */
        /* JADX WARNING: Removed duplicated region for block: B:41:0x00af  */
        /* JADX WARNING: Removed duplicated region for block: B:44:0x00bd  */
        /* JADX WARNING: Removed duplicated region for block: B:47:0x00cb  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private Rule(com.google.tagmanager.protobuf.CodedInputStream r13, com.google.tagmanager.protobuf.ExtensionRegistryLite r14) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
            /*
                r12 = this;
                r11 = 16
                r10 = 8
                r9 = 4
                r8 = 2
                r3 = 1
                r12.<init>()
                r0 = -1
                r12.memoizedIsInitialized = r0
                r0 = -1
                r12.memoizedSerializedSize = r0
                r12.initFields()
                r0 = 0
                com.google.tagmanager.protobuf.ByteString$Output r4 = com.google.tagmanager.protobuf.ByteString.newOutput()
                com.google.tagmanager.protobuf.CodedOutputStream r5 = com.google.tagmanager.protobuf.CodedOutputStream.newInstance(r4)
                r1 = 0
            L_0x001d:
                if (r1 != 0) goto L_0x040c
                int r2 = r13.readTag()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                switch(r2) {
                    case 0: goto L_0x04bc;
                    case 8: goto L_0x002e;
                    case 10: goto L_0x00e0;
                    case 16: goto L_0x0128;
                    case 18: goto L_0x0144;
                    case 24: goto L_0x0178;
                    case 26: goto L_0x0194;
                    case 32: goto L_0x01c8;
                    case 34: goto L_0x01e4;
                    case 40: goto L_0x0218;
                    case 42: goto L_0x0234;
                    case 48: goto L_0x0268;
                    case 50: goto L_0x0286;
                    case 56: goto L_0x02bc;
                    case 58: goto L_0x02da;
                    case 64: goto L_0x0310;
                    case 66: goto L_0x032e;
                    case 72: goto L_0x0364;
                    case 74: goto L_0x0382;
                    case 80: goto L_0x03b8;
                    case 82: goto L_0x03d6;
                    default: goto L_0x0026;
                }     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
            L_0x0026:
                boolean r2 = r12.parseUnknownField(r13, r5, r14, r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r2 != 0) goto L_0x001d
                r1 = r3
                goto L_0x001d
            L_0x002e:
                r2 = r0 & 1
                if (r2 == r3) goto L_0x003b
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.positivePredicate_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 1
            L_0x003b:
                java.util.List<java.lang.Integer> r2 = r12.positivePredicate_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0049:
                r1 = move-exception
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r1 = r1.setUnfinishedMessage(r12)     // Catch:{ all -> 0x004f }
                throw r1     // Catch:{ all -> 0x004f }
            L_0x004f:
                r1 = move-exception
                r2 = r0
            L_0x0051:
                r0 = r2 & 1
                if (r0 != r3) goto L_0x005d
                java.util.List<java.lang.Integer> r0 = r12.positivePredicate_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.positivePredicate_ = r0
            L_0x005d:
                r0 = r2 & 2
                if (r0 != r8) goto L_0x0069
                java.util.List<java.lang.Integer> r0 = r12.negativePredicate_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.negativePredicate_ = r0
            L_0x0069:
                r0 = r2 & 4
                if (r0 != r9) goto L_0x0075
                java.util.List<java.lang.Integer> r0 = r12.addTag_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.addTag_ = r0
            L_0x0075:
                r0 = r2 & 8
                if (r0 != r10) goto L_0x0081
                java.util.List<java.lang.Integer> r0 = r12.removeTag_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.removeTag_ = r0
            L_0x0081:
                r0 = r2 & 16
                if (r0 != r11) goto L_0x008d
                java.util.List<java.lang.Integer> r0 = r12.addTagRuleName_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.addTagRuleName_ = r0
            L_0x008d:
                r0 = r2 & 32
                r3 = 32
                if (r0 != r3) goto L_0x009b
                java.util.List<java.lang.Integer> r0 = r12.removeTagRuleName_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.removeTagRuleName_ = r0
            L_0x009b:
                r0 = r2 & 64
                r3 = 64
                if (r0 != r3) goto L_0x00a9
                java.util.List<java.lang.Integer> r0 = r12.addMacro_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.addMacro_ = r0
            L_0x00a9:
                r0 = r2 & 128(0x80, float:1.794E-43)
                r3 = 128(0x80, float:1.794E-43)
                if (r0 != r3) goto L_0x00b7
                java.util.List<java.lang.Integer> r0 = r12.removeMacro_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.removeMacro_ = r0
            L_0x00b7:
                r0 = r2 & 256(0x100, float:3.59E-43)
                r3 = 256(0x100, float:3.59E-43)
                if (r0 != r3) goto L_0x00c5
                java.util.List<java.lang.Integer> r0 = r12.addMacroRuleName_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.addMacroRuleName_ = r0
            L_0x00c5:
                r0 = r2 & 512(0x200, float:7.175E-43)
                r2 = 512(0x200, float:7.175E-43)
                if (r0 != r2) goto L_0x00d3
                java.util.List<java.lang.Integer> r0 = r12.removeMacroRuleName_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.removeMacroRuleName_ = r0
            L_0x00d3:
                r5.flush()     // Catch:{ IOException -> 0x04ab, all -> 0x04b4 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r12.unknownFields = r0
            L_0x00dc:
                r12.makeExtensionsImmutable()
                throw r1
            L_0x00e0:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 1
                if (r6 == r3) goto L_0x00fb
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x00fb
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.positivePredicate_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 1
            L_0x00fb:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x0123
                java.util.List<java.lang.Integer> r6 = r12.positivePredicate_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x00fb
            L_0x010f:
                r1 = move-exception
                r2 = r0
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = new com.google.tagmanager.protobuf.InvalidProtocolBufferException     // Catch:{ all -> 0x011f }
                java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x011f }
                r0.<init>(r1)     // Catch:{ all -> 0x011f }
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r0.setUnfinishedMessage(r12)     // Catch:{ all -> 0x011f }
                throw r0     // Catch:{ all -> 0x011f }
            L_0x011f:
                r0 = move-exception
                r1 = r0
                goto L_0x0051
            L_0x0123:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0128:
                r2 = r0 & 2
                if (r2 == r8) goto L_0x0135
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.negativePredicate_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 2
            L_0x0135:
                java.util.List<java.lang.Integer> r2 = r12.negativePredicate_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0144:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 2
                if (r6 == r8) goto L_0x015f
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x015f
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.negativePredicate_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 2
            L_0x015f:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x0173
                java.util.List<java.lang.Integer> r6 = r12.negativePredicate_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x015f
            L_0x0173:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0178:
                r2 = r0 & 4
                if (r2 == r9) goto L_0x0185
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addTag_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 4
            L_0x0185:
                java.util.List<java.lang.Integer> r2 = r12.addTag_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0194:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 4
                if (r6 == r9) goto L_0x01af
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x01af
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addTag_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 4
            L_0x01af:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x01c3
                java.util.List<java.lang.Integer> r6 = r12.addTag_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x01af
            L_0x01c3:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x01c8:
                r2 = r0 & 8
                if (r2 == r10) goto L_0x01d5
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeTag_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 8
            L_0x01d5:
                java.util.List<java.lang.Integer> r2 = r12.removeTag_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x01e4:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 8
                if (r6 == r10) goto L_0x01ff
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x01ff
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeTag_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 8
            L_0x01ff:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x0213
                java.util.List<java.lang.Integer> r6 = r12.removeTag_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x01ff
            L_0x0213:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0218:
                r2 = r0 & 16
                if (r2 == r11) goto L_0x0225
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addTagRuleName_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 16
            L_0x0225:
                java.util.List<java.lang.Integer> r2 = r12.addTagRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0234:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 16
                if (r6 == r11) goto L_0x024f
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x024f
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addTagRuleName_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 16
            L_0x024f:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x0263
                java.util.List<java.lang.Integer> r6 = r12.addTagRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x024f
            L_0x0263:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0268:
                r2 = r0 & 32
                r6 = 32
                if (r2 == r6) goto L_0x0277
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeTagRuleName_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 32
            L_0x0277:
                java.util.List<java.lang.Integer> r2 = r12.removeTagRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0286:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 32
                r7 = 32
                if (r6 == r7) goto L_0x02a3
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x02a3
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeTagRuleName_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 32
            L_0x02a3:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x02b7
                java.util.List<java.lang.Integer> r6 = r12.removeTagRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x02a3
            L_0x02b7:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x02bc:
                r2 = r0 & 64
                r6 = 64
                if (r2 == r6) goto L_0x02cb
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addMacro_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 64
            L_0x02cb:
                java.util.List<java.lang.Integer> r2 = r12.addMacro_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x02da:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 64
                r7 = 64
                if (r6 == r7) goto L_0x02f7
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x02f7
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addMacro_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 64
            L_0x02f7:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x030b
                java.util.List<java.lang.Integer> r6 = r12.addMacro_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x02f7
            L_0x030b:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0310:
                r2 = r0 & 128(0x80, float:1.794E-43)
                r6 = 128(0x80, float:1.794E-43)
                if (r2 == r6) goto L_0x031f
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeMacro_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 128(0x80, float:1.794E-43)
            L_0x031f:
                java.util.List<java.lang.Integer> r2 = r12.removeMacro_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x032e:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 128(0x80, float:1.794E-43)
                r7 = 128(0x80, float:1.794E-43)
                if (r6 == r7) goto L_0x034b
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x034b
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeMacro_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 128(0x80, float:1.794E-43)
            L_0x034b:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x035f
                java.util.List<java.lang.Integer> r6 = r12.removeMacro_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x034b
            L_0x035f:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0364:
                r2 = r0 & 256(0x100, float:3.59E-43)
                r6 = 256(0x100, float:3.59E-43)
                if (r2 == r6) goto L_0x0373
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addMacroRuleName_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 256(0x100, float:3.59E-43)
            L_0x0373:
                java.util.List<java.lang.Integer> r2 = r12.addMacroRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x0382:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 256(0x100, float:3.59E-43)
                r7 = 256(0x100, float:3.59E-43)
                if (r6 == r7) goto L_0x039f
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x039f
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.addMacroRuleName_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 256(0x100, float:3.59E-43)
            L_0x039f:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x03b3
                java.util.List<java.lang.Integer> r6 = r12.addMacroRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x039f
            L_0x03b3:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x03b8:
                r2 = r0 & 512(0x200, float:7.175E-43)
                r6 = 512(0x200, float:7.175E-43)
                if (r2 == r6) goto L_0x03c7
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeMacroRuleName_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 512(0x200, float:7.175E-43)
            L_0x03c7:
                java.util.List<java.lang.Integer> r2 = r12.removeMacroRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r6 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x03d6:
                int r2 = r13.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r2 = r13.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6 = r0 & 512(0x200, float:7.175E-43)
                r7 = 512(0x200, float:7.175E-43)
                if (r6 == r7) goto L_0x03f3
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x03f3
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r12.removeMacroRuleName_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r0 = r0 | 512(0x200, float:7.175E-43)
            L_0x03f3:
                int r6 = r13.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                if (r6 <= 0) goto L_0x0407
                java.util.List<java.lang.Integer> r6 = r12.removeMacroRuleName_     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                int r7 = r13.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x03f3
            L_0x0407:
                r13.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0049, IOException -> 0x010f }
                goto L_0x001d
            L_0x040c:
                r1 = r0 & 1
                if (r1 != r3) goto L_0x0418
                java.util.List<java.lang.Integer> r1 = r12.positivePredicate_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.positivePredicate_ = r1
            L_0x0418:
                r1 = r0 & 2
                if (r1 != r8) goto L_0x0424
                java.util.List<java.lang.Integer> r1 = r12.negativePredicate_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.negativePredicate_ = r1
            L_0x0424:
                r1 = r0 & 4
                if (r1 != r9) goto L_0x0430
                java.util.List<java.lang.Integer> r1 = r12.addTag_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.addTag_ = r1
            L_0x0430:
                r1 = r0 & 8
                if (r1 != r10) goto L_0x043c
                java.util.List<java.lang.Integer> r1 = r12.removeTag_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.removeTag_ = r1
            L_0x043c:
                r1 = r0 & 16
                if (r1 != r11) goto L_0x0448
                java.util.List<java.lang.Integer> r1 = r12.addTagRuleName_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.addTagRuleName_ = r1
            L_0x0448:
                r1 = r0 & 32
                r2 = 32
                if (r1 != r2) goto L_0x0456
                java.util.List<java.lang.Integer> r1 = r12.removeTagRuleName_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.removeTagRuleName_ = r1
            L_0x0456:
                r1 = r0 & 64
                r2 = 64
                if (r1 != r2) goto L_0x0464
                java.util.List<java.lang.Integer> r1 = r12.addMacro_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.addMacro_ = r1
            L_0x0464:
                r1 = r0 & 128(0x80, float:1.794E-43)
                r2 = 128(0x80, float:1.794E-43)
                if (r1 != r2) goto L_0x0472
                java.util.List<java.lang.Integer> r1 = r12.removeMacro_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.removeMacro_ = r1
            L_0x0472:
                r1 = r0 & 256(0x100, float:3.59E-43)
                r2 = 256(0x100, float:3.59E-43)
                if (r1 != r2) goto L_0x0480
                java.util.List<java.lang.Integer> r1 = r12.addMacroRuleName_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r12.addMacroRuleName_ = r1
            L_0x0480:
                r0 = r0 & 512(0x200, float:7.175E-43)
                r1 = 512(0x200, float:7.175E-43)
                if (r0 != r1) goto L_0x048e
                java.util.List<java.lang.Integer> r0 = r12.removeMacroRuleName_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r12.removeMacroRuleName_ = r0
            L_0x048e:
                r5.flush()     // Catch:{ IOException -> 0x049b, all -> 0x04a3 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r12.unknownFields = r0
            L_0x0497:
                r12.makeExtensionsImmutable()
                return
            L_0x049b:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r12.unknownFields = r0
                goto L_0x0497
            L_0x04a3:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r12.unknownFields = r1
                throw r0
            L_0x04ab:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r12.unknownFields = r0
                goto L_0x00dc
            L_0x04b4:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r12.unknownFields = r1
                throw r0
            L_0x04bc:
                r1 = r3
                goto L_0x001d
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.containertag.proto.Serving.Rule.<init>(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):void");
        }

        private Rule(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private Rule(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static Rule getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.positivePredicate_ = Collections.emptyList();
            this.negativePredicate_ = Collections.emptyList();
            this.addTag_ = Collections.emptyList();
            this.removeTag_ = Collections.emptyList();
            this.addTagRuleName_ = Collections.emptyList();
            this.removeTagRuleName_ = Collections.emptyList();
            this.addMacro_ = Collections.emptyList();
            this.removeMacro_ = Collections.emptyList();
            this.addMacroRuleName_ = Collections.emptyList();
            this.removeMacroRuleName_ = Collections.emptyList();
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(Rule rule) {
            return newBuilder().mergeFrom(rule);
        }

        public static Rule parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static Rule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static Rule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static Rule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static Rule parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static Rule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static Rule parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static Rule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static Rule parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static Rule parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Rule)) {
                return super.equals(obj);
            }
            Rule rule = (Rule) obj;
            return (((((((((getPositivePredicateList().equals(rule.getPositivePredicateList())) && getNegativePredicateList().equals(rule.getNegativePredicateList())) && getAddTagList().equals(rule.getAddTagList())) && getRemoveTagList().equals(rule.getRemoveTagList())) && getAddTagRuleNameList().equals(rule.getAddTagRuleNameList())) && getRemoveTagRuleNameList().equals(rule.getRemoveTagRuleNameList())) && getAddMacroList().equals(rule.getAddMacroList())) && getRemoveMacroList().equals(rule.getRemoveMacroList())) && getAddMacroRuleNameList().equals(rule.getAddMacroRuleNameList())) && getRemoveMacroRuleNameList().equals(rule.getRemoveMacroRuleNameList());
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddMacro(int i) {
            return this.addMacro_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddMacroCount() {
            return this.addMacro_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getAddMacroList() {
            return this.addMacro_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddMacroRuleName(int i) {
            return this.addMacroRuleName_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddMacroRuleNameCount() {
            return this.addMacroRuleName_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getAddMacroRuleNameList() {
            return this.addMacroRuleName_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddTag(int i) {
            return this.addTag_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddTagCount() {
            return this.addTag_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getAddTagList() {
            return this.addTag_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddTagRuleName(int i) {
            return this.addTagRuleName_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getAddTagRuleNameCount() {
            return this.addTagRuleName_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getAddTagRuleNameList() {
            return this.addTagRuleName_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public Rule getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getNegativePredicate(int i) {
            return this.negativePredicate_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getNegativePredicateCount() {
            return this.negativePredicate_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getNegativePredicateList() {
            return this.negativePredicate_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<Rule> getParserForType() {
            return PARSER;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getPositivePredicate(int i) {
            return this.positivePredicate_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getPositivePredicateCount() {
            return this.positivePredicate_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getPositivePredicateList() {
            return this.positivePredicate_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveMacro(int i) {
            return this.removeMacro_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveMacroCount() {
            return this.removeMacro_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getRemoveMacroList() {
            return this.removeMacro_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveMacroRuleName(int i) {
            return this.removeMacroRuleName_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveMacroRuleNameCount() {
            return this.removeMacroRuleName_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getRemoveMacroRuleNameList() {
            return this.removeMacroRuleName_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveTag(int i) {
            return this.removeTag_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveTagCount() {
            return this.removeTag_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getRemoveTagList() {
            return this.removeTag_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveTagRuleName(int i) {
            return this.removeTagRuleName_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public int getRemoveTagRuleNameCount() {
            return this.removeTagRuleName_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.RuleOrBuilder
        public List<Integer> getRemoveTagRuleNameList() {
            return this.removeTagRuleName_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            int i3 = 0;
            while (true) {
                int i4 = i3;
                if (i4 >= this.positivePredicate_.size()) {
                    break;
                }
                i2 += CodedOutputStream.computeInt32SizeNoTag(this.positivePredicate_.get(i4).intValue());
                i3 = i4 + 1;
            }
            int size = getPositivePredicateList().size();
            int i5 = 0;
            int i6 = 0;
            while (true) {
                int i7 = i6;
                if (i7 >= this.negativePredicate_.size()) {
                    break;
                }
                i5 += CodedOutputStream.computeInt32SizeNoTag(this.negativePredicate_.get(i7).intValue());
                i6 = i7 + 1;
            }
            int size2 = getNegativePredicateList().size();
            int i8 = 0;
            int i9 = 0;
            while (true) {
                int i10 = i9;
                if (i10 >= this.addTag_.size()) {
                    break;
                }
                i8 += CodedOutputStream.computeInt32SizeNoTag(this.addTag_.get(i10).intValue());
                i9 = i10 + 1;
            }
            int size3 = getAddTagList().size();
            int i11 = 0;
            int i12 = 0;
            while (true) {
                int i13 = i12;
                if (i13 >= this.removeTag_.size()) {
                    break;
                }
                i11 += CodedOutputStream.computeInt32SizeNoTag(this.removeTag_.get(i13).intValue());
                i12 = i13 + 1;
            }
            int size4 = getRemoveTagList().size();
            int i14 = 0;
            int i15 = 0;
            while (true) {
                int i16 = i15;
                if (i16 >= this.addTagRuleName_.size()) {
                    break;
                }
                i14 += CodedOutputStream.computeInt32SizeNoTag(this.addTagRuleName_.get(i16).intValue());
                i15 = i16 + 1;
            }
            int size5 = getAddTagRuleNameList().size();
            int i17 = 0;
            int i18 = 0;
            while (true) {
                int i19 = i18;
                if (i19 >= this.removeTagRuleName_.size()) {
                    break;
                }
                i17 += CodedOutputStream.computeInt32SizeNoTag(this.removeTagRuleName_.get(i19).intValue());
                i18 = i19 + 1;
            }
            int size6 = getRemoveTagRuleNameList().size();
            int i20 = 0;
            int i21 = 0;
            while (true) {
                int i22 = i21;
                if (i22 >= this.addMacro_.size()) {
                    break;
                }
                i20 += CodedOutputStream.computeInt32SizeNoTag(this.addMacro_.get(i22).intValue());
                i21 = i22 + 1;
            }
            int size7 = getAddMacroList().size();
            int i23 = 0;
            int i24 = 0;
            while (true) {
                int i25 = i24;
                if (i25 >= this.removeMacro_.size()) {
                    break;
                }
                i23 += CodedOutputStream.computeInt32SizeNoTag(this.removeMacro_.get(i25).intValue());
                i24 = i25 + 1;
            }
            int size8 = getRemoveMacroList().size();
            int i26 = 0;
            int i27 = 0;
            while (true) {
                int i28 = i27;
                if (i28 >= this.addMacroRuleName_.size()) {
                    break;
                }
                i26 += CodedOutputStream.computeInt32SizeNoTag(this.addMacroRuleName_.get(i28).intValue());
                i27 = i28 + 1;
            }
            int size9 = getAddMacroRuleNameList().size();
            int i29 = 0;
            int i30 = 0;
            while (true) {
                int i31 = i29;
                if (i30 < this.removeMacroRuleName_.size()) {
                    i29 = CodedOutputStream.computeInt32SizeNoTag(this.removeMacroRuleName_.get(i30).intValue()) + i31;
                    i30++;
                } else {
                    int size10 = i2 + 0 + (size * 1) + i5 + (size2 * 1) + i8 + (size3 * 1) + i11 + (size4 * 1) + i14 + (size5 * 1) + i17 + (size6 * 1) + i20 + (size7 * 1) + i23 + (size8 * 1) + i26 + (size9 * 1) + i31 + (getRemoveMacroRuleNameList().size() * 1) + this.unknownFields.size();
                    this.memoizedSerializedSize = size10;
                    return size10;
                }
            }
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = Rule.class.hashCode() + 779;
            if (getPositivePredicateCount() > 0) {
                hashCode = (((hashCode * 37) + 1) * 53) + getPositivePredicateList().hashCode();
            }
            if (getNegativePredicateCount() > 0) {
                hashCode = (((hashCode * 37) + 2) * 53) + getNegativePredicateList().hashCode();
            }
            if (getAddTagCount() > 0) {
                hashCode = (((hashCode * 37) + 3) * 53) + getAddTagList().hashCode();
            }
            if (getRemoveTagCount() > 0) {
                hashCode = (((hashCode * 37) + 4) * 53) + getRemoveTagList().hashCode();
            }
            if (getAddTagRuleNameCount() > 0) {
                hashCode = (((hashCode * 37) + 5) * 53) + getAddTagRuleNameList().hashCode();
            }
            if (getRemoveTagRuleNameCount() > 0) {
                hashCode = (((hashCode * 37) + 6) * 53) + getRemoveTagRuleNameList().hashCode();
            }
            if (getAddMacroCount() > 0) {
                hashCode = (((hashCode * 37) + 7) * 53) + getAddMacroList().hashCode();
            }
            if (getRemoveMacroCount() > 0) {
                hashCode = (((hashCode * 37) + 8) * 53) + getRemoveMacroList().hashCode();
            }
            if (getAddMacroRuleNameCount() > 0) {
                hashCode = (((hashCode * 37) + 9) * 53) + getAddMacroRuleNameList().hashCode();
            }
            if (getRemoveMacroRuleNameCount() > 0) {
                hashCode = (((hashCode * 37) + 10) * 53) + getRemoveMacroRuleNameList().hashCode();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$Rule");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            for (int i = 0; i < this.positivePredicate_.size(); i++) {
                codedOutputStream.writeInt32(1, this.positivePredicate_.get(i).intValue());
            }
            for (int i2 = 0; i2 < this.negativePredicate_.size(); i2++) {
                codedOutputStream.writeInt32(2, this.negativePredicate_.get(i2).intValue());
            }
            for (int i3 = 0; i3 < this.addTag_.size(); i3++) {
                codedOutputStream.writeInt32(3, this.addTag_.get(i3).intValue());
            }
            for (int i4 = 0; i4 < this.removeTag_.size(); i4++) {
                codedOutputStream.writeInt32(4, this.removeTag_.get(i4).intValue());
            }
            for (int i5 = 0; i5 < this.addTagRuleName_.size(); i5++) {
                codedOutputStream.writeInt32(5, this.addTagRuleName_.get(i5).intValue());
            }
            for (int i6 = 0; i6 < this.removeTagRuleName_.size(); i6++) {
                codedOutputStream.writeInt32(6, this.removeTagRuleName_.get(i6).intValue());
            }
            for (int i7 = 0; i7 < this.addMacro_.size(); i7++) {
                codedOutputStream.writeInt32(7, this.addMacro_.get(i7).intValue());
            }
            for (int i8 = 0; i8 < this.removeMacro_.size(); i8++) {
                codedOutputStream.writeInt32(8, this.removeMacro_.get(i8).intValue());
            }
            for (int i9 = 0; i9 < this.addMacroRuleName_.size(); i9++) {
                codedOutputStream.writeInt32(9, this.addMacroRuleName_.get(i9).intValue());
            }
            for (int i10 = 0; i10 < this.removeMacroRuleName_.size(); i10++) {
                codedOutputStream.writeInt32(10, this.removeMacroRuleName_.get(i10).intValue());
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface RuleOrBuilder extends MessageLiteOrBuilder {
        int getAddMacro(int i);

        int getAddMacroCount();

        List<Integer> getAddMacroList();

        int getAddMacroRuleName(int i);

        int getAddMacroRuleNameCount();

        List<Integer> getAddMacroRuleNameList();

        int getAddTag(int i);

        int getAddTagCount();

        List<Integer> getAddTagList();

        int getAddTagRuleName(int i);

        int getAddTagRuleNameCount();

        List<Integer> getAddTagRuleNameList();

        int getNegativePredicate(int i);

        int getNegativePredicateCount();

        List<Integer> getNegativePredicateList();

        int getPositivePredicate(int i);

        int getPositivePredicateCount();

        List<Integer> getPositivePredicateList();

        int getRemoveMacro(int i);

        int getRemoveMacroCount();

        List<Integer> getRemoveMacroList();

        int getRemoveMacroRuleName(int i);

        int getRemoveMacroRuleNameCount();

        List<Integer> getRemoveMacroRuleNameList();

        int getRemoveTag(int i);

        int getRemoveTagCount();

        List<Integer> getRemoveTagList();

        int getRemoveTagRuleName(int i);

        int getRemoveTagRuleNameCount();

        List<Integer> getRemoveTagRuleNameList();
    }

    public static final class ServingValue extends GeneratedMessageLite implements ServingValueOrBuilder {
        public static final int EXT_FIELD_NUMBER = 101;
        public static final int LIST_ITEM_FIELD_NUMBER = 1;
        public static final int MACRO_NAME_REFERENCE_FIELD_NUMBER = 6;
        public static final int MACRO_REFERENCE_FIELD_NUMBER = 4;
        public static final int MAP_KEY_FIELD_NUMBER = 2;
        public static final int MAP_VALUE_FIELD_NUMBER = 3;
        public static Parser<ServingValue> PARSER = new AbstractParser<ServingValue>() {
            /* class com.google.analytics.containertag.proto.Serving.ServingValue.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public ServingValue parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return new ServingValue(codedInputStream, extensionRegistryLite);
            }
        };
        public static final int TEMPLATE_TOKEN_FIELD_NUMBER = 5;
        private static final ServingValue defaultInstance = new ServingValue(true);
        public static final GeneratedMessageLite.GeneratedExtension<TypeSystem.Value, ServingValue> ext = GeneratedMessageLite.newSingularGeneratedExtension(TypeSystem.Value.getDefaultInstance(), getDefaultInstance(), getDefaultInstance(), null, 101, WireFormat.FieldType.MESSAGE, ServingValue.class);
        private static volatile MutableMessageLite mutableDefault = null;
        private static final long serialVersionUID = 0;
        /* access modifiers changed from: private */
        public int bitField0_;
        /* access modifiers changed from: private */
        public List<Integer> listItem_;
        /* access modifiers changed from: private */
        public int macroNameReference_;
        /* access modifiers changed from: private */
        public int macroReference_;
        /* access modifiers changed from: private */
        public List<Integer> mapKey_;
        /* access modifiers changed from: private */
        public List<Integer> mapValue_;
        private byte memoizedIsInitialized;
        private int memoizedSerializedSize;
        /* access modifiers changed from: private */
        public List<Integer> templateToken_;
        /* access modifiers changed from: private */
        public final ByteString unknownFields;

        public static final class Builder extends GeneratedMessageLite.Builder<ServingValue, Builder> implements ServingValueOrBuilder {
            private int bitField0_;
            private List<Integer> listItem_ = Collections.emptyList();
            private int macroNameReference_;
            private int macroReference_;
            private List<Integer> mapKey_ = Collections.emptyList();
            private List<Integer> mapValue_ = Collections.emptyList();
            private List<Integer> templateToken_ = Collections.emptyList();

            private Builder() {
                maybeForceBuilderInitialization();
            }

            /* access modifiers changed from: private */
            public static Builder create() {
                return new Builder();
            }

            private void ensureListItemIsMutable() {
                if ((this.bitField0_ & 1) != 1) {
                    this.listItem_ = new ArrayList(this.listItem_);
                    this.bitField0_ |= 1;
                }
            }

            private void ensureMapKeyIsMutable() {
                if ((this.bitField0_ & 2) != 2) {
                    this.mapKey_ = new ArrayList(this.mapKey_);
                    this.bitField0_ |= 2;
                }
            }

            private void ensureMapValueIsMutable() {
                if ((this.bitField0_ & 4) != 4) {
                    this.mapValue_ = new ArrayList(this.mapValue_);
                    this.bitField0_ |= 4;
                }
            }

            private void ensureTemplateTokenIsMutable() {
                if ((this.bitField0_ & 16) != 16) {
                    this.templateToken_ = new ArrayList(this.templateToken_);
                    this.bitField0_ |= 16;
                }
            }

            private void maybeForceBuilderInitialization() {
            }

            public Builder addAllListItem(Iterable<? extends Integer> iterable) {
                ensureListItemIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.listItem_);
                return this;
            }

            public Builder addAllMapKey(Iterable<? extends Integer> iterable) {
                ensureMapKeyIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.mapKey_);
                return this;
            }

            public Builder addAllMapValue(Iterable<? extends Integer> iterable) {
                ensureMapValueIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.mapValue_);
                return this;
            }

            public Builder addAllTemplateToken(Iterable<? extends Integer> iterable) {
                ensureTemplateTokenIsMutable();
                AbstractMessageLite.Builder.addAll(iterable, this.templateToken_);
                return this;
            }

            public Builder addListItem(int i) {
                ensureListItemIsMutable();
                this.listItem_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addMapKey(int i) {
                ensureMapKeyIsMutable();
                this.mapKey_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addMapValue(int i) {
                ensureMapValueIsMutable();
                this.mapValue_.add(Integer.valueOf(i));
                return this;
            }

            public Builder addTemplateToken(int i) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.add(Integer.valueOf(i));
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public ServingValue build() {
                ServingValue buildPartial = buildPartial();
                if (buildPartial.isInitialized()) {
                    return buildPartial;
                }
                throw newUninitializedMessageException(buildPartial);
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder
            public ServingValue buildPartial() {
                int i = 1;
                ServingValue servingValue = new ServingValue(this);
                int i2 = this.bitField0_;
                if ((this.bitField0_ & 1) == 1) {
                    this.listItem_ = Collections.unmodifiableList(this.listItem_);
                    this.bitField0_ &= -2;
                }
                List unused = servingValue.listItem_ = this.listItem_;
                if ((this.bitField0_ & 2) == 2) {
                    this.mapKey_ = Collections.unmodifiableList(this.mapKey_);
                    this.bitField0_ &= -3;
                }
                List unused2 = servingValue.mapKey_ = this.mapKey_;
                if ((this.bitField0_ & 4) == 4) {
                    this.mapValue_ = Collections.unmodifiableList(this.mapValue_);
                    this.bitField0_ &= -5;
                }
                List unused3 = servingValue.mapValue_ = this.mapValue_;
                if ((i2 & 8) != 8) {
                    i = 0;
                }
                int unused4 = servingValue.macroReference_ = this.macroReference_;
                if ((this.bitField0_ & 16) == 16) {
                    this.templateToken_ = Collections.unmodifiableList(this.templateToken_);
                    this.bitField0_ &= -17;
                }
                List unused5 = servingValue.templateToken_ = this.templateToken_;
                if ((i2 & 32) == 32) {
                    i |= 2;
                }
                int unused6 = servingValue.macroNameReference_ = this.macroNameReference_;
                int unused7 = servingValue.bitField0_ = i;
                return servingValue;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clear() {
                super.clear();
                this.listItem_ = Collections.emptyList();
                this.bitField0_ &= -2;
                this.mapKey_ = Collections.emptyList();
                this.bitField0_ &= -3;
                this.mapValue_ = Collections.emptyList();
                this.bitField0_ &= -5;
                this.macroReference_ = 0;
                this.bitField0_ &= -9;
                this.templateToken_ = Collections.emptyList();
                this.bitField0_ &= -17;
                this.macroNameReference_ = 0;
                this.bitField0_ &= -33;
                return this;
            }

            public Builder clearListItem() {
                this.listItem_ = Collections.emptyList();
                this.bitField0_ &= -2;
                return this;
            }

            public Builder clearMacroNameReference() {
                this.bitField0_ &= -33;
                this.macroNameReference_ = 0;
                return this;
            }

            public Builder clearMacroReference() {
                this.bitField0_ &= -9;
                this.macroReference_ = 0;
                return this;
            }

            public Builder clearMapKey() {
                this.mapKey_ = Collections.emptyList();
                this.bitField0_ &= -3;
                return this;
            }

            public Builder clearMapValue() {
                this.mapValue_ = Collections.emptyList();
                this.bitField0_ &= -5;
                return this;
            }

            public Builder clearTemplateToken() {
                this.templateToken_ = Collections.emptyList();
                this.bitField0_ &= -17;
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, java.lang.Object, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder
            public Builder clone() {
                return create().mergeFrom(buildPartial());
            }

            @Override // com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.GeneratedMessageLite.Builder, com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public ServingValue getDefaultInstanceForType() {
                return ServingValue.getDefaultInstance();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getListItem(int i) {
                return this.listItem_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getListItemCount() {
                return this.listItem_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public List<Integer> getListItemList() {
                return Collections.unmodifiableList(this.listItem_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMacroNameReference() {
                return this.macroNameReference_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMacroReference() {
                return this.macroReference_;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMapKey(int i) {
                return this.mapKey_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMapKeyCount() {
                return this.mapKey_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public List<Integer> getMapKeyList() {
                return Collections.unmodifiableList(this.mapKey_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMapValue(int i) {
                return this.mapValue_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getMapValueCount() {
                return this.mapValue_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public List<Integer> getMapValueList() {
                return Collections.unmodifiableList(this.mapValue_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getTemplateToken(int i) {
                return this.templateToken_.get(i).intValue();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public int getTemplateTokenCount() {
                return this.templateToken_.size();
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public List<Integer> getTemplateTokenList() {
                return Collections.unmodifiableList(this.templateToken_);
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public boolean hasMacroNameReference() {
                return (this.bitField0_ & 32) == 32;
            }

            @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
            public boolean hasMacroReference() {
                return (this.bitField0_ & 8) == 8;
            }

            @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(ServingValue servingValue) {
                if (servingValue != ServingValue.getDefaultInstance()) {
                    if (!servingValue.listItem_.isEmpty()) {
                        if (this.listItem_.isEmpty()) {
                            this.listItem_ = servingValue.listItem_;
                            this.bitField0_ &= -2;
                        } else {
                            ensureListItemIsMutable();
                            this.listItem_.addAll(servingValue.listItem_);
                        }
                    }
                    if (!servingValue.mapKey_.isEmpty()) {
                        if (this.mapKey_.isEmpty()) {
                            this.mapKey_ = servingValue.mapKey_;
                            this.bitField0_ &= -3;
                        } else {
                            ensureMapKeyIsMutable();
                            this.mapKey_.addAll(servingValue.mapKey_);
                        }
                    }
                    if (!servingValue.mapValue_.isEmpty()) {
                        if (this.mapValue_.isEmpty()) {
                            this.mapValue_ = servingValue.mapValue_;
                            this.bitField0_ &= -5;
                        } else {
                            ensureMapValueIsMutable();
                            this.mapValue_.addAll(servingValue.mapValue_);
                        }
                    }
                    if (servingValue.hasMacroReference()) {
                        setMacroReference(servingValue.getMacroReference());
                    }
                    if (!servingValue.templateToken_.isEmpty()) {
                        if (this.templateToken_.isEmpty()) {
                            this.templateToken_ = servingValue.templateToken_;
                            this.bitField0_ &= -17;
                        } else {
                            ensureTemplateTokenIsMutable();
                            this.templateToken_.addAll(servingValue.templateToken_);
                        }
                    }
                    if (servingValue.hasMacroNameReference()) {
                        setMacroNameReference(servingValue.getMacroNameReference());
                    }
                    setUnknownFields(getUnknownFields().concat(servingValue.unknownFields));
                }
                return this;
            }

            @Override // com.google.tagmanager.protobuf.MessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder, com.google.tagmanager.protobuf.AbstractMessageLite.Builder
            public Builder mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                Throwable th;
                ServingValue servingValue;
                ServingValue servingValue2 = null;
                try {
                    ServingValue parsePartialFrom = ServingValue.PARSER.parsePartialFrom(codedInputStream, extensionRegistryLite);
                    if (parsePartialFrom != null) {
                        mergeFrom(parsePartialFrom);
                    }
                    return this;
                } catch (InvalidProtocolBufferException e) {
                    InvalidProtocolBufferException invalidProtocolBufferException = e;
                    servingValue = (ServingValue) invalidProtocolBufferException.getUnfinishedMessage();
                    throw invalidProtocolBufferException;
                } catch (Throwable th2) {
                    th = th2;
                    servingValue2 = servingValue;
                }
                if (servingValue2 != null) {
                    mergeFrom(servingValue2);
                }
                throw th;
            }

            public Builder setListItem(int i, int i2) {
                ensureListItemIsMutable();
                this.listItem_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setMacroNameReference(int i) {
                this.bitField0_ |= 32;
                this.macroNameReference_ = i;
                return this;
            }

            public Builder setMacroReference(int i) {
                this.bitField0_ |= 8;
                this.macroReference_ = i;
                return this;
            }

            public Builder setMapKey(int i, int i2) {
                ensureMapKeyIsMutable();
                this.mapKey_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setMapValue(int i, int i2) {
                ensureMapValueIsMutable();
                this.mapValue_.set(i, Integer.valueOf(i2));
                return this;
            }

            public Builder setTemplateToken(int i, int i2) {
                ensureTemplateTokenIsMutable();
                this.templateToken_.set(i, Integer.valueOf(i2));
                return this;
            }
        }

        static {
            defaultInstance.initFields();
        }

        /* JADX WARNING: Removed duplicated region for block: B:20:0x0052  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x005e  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x006a  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0076  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private ServingValue(com.google.tagmanager.protobuf.CodedInputStream r12, com.google.tagmanager.protobuf.ExtensionRegistryLite r13) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
            /*
                r11 = this;
                r0 = -1
                r10 = 16
                r9 = 4
                r8 = 2
                r3 = 1
                r11.<init>()
                r11.memoizedIsInitialized = r0
                r11.memoizedSerializedSize = r0
                r11.initFields()
                r0 = 0
                com.google.tagmanager.protobuf.ByteString$Output r4 = com.google.tagmanager.protobuf.ByteString.newOutput()
                com.google.tagmanager.protobuf.CodedOutputStream r5 = com.google.tagmanager.protobuf.CodedOutputStream.newInstance(r4)
                r1 = 0
            L_0x001a:
                if (r1 != 0) goto L_0x01de
                int r2 = r12.readTag()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                switch(r2) {
                    case 0: goto L_0x023c;
                    case 8: goto L_0x002b;
                    case 10: goto L_0x008b;
                    case 16: goto L_0x00d2;
                    case 18: goto L_0x00ee;
                    case 24: goto L_0x0122;
                    case 26: goto L_0x013e;
                    case 32: goto L_0x0172;
                    case 40: goto L_0x0180;
                    case 42: goto L_0x019c;
                    case 48: goto L_0x01d0;
                    default: goto L_0x0023;
                }     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
            L_0x0023:
                boolean r2 = r11.parseUnknownField(r12, r5, r13, r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r2 != 0) goto L_0x001a
                r1 = r3
                goto L_0x001a
            L_0x002b:
                r2 = r0 & 1
                if (r2 == r3) goto L_0x0038
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.listItem_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 1
            L_0x0038:
                java.util.List<java.lang.Integer> r2 = r11.listItem_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r6 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x0046:
                r1 = move-exception
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r1 = r1.setUnfinishedMessage(r11)     // Catch:{ all -> 0x004c }
                throw r1     // Catch:{ all -> 0x004c }
            L_0x004c:
                r1 = move-exception
                r2 = r0
            L_0x004e:
                r0 = r2 & 1
                if (r0 != r3) goto L_0x005a
                java.util.List<java.lang.Integer> r0 = r11.listItem_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r11.listItem_ = r0
            L_0x005a:
                r0 = r2 & 2
                if (r0 != r8) goto L_0x0066
                java.util.List<java.lang.Integer> r0 = r11.mapKey_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r11.mapKey_ = r0
            L_0x0066:
                r0 = r2 & 4
                if (r0 != r9) goto L_0x0072
                java.util.List<java.lang.Integer> r0 = r11.mapValue_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r11.mapValue_ = r0
            L_0x0072:
                r0 = r2 & 16
                if (r0 != r10) goto L_0x007e
                java.util.List<java.lang.Integer> r0 = r11.templateToken_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r11.templateToken_ = r0
            L_0x007e:
                r5.flush()     // Catch:{ IOException -> 0x022b, all -> 0x0234 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r11.unknownFields = r0
            L_0x0087:
                r11.makeExtensionsImmutable()
                throw r1
            L_0x008b:
                int r2 = r12.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6 = r0 & 1
                if (r6 == r3) goto L_0x00a6
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x00a6
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.listItem_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 1
            L_0x00a6:
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x00cd
                java.util.List<java.lang.Integer> r6 = r11.listItem_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r7 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x00a6
            L_0x00ba:
                r1 = move-exception
                r2 = r0
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = new com.google.tagmanager.protobuf.InvalidProtocolBufferException     // Catch:{ all -> 0x00ca }
                java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x00ca }
                r0.<init>(r1)     // Catch:{ all -> 0x00ca }
                com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r0.setUnfinishedMessage(r11)     // Catch:{ all -> 0x00ca }
                throw r0     // Catch:{ all -> 0x00ca }
            L_0x00ca:
                r0 = move-exception
                r1 = r0
                goto L_0x004e
            L_0x00cd:
                r12.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x00d2:
                r2 = r0 & 2
                if (r2 == r8) goto L_0x00df
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.mapKey_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 2
            L_0x00df:
                java.util.List<java.lang.Integer> r2 = r11.mapKey_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r6 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x00ee:
                int r2 = r12.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6 = r0 & 2
                if (r6 == r8) goto L_0x0109
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x0109
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.mapKey_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 2
            L_0x0109:
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x011d
                java.util.List<java.lang.Integer> r6 = r11.mapKey_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r7 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x0109
            L_0x011d:
                r12.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x0122:
                r2 = r0 & 4
                if (r2 == r9) goto L_0x012f
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.mapValue_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 4
            L_0x012f:
                java.util.List<java.lang.Integer> r2 = r11.mapValue_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r6 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x013e:
                int r2 = r12.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6 = r0 & 4
                if (r6 == r9) goto L_0x0159
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x0159
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.mapValue_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 4
            L_0x0159:
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x016d
                java.util.List<java.lang.Integer> r6 = r11.mapValue_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r7 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x0159
            L_0x016d:
                r12.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x0172:
                int r2 = r11.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2 = r2 | 1
                r11.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.macroReference_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x0180:
                r2 = r0 & 16
                if (r2 == r10) goto L_0x018d
                java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.templateToken_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 16
            L_0x018d:
                java.util.List<java.lang.Integer> r2 = r11.templateToken_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r6 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2.add(r6)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x019c:
                int r2 = r12.readRawVarint32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.pushLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6 = r0 & 16
                if (r6 == r10) goto L_0x01b7
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x01b7
                java.util.ArrayList r6 = new java.util.ArrayList     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.<init>()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.templateToken_ = r6     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r0 = r0 | 16
            L_0x01b7:
                int r6 = r12.getBytesUntilLimit()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                if (r6 <= 0) goto L_0x01cb
                java.util.List<java.lang.Integer> r6 = r11.templateToken_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r7 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r6.add(r7)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x01b7
            L_0x01cb:
                r12.popLimit(r2)     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x01d0:
                int r2 = r11.bitField0_     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r2 = r2 | 2
                r11.bitField0_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                int r2 = r12.readInt32()     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                r11.macroNameReference_ = r2     // Catch:{ InvalidProtocolBufferException -> 0x0046, IOException -> 0x00ba }
                goto L_0x001a
            L_0x01de:
                r1 = r0 & 1
                if (r1 != r3) goto L_0x01ea
                java.util.List<java.lang.Integer> r1 = r11.listItem_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r11.listItem_ = r1
            L_0x01ea:
                r1 = r0 & 2
                if (r1 != r8) goto L_0x01f6
                java.util.List<java.lang.Integer> r1 = r11.mapKey_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r11.mapKey_ = r1
            L_0x01f6:
                r1 = r0 & 4
                if (r1 != r9) goto L_0x0202
                java.util.List<java.lang.Integer> r1 = r11.mapValue_
                java.util.List r1 = java.util.Collections.unmodifiableList(r1)
                r11.mapValue_ = r1
            L_0x0202:
                r0 = r0 & 16
                if (r0 != r10) goto L_0x020e
                java.util.List<java.lang.Integer> r0 = r11.templateToken_
                java.util.List r0 = java.util.Collections.unmodifiableList(r0)
                r11.templateToken_ = r0
            L_0x020e:
                r5.flush()     // Catch:{ IOException -> 0x021b, all -> 0x0223 }
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r11.unknownFields = r0
            L_0x0217:
                r11.makeExtensionsImmutable()
                return
            L_0x021b:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r11.unknownFields = r0
                goto L_0x0217
            L_0x0223:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r11.unknownFields = r1
                throw r0
            L_0x022b:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r0 = r4.toByteString()
                r11.unknownFields = r0
                goto L_0x0087
            L_0x0234:
                r0 = move-exception
                com.google.tagmanager.protobuf.ByteString r1 = r4.toByteString()
                r11.unknownFields = r1
                throw r0
            L_0x023c:
                r1 = r3
                goto L_0x001a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.analytics.containertag.proto.Serving.ServingValue.<init>(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):void");
        }

        private ServingValue(GeneratedMessageLite.Builder builder) {
            super(builder);
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = builder.getUnknownFields();
        }

        private ServingValue(boolean z) {
            this.memoizedIsInitialized = -1;
            this.memoizedSerializedSize = -1;
            this.unknownFields = ByteString.EMPTY;
        }

        public static ServingValue getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.listItem_ = Collections.emptyList();
            this.mapKey_ = Collections.emptyList();
            this.mapValue_ = Collections.emptyList();
            this.macroReference_ = 0;
            this.templateToken_ = Collections.emptyList();
            this.macroNameReference_ = 0;
        }

        public static Builder newBuilder() {
            return Builder.create();
        }

        public static Builder newBuilder(ServingValue servingValue) {
            return newBuilder().mergeFrom(servingValue);
        }

        public static ServingValue parseDelimitedFrom(InputStream inputStream) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream);
        }

        public static ServingValue parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseDelimitedFrom(inputStream, extensionRegistryLite);
        }

        public static ServingValue parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString);
        }

        public static ServingValue parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(byteString, extensionRegistryLite);
        }

        public static ServingValue parseFrom(CodedInputStream codedInputStream) throws IOException {
            return PARSER.parseFrom(codedInputStream);
        }

        public static ServingValue parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(codedInputStream, extensionRegistryLite);
        }

        public static ServingValue parseFrom(InputStream inputStream) throws IOException {
            return PARSER.parseFrom(inputStream);
        }

        public static ServingValue parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return PARSER.parseFrom(inputStream, extensionRegistryLite);
        }

        public static ServingValue parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr);
        }

        public static ServingValue parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return PARSER.parseFrom(bArr, extensionRegistryLite);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ServingValue)) {
                return super.equals(obj);
            }
            ServingValue servingValue = (ServingValue) obj;
            boolean z = (((getListItemList().equals(servingValue.getListItemList())) && getMapKeyList().equals(servingValue.getMapKeyList())) && getMapValueList().equals(servingValue.getMapValueList())) && hasMacroReference() == servingValue.hasMacroReference();
            if (hasMacroReference()) {
                z = z && getMacroReference() == servingValue.getMacroReference();
            }
            boolean z2 = (z && getTemplateTokenList().equals(servingValue.getTemplateTokenList())) && hasMacroNameReference() == servingValue.hasMacroNameReference();
            return hasMacroNameReference() ? z2 && getMacroNameReference() == servingValue.getMacroNameReference() : z2;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public ServingValue getDefaultInstanceForType() {
            return defaultInstance;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getListItem(int i) {
            return this.listItem_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getListItemCount() {
            return this.listItem_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public List<Integer> getListItemList() {
            return this.listItem_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMacroNameReference() {
            return this.macroNameReference_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMacroReference() {
            return this.macroReference_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMapKey(int i) {
            return this.mapKey_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMapKeyCount() {
            return this.mapKey_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public List<Integer> getMapKeyList() {
            return this.mapKey_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMapValue(int i) {
            return this.mapValue_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getMapValueCount() {
            return this.mapValue_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public List<Integer> getMapValueList() {
            return this.mapValue_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMessageLite
        public Parser<ServingValue> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = this.memoizedSerializedSize;
            if (i != -1) {
                return i;
            }
            int i2 = 0;
            for (int i3 = 0; i3 < this.listItem_.size(); i3++) {
                i2 += CodedOutputStream.computeInt32SizeNoTag(this.listItem_.get(i3).intValue());
            }
            int size = getListItemList().size();
            int i4 = 0;
            for (int i5 = 0; i5 < this.mapKey_.size(); i5++) {
                i4 += CodedOutputStream.computeInt32SizeNoTag(this.mapKey_.get(i5).intValue());
            }
            int size2 = getMapKeyList().size();
            int i6 = 0;
            int i7 = 0;
            while (i7 < this.mapValue_.size()) {
                i7++;
                i6 = CodedOutputStream.computeInt32SizeNoTag(this.mapValue_.get(i7).intValue()) + i6;
            }
            int size3 = i2 + 0 + (size * 1) + i4 + (size2 * 1) + i6 + (getMapValueList().size() * 1);
            int computeInt32Size = (this.bitField0_ & 1) == 1 ? size3 + CodedOutputStream.computeInt32Size(4, this.macroReference_) : size3;
            int i8 = 0;
            for (int i9 = 0; i9 < this.templateToken_.size(); i9++) {
                i8 += CodedOutputStream.computeInt32SizeNoTag(this.templateToken_.get(i9).intValue());
            }
            int size4 = computeInt32Size + i8 + (getTemplateTokenList().size() * 1);
            if ((this.bitField0_ & 2) == 2) {
                size4 += CodedOutputStream.computeInt32Size(6, this.macroNameReference_);
            }
            int size5 = size4 + this.unknownFields.size();
            this.memoizedSerializedSize = size5;
            return size5;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getTemplateToken(int i) {
            return this.templateToken_.get(i).intValue();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public int getTemplateTokenCount() {
            return this.templateToken_.size();
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public List<Integer> getTemplateTokenList() {
            return this.templateToken_;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public boolean hasMacroNameReference() {
            return (this.bitField0_ & 2) == 2;
        }

        @Override // com.google.analytics.containertag.proto.Serving.ServingValueOrBuilder
        public boolean hasMacroReference() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            if (this.memoizedHashCode != 0) {
                return this.memoizedHashCode;
            }
            int hashCode = ServingValue.class.hashCode() + 779;
            if (getListItemCount() > 0) {
                hashCode = (((hashCode * 37) + 1) * 53) + getListItemList().hashCode();
            }
            if (getMapKeyCount() > 0) {
                hashCode = (((hashCode * 37) + 2) * 53) + getMapKeyList().hashCode();
            }
            if (getMapValueCount() > 0) {
                hashCode = (((hashCode * 37) + 3) * 53) + getMapValueList().hashCode();
            }
            if (hasMacroReference()) {
                hashCode = (((hashCode * 37) + 4) * 53) + getMacroReference();
            }
            if (getTemplateTokenCount() > 0) {
                hashCode = (((hashCode * 37) + 5) * 53) + getTemplateTokenList().hashCode();
            }
            if (hasMacroNameReference()) {
                hashCode = (((hashCode * 37) + 6) * 53) + getMacroNameReference();
            }
            int hashCode2 = (hashCode * 29) + this.unknownFields.hashCode();
            this.memoizedHashCode = hashCode2;
            return hashCode2;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public MutableMessageLite internalMutableDefault() {
            if (mutableDefault == null) {
                mutableDefault = internalMutableDefault("com.google.analytics.containertag.proto.MutableServing$ServingValue");
            }
            return mutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            byte b = this.memoizedIsInitialized;
            if (b != -1) {
                return b == 1;
            }
            this.memoizedIsInitialized = 1;
            return true;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder newBuilderForType() {
            return newBuilder();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public Builder toBuilder() {
            return newBuilder(this);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            getSerializedSize();
            for (int i = 0; i < this.listItem_.size(); i++) {
                codedOutputStream.writeInt32(1, this.listItem_.get(i).intValue());
            }
            for (int i2 = 0; i2 < this.mapKey_.size(); i2++) {
                codedOutputStream.writeInt32(2, this.mapKey_.get(i2).intValue());
            }
            for (int i3 = 0; i3 < this.mapValue_.size(); i3++) {
                codedOutputStream.writeInt32(3, this.mapValue_.get(i3).intValue());
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeInt32(4, this.macroReference_);
            }
            for (int i4 = 0; i4 < this.templateToken_.size(); i4++) {
                codedOutputStream.writeInt32(5, this.templateToken_.get(i4).intValue());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(6, this.macroNameReference_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
        }
    }

    public interface ServingValueOrBuilder extends MessageLiteOrBuilder {
        int getListItem(int i);

        int getListItemCount();

        List<Integer> getListItemList();

        int getMacroNameReference();

        int getMacroReference();

        int getMapKey(int i);

        int getMapKeyCount();

        List<Integer> getMapKeyList();

        int getMapValue(int i);

        int getMapValueCount();

        List<Integer> getMapValueList();

        int getTemplateToken(int i);

        int getTemplateTokenCount();

        List<Integer> getTemplateTokenList();

        boolean hasMacroNameReference();

        boolean hasMacroReference();
    }

    private Serving() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
        extensionRegistryLite.add(ServingValue.ext);
    }
}

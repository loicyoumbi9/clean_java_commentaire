package com.google.analytics.tracking.android;

import android.text.TextUtils;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Utility;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

class HitBuilder {
    HitBuilder() {
    }

    static String encode(String str) {
        try {
            return URLEncoder.encode(str, Constants.ENCODING_CHARSET);
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError("URL encoding failed for: " + str);
        }
    }

    static Map<String, String> generateHitParams(Map<String, String> map) {
        HashMap hashMap = new HashMap();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getKey().startsWith(Utility.QUERY_APPENDIX) && entry.getValue() != null) {
                String substring = entry.getKey().substring(1);
                if (!TextUtils.isEmpty(substring)) {
                    hashMap.put(substring, entry.getValue());
                }
            }
        }
        return hashMap;
    }

    static String postProcessHit(Hit hit, long j) {
        StringBuilder sb = new StringBuilder();
        sb.append(hit.getHitParams());
        if (hit.getHitTime() > 0) {
            long hitTime = j - hit.getHitTime();
            if (hitTime >= 0) {
                sb.append("&qt").append("=").append(hitTime);
            }
        }
        sb.append("&z").append("=").append(hit.getHitId());
        return sb.toString();
    }
}

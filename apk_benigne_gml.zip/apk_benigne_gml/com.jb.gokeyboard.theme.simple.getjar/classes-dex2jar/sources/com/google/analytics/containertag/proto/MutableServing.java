package com.google.analytics.containertag.proto;

import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import com.google.ads.AdSize;
import com.google.analytics.midtier.proto.containertag.MutableTypeSystem;
import com.google.tagmanager.protobuf.AbstractMutableMessageLite;
import com.google.tagmanager.protobuf.ByteString;
import com.google.tagmanager.protobuf.CodedInputStream;
import com.google.tagmanager.protobuf.CodedOutputStream;
import com.google.tagmanager.protobuf.ExtensionRegistryLite;
import com.google.tagmanager.protobuf.GeneratedMessageLite;
import com.google.tagmanager.protobuf.GeneratedMutableMessageLite;
import com.google.tagmanager.protobuf.Internal;
import com.google.tagmanager.protobuf.LazyStringArrayList;
import com.google.tagmanager.protobuf.LazyStringList;
import com.google.tagmanager.protobuf.MessageLite;
import com.google.tagmanager.protobuf.MutableMessageLite;
import com.google.tagmanager.protobuf.Parser;
import com.google.tagmanager.protobuf.WireFormat;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class MutableServing {

    public static final class CacheOption extends GeneratedMutableMessageLite<CacheOption> implements MutableMessageLite {
        public static final int EXPIRATION_SECONDS_FIELD_NUMBER = 2;
        public static final int GCACHE_EXPIRATION_SECONDS_FIELD_NUMBER = 3;
        public static final int LEVEL_FIELD_NUMBER = 1;
        public static Parser<CacheOption> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        private static final CacheOption defaultInstance = new CacheOption(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private int expirationSeconds_;
        private int gcacheExpirationSeconds_;
        private CacheLevel level_ = CacheLevel.NO_CACHE;

        public enum CacheLevel implements Internal.EnumLite {
            NO_CACHE(0, 1),
            PRIVATE(1, 2),
            PUBLIC(2, 3);
            
            public static final int NO_CACHE_VALUE = 1;
            public static final int PRIVATE_VALUE = 2;
            public static final int PUBLIC_VALUE = 3;
            private static Internal.EnumLiteMap<CacheLevel> internalValueMap = new Internal.EnumLiteMap<CacheLevel>() {
                /* class com.google.analytics.containertag.proto.MutableServing.CacheOption.CacheLevel.AnonymousClass1 */

                @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
                public CacheLevel findValueByNumber(int i) {
                    return CacheLevel.valueOf(i);
                }
            };
            private final int value;

            private CacheLevel(int i, int i2) {
                this.value = i2;
            }

            public static Internal.EnumLiteMap<CacheLevel> internalGetValueMap() {
                return internalValueMap;
            }

            public static CacheLevel valueOf(int i) {
                switch (i) {
                    case 1:
                        return NO_CACHE;
                    case 2:
                        return PRIVATE;
                    case 3:
                        return PUBLIC;
                    default:
                        return null;
                }
            }

            @Override // com.google.tagmanager.protobuf.Internal.EnumLite
            public final int getNumber() {
                return this.value;
            }
        }

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private CacheOption() {
            initFields();
        }

        private CacheOption(boolean z) {
        }

        public static CacheOption getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.level_ = CacheLevel.NO_CACHE;
        }

        public static CacheOption newMessage() {
            return new CacheOption();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public CacheOption clear() {
            assertMutable();
            super.clear();
            this.level_ = CacheLevel.NO_CACHE;
            this.bitField0_ &= -2;
            this.expirationSeconds_ = 0;
            this.bitField0_ &= -3;
            this.gcacheExpirationSeconds_ = 0;
            this.bitField0_ &= -5;
            return this;
        }

        public CacheOption clearExpirationSeconds() {
            assertMutable();
            this.bitField0_ &= -3;
            this.expirationSeconds_ = 0;
            return this;
        }

        public CacheOption clearGcacheExpirationSeconds() {
            assertMutable();
            this.bitField0_ &= -5;
            this.gcacheExpirationSeconds_ = 0;
            return this;
        }

        public CacheOption clearLevel() {
            assertMutable();
            this.bitField0_ &= -2;
            this.level_ = CacheLevel.NO_CACHE;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public CacheOption clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof CacheOption)) {
                return super.equals(obj);
            }
            CacheOption cacheOption = (CacheOption) obj;
            boolean z = hasLevel() == cacheOption.hasLevel();
            if (hasLevel()) {
                z = z && getLevel() == cacheOption.getLevel();
            }
            boolean z2 = z && hasExpirationSeconds() == cacheOption.hasExpirationSeconds();
            if (hasExpirationSeconds()) {
                z2 = z2 && getExpirationSeconds() == cacheOption.getExpirationSeconds();
            }
            boolean z3 = z2 && hasGcacheExpirationSeconds() == cacheOption.hasGcacheExpirationSeconds();
            return hasGcacheExpirationSeconds() ? z3 && getGcacheExpirationSeconds() == cacheOption.getGcacheExpirationSeconds() : z3;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final CacheOption getDefaultInstanceForType() {
            return defaultInstance;
        }

        public int getExpirationSeconds() {
            return this.expirationSeconds_;
        }

        public int getGcacheExpirationSeconds() {
            return this.gcacheExpirationSeconds_;
        }

        public CacheLevel getLevel() {
            return this.level_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<CacheOption> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if ((this.bitField0_ & 1) == 1) {
                i = CodedOutputStream.computeEnumSize(1, this.level_.getNumber()) + 0;
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeInt32Size(2, this.expirationSeconds_);
            }
            if ((this.bitField0_ & 4) == 4) {
                i += CodedOutputStream.computeInt32Size(3, this.gcacheExpirationSeconds_);
            }
            int size = i + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public boolean hasExpirationSeconds() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasGcacheExpirationSeconds() {
            return (this.bitField0_ & 4) == 4;
        }

        public boolean hasLevel() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (hasLevel()) {
                i = 80454 + Internal.hashEnum(getLevel());
            }
            if (hasExpirationSeconds()) {
                i = (((i * 37) + 2) * 53) + getExpirationSeconds();
            }
            if (hasGcacheExpirationSeconds()) {
                i = (((i * 37) + 3) * 53) + getGcacheExpirationSeconds();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$CacheOption");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return true;
        }

        public CacheOption mergeFrom(CacheOption cacheOption) {
            if (this == cacheOption) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (cacheOption != getDefaultInstance()) {
                if (cacheOption.hasLevel()) {
                    setLevel(cacheOption.getLevel());
                }
                if (cacheOption.hasExpirationSeconds()) {
                    setExpirationSeconds(cacheOption.getExpirationSeconds());
                }
                if (cacheOption.hasGcacheExpirationSeconds()) {
                    setGcacheExpirationSeconds(cacheOption.getGcacheExpirationSeconds());
                }
                this.unknownFields = this.unknownFields.concat(cacheOption.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            int readEnum = codedInputStream.readEnum();
                            CacheLevel valueOf = CacheLevel.valueOf(readEnum);
                            if (valueOf != null) {
                                this.bitField0_ |= 1;
                                this.level_ = valueOf;
                                break;
                            } else {
                                newInstance.writeRawVarint32(readTag);
                                newInstance.writeRawVarint32(readEnum);
                                break;
                            }
                        case 16:
                            this.bitField0_ |= 2;
                            this.expirationSeconds_ = codedInputStream.readInt32();
                            break;
                        case 24:
                            this.bitField0_ |= 4;
                            this.gcacheExpirationSeconds_ = codedInputStream.readInt32();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public CacheOption newMessageForType() {
            return new CacheOption();
        }

        public CacheOption setExpirationSeconds(int i) {
            assertMutable();
            this.bitField0_ |= 2;
            this.expirationSeconds_ = i;
            return this;
        }

        public CacheOption setGcacheExpirationSeconds(int i) {
            assertMutable();
            this.bitField0_ |= 4;
            this.gcacheExpirationSeconds_ = i;
            return this;
        }

        public CacheOption setLevel(CacheLevel cacheLevel) {
            assertMutable();
            if (cacheLevel == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.level_ = cacheLevel;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeEnum(1, this.level_.getNumber());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(2, this.expirationSeconds_);
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeInt32(3, this.gcacheExpirationSeconds_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class Container extends GeneratedMutableMessageLite<Container> implements MutableMessageLite {
        public static final int CONTAINER_ID_FIELD_NUMBER = 3;
        public static final int JS_RESOURCE_FIELD_NUMBER = 1;
        public static Parser<Container> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int STATE_FIELD_NUMBER = 4;
        public static final int VERSION_FIELD_NUMBER = 5;
        private static final Container defaultInstance = new Container(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private Object containerId_ = Internal.EMPTY_BYTE_ARRAY;
        private Resource jsResource_;
        private ResourceState state_ = ResourceState.PREVIEW;
        private Object version_ = Internal.EMPTY_BYTE_ARRAY;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private Container() {
            initFields();
        }

        private Container(boolean z) {
        }

        private void ensureJsResourceInitialized() {
            if (this.jsResource_ == Resource.getDefaultInstance()) {
                this.jsResource_ = Resource.newMessage();
            }
        }

        public static Container getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.jsResource_ = Resource.getDefaultInstance();
            this.state_ = ResourceState.PREVIEW;
        }

        public static Container newMessage() {
            return new Container();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Container clear() {
            assertMutable();
            super.clear();
            if (this.jsResource_ != Resource.getDefaultInstance()) {
                this.jsResource_.clear();
            }
            this.bitField0_ &= -2;
            this.containerId_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -3;
            this.state_ = ResourceState.PREVIEW;
            this.bitField0_ &= -5;
            this.version_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -9;
            return this;
        }

        public Container clearContainerId() {
            assertMutable();
            this.bitField0_ &= -3;
            this.containerId_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public Container clearJsResource() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.jsResource_ != Resource.getDefaultInstance()) {
                this.jsResource_.clear();
            }
            return this;
        }

        public Container clearState() {
            assertMutable();
            this.bitField0_ &= -5;
            this.state_ = ResourceState.PREVIEW;
            return this;
        }

        public Container clearVersion() {
            assertMutable();
            this.bitField0_ &= -9;
            this.version_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public Container clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Container)) {
                return super.equals(obj);
            }
            Container container = (Container) obj;
            boolean z = hasJsResource() == container.hasJsResource();
            if (hasJsResource()) {
                z = z && getJsResource().equals(container.getJsResource());
            }
            boolean z2 = z && hasContainerId() == container.hasContainerId();
            if (hasContainerId()) {
                z2 = z2 && getContainerId().equals(container.getContainerId());
            }
            boolean z3 = z2 && hasState() == container.hasState();
            if (hasState()) {
                z3 = z3 && getState() == container.getState();
            }
            boolean z4 = z3 && hasVersion() == container.hasVersion();
            return hasVersion() ? z4 && getVersion().equals(container.getVersion()) : z4;
        }

        public String getContainerId() {
            Object obj = this.containerId_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.containerId_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getContainerIdAsBytes() {
            Object obj = this.containerId_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.containerId_ = byteArray;
            return byteArray;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final Container getDefaultInstanceForType() {
            return defaultInstance;
        }

        public Resource getJsResource() {
            return this.jsResource_;
        }

        public Resource getMutableJsResource() {
            assertMutable();
            ensureJsResourceInitialized();
            this.bitField0_ |= 1;
            return this.jsResource_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<Container> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int computeMessageSize = CodedOutputStream.computeMessageSize(1, this.jsResource_) + 0 + CodedOutputStream.computeByteArraySize(3, getContainerIdAsBytes()) + CodedOutputStream.computeEnumSize(4, this.state_.getNumber());
            if ((this.bitField0_ & 8) == 8) {
                computeMessageSize += CodedOutputStream.computeByteArraySize(5, getVersionAsBytes());
            }
            int size = computeMessageSize + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public ResourceState getState() {
            return this.state_;
        }

        public String getVersion() {
            Object obj = this.version_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.version_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getVersionAsBytes() {
            Object obj = this.version_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.version_ = byteArray;
            return byteArray;
        }

        public boolean hasContainerId() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasJsResource() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasState() {
            return (this.bitField0_ & 4) == 4;
        }

        public boolean hasVersion() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            int i = 41;
            if (hasJsResource()) {
                i = 80454 + getJsResource().hashCode();
            }
            if (hasContainerId()) {
                i = (((i * 37) + 3) * 53) + getContainerId().hashCode();
            }
            if (hasState()) {
                i = (((i * 37) + 4) * 53) + Internal.hashEnum(getState());
            }
            if (hasVersion()) {
                i = (((i * 37) + 5) * 53) + getVersion().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$Container");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return hasJsResource() && hasContainerId() && hasState() && getJsResource().isInitialized();
        }

        public Container mergeFrom(Container container) {
            if (this == container) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (container != getDefaultInstance()) {
                if (container.hasJsResource()) {
                    ensureJsResourceInitialized();
                    this.jsResource_.mergeFrom(container.getJsResource());
                    this.bitField0_ |= 1;
                }
                if (container.hasContainerId()) {
                    this.bitField0_ |= 2;
                    if (container.containerId_ instanceof String) {
                        this.containerId_ = container.containerId_;
                    } else {
                        byte[] bArr = (byte[]) container.containerId_;
                        this.containerId_ = Arrays.copyOf(bArr, bArr.length);
                    }
                }
                if (container.hasState()) {
                    setState(container.getState());
                }
                if (container.hasVersion()) {
                    this.bitField0_ |= 8;
                    if (container.version_ instanceof String) {
                        this.version_ = container.version_;
                    } else {
                        byte[] bArr2 = (byte[]) container.version_;
                        this.version_ = Arrays.copyOf(bArr2, bArr2.length);
                    }
                }
                this.unknownFields = this.unknownFields.concat(container.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            if (this.jsResource_ == Resource.getDefaultInstance()) {
                                this.jsResource_ = Resource.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.jsResource_, extensionRegistryLite);
                            break;
                        case 26:
                            this.bitField0_ |= 2;
                            this.containerId_ = codedInputStream.readByteArray();
                            break;
                        case 32:
                            int readEnum = codedInputStream.readEnum();
                            ResourceState valueOf = ResourceState.valueOf(readEnum);
                            if (valueOf != null) {
                                this.bitField0_ |= 4;
                                this.state_ = valueOf;
                                break;
                            } else {
                                newInstance.writeRawVarint32(readTag);
                                newInstance.writeRawVarint32(readEnum);
                                break;
                            }
                        case 42:
                            this.bitField0_ |= 8;
                            this.version_ = codedInputStream.readByteArray();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public Container newMessageForType() {
            return new Container();
        }

        public Container setContainerId(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.containerId_ = str;
            return this;
        }

        public Container setContainerIdAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.containerId_ = bArr;
            return this;
        }

        public Container setJsResource(Resource resource) {
            assertMutable();
            if (resource == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.jsResource_ = resource;
            return this;
        }

        public Container setState(ResourceState resourceState) {
            assertMutable();
            if (resourceState == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 4;
            this.state_ = resourceState;
            return this;
        }

        public Container setVersion(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.version_ = str;
            return this;
        }

        public Container setVersionAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.version_ = bArr;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            codedOutputStream.writeMessageWithCachedSizes(1, this.jsResource_);
            codedOutputStream.writeByteArray(3, getContainerIdAsBytes());
            codedOutputStream.writeEnum(4, this.state_.getNumber());
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeByteArray(5, getVersionAsBytes());
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class FunctionCall extends GeneratedMutableMessageLite<FunctionCall> implements MutableMessageLite {
        public static final int FUNCTION_FIELD_NUMBER = 2;
        public static final int LIVE_ONLY_FIELD_NUMBER = 6;
        public static final int NAME_FIELD_NUMBER = 4;
        public static Parser<FunctionCall> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int PROPERTY_FIELD_NUMBER = 3;
        public static final int SERVER_SIDE_FIELD_NUMBER = 1;
        private static final FunctionCall defaultInstance = new FunctionCall(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private int function_;
        private boolean liveOnly_;
        private int name_;
        private List<Integer> property_ = null;
        private boolean serverSide_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private FunctionCall() {
            initFields();
        }

        private FunctionCall(boolean z) {
        }

        private void ensurePropertyInitialized() {
            if (this.property_ == null) {
                this.property_ = new ArrayList();
            }
        }

        public static FunctionCall getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static FunctionCall newMessage() {
            return new FunctionCall();
        }

        public FunctionCall addAllProperty(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensurePropertyInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.property_);
            return this;
        }

        public FunctionCall addProperty(int i) {
            assertMutable();
            ensurePropertyInitialized();
            this.property_.add(Integer.valueOf(i));
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public FunctionCall clear() {
            assertMutable();
            super.clear();
            this.property_ = null;
            this.function_ = 0;
            this.bitField0_ &= -2;
            this.name_ = 0;
            this.bitField0_ &= -3;
            this.liveOnly_ = false;
            this.bitField0_ &= -5;
            this.serverSide_ = false;
            this.bitField0_ &= -9;
            return this;
        }

        public FunctionCall clearFunction() {
            assertMutable();
            this.bitField0_ &= -2;
            this.function_ = 0;
            return this;
        }

        public FunctionCall clearLiveOnly() {
            assertMutable();
            this.bitField0_ &= -5;
            this.liveOnly_ = false;
            return this;
        }

        public FunctionCall clearName() {
            assertMutable();
            this.bitField0_ &= -3;
            this.name_ = 0;
            return this;
        }

        public FunctionCall clearProperty() {
            assertMutable();
            this.property_ = null;
            return this;
        }

        public FunctionCall clearServerSide() {
            assertMutable();
            this.bitField0_ &= -9;
            this.serverSide_ = false;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public FunctionCall clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof FunctionCall)) {
                return super.equals(obj);
            }
            FunctionCall functionCall = (FunctionCall) obj;
            boolean z = (getPropertyList().equals(functionCall.getPropertyList())) && hasFunction() == functionCall.hasFunction();
            if (hasFunction()) {
                z = z && getFunction() == functionCall.getFunction();
            }
            boolean z2 = z && hasName() == functionCall.hasName();
            if (hasName()) {
                z2 = z2 && getName() == functionCall.getName();
            }
            boolean z3 = z2 && hasLiveOnly() == functionCall.hasLiveOnly();
            if (hasLiveOnly()) {
                z3 = z3 && getLiveOnly() == functionCall.getLiveOnly();
            }
            boolean z4 = z3 && hasServerSide() == functionCall.hasServerSide();
            return hasServerSide() ? z4 && getServerSide() == functionCall.getServerSide() : z4;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final FunctionCall getDefaultInstanceForType() {
            return defaultInstance;
        }

        public int getFunction() {
            return this.function_;
        }

        public boolean getLiveOnly() {
            return this.liveOnly_;
        }

        public List<Integer> getMutablePropertyList() {
            assertMutable();
            ensurePropertyInitialized();
            return this.property_;
        }

        public int getName() {
            return this.name_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<FunctionCall> getParserForType() {
            return PARSER;
        }

        public int getProperty(int i) {
            return this.property_.get(i).intValue();
        }

        public int getPropertyCount() {
            if (this.property_ == null) {
                return 0;
            }
            return this.property_.size();
        }

        public List<Integer> getPropertyList() {
            return this.property_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.property_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if (this.property_ != null && this.property_.size() > 0) {
                int i2 = 0;
                int i3 = 0;
                while (i3 < this.property_.size()) {
                    i3++;
                    i2 = CodedOutputStream.computeInt32SizeNoTag(this.property_.get(i3).intValue()) + i2;
                }
                i = i2 + 0 + (getPropertyList().size() * 1);
            }
            int computeInt32Size = i + CodedOutputStream.computeInt32Size(2, this.function_);
            if ((this.bitField0_ & 2) == 2) {
                computeInt32Size += CodedOutputStream.computeInt32Size(4, this.name_);
            }
            if ((this.bitField0_ & 4) == 4) {
                computeInt32Size += CodedOutputStream.computeBoolSize(6, this.liveOnly_);
            }
            if ((this.bitField0_ & 8) == 8) {
                computeInt32Size += CodedOutputStream.computeBoolSize(1, this.serverSide_);
            }
            int size = computeInt32Size + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public boolean getServerSide() {
            return this.serverSide_;
        }

        public boolean hasFunction() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasLiveOnly() {
            return (this.bitField0_ & 4) == 4;
        }

        public boolean hasName() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasServerSide() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            int i = 41;
            if (getPropertyCount() > 0) {
                i = 80560 + getPropertyList().hashCode();
            }
            if (hasFunction()) {
                i = (((i * 37) + 2) * 53) + getFunction();
            }
            if (hasName()) {
                i = (((i * 37) + 4) * 53) + getName();
            }
            if (hasLiveOnly()) {
                i = (((i * 37) + 6) * 53) + Internal.hashBoolean(getLiveOnly());
            }
            if (hasServerSide()) {
                i = (((i * 37) + 1) * 53) + Internal.hashBoolean(getServerSide());
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$FunctionCall");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return hasFunction();
        }

        public FunctionCall mergeFrom(FunctionCall functionCall) {
            if (this == functionCall) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (functionCall != getDefaultInstance()) {
                if (functionCall.hasServerSide()) {
                    setServerSide(functionCall.getServerSide());
                }
                if (functionCall.hasFunction()) {
                    setFunction(functionCall.getFunction());
                }
                if (functionCall.property_ != null && !functionCall.property_.isEmpty()) {
                    ensurePropertyInitialized();
                    this.property_.addAll(functionCall.property_);
                }
                if (functionCall.hasName()) {
                    setName(functionCall.getName());
                }
                if (functionCall.hasLiveOnly()) {
                    setLiveOnly(functionCall.getLiveOnly());
                }
                this.unknownFields = this.unknownFields.concat(functionCall.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            this.bitField0_ |= 8;
                            this.serverSide_ = codedInputStream.readBool();
                            break;
                        case 16:
                            this.bitField0_ |= 1;
                            this.function_ = codedInputStream.readInt32();
                            break;
                        case 24:
                            if (this.property_ == null) {
                                this.property_ = new ArrayList();
                            }
                            this.property_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 26:
                            int pushLimit = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.property_ == null) {
                                this.property_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.property_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit);
                            break;
                        case 32:
                            this.bitField0_ |= 2;
                            this.name_ = codedInputStream.readInt32();
                            break;
                        case 48:
                            this.bitField0_ |= 4;
                            this.liveOnly_ = codedInputStream.readBool();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public FunctionCall newMessageForType() {
            return new FunctionCall();
        }

        public FunctionCall setFunction(int i) {
            assertMutable();
            this.bitField0_ |= 1;
            this.function_ = i;
            return this;
        }

        public FunctionCall setLiveOnly(boolean z) {
            assertMutable();
            this.bitField0_ |= 4;
            this.liveOnly_ = z;
            return this;
        }

        public FunctionCall setName(int i) {
            assertMutable();
            this.bitField0_ |= 2;
            this.name_ = i;
            return this;
        }

        public FunctionCall setProperty(int i, int i2) {
            assertMutable();
            ensurePropertyInitialized();
            this.property_.set(i, Integer.valueOf(i2));
            return this;
        }

        public FunctionCall setServerSide(boolean z) {
            assertMutable();
            this.bitField0_ |= 8;
            this.serverSide_ = z;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeBool(1, this.serverSide_);
            }
            codedOutputStream.writeInt32(2, this.function_);
            if (this.property_ != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= this.property_.size()) {
                        break;
                    }
                    codedOutputStream.writeInt32(3, this.property_.get(i2).intValue());
                    i = i2 + 1;
                }
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(4, this.name_);
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeBool(6, this.liveOnly_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class OptionalResource extends GeneratedMutableMessageLite<OptionalResource> implements MutableMessageLite {
        public static Parser<OptionalResource> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int RESOURCE_FIELD_NUMBER = 2;
        private static final OptionalResource defaultInstance = new OptionalResource(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private Resource resource_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private OptionalResource() {
            initFields();
        }

        private OptionalResource(boolean z) {
        }

        private void ensureResourceInitialized() {
            if (this.resource_ == Resource.getDefaultInstance()) {
                this.resource_ = Resource.newMessage();
            }
        }

        public static OptionalResource getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.resource_ = Resource.getDefaultInstance();
        }

        public static OptionalResource newMessage() {
            return new OptionalResource();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public OptionalResource clear() {
            assertMutable();
            super.clear();
            if (this.resource_ != Resource.getDefaultInstance()) {
                this.resource_.clear();
            }
            this.bitField0_ &= -2;
            return this;
        }

        public OptionalResource clearResource() {
            assertMutable();
            this.bitField0_ &= -2;
            if (this.resource_ != Resource.getDefaultInstance()) {
                this.resource_.clear();
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public OptionalResource clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof OptionalResource)) {
                return super.equals(obj);
            }
            OptionalResource optionalResource = (OptionalResource) obj;
            boolean z = hasResource() == optionalResource.hasResource();
            return hasResource() ? z && getResource().equals(optionalResource.getResource()) : z;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final OptionalResource getDefaultInstanceForType() {
            return defaultInstance;
        }

        public Resource getMutableResource() {
            assertMutable();
            ensureResourceInitialized();
            this.bitField0_ |= 1;
            return this.resource_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<OptionalResource> getParserForType() {
            return PARSER;
        }

        public Resource getResource() {
            return this.resource_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i = 0;
            if ((this.bitField0_ & 1) == 1) {
                i = CodedOutputStream.computeMessageSize(2, this.resource_) + 0;
            }
            int size = i + this.unknownFields.size();
            this.cachedSize = size;
            return size;
        }

        public boolean hasResource() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (hasResource()) {
                i = 80507 + getResource().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$OptionalResource");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return !hasResource() || getResource().isInitialized();
        }

        public OptionalResource mergeFrom(OptionalResource optionalResource) {
            if (this == optionalResource) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (optionalResource != getDefaultInstance()) {
                if (optionalResource.hasResource()) {
                    ensureResourceInitialized();
                    this.resource_.mergeFrom(optionalResource.getResource());
                    this.bitField0_ |= 1;
                }
                this.unknownFields = this.unknownFields.concat(optionalResource.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 18:
                            if (this.resource_ == Resource.getDefaultInstance()) {
                                this.resource_ = Resource.newMessage();
                            }
                            this.bitField0_ |= 1;
                            codedInputStream.readMessage(this.resource_, extensionRegistryLite);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public OptionalResource newMessageForType() {
            return new OptionalResource();
        }

        public OptionalResource setResource(Resource resource) {
            assertMutable();
            if (resource == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.resource_ = resource;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeMessageWithCachedSizes(2, this.resource_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class Property extends GeneratedMutableMessageLite<Property> implements MutableMessageLite {
        public static final int KEY_FIELD_NUMBER = 1;
        public static Parser<Property> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int VALUE_FIELD_NUMBER = 2;
        private static final Property defaultInstance = new Property(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private int key_;
        private int value_;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private Property() {
            initFields();
        }

        private Property(boolean z) {
        }

        public static Property getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static Property newMessage() {
            return new Property();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Property clear() {
            assertMutable();
            super.clear();
            this.key_ = 0;
            this.bitField0_ &= -2;
            this.value_ = 0;
            this.bitField0_ &= -3;
            return this;
        }

        public Property clearKey() {
            assertMutable();
            this.bitField0_ &= -2;
            this.key_ = 0;
            return this;
        }

        public Property clearValue() {
            assertMutable();
            this.bitField0_ &= -3;
            this.value_ = 0;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public Property clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Property)) {
                return super.equals(obj);
            }
            Property property = (Property) obj;
            boolean z = hasKey() == property.hasKey();
            if (hasKey()) {
                z = z && getKey() == property.getKey();
            }
            boolean z2 = z && hasValue() == property.hasValue();
            return hasValue() ? z2 && getValue() == property.getValue() : z2;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final Property getDefaultInstanceForType() {
            return defaultInstance;
        }

        public int getKey() {
            return this.key_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<Property> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int computeInt32Size = CodedOutputStream.computeInt32Size(1, this.key_) + 0 + CodedOutputStream.computeInt32Size(2, this.value_) + this.unknownFields.size();
            this.cachedSize = computeInt32Size;
            return computeInt32Size;
        }

        public int getValue() {
            return this.value_;
        }

        public boolean hasKey() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasValue() {
            return (this.bitField0_ & 2) == 2;
        }

        public int hashCode() {
            int i = 41;
            if (hasKey()) {
                i = 80454 + getKey();
            }
            if (hasValue()) {
                i = (((i * 37) + 2) * 53) + getValue();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$Property");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return hasKey() && hasValue();
        }

        public Property mergeFrom(Property property) {
            if (this == property) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (property != getDefaultInstance()) {
                if (property.hasKey()) {
                    setKey(property.getKey());
                }
                if (property.hasValue()) {
                    setValue(property.getValue());
                }
                this.unknownFields = this.unknownFields.concat(property.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            this.bitField0_ |= 1;
                            this.key_ = codedInputStream.readInt32();
                            break;
                        case 16:
                            this.bitField0_ |= 2;
                            this.value_ = codedInputStream.readInt32();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public Property newMessageForType() {
            return new Property();
        }

        public Property setKey(int i) {
            assertMutable();
            this.bitField0_ |= 1;
            this.key_ = i;
            return this;
        }

        public Property setValue(int i) {
            assertMutable();
            this.bitField0_ |= 2;
            this.value_ = i;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            codedOutputStream.writeInt32(1, this.key_);
            codedOutputStream.writeInt32(2, this.value_);
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class Resource extends GeneratedMutableMessageLite<Resource> implements MutableMessageLite {
        public static final int ENABLE_AUTO_EVENT_TRACKING_FIELD_NUMBER = 18;
        public static final int KEY_FIELD_NUMBER = 1;
        public static final int LIVE_JS_CACHE_OPTION_FIELD_NUMBER = 14;
        public static final int MACRO_FIELD_NUMBER = 4;
        public static final int MALWARE_SCAN_AUTH_CODE_FIELD_NUMBER = 10;
        public static Parser<Resource> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int PREDICATE_FIELD_NUMBER = 6;
        public static final int PREVIEW_AUTH_CODE_FIELD_NUMBER = 9;
        public static final int PROPERTY_FIELD_NUMBER = 3;
        public static final int REPORTING_SAMPLE_RATE_FIELD_NUMBER = 15;
        public static final int RESOURCE_FORMAT_VERSION_FIELD_NUMBER = 17;
        public static final int RULE_FIELD_NUMBER = 7;
        public static final int TAG_FIELD_NUMBER = 5;
        public static final int TEMPLATE_VERSION_SET_FIELD_NUMBER = 12;
        public static final int USAGE_CONTEXT_FIELD_NUMBER = 16;
        public static final int VALUE_FIELD_NUMBER = 2;
        public static final int VERSION_FIELD_NUMBER = 13;
        private static final Resource defaultInstance = new Resource(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private boolean enableAutoEventTracking_;
        private LazyStringList key_ = null;
        private CacheOption liveJsCacheOption_;
        private List<FunctionCall> macro_ = null;
        private Object malwareScanAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
        private List<FunctionCall> predicate_ = null;
        private Object previewAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
        private List<Property> property_ = null;
        private float reportingSampleRate_;
        private int resourceFormatVersion_;
        private List<Rule> rule_ = null;
        private List<FunctionCall> tag_ = null;
        private Object templateVersionSet_ = Internal.byteArrayDefaultValue("0");
        private LazyStringList usageContext_ = null;
        private List<MutableTypeSystem.Value> value_ = null;
        private Object version_ = Internal.EMPTY_BYTE_ARRAY;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private Resource() {
            initFields();
        }

        private Resource(boolean z) {
        }

        private void ensureKeyInitialized() {
            if (this.key_ == null) {
                this.key_ = new LazyStringArrayList();
            }
        }

        private void ensureLiveJsCacheOptionInitialized() {
            if (this.liveJsCacheOption_ == CacheOption.getDefaultInstance()) {
                this.liveJsCacheOption_ = CacheOption.newMessage();
            }
        }

        private void ensureMacroInitialized() {
            if (this.macro_ == null) {
                this.macro_ = new ArrayList();
            }
        }

        private void ensurePredicateInitialized() {
            if (this.predicate_ == null) {
                this.predicate_ = new ArrayList();
            }
        }

        private void ensurePropertyInitialized() {
            if (this.property_ == null) {
                this.property_ = new ArrayList();
            }
        }

        private void ensureRuleInitialized() {
            if (this.rule_ == null) {
                this.rule_ = new ArrayList();
            }
        }

        private void ensureTagInitialized() {
            if (this.tag_ == null) {
                this.tag_ = new ArrayList();
            }
        }

        private void ensureUsageContextInitialized() {
            if (this.usageContext_ == null) {
                this.usageContext_ = new LazyStringArrayList();
            }
        }

        private void ensureValueInitialized() {
            if (this.value_ == null) {
                this.value_ = new ArrayList();
            }
        }

        public static Resource getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
            this.liveJsCacheOption_ = CacheOption.getDefaultInstance();
        }

        public static Resource newMessage() {
            return new Resource();
        }

        public Resource addAllKey(Iterable<String> iterable) {
            assertMutable();
            ensureKeyInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.key_);
            return this;
        }

        public Resource addAllMacro(Iterable<? extends FunctionCall> iterable) {
            assertMutable();
            ensureMacroInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.macro_);
            return this;
        }

        public Resource addAllPredicate(Iterable<? extends FunctionCall> iterable) {
            assertMutable();
            ensurePredicateInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.predicate_);
            return this;
        }

        public Resource addAllProperty(Iterable<? extends Property> iterable) {
            assertMutable();
            ensurePropertyInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.property_);
            return this;
        }

        public Resource addAllRule(Iterable<? extends Rule> iterable) {
            assertMutable();
            ensureRuleInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.rule_);
            return this;
        }

        public Resource addAllTag(Iterable<? extends FunctionCall> iterable) {
            assertMutable();
            ensureTagInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.tag_);
            return this;
        }

        public Resource addAllUsageContext(Iterable<String> iterable) {
            assertMutable();
            ensureUsageContextInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.usageContext_);
            return this;
        }

        public Resource addAllValue(Iterable<? extends MutableTypeSystem.Value> iterable) {
            assertMutable();
            ensureValueInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.value_);
            return this;
        }

        public Resource addKey(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            ensureKeyInitialized();
            this.key_.add(str);
            return this;
        }

        public Resource addKeyAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            ensureKeyInitialized();
            this.key_.add(bArr);
            return this;
        }

        public FunctionCall addMacro() {
            assertMutable();
            ensureMacroInitialized();
            FunctionCall newMessage = FunctionCall.newMessage();
            this.macro_.add(newMessage);
            return newMessage;
        }

        public Resource addMacro(FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensureMacroInitialized();
            this.macro_.add(functionCall);
            return this;
        }

        public FunctionCall addPredicate() {
            assertMutable();
            ensurePredicateInitialized();
            FunctionCall newMessage = FunctionCall.newMessage();
            this.predicate_.add(newMessage);
            return newMessage;
        }

        public Resource addPredicate(FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensurePredicateInitialized();
            this.predicate_.add(functionCall);
            return this;
        }

        public Property addProperty() {
            assertMutable();
            ensurePropertyInitialized();
            Property newMessage = Property.newMessage();
            this.property_.add(newMessage);
            return newMessage;
        }

        public Resource addProperty(Property property) {
            assertMutable();
            if (property == null) {
                throw new NullPointerException();
            }
            ensurePropertyInitialized();
            this.property_.add(property);
            return this;
        }

        public Resource addRule(Rule rule) {
            assertMutable();
            if (rule == null) {
                throw new NullPointerException();
            }
            ensureRuleInitialized();
            this.rule_.add(rule);
            return this;
        }

        public Rule addRule() {
            assertMutable();
            ensureRuleInitialized();
            Rule newMessage = Rule.newMessage();
            this.rule_.add(newMessage);
            return newMessage;
        }

        public FunctionCall addTag() {
            assertMutable();
            ensureTagInitialized();
            FunctionCall newMessage = FunctionCall.newMessage();
            this.tag_.add(newMessage);
            return newMessage;
        }

        public Resource addTag(FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensureTagInitialized();
            this.tag_.add(functionCall);
            return this;
        }

        public Resource addUsageContext(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            ensureUsageContextInitialized();
            this.usageContext_.add(str);
            return this;
        }

        public Resource addUsageContextAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            ensureUsageContextInitialized();
            this.usageContext_.add(bArr);
            return this;
        }

        public Resource addValue(MutableTypeSystem.Value value) {
            assertMutable();
            if (value == null) {
                throw new NullPointerException();
            }
            ensureValueInitialized();
            this.value_.add(value);
            return this;
        }

        public MutableTypeSystem.Value addValue() {
            assertMutable();
            ensureValueInitialized();
            MutableTypeSystem.Value newMessage = MutableTypeSystem.Value.newMessage();
            this.value_.add(newMessage);
            return newMessage;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Resource clear() {
            assertMutable();
            super.clear();
            this.key_ = null;
            this.value_ = null;
            this.property_ = null;
            this.macro_ = null;
            this.tag_ = null;
            this.predicate_ = null;
            this.rule_ = null;
            this.previewAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -2;
            this.malwareScanAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -3;
            this.templateVersionSet_ = getDefaultInstance().getTemplateVersionSetAsBytes();
            this.bitField0_ &= -5;
            this.version_ = Internal.EMPTY_BYTE_ARRAY;
            this.bitField0_ &= -9;
            if (this.liveJsCacheOption_ != CacheOption.getDefaultInstance()) {
                this.liveJsCacheOption_.clear();
            }
            this.bitField0_ &= -17;
            this.reportingSampleRate_ = 0.0f;
            this.bitField0_ &= -33;
            this.enableAutoEventTracking_ = false;
            this.bitField0_ &= -65;
            this.usageContext_ = null;
            this.resourceFormatVersion_ = 0;
            this.bitField0_ &= -129;
            return this;
        }

        public Resource clearEnableAutoEventTracking() {
            assertMutable();
            this.bitField0_ &= -65;
            this.enableAutoEventTracking_ = false;
            return this;
        }

        public Resource clearKey() {
            assertMutable();
            this.key_ = null;
            return this;
        }

        public Resource clearLiveJsCacheOption() {
            assertMutable();
            this.bitField0_ &= -17;
            if (this.liveJsCacheOption_ != CacheOption.getDefaultInstance()) {
                this.liveJsCacheOption_.clear();
            }
            return this;
        }

        public Resource clearMacro() {
            assertMutable();
            this.macro_ = null;
            return this;
        }

        public Resource clearMalwareScanAuthCode() {
            assertMutable();
            this.bitField0_ &= -3;
            this.malwareScanAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public Resource clearPredicate() {
            assertMutable();
            this.predicate_ = null;
            return this;
        }

        public Resource clearPreviewAuthCode() {
            assertMutable();
            this.bitField0_ &= -2;
            this.previewAuthCode_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        public Resource clearProperty() {
            assertMutable();
            this.property_ = null;
            return this;
        }

        public Resource clearReportingSampleRate() {
            assertMutable();
            this.bitField0_ &= -33;
            this.reportingSampleRate_ = 0.0f;
            return this;
        }

        public Resource clearResourceFormatVersion() {
            assertMutable();
            this.bitField0_ &= -129;
            this.resourceFormatVersion_ = 0;
            return this;
        }

        public Resource clearRule() {
            assertMutable();
            this.rule_ = null;
            return this;
        }

        public Resource clearTag() {
            assertMutable();
            this.tag_ = null;
            return this;
        }

        public Resource clearTemplateVersionSet() {
            assertMutable();
            this.bitField0_ &= -5;
            this.templateVersionSet_ = getDefaultInstance().getTemplateVersionSetAsBytes();
            return this;
        }

        public Resource clearUsageContext() {
            assertMutable();
            this.usageContext_ = null;
            return this;
        }

        public Resource clearValue() {
            assertMutable();
            this.value_ = null;
            return this;
        }

        public Resource clearVersion() {
            assertMutable();
            this.bitField0_ &= -9;
            this.version_ = Internal.EMPTY_BYTE_ARRAY;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public Resource clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Resource)) {
                return super.equals(obj);
            }
            Resource resource = (Resource) obj;
            boolean z = (((((((getKeyList().equals(resource.getKeyList())) && getValueList().equals(resource.getValueList())) && getPropertyList().equals(resource.getPropertyList())) && getMacroList().equals(resource.getMacroList())) && getTagList().equals(resource.getTagList())) && getPredicateList().equals(resource.getPredicateList())) && getRuleList().equals(resource.getRuleList())) && hasPreviewAuthCode() == resource.hasPreviewAuthCode();
            if (hasPreviewAuthCode()) {
                z = z && getPreviewAuthCode().equals(resource.getPreviewAuthCode());
            }
            boolean z2 = z && hasMalwareScanAuthCode() == resource.hasMalwareScanAuthCode();
            if (hasMalwareScanAuthCode()) {
                z2 = z2 && getMalwareScanAuthCode().equals(resource.getMalwareScanAuthCode());
            }
            boolean z3 = z2 && hasTemplateVersionSet() == resource.hasTemplateVersionSet();
            if (hasTemplateVersionSet()) {
                z3 = z3 && getTemplateVersionSet().equals(resource.getTemplateVersionSet());
            }
            boolean z4 = z3 && hasVersion() == resource.hasVersion();
            if (hasVersion()) {
                z4 = z4 && getVersion().equals(resource.getVersion());
            }
            boolean z5 = z4 && hasLiveJsCacheOption() == resource.hasLiveJsCacheOption();
            if (hasLiveJsCacheOption()) {
                z5 = z5 && getLiveJsCacheOption().equals(resource.getLiveJsCacheOption());
            }
            boolean z6 = z5 && hasReportingSampleRate() == resource.hasReportingSampleRate();
            if (hasReportingSampleRate()) {
                z6 = z6 && Float.floatToIntBits(getReportingSampleRate()) == Float.floatToIntBits(resource.getReportingSampleRate());
            }
            boolean z7 = z6 && hasEnableAutoEventTracking() == resource.hasEnableAutoEventTracking();
            if (hasEnableAutoEventTracking()) {
                z7 = z7 && getEnableAutoEventTracking() == resource.getEnableAutoEventTracking();
            }
            boolean z8 = (z7 && getUsageContextList().equals(resource.getUsageContextList())) && hasResourceFormatVersion() == resource.hasResourceFormatVersion();
            return hasResourceFormatVersion() ? z8 && getResourceFormatVersion() == resource.getResourceFormatVersion() : z8;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final Resource getDefaultInstanceForType() {
            return defaultInstance;
        }

        public boolean getEnableAutoEventTracking() {
            return this.enableAutoEventTracking_;
        }

        public String getKey(int i) {
            return (String) this.key_.get(i);
        }

        public byte[] getKeyAsBytes(int i) {
            return this.key_.getByteArray(i);
        }

        public int getKeyCount() {
            if (this.key_ == null) {
                return 0;
            }
            return this.key_.size();
        }

        public List<String> getKeyList() {
            return this.key_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.key_);
        }

        public List<byte[]> getKeyListAsBytes() {
            return this.key_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.key_.asByteArrayList());
        }

        public CacheOption getLiveJsCacheOption() {
            return this.liveJsCacheOption_;
        }

        public FunctionCall getMacro(int i) {
            return this.macro_.get(i);
        }

        public int getMacroCount() {
            if (this.macro_ == null) {
                return 0;
            }
            return this.macro_.size();
        }

        public List<FunctionCall> getMacroList() {
            return this.macro_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.macro_);
        }

        public String getMalwareScanAuthCode() {
            Object obj = this.malwareScanAuthCode_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.malwareScanAuthCode_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getMalwareScanAuthCodeAsBytes() {
            Object obj = this.malwareScanAuthCode_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.malwareScanAuthCode_ = byteArray;
            return byteArray;
        }

        public List<String> getMutableKeyList() {
            assertMutable();
            ensureKeyInitialized();
            return this.key_;
        }

        public List<byte[]> getMutableKeyListAsBytes() {
            assertMutable();
            ensureKeyInitialized();
            return this.key_.asByteArrayList();
        }

        public CacheOption getMutableLiveJsCacheOption() {
            assertMutable();
            ensureLiveJsCacheOptionInitialized();
            this.bitField0_ |= 16;
            return this.liveJsCacheOption_;
        }

        public FunctionCall getMutableMacro(int i) {
            return this.macro_.get(i);
        }

        public List<FunctionCall> getMutableMacroList() {
            assertMutable();
            ensureMacroInitialized();
            return this.macro_;
        }

        public FunctionCall getMutablePredicate(int i) {
            return this.predicate_.get(i);
        }

        public List<FunctionCall> getMutablePredicateList() {
            assertMutable();
            ensurePredicateInitialized();
            return this.predicate_;
        }

        public Property getMutableProperty(int i) {
            return this.property_.get(i);
        }

        public List<Property> getMutablePropertyList() {
            assertMutable();
            ensurePropertyInitialized();
            return this.property_;
        }

        public Rule getMutableRule(int i) {
            return this.rule_.get(i);
        }

        public List<Rule> getMutableRuleList() {
            assertMutable();
            ensureRuleInitialized();
            return this.rule_;
        }

        public FunctionCall getMutableTag(int i) {
            return this.tag_.get(i);
        }

        public List<FunctionCall> getMutableTagList() {
            assertMutable();
            ensureTagInitialized();
            return this.tag_;
        }

        public List<String> getMutableUsageContextList() {
            assertMutable();
            ensureUsageContextInitialized();
            return this.usageContext_;
        }

        public List<byte[]> getMutableUsageContextListAsBytes() {
            assertMutable();
            ensureUsageContextInitialized();
            return this.usageContext_.asByteArrayList();
        }

        public MutableTypeSystem.Value getMutableValue(int i) {
            return this.value_.get(i);
        }

        public List<MutableTypeSystem.Value> getMutableValueList() {
            assertMutable();
            ensureValueInitialized();
            return this.value_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<Resource> getParserForType() {
            return PARSER;
        }

        public FunctionCall getPredicate(int i) {
            return this.predicate_.get(i);
        }

        public int getPredicateCount() {
            if (this.predicate_ == null) {
                return 0;
            }
            return this.predicate_.size();
        }

        public List<FunctionCall> getPredicateList() {
            return this.predicate_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.predicate_);
        }

        public String getPreviewAuthCode() {
            Object obj = this.previewAuthCode_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.previewAuthCode_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getPreviewAuthCodeAsBytes() {
            Object obj = this.previewAuthCode_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.previewAuthCode_ = byteArray;
            return byteArray;
        }

        public Property getProperty(int i) {
            return this.property_.get(i);
        }

        public int getPropertyCount() {
            if (this.property_ == null) {
                return 0;
            }
            return this.property_.size();
        }

        public List<Property> getPropertyList() {
            return this.property_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.property_);
        }

        public float getReportingSampleRate() {
            return this.reportingSampleRate_;
        }

        public int getResourceFormatVersion() {
            return this.resourceFormatVersion_;
        }

        public Rule getRule(int i) {
            return this.rule_.get(i);
        }

        public int getRuleCount() {
            if (this.rule_ == null) {
                return 0;
            }
            return this.rule_.size();
        }

        public List<Rule> getRuleList() {
            return this.rule_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.rule_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            int i2;
            if (this.key_ == null || this.key_.size() <= 0) {
                i = 0;
            } else {
                int i3 = 0;
                for (int i4 = 0; i4 < this.key_.size(); i4++) {
                    i3 += CodedOutputStream.computeByteArraySizeNoTag(this.key_.getByteArray(i4));
                }
                i = i3 + 0 + (this.key_.size() * 1);
            }
            if (this.value_ != null) {
                i2 = i;
                for (int i5 = 0; i5 < this.value_.size(); i5++) {
                    i2 += CodedOutputStream.computeMessageSize(2, this.value_.get(i5));
                }
            } else {
                i2 = i;
            }
            if (this.property_ != null) {
                for (int i6 = 0; i6 < this.property_.size(); i6++) {
                    i2 += CodedOutputStream.computeMessageSize(3, this.property_.get(i6));
                }
            }
            if (this.macro_ != null) {
                for (int i7 = 0; i7 < this.macro_.size(); i7++) {
                    i2 += CodedOutputStream.computeMessageSize(4, this.macro_.get(i7));
                }
            }
            if (this.tag_ != null) {
                for (int i8 = 0; i8 < this.tag_.size(); i8++) {
                    i2 += CodedOutputStream.computeMessageSize(5, this.tag_.get(i8));
                }
            }
            if (this.predicate_ != null) {
                for (int i9 = 0; i9 < this.predicate_.size(); i9++) {
                    i2 += CodedOutputStream.computeMessageSize(6, this.predicate_.get(i9));
                }
            }
            if (this.rule_ != null) {
                for (int i10 = 0; i10 < this.rule_.size(); i10++) {
                    i2 += CodedOutputStream.computeMessageSize(7, this.rule_.get(i10));
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                i2 += CodedOutputStream.computeByteArraySize(9, getPreviewAuthCodeAsBytes());
            }
            if ((this.bitField0_ & 2) == 2) {
                i2 += CodedOutputStream.computeByteArraySize(10, getMalwareScanAuthCodeAsBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                i2 += CodedOutputStream.computeByteArraySize(12, getTemplateVersionSetAsBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                i2 += CodedOutputStream.computeByteArraySize(13, getVersionAsBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                i2 += CodedOutputStream.computeMessageSize(14, this.liveJsCacheOption_);
            }
            if ((this.bitField0_ & 32) == 32) {
                i2 += CodedOutputStream.computeFloatSize(15, this.reportingSampleRate_);
            }
            if ((this.bitField0_ & 64) == 64) {
                i2 += CodedOutputStream.computeBoolSize(18, this.enableAutoEventTracking_);
            }
            if (this.usageContext_ != null && this.usageContext_.size() > 0) {
                int i11 = 0;
                int i12 = 0;
                while (i12 < this.usageContext_.size()) {
                    i12++;
                    i11 = CodedOutputStream.computeByteArraySizeNoTag(this.usageContext_.getByteArray(i12)) + i11;
                }
                i2 = i11 + i2 + (this.usageContext_.size() * 2);
            }
            if ((this.bitField0_ & 128) == 128) {
                i2 += CodedOutputStream.computeInt32Size(17, this.resourceFormatVersion_);
            }
            int size = this.unknownFields.size() + i2;
            this.cachedSize = size;
            return size;
        }

        public FunctionCall getTag(int i) {
            return this.tag_.get(i);
        }

        public int getTagCount() {
            if (this.tag_ == null) {
                return 0;
            }
            return this.tag_.size();
        }

        public List<FunctionCall> getTagList() {
            return this.tag_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.tag_);
        }

        public String getTemplateVersionSet() {
            Object obj = this.templateVersionSet_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.templateVersionSet_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getTemplateVersionSetAsBytes() {
            Object obj = this.templateVersionSet_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.templateVersionSet_ = byteArray;
            return byteArray;
        }

        public String getUsageContext(int i) {
            return (String) this.usageContext_.get(i);
        }

        public byte[] getUsageContextAsBytes(int i) {
            return this.usageContext_.getByteArray(i);
        }

        public int getUsageContextCount() {
            if (this.usageContext_ == null) {
                return 0;
            }
            return this.usageContext_.size();
        }

        public List<String> getUsageContextList() {
            return this.usageContext_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.usageContext_);
        }

        public List<byte[]> getUsageContextListAsBytes() {
            return this.usageContext_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.usageContext_.asByteArrayList());
        }

        public MutableTypeSystem.Value getValue(int i) {
            return this.value_.get(i);
        }

        public int getValueCount() {
            if (this.value_ == null) {
                return 0;
            }
            return this.value_.size();
        }

        public List<MutableTypeSystem.Value> getValueList() {
            return this.value_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.value_);
        }

        public String getVersion() {
            Object obj = this.version_;
            if (obj instanceof String) {
                return (String) obj;
            }
            byte[] bArr = (byte[]) obj;
            String stringUtf8 = Internal.toStringUtf8(bArr);
            if (Internal.isValidUtf8(bArr)) {
                this.version_ = stringUtf8;
            }
            return stringUtf8;
        }

        public byte[] getVersionAsBytes() {
            Object obj = this.version_;
            if (!(obj instanceof String)) {
                return (byte[]) obj;
            }
            byte[] byteArray = Internal.toByteArray((String) obj);
            this.version_ = byteArray;
            return byteArray;
        }

        public boolean hasEnableAutoEventTracking() {
            return (this.bitField0_ & 64) == 64;
        }

        public boolean hasLiveJsCacheOption() {
            return (this.bitField0_ & 16) == 16;
        }

        public boolean hasMalwareScanAuthCode() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasPreviewAuthCode() {
            return (this.bitField0_ & 1) == 1;
        }

        public boolean hasReportingSampleRate() {
            return (this.bitField0_ & 32) == 32;
        }

        public boolean hasResourceFormatVersion() {
            return (this.bitField0_ & 128) == 128;
        }

        public boolean hasTemplateVersionSet() {
            return (this.bitField0_ & 4) == 4;
        }

        public boolean hasVersion() {
            return (this.bitField0_ & 8) == 8;
        }

        public int hashCode() {
            int i = 41;
            if (getKeyCount() > 0) {
                i = 80454 + getKeyList().hashCode();
            }
            if (getValueCount() > 0) {
                i = (((i * 37) + 2) * 53) + getValueList().hashCode();
            }
            if (getPropertyCount() > 0) {
                i = (((i * 37) + 3) * 53) + getPropertyList().hashCode();
            }
            if (getMacroCount() > 0) {
                i = (((i * 37) + 4) * 53) + getMacroList().hashCode();
            }
            if (getTagCount() > 0) {
                i = (((i * 37) + 5) * 53) + getTagList().hashCode();
            }
            if (getPredicateCount() > 0) {
                i = (((i * 37) + 6) * 53) + getPredicateList().hashCode();
            }
            if (getRuleCount() > 0) {
                i = (((i * 37) + 7) * 53) + getRuleList().hashCode();
            }
            if (hasPreviewAuthCode()) {
                i = (((i * 37) + 9) * 53) + getPreviewAuthCode().hashCode();
            }
            if (hasMalwareScanAuthCode()) {
                i = (((i * 37) + 10) * 53) + getMalwareScanAuthCode().hashCode();
            }
            if (hasTemplateVersionSet()) {
                i = (((i * 37) + 12) * 53) + getTemplateVersionSet().hashCode();
            }
            if (hasVersion()) {
                i = (((i * 37) + 13) * 53) + getVersion().hashCode();
            }
            if (hasLiveJsCacheOption()) {
                i = (((i * 37) + 14) * 53) + getLiveJsCacheOption().hashCode();
            }
            if (hasReportingSampleRate()) {
                i = (((i * 37) + 15) * 53) + Float.floatToIntBits(getReportingSampleRate());
            }
            if (hasEnableAutoEventTracking()) {
                i = (((i * 37) + 18) * 53) + Internal.hashBoolean(getEnableAutoEventTracking());
            }
            if (getUsageContextCount() > 0) {
                i = (((i * 37) + 16) * 53) + getUsageContextList().hashCode();
            }
            if (hasResourceFormatVersion()) {
                i = (((i * 37) + 17) * 53) + getResourceFormatVersion();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$Resource");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            for (int i = 0; i < getValueCount(); i++) {
                if (!getValue(i).isInitialized()) {
                    return false;
                }
            }
            for (int i2 = 0; i2 < getPropertyCount(); i2++) {
                if (!getProperty(i2).isInitialized()) {
                    return false;
                }
            }
            for (int i3 = 0; i3 < getMacroCount(); i3++) {
                if (!getMacro(i3).isInitialized()) {
                    return false;
                }
            }
            for (int i4 = 0; i4 < getTagCount(); i4++) {
                if (!getTag(i4).isInitialized()) {
                    return false;
                }
            }
            for (int i5 = 0; i5 < getPredicateCount(); i5++) {
                if (!getPredicate(i5).isInitialized()) {
                    return false;
                }
            }
            return true;
        }

        public Resource mergeFrom(Resource resource) {
            if (this == resource) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (resource != getDefaultInstance()) {
                if (resource.key_ != null && !resource.key_.isEmpty()) {
                    ensureKeyInitialized();
                    this.key_.mergeFrom(resource.key_);
                }
                if (resource.value_ != null && !resource.value_.isEmpty()) {
                    ensureValueInitialized();
                    AbstractMutableMessageLite.addAll(resource.value_, this.value_);
                }
                if (resource.property_ != null && !resource.property_.isEmpty()) {
                    ensurePropertyInitialized();
                    AbstractMutableMessageLite.addAll(resource.property_, this.property_);
                }
                if (resource.macro_ != null && !resource.macro_.isEmpty()) {
                    ensureMacroInitialized();
                    AbstractMutableMessageLite.addAll(resource.macro_, this.macro_);
                }
                if (resource.tag_ != null && !resource.tag_.isEmpty()) {
                    ensureTagInitialized();
                    AbstractMutableMessageLite.addAll(resource.tag_, this.tag_);
                }
                if (resource.predicate_ != null && !resource.predicate_.isEmpty()) {
                    ensurePredicateInitialized();
                    AbstractMutableMessageLite.addAll(resource.predicate_, this.predicate_);
                }
                if (resource.rule_ != null && !resource.rule_.isEmpty()) {
                    ensureRuleInitialized();
                    AbstractMutableMessageLite.addAll(resource.rule_, this.rule_);
                }
                if (resource.hasPreviewAuthCode()) {
                    this.bitField0_ |= 1;
                    if (resource.previewAuthCode_ instanceof String) {
                        this.previewAuthCode_ = resource.previewAuthCode_;
                    } else {
                        byte[] bArr = (byte[]) resource.previewAuthCode_;
                        this.previewAuthCode_ = Arrays.copyOf(bArr, bArr.length);
                    }
                }
                if (resource.hasMalwareScanAuthCode()) {
                    this.bitField0_ |= 2;
                    if (resource.malwareScanAuthCode_ instanceof String) {
                        this.malwareScanAuthCode_ = resource.malwareScanAuthCode_;
                    } else {
                        byte[] bArr2 = (byte[]) resource.malwareScanAuthCode_;
                        this.malwareScanAuthCode_ = Arrays.copyOf(bArr2, bArr2.length);
                    }
                }
                if (resource.hasTemplateVersionSet()) {
                    this.bitField0_ |= 4;
                    if (resource.templateVersionSet_ instanceof String) {
                        this.templateVersionSet_ = resource.templateVersionSet_;
                    } else {
                        byte[] bArr3 = (byte[]) resource.templateVersionSet_;
                        this.templateVersionSet_ = Arrays.copyOf(bArr3, bArr3.length);
                    }
                }
                if (resource.hasVersion()) {
                    this.bitField0_ |= 8;
                    if (resource.version_ instanceof String) {
                        this.version_ = resource.version_;
                    } else {
                        byte[] bArr4 = (byte[]) resource.version_;
                        this.version_ = Arrays.copyOf(bArr4, bArr4.length);
                    }
                }
                if (resource.hasLiveJsCacheOption()) {
                    ensureLiveJsCacheOptionInitialized();
                    this.liveJsCacheOption_.mergeFrom(resource.getLiveJsCacheOption());
                    this.bitField0_ |= 16;
                }
                if (resource.hasReportingSampleRate()) {
                    setReportingSampleRate(resource.getReportingSampleRate());
                }
                if (resource.usageContext_ != null && !resource.usageContext_.isEmpty()) {
                    ensureUsageContextInitialized();
                    this.usageContext_.mergeFrom(resource.usageContext_);
                }
                if (resource.hasResourceFormatVersion()) {
                    setResourceFormatVersion(resource.getResourceFormatVersion());
                }
                if (resource.hasEnableAutoEventTracking()) {
                    setEnableAutoEventTracking(resource.getEnableAutoEventTracking());
                }
                this.unknownFields = this.unknownFields.concat(resource.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 10:
                            ensureKeyInitialized();
                            this.key_.add(codedInputStream.readByteArray());
                            break;
                        case 18:
                            codedInputStream.readMessage(addValue(), extensionRegistryLite);
                            break;
                        case 26:
                            codedInputStream.readMessage(addProperty(), extensionRegistryLite);
                            break;
                        case 34:
                            codedInputStream.readMessage(addMacro(), extensionRegistryLite);
                            break;
                        case 42:
                            codedInputStream.readMessage(addTag(), extensionRegistryLite);
                            break;
                        case AdSize.PORTRAIT_AD_HEIGHT:
                            codedInputStream.readMessage(addPredicate(), extensionRegistryLite);
                            break;
                        case 58:
                            codedInputStream.readMessage(addRule(), extensionRegistryLite);
                            break;
                        case 74:
                            this.bitField0_ |= 1;
                            this.previewAuthCode_ = codedInputStream.readByteArray();
                            break;
                        case 82:
                            this.bitField0_ |= 2;
                            this.malwareScanAuthCode_ = codedInputStream.readByteArray();
                            break;
                        case 98:
                            this.bitField0_ |= 4;
                            this.templateVersionSet_ = codedInputStream.readByteArray();
                            break;
                        case 106:
                            this.bitField0_ |= 8;
                            this.version_ = codedInputStream.readByteArray();
                            break;
                        case 114:
                            if (this.liveJsCacheOption_ == CacheOption.getDefaultInstance()) {
                                this.liveJsCacheOption_ = CacheOption.newMessage();
                            }
                            this.bitField0_ |= 16;
                            codedInputStream.readMessage(this.liveJsCacheOption_, extensionRegistryLite);
                            break;
                        case 125:
                            this.bitField0_ |= 32;
                            this.reportingSampleRate_ = codedInputStream.readFloat();
                            break;
                        case 130:
                            ensureUsageContextInitialized();
                            this.usageContext_.add(codedInputStream.readByteArray());
                            break;
                        case 136:
                            this.bitField0_ |= 128;
                            this.resourceFormatVersion_ = codedInputStream.readInt32();
                            break;
                        case 144:
                            this.bitField0_ |= 64;
                            this.enableAutoEventTracking_ = codedInputStream.readBool();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public Resource newMessageForType() {
            return new Resource();
        }

        public Resource setEnableAutoEventTracking(boolean z) {
            assertMutable();
            this.bitField0_ |= 64;
            this.enableAutoEventTracking_ = z;
            return this;
        }

        public Resource setKey(int i, String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            ensureKeyInitialized();
            this.key_.set(i, str);
            return this;
        }

        public Resource setKeyAsBytes(int i, byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            ensureKeyInitialized();
            this.key_.set(i, bArr);
            return this;
        }

        public Resource setLiveJsCacheOption(CacheOption cacheOption) {
            assertMutable();
            if (cacheOption == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 16;
            this.liveJsCacheOption_ = cacheOption;
            return this;
        }

        public Resource setMacro(int i, FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensureMacroInitialized();
            this.macro_.set(i, functionCall);
            return this;
        }

        public Resource setMalwareScanAuthCode(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.malwareScanAuthCode_ = str;
            return this;
        }

        public Resource setMalwareScanAuthCodeAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 2;
            this.malwareScanAuthCode_ = bArr;
            return this;
        }

        public Resource setPredicate(int i, FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensurePredicateInitialized();
            this.predicate_.set(i, functionCall);
            return this;
        }

        public Resource setPreviewAuthCode(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.previewAuthCode_ = str;
            return this;
        }

        public Resource setPreviewAuthCodeAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 1;
            this.previewAuthCode_ = bArr;
            return this;
        }

        public Resource setProperty(int i, Property property) {
            assertMutable();
            if (property == null) {
                throw new NullPointerException();
            }
            ensurePropertyInitialized();
            this.property_.set(i, property);
            return this;
        }

        public Resource setReportingSampleRate(float f) {
            assertMutable();
            this.bitField0_ |= 32;
            this.reportingSampleRate_ = f;
            return this;
        }

        public Resource setResourceFormatVersion(int i) {
            assertMutable();
            this.bitField0_ |= 128;
            this.resourceFormatVersion_ = i;
            return this;
        }

        public Resource setRule(int i, Rule rule) {
            assertMutable();
            if (rule == null) {
                throw new NullPointerException();
            }
            ensureRuleInitialized();
            this.rule_.set(i, rule);
            return this;
        }

        public Resource setTag(int i, FunctionCall functionCall) {
            assertMutable();
            if (functionCall == null) {
                throw new NullPointerException();
            }
            ensureTagInitialized();
            this.tag_.set(i, functionCall);
            return this;
        }

        public Resource setTemplateVersionSet(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 4;
            this.templateVersionSet_ = str;
            return this;
        }

        public Resource setTemplateVersionSetAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 4;
            this.templateVersionSet_ = bArr;
            return this;
        }

        public Resource setUsageContext(int i, String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            ensureUsageContextInitialized();
            this.usageContext_.set(i, str);
            return this;
        }

        public Resource setUsageContextAsBytes(int i, byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            ensureUsageContextInitialized();
            this.usageContext_.set(i, bArr);
            return this;
        }

        public Resource setValue(int i, MutableTypeSystem.Value value) {
            assertMutable();
            if (value == null) {
                throw new NullPointerException();
            }
            ensureValueInitialized();
            this.value_.set(i, value);
            return this;
        }

        public Resource setVersion(String str) {
            assertMutable();
            if (str == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.version_ = str;
            return this;
        }

        public Resource setVersionAsBytes(byte[] bArr) {
            assertMutable();
            if (bArr == null) {
                throw new NullPointerException();
            }
            this.bitField0_ |= 8;
            this.version_ = bArr;
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.key_ != null) {
                for (int i = 0; i < this.key_.size(); i++) {
                    codedOutputStream.writeByteArray(1, this.key_.getByteArray(i));
                }
            }
            if (this.value_ != null) {
                for (int i2 = 0; i2 < this.value_.size(); i2++) {
                    codedOutputStream.writeMessageWithCachedSizes(2, this.value_.get(i2));
                }
            }
            if (this.property_ != null) {
                for (int i3 = 0; i3 < this.property_.size(); i3++) {
                    codedOutputStream.writeMessageWithCachedSizes(3, this.property_.get(i3));
                }
            }
            if (this.macro_ != null) {
                for (int i4 = 0; i4 < this.macro_.size(); i4++) {
                    codedOutputStream.writeMessageWithCachedSizes(4, this.macro_.get(i4));
                }
            }
            if (this.tag_ != null) {
                for (int i5 = 0; i5 < this.tag_.size(); i5++) {
                    codedOutputStream.writeMessageWithCachedSizes(5, this.tag_.get(i5));
                }
            }
            if (this.predicate_ != null) {
                for (int i6 = 0; i6 < this.predicate_.size(); i6++) {
                    codedOutputStream.writeMessageWithCachedSizes(6, this.predicate_.get(i6));
                }
            }
            if (this.rule_ != null) {
                for (int i7 = 0; i7 < this.rule_.size(); i7++) {
                    codedOutputStream.writeMessageWithCachedSizes(7, this.rule_.get(i7));
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeByteArray(9, getPreviewAuthCodeAsBytes());
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeByteArray(10, getMalwareScanAuthCodeAsBytes());
            }
            if ((this.bitField0_ & 4) == 4) {
                codedOutputStream.writeByteArray(12, getTemplateVersionSetAsBytes());
            }
            if ((this.bitField0_ & 8) == 8) {
                codedOutputStream.writeByteArray(13, getVersionAsBytes());
            }
            if ((this.bitField0_ & 16) == 16) {
                codedOutputStream.writeMessageWithCachedSizes(14, this.liveJsCacheOption_);
            }
            if ((this.bitField0_ & 32) == 32) {
                codedOutputStream.writeFloat(15, this.reportingSampleRate_);
            }
            if (this.usageContext_ != null) {
                for (int i8 = 0; i8 < this.usageContext_.size(); i8++) {
                    codedOutputStream.writeByteArray(16, this.usageContext_.getByteArray(i8));
                }
            }
            if ((this.bitField0_ & 128) == 128) {
                codedOutputStream.writeInt32(17, this.resourceFormatVersion_);
            }
            if ((this.bitField0_ & 64) == 64) {
                codedOutputStream.writeBool(18, this.enableAutoEventTracking_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public enum ResourceState implements Internal.EnumLite {
        PREVIEW(0, 1),
        LIVE(1, 2);
        
        public static final int LIVE_VALUE = 2;
        public static final int PREVIEW_VALUE = 1;
        private static Internal.EnumLiteMap<ResourceState> internalValueMap = new Internal.EnumLiteMap<ResourceState>() {
            /* class com.google.analytics.containertag.proto.MutableServing.ResourceState.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
            public ResourceState findValueByNumber(int i) {
                return ResourceState.valueOf(i);
            }
        };
        private final int value;

        private ResourceState(int i, int i2) {
            this.value = i2;
        }

        public static Internal.EnumLiteMap<ResourceState> internalGetValueMap() {
            return internalValueMap;
        }

        public static ResourceState valueOf(int i) {
            switch (i) {
                case 1:
                    return PREVIEW;
                case 2:
                    return LIVE;
                default:
                    return null;
            }
        }

        @Override // com.google.tagmanager.protobuf.Internal.EnumLite
        public final int getNumber() {
            return this.value;
        }
    }

    public enum ResourceType implements Internal.EnumLite {
        JS_RESOURCE(0, 1),
        NS_RESOURCE(1, 2),
        PIXEL_COLLECTION(2, 3),
        SET_COOKIE(3, 4),
        GET_COOKIE(4, 5),
        CLEAR_CACHE(5, 6),
        RAW_PROTO(6, 7);
        
        public static final int CLEAR_CACHE_VALUE = 6;
        public static final int GET_COOKIE_VALUE = 5;
        public static final int JS_RESOURCE_VALUE = 1;
        public static final int NS_RESOURCE_VALUE = 2;
        public static final int PIXEL_COLLECTION_VALUE = 3;
        public static final int RAW_PROTO_VALUE = 7;
        public static final int SET_COOKIE_VALUE = 4;
        private static Internal.EnumLiteMap<ResourceType> internalValueMap = new Internal.EnumLiteMap<ResourceType>() {
            /* class com.google.analytics.containertag.proto.MutableServing.ResourceType.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Internal.EnumLiteMap
            public ResourceType findValueByNumber(int i) {
                return ResourceType.valueOf(i);
            }
        };
        private final int value;

        private ResourceType(int i, int i2) {
            this.value = i2;
        }

        public static Internal.EnumLiteMap<ResourceType> internalGetValueMap() {
            return internalValueMap;
        }

        public static ResourceType valueOf(int i) {
            switch (i) {
                case 1:
                    return JS_RESOURCE;
                case 2:
                    return NS_RESOURCE;
                case 3:
                    return PIXEL_COLLECTION;
                case 4:
                    return SET_COOKIE;
                case 5:
                    return GET_COOKIE;
                case 6:
                    return CLEAR_CACHE;
                case 7:
                    return RAW_PROTO;
                default:
                    return null;
            }
        }

        @Override // com.google.tagmanager.protobuf.Internal.EnumLite
        public final int getNumber() {
            return this.value;
        }
    }

    public static final class Rule extends GeneratedMutableMessageLite<Rule> implements MutableMessageLite {
        public static final int ADD_MACRO_FIELD_NUMBER = 7;
        public static final int ADD_MACRO_RULE_NAME_FIELD_NUMBER = 9;
        public static final int ADD_TAG_FIELD_NUMBER = 3;
        public static final int ADD_TAG_RULE_NAME_FIELD_NUMBER = 5;
        public static final int NEGATIVE_PREDICATE_FIELD_NUMBER = 2;
        public static Parser<Rule> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int POSITIVE_PREDICATE_FIELD_NUMBER = 1;
        public static final int REMOVE_MACRO_FIELD_NUMBER = 8;
        public static final int REMOVE_MACRO_RULE_NAME_FIELD_NUMBER = 10;
        public static final int REMOVE_TAG_FIELD_NUMBER = 4;
        public static final int REMOVE_TAG_RULE_NAME_FIELD_NUMBER = 6;
        private static final Rule defaultInstance = new Rule(true);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private List<Integer> addMacroRuleName_ = null;
        private List<Integer> addMacro_ = null;
        private List<Integer> addTagRuleName_ = null;
        private List<Integer> addTag_ = null;
        private List<Integer> negativePredicate_ = null;
        private List<Integer> positivePredicate_ = null;
        private List<Integer> removeMacroRuleName_ = null;
        private List<Integer> removeMacro_ = null;
        private List<Integer> removeTagRuleName_ = null;
        private List<Integer> removeTag_ = null;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private Rule() {
            initFields();
        }

        private Rule(boolean z) {
        }

        private void ensureAddMacroInitialized() {
            if (this.addMacro_ == null) {
                this.addMacro_ = new ArrayList();
            }
        }

        private void ensureAddMacroRuleNameInitialized() {
            if (this.addMacroRuleName_ == null) {
                this.addMacroRuleName_ = new ArrayList();
            }
        }

        private void ensureAddTagInitialized() {
            if (this.addTag_ == null) {
                this.addTag_ = new ArrayList();
            }
        }

        private void ensureAddTagRuleNameInitialized() {
            if (this.addTagRuleName_ == null) {
                this.addTagRuleName_ = new ArrayList();
            }
        }

        private void ensureNegativePredicateInitialized() {
            if (this.negativePredicate_ == null) {
                this.negativePredicate_ = new ArrayList();
            }
        }

        private void ensurePositivePredicateInitialized() {
            if (this.positivePredicate_ == null) {
                this.positivePredicate_ = new ArrayList();
            }
        }

        private void ensureRemoveMacroInitialized() {
            if (this.removeMacro_ == null) {
                this.removeMacro_ = new ArrayList();
            }
        }

        private void ensureRemoveMacroRuleNameInitialized() {
            if (this.removeMacroRuleName_ == null) {
                this.removeMacroRuleName_ = new ArrayList();
            }
        }

        private void ensureRemoveTagInitialized() {
            if (this.removeTag_ == null) {
                this.removeTag_ = new ArrayList();
            }
        }

        private void ensureRemoveTagRuleNameInitialized() {
            if (this.removeTagRuleName_ == null) {
                this.removeTagRuleName_ = new ArrayList();
            }
        }

        public static Rule getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static Rule newMessage() {
            return new Rule();
        }

        public Rule addAddMacro(int i) {
            assertMutable();
            ensureAddMacroInitialized();
            this.addMacro_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addAddMacroRuleName(int i) {
            assertMutable();
            ensureAddMacroRuleNameInitialized();
            this.addMacroRuleName_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addAddTag(int i) {
            assertMutable();
            ensureAddTagInitialized();
            this.addTag_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addAddTagRuleName(int i) {
            assertMutable();
            ensureAddTagRuleNameInitialized();
            this.addTagRuleName_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addAllAddMacro(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureAddMacroInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addMacro_);
            return this;
        }

        public Rule addAllAddMacroRuleName(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureAddMacroRuleNameInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addMacroRuleName_);
            return this;
        }

        public Rule addAllAddTag(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureAddTagInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addTag_);
            return this;
        }

        public Rule addAllAddTagRuleName(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureAddTagRuleNameInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.addTagRuleName_);
            return this;
        }

        public Rule addAllNegativePredicate(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureNegativePredicateInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.negativePredicate_);
            return this;
        }

        public Rule addAllPositivePredicate(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensurePositivePredicateInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.positivePredicate_);
            return this;
        }

        public Rule addAllRemoveMacro(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureRemoveMacroInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeMacro_);
            return this;
        }

        public Rule addAllRemoveMacroRuleName(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureRemoveMacroRuleNameInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeMacroRuleName_);
            return this;
        }

        public Rule addAllRemoveTag(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureRemoveTagInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeTag_);
            return this;
        }

        public Rule addAllRemoveTagRuleName(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureRemoveTagRuleNameInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.removeTagRuleName_);
            return this;
        }

        public Rule addNegativePredicate(int i) {
            assertMutable();
            ensureNegativePredicateInitialized();
            this.negativePredicate_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addPositivePredicate(int i) {
            assertMutable();
            ensurePositivePredicateInitialized();
            this.positivePredicate_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addRemoveMacro(int i) {
            assertMutable();
            ensureRemoveMacroInitialized();
            this.removeMacro_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addRemoveMacroRuleName(int i) {
            assertMutable();
            ensureRemoveMacroRuleNameInitialized();
            this.removeMacroRuleName_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addRemoveTag(int i) {
            assertMutable();
            ensureRemoveTagInitialized();
            this.removeTag_.add(Integer.valueOf(i));
            return this;
        }

        public Rule addRemoveTagRuleName(int i) {
            assertMutable();
            ensureRemoveTagRuleNameInitialized();
            this.removeTagRuleName_.add(Integer.valueOf(i));
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Rule clear() {
            assertMutable();
            super.clear();
            this.positivePredicate_ = null;
            this.negativePredicate_ = null;
            this.addTag_ = null;
            this.removeTag_ = null;
            this.addTagRuleName_ = null;
            this.removeTagRuleName_ = null;
            this.addMacro_ = null;
            this.removeMacro_ = null;
            this.addMacroRuleName_ = null;
            this.removeMacroRuleName_ = null;
            return this;
        }

        public Rule clearAddMacro() {
            assertMutable();
            this.addMacro_ = null;
            return this;
        }

        public Rule clearAddMacroRuleName() {
            assertMutable();
            this.addMacroRuleName_ = null;
            return this;
        }

        public Rule clearAddTag() {
            assertMutable();
            this.addTag_ = null;
            return this;
        }

        public Rule clearAddTagRuleName() {
            assertMutable();
            this.addTagRuleName_ = null;
            return this;
        }

        public Rule clearNegativePredicate() {
            assertMutable();
            this.negativePredicate_ = null;
            return this;
        }

        public Rule clearPositivePredicate() {
            assertMutable();
            this.positivePredicate_ = null;
            return this;
        }

        public Rule clearRemoveMacro() {
            assertMutable();
            this.removeMacro_ = null;
            return this;
        }

        public Rule clearRemoveMacroRuleName() {
            assertMutable();
            this.removeMacroRuleName_ = null;
            return this;
        }

        public Rule clearRemoveTag() {
            assertMutable();
            this.removeTag_ = null;
            return this;
        }

        public Rule clearRemoveTagRuleName() {
            assertMutable();
            this.removeTagRuleName_ = null;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public Rule clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Rule)) {
                return super.equals(obj);
            }
            Rule rule = (Rule) obj;
            return (((((((((getPositivePredicateList().equals(rule.getPositivePredicateList())) && getNegativePredicateList().equals(rule.getNegativePredicateList())) && getAddTagList().equals(rule.getAddTagList())) && getRemoveTagList().equals(rule.getRemoveTagList())) && getAddTagRuleNameList().equals(rule.getAddTagRuleNameList())) && getRemoveTagRuleNameList().equals(rule.getRemoveTagRuleNameList())) && getAddMacroList().equals(rule.getAddMacroList())) && getRemoveMacroList().equals(rule.getRemoveMacroList())) && getAddMacroRuleNameList().equals(rule.getAddMacroRuleNameList())) && getRemoveMacroRuleNameList().equals(rule.getRemoveMacroRuleNameList());
        }

        public int getAddMacro(int i) {
            return this.addMacro_.get(i).intValue();
        }

        public int getAddMacroCount() {
            if (this.addMacro_ == null) {
                return 0;
            }
            return this.addMacro_.size();
        }

        public List<Integer> getAddMacroList() {
            return this.addMacro_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addMacro_);
        }

        public int getAddMacroRuleName(int i) {
            return this.addMacroRuleName_.get(i).intValue();
        }

        public int getAddMacroRuleNameCount() {
            if (this.addMacroRuleName_ == null) {
                return 0;
            }
            return this.addMacroRuleName_.size();
        }

        public List<Integer> getAddMacroRuleNameList() {
            return this.addMacroRuleName_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addMacroRuleName_);
        }

        public int getAddTag(int i) {
            return this.addTag_.get(i).intValue();
        }

        public int getAddTagCount() {
            if (this.addTag_ == null) {
                return 0;
            }
            return this.addTag_.size();
        }

        public List<Integer> getAddTagList() {
            return this.addTag_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addTag_);
        }

        public int getAddTagRuleName(int i) {
            return this.addTagRuleName_.get(i).intValue();
        }

        public int getAddTagRuleNameCount() {
            if (this.addTagRuleName_ == null) {
                return 0;
            }
            return this.addTagRuleName_.size();
        }

        public List<Integer> getAddTagRuleNameList() {
            return this.addTagRuleName_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.addTagRuleName_);
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final Rule getDefaultInstanceForType() {
            return defaultInstance;
        }

        public List<Integer> getMutableAddMacroList() {
            assertMutable();
            ensureAddMacroInitialized();
            return this.addMacro_;
        }

        public List<Integer> getMutableAddMacroRuleNameList() {
            assertMutable();
            ensureAddMacroRuleNameInitialized();
            return this.addMacroRuleName_;
        }

        public List<Integer> getMutableAddTagList() {
            assertMutable();
            ensureAddTagInitialized();
            return this.addTag_;
        }

        public List<Integer> getMutableAddTagRuleNameList() {
            assertMutable();
            ensureAddTagRuleNameInitialized();
            return this.addTagRuleName_;
        }

        public List<Integer> getMutableNegativePredicateList() {
            assertMutable();
            ensureNegativePredicateInitialized();
            return this.negativePredicate_;
        }

        public List<Integer> getMutablePositivePredicateList() {
            assertMutable();
            ensurePositivePredicateInitialized();
            return this.positivePredicate_;
        }

        public List<Integer> getMutableRemoveMacroList() {
            assertMutable();
            ensureRemoveMacroInitialized();
            return this.removeMacro_;
        }

        public List<Integer> getMutableRemoveMacroRuleNameList() {
            assertMutable();
            ensureRemoveMacroRuleNameInitialized();
            return this.removeMacroRuleName_;
        }

        public List<Integer> getMutableRemoveTagList() {
            assertMutable();
            ensureRemoveTagInitialized();
            return this.removeTag_;
        }

        public List<Integer> getMutableRemoveTagRuleNameList() {
            assertMutable();
            ensureRemoveTagRuleNameInitialized();
            return this.removeTagRuleName_;
        }

        public int getNegativePredicate(int i) {
            return this.negativePredicate_.get(i).intValue();
        }

        public int getNegativePredicateCount() {
            if (this.negativePredicate_ == null) {
                return 0;
            }
            return this.negativePredicate_.size();
        }

        public List<Integer> getNegativePredicateList() {
            return this.negativePredicate_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.negativePredicate_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<Rule> getParserForType() {
            return PARSER;
        }

        public int getPositivePredicate(int i) {
            return this.positivePredicate_.get(i).intValue();
        }

        public int getPositivePredicateCount() {
            if (this.positivePredicate_ == null) {
                return 0;
            }
            return this.positivePredicate_.size();
        }

        public List<Integer> getPositivePredicateList() {
            return this.positivePredicate_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.positivePredicate_);
        }

        public int getRemoveMacro(int i) {
            return this.removeMacro_.get(i).intValue();
        }

        public int getRemoveMacroCount() {
            if (this.removeMacro_ == null) {
                return 0;
            }
            return this.removeMacro_.size();
        }

        public List<Integer> getRemoveMacroList() {
            return this.removeMacro_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeMacro_);
        }

        public int getRemoveMacroRuleName(int i) {
            return this.removeMacroRuleName_.get(i).intValue();
        }

        public int getRemoveMacroRuleNameCount() {
            if (this.removeMacroRuleName_ == null) {
                return 0;
            }
            return this.removeMacroRuleName_.size();
        }

        public List<Integer> getRemoveMacroRuleNameList() {
            return this.removeMacroRuleName_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeMacroRuleName_);
        }

        public int getRemoveTag(int i) {
            return this.removeTag_.get(i).intValue();
        }

        public int getRemoveTagCount() {
            if (this.removeTag_ == null) {
                return 0;
            }
            return this.removeTag_.size();
        }

        public List<Integer> getRemoveTagList() {
            return this.removeTag_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeTag_);
        }

        public int getRemoveTagRuleName(int i) {
            return this.removeTagRuleName_.get(i).intValue();
        }

        public int getRemoveTagRuleNameCount() {
            if (this.removeTagRuleName_ == null) {
                return 0;
            }
            return this.removeTagRuleName_.size();
        }

        public List<Integer> getRemoveTagRuleNameList() {
            return this.removeTagRuleName_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.removeTagRuleName_);
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.positivePredicate_ == null || this.positivePredicate_.size() <= 0) {
                i = 0;
            } else {
                int i2 = 0;
                int i3 = 0;
                while (i3 < this.positivePredicate_.size()) {
                    i3++;
                    i2 = CodedOutputStream.computeInt32SizeNoTag(this.positivePredicate_.get(i3).intValue()) + i2;
                }
                i = i2 + 0 + (getPositivePredicateList().size() * 1);
            }
            if (this.negativePredicate_ != null && this.negativePredicate_.size() > 0) {
                int i4 = 0;
                int i5 = 0;
                while (i5 < this.negativePredicate_.size()) {
                    i5++;
                    i4 = CodedOutputStream.computeInt32SizeNoTag(this.negativePredicate_.get(i5).intValue()) + i4;
                }
                i = (getNegativePredicateList().size() * 1) + i + i4;
            }
            if (this.addTag_ != null && this.addTag_.size() > 0) {
                int i6 = 0;
                int i7 = 0;
                while (i7 < this.addTag_.size()) {
                    i7++;
                    i6 = CodedOutputStream.computeInt32SizeNoTag(this.addTag_.get(i7).intValue()) + i6;
                }
                i = (getAddTagList().size() * 1) + i + i6;
            }
            if (this.removeTag_ != null && this.removeTag_.size() > 0) {
                int i8 = 0;
                int i9 = 0;
                while (i9 < this.removeTag_.size()) {
                    i9++;
                    i8 = CodedOutputStream.computeInt32SizeNoTag(this.removeTag_.get(i9).intValue()) + i8;
                }
                i = (getRemoveTagList().size() * 1) + i + i8;
            }
            if (this.addTagRuleName_ != null && this.addTagRuleName_.size() > 0) {
                int i10 = 0;
                int i11 = 0;
                while (i11 < this.addTagRuleName_.size()) {
                    i11++;
                    i10 = CodedOutputStream.computeInt32SizeNoTag(this.addTagRuleName_.get(i11).intValue()) + i10;
                }
                i = (getAddTagRuleNameList().size() * 1) + i + i10;
            }
            if (this.removeTagRuleName_ != null && this.removeTagRuleName_.size() > 0) {
                int i12 = 0;
                int i13 = 0;
                while (i13 < this.removeTagRuleName_.size()) {
                    i13++;
                    i12 = CodedOutputStream.computeInt32SizeNoTag(this.removeTagRuleName_.get(i13).intValue()) + i12;
                }
                i = (getRemoveTagRuleNameList().size() * 1) + i + i12;
            }
            if (this.addMacro_ != null && this.addMacro_.size() > 0) {
                int i14 = 0;
                int i15 = 0;
                while (i15 < this.addMacro_.size()) {
                    i15++;
                    i14 = CodedOutputStream.computeInt32SizeNoTag(this.addMacro_.get(i15).intValue()) + i14;
                }
                i = (getAddMacroList().size() * 1) + i + i14;
            }
            if (this.removeMacro_ != null && this.removeMacro_.size() > 0) {
                int i16 = 0;
                int i17 = 0;
                while (i17 < this.removeMacro_.size()) {
                    i17++;
                    i16 = CodedOutputStream.computeInt32SizeNoTag(this.removeMacro_.get(i17).intValue()) + i16;
                }
                i = (getRemoveMacroList().size() * 1) + i + i16;
            }
            if (this.addMacroRuleName_ != null && this.addMacroRuleName_.size() > 0) {
                int i18 = 0;
                int i19 = 0;
                while (i19 < this.addMacroRuleName_.size()) {
                    i19++;
                    i18 = CodedOutputStream.computeInt32SizeNoTag(this.addMacroRuleName_.get(i19).intValue()) + i18;
                }
                i = (getAddMacroRuleNameList().size() * 1) + i + i18;
            }
            if (this.removeMacroRuleName_ != null && this.removeMacroRuleName_.size() > 0) {
                int i20 = 0;
                for (int i21 = 0; i21 < this.removeMacroRuleName_.size(); i21++) {
                    i20 += CodedOutputStream.computeInt32SizeNoTag(this.removeMacroRuleName_.get(i21).intValue());
                }
                i = (getRemoveMacroRuleNameList().size() * 1) + i + i20;
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public int hashCode() {
            int i = 41;
            if (getPositivePredicateCount() > 0) {
                i = 80454 + getPositivePredicateList().hashCode();
            }
            if (getNegativePredicateCount() > 0) {
                i = (((i * 37) + 2) * 53) + getNegativePredicateList().hashCode();
            }
            if (getAddTagCount() > 0) {
                i = (((i * 37) + 3) * 53) + getAddTagList().hashCode();
            }
            if (getRemoveTagCount() > 0) {
                i = (((i * 37) + 4) * 53) + getRemoveTagList().hashCode();
            }
            if (getAddTagRuleNameCount() > 0) {
                i = (((i * 37) + 5) * 53) + getAddTagRuleNameList().hashCode();
            }
            if (getRemoveTagRuleNameCount() > 0) {
                i = (((i * 37) + 6) * 53) + getRemoveTagRuleNameList().hashCode();
            }
            if (getAddMacroCount() > 0) {
                i = (((i * 37) + 7) * 53) + getAddMacroList().hashCode();
            }
            if (getRemoveMacroCount() > 0) {
                i = (((i * 37) + 8) * 53) + getRemoveMacroList().hashCode();
            }
            if (getAddMacroRuleNameCount() > 0) {
                i = (((i * 37) + 9) * 53) + getAddMacroRuleNameList().hashCode();
            }
            if (getRemoveMacroRuleNameCount() > 0) {
                i = (((i * 37) + 10) * 53) + getRemoveMacroRuleNameList().hashCode();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$Rule");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return true;
        }

        public Rule mergeFrom(Rule rule) {
            if (this == rule) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (rule != getDefaultInstance()) {
                if (rule.positivePredicate_ != null && !rule.positivePredicate_.isEmpty()) {
                    ensurePositivePredicateInitialized();
                    this.positivePredicate_.addAll(rule.positivePredicate_);
                }
                if (rule.negativePredicate_ != null && !rule.negativePredicate_.isEmpty()) {
                    ensureNegativePredicateInitialized();
                    this.negativePredicate_.addAll(rule.negativePredicate_);
                }
                if (rule.addTag_ != null && !rule.addTag_.isEmpty()) {
                    ensureAddTagInitialized();
                    this.addTag_.addAll(rule.addTag_);
                }
                if (rule.removeTag_ != null && !rule.removeTag_.isEmpty()) {
                    ensureRemoveTagInitialized();
                    this.removeTag_.addAll(rule.removeTag_);
                }
                if (rule.addTagRuleName_ != null && !rule.addTagRuleName_.isEmpty()) {
                    ensureAddTagRuleNameInitialized();
                    this.addTagRuleName_.addAll(rule.addTagRuleName_);
                }
                if (rule.removeTagRuleName_ != null && !rule.removeTagRuleName_.isEmpty()) {
                    ensureRemoveTagRuleNameInitialized();
                    this.removeTagRuleName_.addAll(rule.removeTagRuleName_);
                }
                if (rule.addMacro_ != null && !rule.addMacro_.isEmpty()) {
                    ensureAddMacroInitialized();
                    this.addMacro_.addAll(rule.addMacro_);
                }
                if (rule.removeMacro_ != null && !rule.removeMacro_.isEmpty()) {
                    ensureRemoveMacroInitialized();
                    this.removeMacro_.addAll(rule.removeMacro_);
                }
                if (rule.addMacroRuleName_ != null && !rule.addMacroRuleName_.isEmpty()) {
                    ensureAddMacroRuleNameInitialized();
                    this.addMacroRuleName_.addAll(rule.addMacroRuleName_);
                }
                if (rule.removeMacroRuleName_ != null && !rule.removeMacroRuleName_.isEmpty()) {
                    ensureRemoveMacroRuleNameInitialized();
                    this.removeMacroRuleName_.addAll(rule.removeMacroRuleName_);
                }
                this.unknownFields = this.unknownFields.concat(rule.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            if (this.positivePredicate_ == null) {
                                this.positivePredicate_ = new ArrayList();
                            }
                            this.positivePredicate_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 10:
                            int pushLimit = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.positivePredicate_ == null) {
                                this.positivePredicate_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.positivePredicate_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit);
                            break;
                        case 16:
                            if (this.negativePredicate_ == null) {
                                this.negativePredicate_ = new ArrayList();
                            }
                            this.negativePredicate_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 18:
                            int pushLimit2 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.negativePredicate_ == null) {
                                this.negativePredicate_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.negativePredicate_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit2);
                            break;
                        case 24:
                            if (this.addTag_ == null) {
                                this.addTag_ = new ArrayList();
                            }
                            this.addTag_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 26:
                            int pushLimit3 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.addTag_ == null) {
                                this.addTag_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.addTag_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit3);
                            break;
                        case 32:
                            if (this.removeTag_ == null) {
                                this.removeTag_ = new ArrayList();
                            }
                            this.removeTag_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 34:
                            int pushLimit4 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.removeTag_ == null) {
                                this.removeTag_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.removeTag_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit4);
                            break;
                        case 40:
                            if (this.addTagRuleName_ == null) {
                                this.addTagRuleName_ = new ArrayList();
                            }
                            this.addTagRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 42:
                            int pushLimit5 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.addTagRuleName_ == null) {
                                this.addTagRuleName_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.addTagRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit5);
                            break;
                        case 48:
                            if (this.removeTagRuleName_ == null) {
                                this.removeTagRuleName_ = new ArrayList();
                            }
                            this.removeTagRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case AdSize.PORTRAIT_AD_HEIGHT:
                            int pushLimit6 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.removeTagRuleName_ == null) {
                                this.removeTagRuleName_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.removeTagRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit6);
                            break;
                        case 56:
                            if (this.addMacro_ == null) {
                                this.addMacro_ = new ArrayList();
                            }
                            this.addMacro_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 58:
                            int pushLimit7 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.addMacro_ == null) {
                                this.addMacro_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.addMacro_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit7);
                            break;
                        case AccessibilityNodeInfoCompat.ACTION_ACCESSIBILITY_FOCUS:
                            if (this.removeMacro_ == null) {
                                this.removeMacro_ = new ArrayList();
                            }
                            this.removeMacro_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 66:
                            int pushLimit8 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.removeMacro_ == null) {
                                this.removeMacro_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.removeMacro_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit8);
                            break;
                        case 72:
                            if (this.addMacroRuleName_ == null) {
                                this.addMacroRuleName_ = new ArrayList();
                            }
                            this.addMacroRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 74:
                            int pushLimit9 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.addMacroRuleName_ == null) {
                                this.addMacroRuleName_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.addMacroRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit9);
                            break;
                        case 80:
                            if (this.removeMacroRuleName_ == null) {
                                this.removeMacroRuleName_ = new ArrayList();
                            }
                            this.removeMacroRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 82:
                            int pushLimit10 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.removeMacroRuleName_ == null) {
                                this.removeMacroRuleName_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.removeMacroRuleName_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit10);
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public Rule newMessageForType() {
            return new Rule();
        }

        public Rule setAddMacro(int i, int i2) {
            assertMutable();
            ensureAddMacroInitialized();
            this.addMacro_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setAddMacroRuleName(int i, int i2) {
            assertMutable();
            ensureAddMacroRuleNameInitialized();
            this.addMacroRuleName_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setAddTag(int i, int i2) {
            assertMutable();
            ensureAddTagInitialized();
            this.addTag_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setAddTagRuleName(int i, int i2) {
            assertMutable();
            ensureAddTagRuleNameInitialized();
            this.addTagRuleName_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setNegativePredicate(int i, int i2) {
            assertMutable();
            ensureNegativePredicateInitialized();
            this.negativePredicate_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setPositivePredicate(int i, int i2) {
            assertMutable();
            ensurePositivePredicateInitialized();
            this.positivePredicate_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setRemoveMacro(int i, int i2) {
            assertMutable();
            ensureRemoveMacroInitialized();
            this.removeMacro_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setRemoveMacroRuleName(int i, int i2) {
            assertMutable();
            ensureRemoveMacroRuleNameInitialized();
            this.removeMacroRuleName_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setRemoveTag(int i, int i2) {
            assertMutable();
            ensureRemoveTagInitialized();
            this.removeTag_.set(i, Integer.valueOf(i2));
            return this;
        }

        public Rule setRemoveTagRuleName(int i, int i2) {
            assertMutable();
            ensureRemoveTagRuleNameInitialized();
            this.removeTagRuleName_.set(i, Integer.valueOf(i2));
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.positivePredicate_ != null) {
                for (int i = 0; i < this.positivePredicate_.size(); i++) {
                    codedOutputStream.writeInt32(1, this.positivePredicate_.get(i).intValue());
                }
            }
            if (this.negativePredicate_ != null) {
                for (int i2 = 0; i2 < this.negativePredicate_.size(); i2++) {
                    codedOutputStream.writeInt32(2, this.negativePredicate_.get(i2).intValue());
                }
            }
            if (this.addTag_ != null) {
                for (int i3 = 0; i3 < this.addTag_.size(); i3++) {
                    codedOutputStream.writeInt32(3, this.addTag_.get(i3).intValue());
                }
            }
            if (this.removeTag_ != null) {
                for (int i4 = 0; i4 < this.removeTag_.size(); i4++) {
                    codedOutputStream.writeInt32(4, this.removeTag_.get(i4).intValue());
                }
            }
            if (this.addTagRuleName_ != null) {
                for (int i5 = 0; i5 < this.addTagRuleName_.size(); i5++) {
                    codedOutputStream.writeInt32(5, this.addTagRuleName_.get(i5).intValue());
                }
            }
            if (this.removeTagRuleName_ != null) {
                for (int i6 = 0; i6 < this.removeTagRuleName_.size(); i6++) {
                    codedOutputStream.writeInt32(6, this.removeTagRuleName_.get(i6).intValue());
                }
            }
            if (this.addMacro_ != null) {
                for (int i7 = 0; i7 < this.addMacro_.size(); i7++) {
                    codedOutputStream.writeInt32(7, this.addMacro_.get(i7).intValue());
                }
            }
            if (this.removeMacro_ != null) {
                for (int i8 = 0; i8 < this.removeMacro_.size(); i8++) {
                    codedOutputStream.writeInt32(8, this.removeMacro_.get(i8).intValue());
                }
            }
            if (this.addMacroRuleName_ != null) {
                for (int i9 = 0; i9 < this.addMacroRuleName_.size(); i9++) {
                    codedOutputStream.writeInt32(9, this.addMacroRuleName_.get(i9).intValue());
                }
            }
            if (this.removeMacroRuleName_ != null) {
                for (int i10 = 0; i10 < this.removeMacroRuleName_.size(); i10++) {
                    codedOutputStream.writeInt32(10, this.removeMacroRuleName_.get(i10).intValue());
                }
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    public static final class ServingValue extends GeneratedMutableMessageLite<ServingValue> implements MutableMessageLite {
        public static final int EXT_FIELD_NUMBER = 101;
        public static final int LIST_ITEM_FIELD_NUMBER = 1;
        public static final int MACRO_NAME_REFERENCE_FIELD_NUMBER = 6;
        public static final int MACRO_REFERENCE_FIELD_NUMBER = 4;
        public static final int MAP_KEY_FIELD_NUMBER = 2;
        public static final int MAP_VALUE_FIELD_NUMBER = 3;
        public static Parser<ServingValue> PARSER = AbstractMutableMessageLite.internalNewParserForType(defaultInstance);
        public static final int TEMPLATE_TOKEN_FIELD_NUMBER = 5;
        private static final ServingValue defaultInstance = new ServingValue(true);
        public static final GeneratedMessageLite.GeneratedExtension<MutableTypeSystem.Value, ServingValue> ext = GeneratedMessageLite.newSingularGeneratedExtension(MutableTypeSystem.Value.getDefaultInstance(), getDefaultInstance(), getDefaultInstance(), null, 101, WireFormat.FieldType.MESSAGE, ServingValue.class);
        private static volatile MessageLite immutableDefault = null;
        private static final long serialVersionUID = 0;
        private int bitField0_;
        private List<Integer> listItem_ = null;
        private int macroNameReference_;
        private int macroReference_;
        private List<Integer> mapKey_ = null;
        private List<Integer> mapValue_ = null;
        private List<Integer> templateToken_ = null;

        static {
            defaultInstance.initFields();
            defaultInstance.makeImmutable();
        }

        private ServingValue() {
            initFields();
        }

        private ServingValue(boolean z) {
        }

        private void ensureListItemInitialized() {
            if (this.listItem_ == null) {
                this.listItem_ = new ArrayList();
            }
        }

        private void ensureMapKeyInitialized() {
            if (this.mapKey_ == null) {
                this.mapKey_ = new ArrayList();
            }
        }

        private void ensureMapValueInitialized() {
            if (this.mapValue_ == null) {
                this.mapValue_ = new ArrayList();
            }
        }

        private void ensureTemplateTokenInitialized() {
            if (this.templateToken_ == null) {
                this.templateToken_ = new ArrayList();
            }
        }

        public static ServingValue getDefaultInstance() {
            return defaultInstance;
        }

        private void initFields() {
        }

        public static ServingValue newMessage() {
            return new ServingValue();
        }

        public ServingValue addAllListItem(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureListItemInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.listItem_);
            return this;
        }

        public ServingValue addAllMapKey(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureMapKeyInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.mapKey_);
            return this;
        }

        public ServingValue addAllMapValue(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureMapValueInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.mapValue_);
            return this;
        }

        public ServingValue addAllTemplateToken(Iterable<? extends Integer> iterable) {
            assertMutable();
            ensureTemplateTokenInitialized();
            AbstractMutableMessageLite.addAll(iterable, this.templateToken_);
            return this;
        }

        public ServingValue addListItem(int i) {
            assertMutable();
            ensureListItemInitialized();
            this.listItem_.add(Integer.valueOf(i));
            return this;
        }

        public ServingValue addMapKey(int i) {
            assertMutable();
            ensureMapKeyInitialized();
            this.mapKey_.add(Integer.valueOf(i));
            return this;
        }

        public ServingValue addMapValue(int i) {
            assertMutable();
            ensureMapValueInitialized();
            this.mapValue_.add(Integer.valueOf(i));
            return this;
        }

        public ServingValue addTemplateToken(int i) {
            assertMutable();
            ensureTemplateTokenInitialized();
            this.templateToken_.add(Integer.valueOf(i));
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public ServingValue clear() {
            assertMutable();
            super.clear();
            this.listItem_ = null;
            this.mapKey_ = null;
            this.mapValue_ = null;
            this.macroReference_ = 0;
            this.bitField0_ &= -2;
            this.templateToken_ = null;
            this.macroNameReference_ = 0;
            this.bitField0_ &= -3;
            return this;
        }

        public ServingValue clearListItem() {
            assertMutable();
            this.listItem_ = null;
            return this;
        }

        public ServingValue clearMacroNameReference() {
            assertMutable();
            this.bitField0_ &= -3;
            this.macroNameReference_ = 0;
            return this;
        }

        public ServingValue clearMacroReference() {
            assertMutable();
            this.bitField0_ &= -2;
            this.macroReference_ = 0;
            return this;
        }

        public ServingValue clearMapKey() {
            assertMutable();
            this.mapKey_ = null;
            return this;
        }

        public ServingValue clearMapValue() {
            assertMutable();
            this.mapValue_ = null;
            return this;
        }

        public ServingValue clearTemplateToken() {
            assertMutable();
            this.templateToken_ = null;
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, com.google.tagmanager.protobuf.AbstractMutableMessageLite, java.lang.Object
        public ServingValue clone() {
            return newMessageForType().mergeFrom(this);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ServingValue)) {
                return super.equals(obj);
            }
            ServingValue servingValue = (ServingValue) obj;
            boolean z = (((getListItemList().equals(servingValue.getListItemList())) && getMapKeyList().equals(servingValue.getMapKeyList())) && getMapValueList().equals(servingValue.getMapValueList())) && hasMacroReference() == servingValue.hasMacroReference();
            if (hasMacroReference()) {
                z = z && getMacroReference() == servingValue.getMacroReference();
            }
            boolean z2 = (z && getTemplateTokenList().equals(servingValue.getTemplateTokenList())) && hasMacroNameReference() == servingValue.hasMacroNameReference();
            return hasMacroNameReference() ? z2 && getMacroNameReference() == servingValue.getMacroNameReference() : z2;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final ServingValue getDefaultInstanceForType() {
            return defaultInstance;
        }

        public int getListItem(int i) {
            return this.listItem_.get(i).intValue();
        }

        public int getListItemCount() {
            if (this.listItem_ == null) {
                return 0;
            }
            return this.listItem_.size();
        }

        public List<Integer> getListItemList() {
            return this.listItem_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.listItem_);
        }

        public int getMacroNameReference() {
            return this.macroNameReference_;
        }

        public int getMacroReference() {
            return this.macroReference_;
        }

        public int getMapKey(int i) {
            return this.mapKey_.get(i).intValue();
        }

        public int getMapKeyCount() {
            if (this.mapKey_ == null) {
                return 0;
            }
            return this.mapKey_.size();
        }

        public List<Integer> getMapKeyList() {
            return this.mapKey_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.mapKey_);
        }

        public int getMapValue(int i) {
            return this.mapValue_.get(i).intValue();
        }

        public int getMapValueCount() {
            if (this.mapValue_ == null) {
                return 0;
            }
            return this.mapValue_.size();
        }

        public List<Integer> getMapValueList() {
            return this.mapValue_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.mapValue_);
        }

        public List<Integer> getMutableListItemList() {
            assertMutable();
            ensureListItemInitialized();
            return this.listItem_;
        }

        public List<Integer> getMutableMapKeyList() {
            assertMutable();
            ensureMapKeyInitialized();
            return this.mapKey_;
        }

        public List<Integer> getMutableMapValueList() {
            assertMutable();
            ensureMapValueInitialized();
            return this.mapValue_;
        }

        public List<Integer> getMutableTemplateTokenList() {
            assertMutable();
            ensureTemplateTokenInitialized();
            return this.templateToken_;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Parser<ServingValue> getParserForType() {
            return PARSER;
        }

        @Override // com.google.tagmanager.protobuf.MessageLite
        public int getSerializedSize() {
            int i;
            if (this.listItem_ == null || this.listItem_.size() <= 0) {
                i = 0;
            } else {
                int i2 = 0;
                int i3 = 0;
                while (i3 < this.listItem_.size()) {
                    i3++;
                    i2 = CodedOutputStream.computeInt32SizeNoTag(this.listItem_.get(i3).intValue()) + i2;
                }
                i = i2 + 0 + (getListItemList().size() * 1);
            }
            if (this.mapKey_ != null && this.mapKey_.size() > 0) {
                int i4 = 0;
                int i5 = 0;
                while (i5 < this.mapKey_.size()) {
                    i5++;
                    i4 = CodedOutputStream.computeInt32SizeNoTag(this.mapKey_.get(i5).intValue()) + i4;
                }
                i = (getMapKeyList().size() * 1) + i + i4;
            }
            if (this.mapValue_ != null && this.mapValue_.size() > 0) {
                int i6 = 0;
                int i7 = 0;
                while (i7 < this.mapValue_.size()) {
                    i7++;
                    i6 = CodedOutputStream.computeInt32SizeNoTag(this.mapValue_.get(i7).intValue()) + i6;
                }
                i = (getMapValueList().size() * 1) + i + i6;
            }
            if ((this.bitField0_ & 1) == 1) {
                i += CodedOutputStream.computeInt32Size(4, this.macroReference_);
            }
            if (this.templateToken_ != null && this.templateToken_.size() > 0) {
                int i8 = 0;
                for (int i9 = 0; i9 < this.templateToken_.size(); i9++) {
                    i8 += CodedOutputStream.computeInt32SizeNoTag(this.templateToken_.get(i9).intValue());
                }
                i = (getTemplateTokenList().size() * 1) + i + i8;
            }
            if ((this.bitField0_ & 2) == 2) {
                i += CodedOutputStream.computeInt32Size(6, this.macroNameReference_);
            }
            int size = this.unknownFields.size() + i;
            this.cachedSize = size;
            return size;
        }

        public int getTemplateToken(int i) {
            return this.templateToken_.get(i).intValue();
        }

        public int getTemplateTokenCount() {
            if (this.templateToken_ == null) {
                return 0;
            }
            return this.templateToken_.size();
        }

        public List<Integer> getTemplateTokenList() {
            return this.templateToken_ == null ? Collections.emptyList() : Collections.unmodifiableList(this.templateToken_);
        }

        public boolean hasMacroNameReference() {
            return (this.bitField0_ & 2) == 2;
        }

        public boolean hasMacroReference() {
            return (this.bitField0_ & 1) == 1;
        }

        public int hashCode() {
            int i = 41;
            if (getListItemCount() > 0) {
                i = 80454 + getListItemList().hashCode();
            }
            if (getMapKeyCount() > 0) {
                i = (((i * 37) + 2) * 53) + getMapKeyList().hashCode();
            }
            if (getMapValueCount() > 0) {
                i = (((i * 37) + 3) * 53) + getMapValueList().hashCode();
            }
            if (hasMacroReference()) {
                i = (((i * 37) + 4) * 53) + getMacroReference();
            }
            if (getTemplateTokenCount() > 0) {
                i = (((i * 37) + 5) * 53) + getTemplateTokenList().hashCode();
            }
            if (hasMacroNameReference()) {
                i = (((i * 37) + 6) * 53) + getMacroNameReference();
            }
            return (i * 29) + this.unknownFields.hashCode();
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite internalImmutableDefault() {
            if (immutableDefault == null) {
                immutableDefault = internalImmutableDefault("com.google.analytics.containertag.proto.Serving$ServingValue");
            }
            return immutableDefault;
        }

        @Override // com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public final boolean isInitialized() {
            return true;
        }

        public ServingValue mergeFrom(ServingValue servingValue) {
            if (this == servingValue) {
                throw new IllegalArgumentException("mergeFrom(message) called on the same message.");
            }
            assertMutable();
            if (servingValue != getDefaultInstance()) {
                if (servingValue.listItem_ != null && !servingValue.listItem_.isEmpty()) {
                    ensureListItemInitialized();
                    this.listItem_.addAll(servingValue.listItem_);
                }
                if (servingValue.mapKey_ != null && !servingValue.mapKey_.isEmpty()) {
                    ensureMapKeyInitialized();
                    this.mapKey_.addAll(servingValue.mapKey_);
                }
                if (servingValue.mapValue_ != null && !servingValue.mapValue_.isEmpty()) {
                    ensureMapValueInitialized();
                    this.mapValue_.addAll(servingValue.mapValue_);
                }
                if (servingValue.hasMacroReference()) {
                    setMacroReference(servingValue.getMacroReference());
                }
                if (servingValue.templateToken_ != null && !servingValue.templateToken_.isEmpty()) {
                    ensureTemplateTokenInitialized();
                    this.templateToken_.addAll(servingValue.templateToken_);
                }
                if (servingValue.hasMacroNameReference()) {
                    setMacroNameReference(servingValue.getMacroNameReference());
                }
                this.unknownFields = this.unknownFields.concat(servingValue.unknownFields);
            }
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public boolean mergeFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            assertMutable();
            try {
                ByteString.Output newOutput = ByteString.newOutput();
                CodedOutputStream newInstance = CodedOutputStream.newInstance(newOutput);
                boolean z = false;
                while (!z) {
                    int readTag = codedInputStream.readTag();
                    switch (readTag) {
                        case 0:
                            z = true;
                            break;
                        case 8:
                            if (this.listItem_ == null) {
                                this.listItem_ = new ArrayList();
                            }
                            this.listItem_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 10:
                            int pushLimit = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.listItem_ == null) {
                                this.listItem_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.listItem_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit);
                            break;
                        case 16:
                            if (this.mapKey_ == null) {
                                this.mapKey_ = new ArrayList();
                            }
                            this.mapKey_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 18:
                            int pushLimit2 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.mapKey_ == null) {
                                this.mapKey_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.mapKey_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit2);
                            break;
                        case 24:
                            if (this.mapValue_ == null) {
                                this.mapValue_ = new ArrayList();
                            }
                            this.mapValue_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 26:
                            int pushLimit3 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.mapValue_ == null) {
                                this.mapValue_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.mapValue_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit3);
                            break;
                        case 32:
                            this.bitField0_ |= 1;
                            this.macroReference_ = codedInputStream.readInt32();
                            break;
                        case 40:
                            if (this.templateToken_ == null) {
                                this.templateToken_ = new ArrayList();
                            }
                            this.templateToken_.add(Integer.valueOf(codedInputStream.readInt32()));
                            break;
                        case 42:
                            int pushLimit4 = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
                            if (this.templateToken_ == null) {
                                this.templateToken_ = new ArrayList();
                            }
                            while (codedInputStream.getBytesUntilLimit() > 0) {
                                this.templateToken_.add(Integer.valueOf(codedInputStream.readInt32()));
                            }
                            codedInputStream.popLimit(pushLimit4);
                            break;
                        case 48:
                            this.bitField0_ |= 2;
                            this.macroNameReference_ = codedInputStream.readInt32();
                            break;
                        default:
                            if (parseUnknownField(codedInputStream, newInstance, extensionRegistryLite, readTag)) {
                                break;
                            } else {
                                z = true;
                                break;
                            }
                    }
                }
                newInstance.flush();
                this.unknownFields = newOutput.toByteString();
                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public ServingValue newMessageForType() {
            return new ServingValue();
        }

        public ServingValue setListItem(int i, int i2) {
            assertMutable();
            ensureListItemInitialized();
            this.listItem_.set(i, Integer.valueOf(i2));
            return this;
        }

        public ServingValue setMacroNameReference(int i) {
            assertMutable();
            this.bitField0_ |= 2;
            this.macroNameReference_ = i;
            return this;
        }

        public ServingValue setMacroReference(int i) {
            assertMutable();
            this.bitField0_ |= 1;
            this.macroReference_ = i;
            return this;
        }

        public ServingValue setMapKey(int i, int i2) {
            assertMutable();
            ensureMapKeyInitialized();
            this.mapKey_.set(i, Integer.valueOf(i2));
            return this;
        }

        public ServingValue setMapValue(int i, int i2) {
            assertMutable();
            ensureMapValueInitialized();
            this.mapValue_.set(i, Integer.valueOf(i2));
            return this;
        }

        public ServingValue setTemplateToken(int i, int i2) {
            assertMutable();
            ensureTemplateTokenInitialized();
            this.templateToken_.set(i, Integer.valueOf(i2));
            return this;
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public Object writeReplace() throws ObjectStreamException {
            return super.writeReplace();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite
        public void writeToWithCachedSizes(CodedOutputStream codedOutputStream) throws IOException {
            int totalBytesWritten = codedOutputStream.getTotalBytesWritten();
            if (this.listItem_ != null) {
                for (int i = 0; i < this.listItem_.size(); i++) {
                    codedOutputStream.writeInt32(1, this.listItem_.get(i).intValue());
                }
            }
            if (this.mapKey_ != null) {
                for (int i2 = 0; i2 < this.mapKey_.size(); i2++) {
                    codedOutputStream.writeInt32(2, this.mapKey_.get(i2).intValue());
                }
            }
            if (this.mapValue_ != null) {
                for (int i3 = 0; i3 < this.mapValue_.size(); i3++) {
                    codedOutputStream.writeInt32(3, this.mapValue_.get(i3).intValue());
                }
            }
            if ((this.bitField0_ & 1) == 1) {
                codedOutputStream.writeInt32(4, this.macroReference_);
            }
            if (this.templateToken_ != null) {
                for (int i4 = 0; i4 < this.templateToken_.size(); i4++) {
                    codedOutputStream.writeInt32(5, this.templateToken_.get(i4).intValue());
                }
            }
            if ((this.bitField0_ & 2) == 2) {
                codedOutputStream.writeInt32(6, this.macroNameReference_);
            }
            codedOutputStream.writeRawBytes(this.unknownFields);
            if (getCachedSize() != codedOutputStream.getTotalBytesWritten() - totalBytesWritten) {
                throw new RuntimeException("Serialized size doesn't match cached size. You may forget to call getSerializedSize() or the message is being modified concurrently.");
            }
        }
    }

    private MutableServing() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
        extensionRegistryLite.add(ServingValue.ext);
    }
}

package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.Intent;
import com.google.analytics.tracking.android.AnalyticsGmsCoreClient;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;

class GAServiceProxy implements ServiceProxy, AnalyticsGmsCoreClient.OnConnectedListener, AnalyticsGmsCoreClient.OnConnectionFailedListener {
    private static final long FAILED_CONNECT_WAIT_TIME = 3000;
    private static final int MAX_TRIES = 2;
    private static final long RECONNECT_WAIT_TIME = 5000;
    private static final long SERVICE_CONNECTION_TIMEOUT = 300000;
    private volatile AnalyticsClient client;
    /* access modifiers changed from: private */
    public Clock clock;
    private volatile int connectTries;
    private final Context ctx;
    /* access modifiers changed from: private */
    public volatile Timer disconnectCheckTimer;
    private volatile Timer failedConnectTimer;
    private boolean forceLocalDispatch;
    private final GoogleAnalytics gaInstance;
    /* access modifiers changed from: private */
    public long idleTimeout;
    /* access modifiers changed from: private */
    public volatile long lastRequestTime;
    private boolean pendingClearHits;
    private boolean pendingDispatch;
    private boolean pendingServiceDisconnect;
    /* access modifiers changed from: private */
    public final Queue<HitParams> queue;
    private volatile Timer reConnectTimer;
    /* access modifiers changed from: private */
    public volatile ConnectState state;
    private AnalyticsStore store;
    private AnalyticsStore testStore;
    private final AnalyticsThread thread;

    private enum ConnectState {
        CONNECTING,
        CONNECTED_SERVICE,
        CONNECTED_LOCAL,
        BLOCKED,
        PENDING_CONNECTION,
        PENDING_DISCONNECT,
        DISCONNECTED
    }

    private class DisconnectCheckTask extends TimerTask {
        private DisconnectCheckTask() {
        }

        public void run() {
            if (GAServiceProxy.this.state != ConnectState.CONNECTED_SERVICE || !GAServiceProxy.this.queue.isEmpty() || GAServiceProxy.this.lastRequestTime + GAServiceProxy.this.idleTimeout >= GAServiceProxy.this.clock.currentTimeMillis()) {
                GAServiceProxy.this.disconnectCheckTimer.schedule(new DisconnectCheckTask(), GAServiceProxy.this.idleTimeout);
                return;
            }
            Log.v("Disconnecting due to inactivity");
            GAServiceProxy.this.disconnectFromService();
        }
    }

    private class FailedConnectTask extends TimerTask {
        private FailedConnectTask() {
        }

        public void run() {
            if (GAServiceProxy.this.state == ConnectState.CONNECTING) {
                GAServiceProxy.this.useStore();
            }
        }
    }

    private static class HitParams {
        private final List<Command> commands;
        private final long hitTimeInMilliseconds;
        private final String path;
        private final Map<String, String> wireFormatParams;

        public HitParams(Map<String, String> map, long j, String str, List<Command> list) {
            this.wireFormatParams = map;
            this.hitTimeInMilliseconds = j;
            this.path = str;
            this.commands = list;
        }

        public List<Command> getCommands() {
            return this.commands;
        }

        public long getHitTimeInMilliseconds() {
            return this.hitTimeInMilliseconds;
        }

        public String getPath() {
            return this.path;
        }

        public Map<String, String> getWireFormatParams() {
            return this.wireFormatParams;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("PATH: ");
            sb.append(this.path);
            if (this.wireFormatParams != null) {
                sb.append("  PARAMS: ");
                for (Map.Entry<String, String> entry : this.wireFormatParams.entrySet()) {
                    sb.append(entry.getKey());
                    sb.append("=");
                    sb.append(entry.getValue());
                    sb.append(",  ");
                }
            }
            return sb.toString();
        }
    }

    private class ReconnectTask extends TimerTask {
        private ReconnectTask() {
        }

        public void run() {
            GAServiceProxy.this.connectToService();
        }
    }

    GAServiceProxy(Context context, AnalyticsThread analyticsThread) {
        this(context, analyticsThread, null, GoogleAnalytics.getInstance(context));
    }

    @VisibleForTesting
    GAServiceProxy(Context context, AnalyticsThread analyticsThread, AnalyticsStore analyticsStore, GoogleAnalytics googleAnalytics) {
        this.queue = new ConcurrentLinkedQueue();
        this.idleTimeout = SERVICE_CONNECTION_TIMEOUT;
        this.testStore = analyticsStore;
        this.ctx = context;
        this.thread = analyticsThread;
        this.gaInstance = googleAnalytics;
        this.clock = new Clock() {
            /* class com.google.analytics.tracking.android.GAServiceProxy.AnonymousClass1 */

            @Override // com.google.analytics.tracking.android.Clock
            public long currentTimeMillis() {
                return System.currentTimeMillis();
            }
        };
        this.connectTries = 0;
        this.state = ConnectState.DISCONNECTED;
    }

    private Timer cancelTimer(Timer timer) {
        if (timer == null) {
            return null;
        }
        timer.cancel();
        return null;
    }

    private void clearAllTimers() {
        this.reConnectTimer = cancelTimer(this.reConnectTimer);
        this.failedConnectTimer = cancelTimer(this.failedConnectTimer);
        this.disconnectCheckTimer = cancelTimer(this.disconnectCheckTimer);
    }

    /* access modifiers changed from: private */
    public void connectToService() {
        synchronized (this) {
            if (this.forceLocalDispatch || this.client == null || this.state == ConnectState.CONNECTED_LOCAL) {
                Log.w("client not initialized.");
                useStore();
            } else {
                try {
                    this.connectTries++;
                    cancelTimer(this.failedConnectTimer);
                    this.state = ConnectState.CONNECTING;
                    this.failedConnectTimer = new Timer("Failed Connect");
                    this.failedConnectTimer.schedule(new FailedConnectTask(), (long) FAILED_CONNECT_WAIT_TIME);
                    Log.v("connecting to Analytics service");
                    this.client.connect();
                } catch (SecurityException e) {
                    Log.w("security exception on connectToService");
                    useStore();
                }
            }
        }
        return;
    }

    /* access modifiers changed from: private */
    public void disconnectFromService() {
        synchronized (this) {
            if (this.client != null && this.state == ConnectState.CONNECTED_SERVICE) {
                this.state = ConnectState.PENDING_DISCONNECT;
                this.client.disconnect();
            }
        }
    }

    private void dispatchToStore() {
        this.store.dispatch();
        this.pendingDispatch = false;
    }

    private void fireReconnectAttempt() {
        this.reConnectTimer = cancelTimer(this.reConnectTimer);
        this.reConnectTimer = new Timer("Service Reconnect");
        this.reConnectTimer.schedule(new ReconnectTask(), (long) RECONNECT_WAIT_TIME);
    }

    /* access modifiers changed from: private */
    public void sendQueue() {
        synchronized (this) {
            if (Thread.currentThread().equals(this.thread.getThread())) {
                if (this.pendingClearHits) {
                    clearHits();
                }
                switch (this.state) {
                    case CONNECTED_LOCAL:
                        while (!this.queue.isEmpty()) {
                            HitParams poll = this.queue.poll();
                            Log.v("Sending hit to store  " + poll);
                            this.store.putHit(poll.getWireFormatParams(), poll.getHitTimeInMilliseconds(), poll.getPath(), poll.getCommands());
                        }
                        if (this.pendingDispatch) {
                            dispatchToStore();
                            break;
                        }
                        break;
                    case CONNECTED_SERVICE:
                        while (!this.queue.isEmpty()) {
                            HitParams peek = this.queue.peek();
                            Log.v("Sending hit to service   " + peek);
                            if (!this.gaInstance.isDryRunEnabled()) {
                                this.client.sendHit(peek.getWireFormatParams(), peek.getHitTimeInMilliseconds(), peek.getPath(), peek.getCommands());
                            } else {
                                Log.v("Dry run enabled. Hit not actually sent to service.");
                            }
                            this.queue.poll();
                        }
                        this.lastRequestTime = this.clock.currentTimeMillis();
                        break;
                    case DISCONNECTED:
                        Log.v("Need to reconnect");
                        if (!this.queue.isEmpty()) {
                            connectToService();
                            break;
                        }
                        break;
                }
            } else {
                this.thread.getQueue().add(new Runnable() {
                    /* class com.google.analytics.tracking.android.GAServiceProxy.AnonymousClass2 */

                    public void run() {
                        GAServiceProxy.this.sendQueue();
                    }
                });
            }
        }
    }

    /* access modifiers changed from: private */
    public void useStore() {
        synchronized (this) {
            if (this.state != ConnectState.CONNECTED_LOCAL) {
                clearAllTimers();
                Log.v("falling back to local store");
                if (this.testStore != null) {
                    this.store = this.testStore;
                } else {
                    GAServiceManager instance = GAServiceManager.getInstance();
                    instance.initialize(this.ctx, this.thread);
                    this.store = instance.getStore();
                }
                this.state = ConnectState.CONNECTED_LOCAL;
                sendQueue();
            }
        }
    }

    @Override // com.google.analytics.tracking.android.ServiceProxy
    public void clearHits() {
        Log.v("clearHits called");
        this.queue.clear();
        switch (this.state) {
            case CONNECTED_LOCAL:
                this.store.clearHits(0);
                this.pendingClearHits = false;
                return;
            case CONNECTED_SERVICE:
                this.client.clearHits();
                this.pendingClearHits = false;
                return;
            default:
                this.pendingClearHits = true;
                return;
        }
    }

    @Override // com.google.analytics.tracking.android.ServiceProxy
    public void createService() {
        if (this.client == null) {
            this.client = new AnalyticsGmsCoreClient(this.ctx, this, this);
            connectToService();
        }
    }

    /* access modifiers changed from: package-private */
    public void createService(AnalyticsClient analyticsClient) {
        if (this.client == null) {
            this.client = analyticsClient;
            connectToService();
        }
    }

    @Override // com.google.analytics.tracking.android.ServiceProxy
    public void dispatch() {
        switch (this.state) {
            case CONNECTED_LOCAL:
                dispatchToStore();
                return;
            case CONNECTED_SERVICE:
                return;
            default:
                this.pendingDispatch = true;
                return;
        }
    }

    @Override // com.google.analytics.tracking.android.AnalyticsGmsCoreClient.OnConnectedListener
    public void onConnected() {
        synchronized (this) {
            this.failedConnectTimer = cancelTimer(this.failedConnectTimer);
            this.connectTries = 0;
            Log.v("Connected to service");
            this.state = ConnectState.CONNECTED_SERVICE;
            if (this.pendingServiceDisconnect) {
                disconnectFromService();
                this.pendingServiceDisconnect = false;
            } else {
                sendQueue();
                this.disconnectCheckTimer = cancelTimer(this.disconnectCheckTimer);
                this.disconnectCheckTimer = new Timer("disconnect check");
                this.disconnectCheckTimer.schedule(new DisconnectCheckTask(), this.idleTimeout);
            }
        }
    }

    @Override // com.google.analytics.tracking.android.AnalyticsGmsCoreClient.OnConnectionFailedListener
    public void onConnectionFailed(int i, Intent intent) {
        synchronized (this) {
            this.state = ConnectState.PENDING_CONNECTION;
            if (this.connectTries < 2) {
                Log.w("Service unavailable (code=" + i + "), will retry.");
                fireReconnectAttempt();
            } else {
                Log.w("Service unavailable (code=" + i + "), using local store.");
                useStore();
            }
        }
    }

    @Override // com.google.analytics.tracking.android.AnalyticsGmsCoreClient.OnConnectedListener
    public void onDisconnected() {
        synchronized (this) {
            if (this.state == ConnectState.PENDING_DISCONNECT) {
                Log.v("Disconnected from service");
                clearAllTimers();
                this.state = ConnectState.DISCONNECTED;
            } else {
                Log.v("Unexpected disconnect.");
                this.state = ConnectState.PENDING_CONNECTION;
                if (this.connectTries < 2) {
                    fireReconnectAttempt();
                } else {
                    useStore();
                }
            }
        }
    }

    @Override // com.google.analytics.tracking.android.ServiceProxy
    public void putHit(Map<String, String> map, long j, String str, List<Command> list) {
        Log.v("putHit called");
        this.queue.add(new HitParams(map, j, str, list));
        sendQueue();
    }

    /* access modifiers changed from: package-private */
    public void setClock(Clock clock2) {
        this.clock = clock2;
    }

    @Override // com.google.analytics.tracking.android.ServiceProxy
    public void setForceLocalDispatch() {
        synchronized (this) {
            if (!this.forceLocalDispatch) {
                Log.v("setForceLocalDispatch called.");
                this.forceLocalDispatch = true;
                switch (this.state) {
                    case CONNECTED_SERVICE:
                        disconnectFromService();
                        break;
                    case CONNECTING:
                        this.pendingServiceDisconnect = true;
                        break;
                }
            }
        }
    }

    public void setIdleTimeout(long j) {
        this.idleTimeout = j;
    }
}

package com.google.analytics.tracking.android;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import com.getjar.vending.GetJarUtils;
import com.google.analytics.tracking.android.GAUsage;
import com.google.analytics.tracking.android.Logger;
import com.google.android.gms.common.util.VisibleForTesting;
import java.lang.Thread;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class EasyTracker extends Tracker {
    private static final int DEFAULT_SAMPLE_RATE = 100;
    private static final String EASY_TRACKER_NAME = "easy_tracker";
    static final int NUM_MILLISECONDS_TO_WAIT_FOR_OPEN_ACTIVITY = 1000;
    private static EasyTracker sInstance;
    private static String sResourcePackageName;
    private int mActivitiesActive;
    private final Map<String, String> mActivityNameMap;
    private Clock mClock;
    private Context mContext;
    private final GoogleAnalytics mGoogleAnalytics;
    private boolean mIsAutoActivityTracking;
    /* access modifiers changed from: private */
    public boolean mIsInForeground;
    private boolean mIsReportUncaughtExceptionsEnabled;
    private long mLastOnStopTime;
    private ParameterLoader mParameterFetcher;
    private ServiceManager mServiceManager;
    private long mSessionTimeout;
    private boolean mStartSessionOnNextSend;
    private Timer mTimer;
    private TimerTask mTimerTask;

    private class NotInForegroundTimerTask extends TimerTask {
        private NotInForegroundTimerTask() {
        }

        public void run() {
            boolean unused = EasyTracker.this.mIsInForeground = false;
        }
    }

    private EasyTracker(Context context) {
        this(context, new ParameterLoaderImpl(context), GoogleAnalytics.getInstance(context), GAServiceManager.getInstance(), null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    private EasyTracker(Context context, ParameterLoader parameterLoader, GoogleAnalytics googleAnalytics, ServiceManager serviceManager, TrackerHandler trackerHandler) {
        super(EASY_TRACKER_NAME, null, trackerHandler == null ? googleAnalytics : trackerHandler);
        this.mIsAutoActivityTracking = false;
        this.mActivitiesActive = 0;
        this.mActivityNameMap = new HashMap();
        this.mIsInForeground = false;
        this.mStartSessionOnNextSend = false;
        if (sResourcePackageName != null) {
            parameterLoader.setResourcePackageName(sResourcePackageName);
        }
        this.mGoogleAnalytics = googleAnalytics;
        setContext(context, parameterLoader, serviceManager);
        this.mClock = new Clock() {
            /* class com.google.analytics.tracking.android.EasyTracker.AnonymousClass1 */

            @Override // com.google.analytics.tracking.android.Clock
            public long currentTimeMillis() {
                return System.currentTimeMillis();
            }
        };
    }

    private void clearExistingTimer() {
        synchronized (this) {
            if (this.mTimer != null) {
                this.mTimer.cancel();
                this.mTimer = null;
            }
        }
    }

    private String getActivityName(Activity activity) {
        String canonicalName = activity.getClass().getCanonicalName();
        if (this.mActivityNameMap.containsKey(canonicalName)) {
            return this.mActivityNameMap.get(canonicalName);
        }
        String string = this.mParameterFetcher.getString(canonicalName);
        if (string == null) {
            string = canonicalName;
        }
        this.mActivityNameMap.put(canonicalName, string);
        return string;
    }

    public static EasyTracker getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new EasyTracker(context);
        }
        return sInstance;
    }

    private Logger.LogLevel getLogLevelFromString(String str) {
        try {
            return Logger.LogLevel.valueOf(str.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @VisibleForTesting
    static EasyTracker getNewInstance(Context context, ParameterLoader parameterLoader, GoogleAnalytics googleAnalytics, ServiceManager serviceManager, TrackerHandler trackerHandler) {
        sInstance = new EasyTracker(context, parameterLoader, googleAnalytics, serviceManager, trackerHandler);
        return sInstance;
    }

    private void loadParameters() {
        Logger.LogLevel logLevelFromString;
        Log.v("Starting EasyTracker.");
        String string = this.mParameterFetcher.getString("ga_trackingId");
        if (TextUtils.isEmpty(string)) {
            string = this.mParameterFetcher.getString("ga_api_key");
        }
        set(Fields.TRACKING_ID, string);
        Log.v("[EasyTracker] trackingId loaded: " + string);
        String string2 = this.mParameterFetcher.getString("ga_appName");
        if (!TextUtils.isEmpty(string2)) {
            Log.v("[EasyTracker] app name loaded: " + string2);
            set(Fields.APP_NAME, string2);
        }
        String string3 = this.mParameterFetcher.getString("ga_appVersion");
        if (string3 != null) {
            Log.v("[EasyTracker] app version loaded: " + string3);
            set(Fields.APP_VERSION, string3);
        }
        String string4 = this.mParameterFetcher.getString("ga_logLevel");
        if (!(string4 == null || (logLevelFromString = getLogLevelFromString(string4)) == null)) {
            Log.v("[EasyTracker] log level loaded: " + logLevelFromString);
            this.mGoogleAnalytics.getLogger().setLogLevel(logLevelFromString);
        }
        Double doubleFromString = this.mParameterFetcher.getDoubleFromString("ga_sampleFrequency");
        if (doubleFromString == null) {
            doubleFromString = new Double((double) this.mParameterFetcher.getInt("ga_sampleRate", DEFAULT_SAMPLE_RATE));
        }
        if (doubleFromString.doubleValue() != 100.0d) {
            set(Fields.SAMPLE_RATE, Double.toString(doubleFromString.doubleValue()));
        }
        Log.v("[EasyTracker] sample rate loaded: " + doubleFromString);
        int i = this.mParameterFetcher.getInt("ga_dispatchPeriod", 1800);
        Log.v("[EasyTracker] dispatch period loaded: " + i);
        this.mServiceManager.setLocalDispatchPeriod(i);
        this.mSessionTimeout = (long) (this.mParameterFetcher.getInt("ga_sessionTimeout", 30) * NUM_MILLISECONDS_TO_WAIT_FOR_OPEN_ACTIVITY);
        Log.v("[EasyTracker] session timeout loaded: " + this.mSessionTimeout);
        this.mIsAutoActivityTracking = this.mParameterFetcher.getBoolean("ga_autoActivityTracking") || this.mParameterFetcher.getBoolean("ga_auto_activity_tracking");
        Log.v("[EasyTracker] auto activity tracking loaded: " + this.mIsAutoActivityTracking);
        boolean z = this.mParameterFetcher.getBoolean("ga_anonymizeIp");
        if (z) {
            set(Fields.ANONYMIZE_IP, GetJarUtils.PVERSION);
            Log.v("[EasyTracker] anonymize ip loaded: " + z);
        }
        this.mIsReportUncaughtExceptionsEnabled = this.mParameterFetcher.getBoolean("ga_reportUncaughtExceptions");
        if (this.mIsReportUncaughtExceptionsEnabled) {
            Thread.setDefaultUncaughtExceptionHandler(new ExceptionReporter(this, this.mServiceManager, Thread.getDefaultUncaughtExceptionHandler(), this.mContext));
            Log.v("[EasyTracker] report uncaught exceptions loaded: " + this.mIsReportUncaughtExceptionsEnabled);
        }
        this.mGoogleAnalytics.setDryRun(this.mParameterFetcher.getBoolean("ga_dryRun"));
    }

    private void setContext(Context context, ParameterLoader parameterLoader, ServiceManager serviceManager) {
        if (context == null) {
            Log.e("Context cannot be null");
        }
        this.mContext = context.getApplicationContext();
        this.mServiceManager = serviceManager;
        this.mParameterFetcher = parameterLoader;
        loadParameters();
    }

    public static void setResourcePackageName(String str) {
        sResourcePackageName = str;
    }

    public void activityStart(Activity activity) {
        GAUsage.getInstance().setUsage(GAUsage.Field.EASY_TRACKER_ACTIVITY_START);
        clearExistingTimer();
        if (!this.mIsInForeground && this.mActivitiesActive == 0 && checkForNewSession()) {
            this.mStartSessionOnNextSend = true;
        }
        this.mIsInForeground = true;
        this.mActivitiesActive++;
        if (this.mIsAutoActivityTracking) {
            HashMap hashMap = new HashMap();
            hashMap.put(Fields.HIT_TYPE, HitTypes.APP_VIEW);
            GAUsage.getInstance().setDisableUsage(true);
            set("&cd", getActivityName(activity));
            send(hashMap);
            GAUsage.getInstance().setDisableUsage(false);
        }
    }

    public void activityStop(Activity activity) {
        GAUsage.getInstance().setUsage(GAUsage.Field.EASY_TRACKER_ACTIVITY_STOP);
        this.mActivitiesActive--;
        this.mActivitiesActive = Math.max(0, this.mActivitiesActive);
        this.mLastOnStopTime = this.mClock.currentTimeMillis();
        if (this.mActivitiesActive == 0) {
            clearExistingTimer();
            this.mTimerTask = new NotInForegroundTimerTask();
            this.mTimer = new Timer("waitForActivityStart");
            this.mTimer.schedule(this.mTimerTask, 1000);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean checkForNewSession() {
        return this.mSessionTimeout == 0 || (this.mSessionTimeout > 0 && this.mClock.currentTimeMillis() > this.mLastOnStopTime + this.mSessionTimeout);
    }

    @Deprecated
    public void dispatchLocalHits() {
        this.mServiceManager.dispatchLocalHits();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public int getActivitiesActive() {
        return this.mActivitiesActive;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void overrideUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        if (this.mIsReportUncaughtExceptionsEnabled) {
            Thread.setDefaultUncaughtExceptionHandler(uncaughtExceptionHandler);
        }
    }

    @Override // com.google.analytics.tracking.android.Tracker
    public void send(Map<String, String> map) {
        if (this.mStartSessionOnNextSend) {
            map.put(Fields.SESSION_CONTROL, "start");
            this.mStartSessionOnNextSend = false;
        }
        super.send(map);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setClock(Clock clock) {
        this.mClock = clock;
    }
}

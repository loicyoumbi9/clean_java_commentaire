package com.google.android.gms.common.util;

public @interface VisibleForTesting {
}

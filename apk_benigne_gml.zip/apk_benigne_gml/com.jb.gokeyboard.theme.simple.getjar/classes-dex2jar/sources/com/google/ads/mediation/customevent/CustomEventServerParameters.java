package com.google.ads.mediation.customevent;

import com.android.vending.util.Base64;
import com.google.ads.mediation.MediationServerParameters;

public class CustomEventServerParameters extends MediationServerParameters {
    @MediationServerParameters.Parameter(name = "class_name", required = Base64.ENCODE)
    public String className;
    @MediationServerParameters.Parameter(name = "label", required = Base64.ENCODE)
    public String label;
    @MediationServerParameters.Parameter(name = "parameter", required = Base64.DECODE)
    public String parameter = null;
}

package com.google.ads;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import com.google.ads.g;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.util.a;
import com.google.ads.util.b;
import java.util.HashMap;

public class h {
    final com.google.ads.internal.h a;
    private final f b;
    private boolean c = false;
    private boolean d = false;
    private g.a e = null;
    private final e f;
    /* access modifiers changed from: private */
    public MediationAdapter<?, ?> g = null;
    private boolean h = false;
    private boolean i = false;
    private View j = null;
    private final String k;
    private final AdRequest l;
    private final HashMap<String, String> m;

    public h(e eVar, com.google.ads.internal.h hVar, f fVar, String str, AdRequest adRequest, HashMap<String, String> hashMap) {
        a.b(TextUtils.isEmpty(str));
        this.f = eVar;
        this.a = hVar;
        this.b = fVar;
        this.k = str;
        this.l = adRequest;
        this.m = hashMap;
    }

    public f a() {
        return this.b;
    }

    public void a(Activity activity) {
        synchronized (this) {
            a.b(this.h, "startLoadAdTask has already been called.");
            this.h = true;
            m.a().c.a().post(new i(this, activity, this.k, this.l, this.m));
        }
    }

    /* access modifiers changed from: package-private */
    public void a(View view) {
        synchronized (this) {
            this.j = view;
        }
    }

    /* access modifiers changed from: package-private */
    public void a(MediationAdapter<?, ?> mediationAdapter) {
        synchronized (this) {
            this.g = mediationAdapter;
        }
    }

    /* access modifiers changed from: package-private */
    public void a(boolean z, g.a aVar) {
        synchronized (this) {
            this.d = z;
            this.c = true;
            this.e = aVar;
            notify();
        }
    }

    public void b() {
        synchronized (this) {
            a.a(this.h, "destroy() called but startLoadAdTask has not been called.");
            m.a().c.a().post(new Runnable() {
                /* class com.google.ads.h.AnonymousClass1 */

                public void run() {
                    if (h.this.l()) {
                        a.b(h.this.g);
                        try {
                            h.this.g.destroy();
                            b.a("Called destroy() for adapter with class: " + h.this.g.getClass().getName());
                        } catch (Throwable th) {
                            b.b("Error while destroying adapter (" + h.this.h() + "):", th);
                        }
                    }
                }
            });
        }
    }

    public boolean c() {
        boolean z;
        synchronized (this) {
            z = this.c;
        }
        return z;
    }

    public boolean d() {
        boolean z;
        synchronized (this) {
            a.a(this.c, "isLoadAdTaskSuccessful() called when isLoadAdTaskDone() is false.");
            z = this.d;
        }
        return z;
    }

    public g.a e() {
        g.a aVar;
        synchronized (this) {
            aVar = this.e == null ? g.a.TIMEOUT : this.e;
        }
        return aVar;
    }

    public View f() {
        View view;
        synchronized (this) {
            a.a(this.c, "getAdView() called when isLoadAdTaskDone() is false.");
            view = this.j;
        }
        return view;
    }

    public void g() {
        synchronized (this) {
            a.a(this.a.a());
            try {
                final MediationInterstitialAdapter mediationInterstitialAdapter = (MediationInterstitialAdapter) this.g;
                m.a().c.a().post(new Runnable() {
                    /* class com.google.ads.h.AnonymousClass2 */

                    public void run() {
                        try {
                            mediationInterstitialAdapter.showInterstitial();
                        } catch (Throwable th) {
                            b.b("Error while telling adapter (" + h.this.h() + ") ad to show interstitial: ", th);
                        }
                    }
                });
            } catch (ClassCastException e2) {
                b.b("In Ambassador.show(): ambassador.adapter does not implement the MediationInterstitialAdapter interface.", e2);
            }
        }
        return;
    }

    public String h() {
        String name;
        synchronized (this) {
            name = this.g != null ? this.g.getClass().getName() : "\"adapter was not created.\"";
        }
        return name;
    }

    /* access modifiers changed from: package-private */
    public MediationAdapter<?, ?> i() {
        MediationAdapter<?, ?> mediationAdapter;
        synchronized (this) {
            mediationAdapter = this.g;
        }
        return mediationAdapter;
    }

    /* access modifiers changed from: package-private */
    public e j() {
        return this.f;
    }

    /* access modifiers changed from: package-private */
    public void k() {
        synchronized (this) {
            this.i = true;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean l() {
        boolean z;
        synchronized (this) {
            z = this.i;
        }
        return z;
    }
}

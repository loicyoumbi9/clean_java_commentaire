package com.google.ads;

import android.app.Activity;
import android.view.View;
import com.google.ads.g;
import com.google.ads.internal.d;
import com.google.ads.util.a;
import com.google.ads.util.b;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class e {
    /* access modifiers changed from: private */
    public final d a;
    /* access modifiers changed from: private */
    public h b;
    private final Object c;
    /* access modifiers changed from: private */
    public Thread d;
    /* access modifiers changed from: private */
    public final Object e;
    private boolean f;
    private final Object g;

    protected e() {
        this.b = null;
        this.c = new Object();
        this.d = null;
        this.e = new Object();
        this.f = false;
        this.g = new Object();
        this.a = null;
    }

    public e(d dVar) {
        this.b = null;
        this.c = new Object();
        this.d = null;
        this.e = new Object();
        this.f = false;
        this.g = new Object();
        a.b(dVar);
        this.a = dVar;
    }

    public static boolean a(c cVar, d dVar) {
        if (cVar.j() == null) {
            return true;
        }
        if (!dVar.i().b()) {
            AdSize c2 = dVar.i().g.a().c();
            if (cVar.j().a()) {
                b.e("AdView received a mediation response corresponding to an interstitial ad. Make sure you specify the banner ad size corresponding to the AdSize you used in your AdView  (" + c2 + ") in the ad-type field in the mediation UI.");
                return false;
            }
            AdSize c3 = cVar.j().c();
            if (c3 == c2) {
                return true;
            }
            b.e("Mediation server returned ad size: '" + c3 + "', while the AdView was created with ad size: '" + c2 + "'. Using the ad-size passed to the AdView on creation.");
            return false;
        } else if (cVar.j().a()) {
            return true;
        } else {
            b.e("InterstitialAd received a mediation response corresponding to a non-interstitial ad. Make sure you specify 'interstitial' as the ad-type in the mediation UI.");
            return false;
        }
    }

    private boolean a(h hVar, String str) {
        if (e() == hVar) {
            return true;
        }
        b.c("GWController: ignoring callback to " + str + " from non showing ambassador with adapter class: '" + hVar.h() + "'.");
        return false;
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean a(java.lang.String r9, android.app.Activity r10, com.google.ads.AdRequest r11, final com.google.ads.f r12, java.util.HashMap<java.lang.String, java.lang.String> r13, long r14) {
        /*
            r8 = this;
            com.google.ads.h r0 = new com.google.ads.h
            com.google.ads.internal.d r1 = r8.a
            com.google.ads.n r1 = r1.i()
            com.google.ads.util.i$b<com.google.ads.internal.h> r1 = r1.g
            java.lang.Object r2 = r1.a()
            com.google.ads.internal.h r2 = (com.google.ads.internal.h) r2
            r1 = r8
            r3 = r12
            r4 = r9
            r5 = r11
            r6 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6)
            monitor-enter(r0)
            r0.a(r10)     // Catch:{ all -> 0x00b8 }
        L_0x001c:
            boolean r1 = r0.c()     // Catch:{ InterruptedException -> 0x0037 }
            if (r1 != 0) goto L_0x004e
            r2 = 0
            int r1 = (r14 > r2 ? 1 : (r14 == r2 ? 0 : -1))
            if (r1 <= 0) goto L_0x004e
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ InterruptedException -> 0x0037 }
            r0.wait(r14)     // Catch:{ InterruptedException -> 0x0037 }
            long r4 = android.os.SystemClock.elapsedRealtime()     // Catch:{ InterruptedException -> 0x0037 }
            long r2 = r4 - r2
            long r14 = r14 - r2
            goto L_0x001c
        L_0x0037:
            r1 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x00b8 }
            r1.<init>()     // Catch:{ all -> 0x00b8 }
            java.lang.String r2 = "Interrupted while waiting for ad network to load ad using adapter class: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x00b8 }
            java.lang.StringBuilder r1 = r1.append(r9)     // Catch:{ all -> 0x00b8 }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x00b8 }
            com.google.ads.util.b.a(r1)     // Catch:{ all -> 0x00b8 }
        L_0x004e:
            com.google.ads.internal.d r1 = r8.a     // Catch:{ all -> 0x00b8 }
            com.google.ads.internal.g r1 = r1.n()     // Catch:{ all -> 0x00b8 }
            com.google.ads.g$a r2 = r0.e()     // Catch:{ all -> 0x00b8 }
            r1.a(r2)     // Catch:{ all -> 0x00b8 }
            boolean r1 = r0.c()     // Catch:{ all -> 0x00b8 }
            if (r1 == 0) goto L_0x0092
            boolean r1 = r0.d()     // Catch:{ all -> 0x00b8 }
            if (r1 == 0) goto L_0x0092
            com.google.ads.internal.d r1 = r8.a     // Catch:{ all -> 0x00b8 }
            com.google.ads.n r1 = r1.i()     // Catch:{ all -> 0x00b8 }
            boolean r1 = r1.b()     // Catch:{ all -> 0x00b8 }
            if (r1 == 0) goto L_0x008c
            r1 = 0
            r2 = r1
        L_0x0075:
            com.google.ads.m r1 = com.google.ads.m.a()     // Catch:{ all -> 0x00b8 }
            com.google.ads.util.i$b<android.os.Handler> r1 = r1.c     // Catch:{ all -> 0x00b8 }
            java.lang.Object r1 = r1.a()     // Catch:{ all -> 0x00b8 }
            android.os.Handler r1 = (android.os.Handler) r1     // Catch:{ all -> 0x00b8 }
            com.google.ads.e$8 r3 = new com.google.ads.e$8     // Catch:{ all -> 0x00b8 }
            r3.<init>(r0, r2, r12)     // Catch:{ all -> 0x00b8 }
            r1.post(r3)     // Catch:{ all -> 0x00b8 }
            monitor-exit(r0)     // Catch:{ all -> 0x00b8 }
            r0 = 1
        L_0x008b:
            return r0
        L_0x008c:
            android.view.View r1 = r0.f()     // Catch:{ all -> 0x00b8 }
            r2 = r1
            goto L_0x0075
        L_0x0092:
            boolean r1 = r0.c()     // Catch:{ all -> 0x00b8 }
            if (r1 != 0) goto L_0x00b2
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x00b8 }
            r1.<init>()     // Catch:{ all -> 0x00b8 }
            java.lang.String r2 = "Timeout occurred in adapter class: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x00b8 }
            java.lang.String r2 = r0.h()     // Catch:{ all -> 0x00b8 }
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x00b8 }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x00b8 }
            com.google.ads.util.b.a(r1)     // Catch:{ all -> 0x00b8 }
        L_0x00b2:
            r0.b()     // Catch:{ all -> 0x00b8 }
            monitor-exit(r0)     // Catch:{ all -> 0x00b8 }
            r0 = 0
            goto L_0x008b
        L_0x00b8:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00b8 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.ads.e.a(java.lang.String, android.app.Activity, com.google.ads.AdRequest, com.google.ads.f, java.util.HashMap, long):boolean");
    }

    /* access modifiers changed from: private */
    public void b(final c cVar, AdRequest adRequest) {
        synchronized (this.e) {
            a.a(Thread.currentThread(), this.d);
        }
        List<a> f2 = cVar.f();
        long b2 = cVar.a() ? (long) cVar.b() : 10000;
        for (a aVar : f2) {
            b.a("Looking to fetch ads from network: " + aVar.b());
            List<String> c2 = aVar.c();
            HashMap<String, String> e2 = aVar.e();
            List<String> d2 = aVar.d();
            String a2 = aVar.a();
            String b3 = aVar.b();
            String c3 = cVar.c();
            if (d2 == null) {
                d2 = cVar.g();
            }
            f fVar = new f(a2, b3, c3, d2, cVar.h(), cVar.i());
            Iterator<String> it = c2.iterator();
            while (true) {
                if (it.hasNext()) {
                    String next = it.next();
                    Activity a3 = this.a.i().c.a();
                    if (a3 == null) {
                        b.a("Activity is null while mediating.  Terminating mediation thread.");
                        return;
                    }
                    this.a.n().c();
                    if (a(next, a3, adRequest, fVar, e2, b2)) {
                        return;
                    }
                    if (d()) {
                        b.a("GWController.destroy() called. Terminating mediation thread.");
                        return;
                    }
                }
            }
        }
        m.a().c.a().post(new Runnable() {
            /* class com.google.ads.e.AnonymousClass7 */

            public void run() {
                e.this.a.b(cVar);
            }
        });
    }

    private boolean d() {
        boolean z;
        synchronized (this.g) {
            z = this.f;
        }
        return z;
    }

    private h e() {
        h hVar;
        synchronized (this.c) {
            hVar = this.b;
        }
        return hVar;
    }

    /* access modifiers changed from: private */
    public boolean e(h hVar) {
        synchronized (this.g) {
            if (!d()) {
                return false;
            }
            hVar.b();
            return true;
        }
    }

    public void a(final c cVar, final AdRequest adRequest) {
        synchronized (this.e) {
            if (a()) {
                b.c("Mediation thread is not done executing previous mediation  request. Ignoring new mediation request");
                return;
            }
            if (cVar.d()) {
                this.a.a((float) cVar.e());
                if (!this.a.t()) {
                    this.a.g();
                }
            } else if (this.a.t()) {
                this.a.f();
            }
            a(cVar, this.a);
            this.d = new Thread(new Runnable() {
                /* class com.google.ads.e.AnonymousClass1 */

                public void run() {
                    e.this.b(cVar, adRequest);
                    synchronized (e.this.e) {
                        Thread unused = e.this.d = (Thread) null;
                    }
                }
            });
            this.d.start();
        }
    }

    public void a(h hVar) {
        if (a(hVar, "onPresentScreen")) {
            m.a().c.a().post(new Runnable() {
                /* class com.google.ads.e.AnonymousClass4 */

                public void run() {
                    e.this.a.v();
                }
            });
        }
    }

    public void a(h hVar, final View view) {
        if (e() != hVar) {
            b.c("GWController: ignoring onAdRefreshed() callback from non-showing ambassador (adapter class name is '" + hVar.h() + "').");
            return;
        }
        this.a.n().a(g.a.AD);
        final f a2 = this.b.a();
        m.a().c.a().post(new Runnable() {
            /* class com.google.ads.e.AnonymousClass3 */

            /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
             method: com.google.ads.internal.d.a(android.view.View, com.google.ads.h, com.google.ads.f, boolean):void
             arg types: [android.view.View, com.google.ads.h, com.google.ads.f, int]
             candidates:
              com.google.ads.internal.d.a(int, int, int, int):void
              com.google.ads.internal.d.a(android.view.View, com.google.ads.h, com.google.ads.f, boolean):void */
            public void run() {
                e.this.a.a(view, e.this.b, a2, true);
            }
        });
    }

    public void a(h hVar, final boolean z) {
        if (a(hVar, "onAdClicked()")) {
            final f a2 = hVar.a();
            m.a().c.a().post(new Runnable() {
                /* class com.google.ads.e.AnonymousClass2 */

                public void run() {
                    e.this.a.a(a2, z);
                }
            });
        }
    }

    public boolean a() {
        boolean z;
        synchronized (this.e) {
            z = this.d != null;
        }
        return z;
    }

    public void b() {
        synchronized (this.g) {
            this.f = true;
            d(null);
            synchronized (this.e) {
                if (this.d != null) {
                    this.d.interrupt();
                }
            }
        }
    }

    public void b(h hVar) {
        if (a(hVar, "onDismissScreen")) {
            m.a().c.a().post(new Runnable() {
                /* class com.google.ads.e.AnonymousClass5 */

                public void run() {
                    e.this.a.u();
                }
            });
        }
    }

    public void c(h hVar) {
        if (a(hVar, "onLeaveApplication")) {
            m.a().c.a().post(new Runnable() {
                /* class com.google.ads.e.AnonymousClass6 */

                public void run() {
                    e.this.a.w();
                }
            });
        }
    }

    public boolean c() {
        a.a(this.a.i().b());
        h e2 = e();
        if (e2 != null) {
            e2.g();
            return true;
        }
        b.b("There is no ad ready to show.");
        return false;
    }

    public void d(h hVar) {
        synchronized (this.c) {
            if (this.b != hVar) {
                if (this.b != null) {
                    this.b.b();
                }
                this.b = hVar;
            }
        }
    }
}

package com.google.ads;

import android.text.TextUtils;
import android.webkit.WebView;
import com.getjar.vending.GetJarUtils;
import com.google.ads.internal.ActivationOverlay;
import com.google.ads.internal.d;
import com.google.ads.util.b;
import java.util.HashMap;

public class aa implements o {
    @Override // com.google.ads.o
    public void a(d dVar, HashMap<String, String> hashMap, WebView webView) {
        int i = -1;
        if (webView instanceof ActivationOverlay) {
            try {
                int parseInt = !TextUtils.isEmpty(hashMap.get("w")) ? Integer.parseInt(hashMap.get("w")) : -1;
                int parseInt2 = !TextUtils.isEmpty(hashMap.get("h")) ? Integer.parseInt(hashMap.get("h")) : -1;
                int parseInt3 = !TextUtils.isEmpty(hashMap.get("x")) ? Integer.parseInt(hashMap.get("x")) : -1;
                if (!TextUtils.isEmpty(hashMap.get("y"))) {
                    i = Integer.parseInt(hashMap.get("y"));
                }
                if (hashMap.get("a") != null && hashMap.get("a").equals(GetJarUtils.PVERSION)) {
                    dVar.a(null, true, parseInt3, i, parseInt, parseInt2);
                } else if (hashMap.get("a") == null || !hashMap.get("a").equals("0")) {
                    dVar.a(parseInt3, i, parseInt, parseInt2);
                } else {
                    dVar.a(null, false, parseInt3, i, parseInt, parseInt2);
                }
            } catch (NumberFormatException e) {
                b.d("Invalid number format in activation overlay response.", e);
            }
        } else {
            b.b("Trying to activate an overlay when this is not an overlay.");
        }
    }
}

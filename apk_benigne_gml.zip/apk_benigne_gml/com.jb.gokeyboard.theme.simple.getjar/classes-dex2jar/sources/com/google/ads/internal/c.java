package com.google.ads.internal;

import android.text.TextUtils;
import android.webkit.WebView;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.l;
import com.google.ads.m;
import com.google.ads.searchads.SearchAdRequest;
import java.util.LinkedList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;

public class c implements Runnable {
    boolean a;
    private String b;
    private String c;
    private String d;
    private String e;
    private boolean f;
    private f g;
    private AdRequest h;
    /* access modifiers changed from: private */
    public WebView i;
    /* access modifiers changed from: private */
    public l j;
    private String k;
    /* access modifiers changed from: private */
    public String l;
    private LinkedList<String> m;
    /* access modifiers changed from: private */
    public String n;
    /* access modifiers changed from: private */
    public AdSize o;
    /* access modifiers changed from: private */
    public boolean p = false;
    private volatile boolean q;
    private boolean r;
    private AdRequest.ErrorCode s;
    private boolean t;
    private int u;
    private Thread v;
    private boolean w;
    private d x = d.ONLINE_SERVER_REQUEST;

    private static class a implements Runnable {
        private final d a;
        private final WebView b;
        private final f c;
        private final AdRequest.ErrorCode d;
        private final boolean e;

        public a(d dVar, WebView webView, f fVar, AdRequest.ErrorCode errorCode, boolean z) {
            this.a = dVar;
            this.b = webView;
            this.c = fVar;
            this.d = errorCode;
            this.e = z;
        }

        public void run() {
            if (this.b != null) {
                this.b.stopLoading();
                this.b.destroy();
            }
            if (this.c != null) {
                this.c.a();
            }
            if (this.e) {
                this.a.l().stopLoading();
                if (this.a.i().i.a() != null) {
                    this.a.i().i.a().setVisibility(8);
                }
            }
            this.a.a(this.d);
        }
    }

    private class b extends Exception {
        public b(String str) {
            super(str);
        }
    }

    /* renamed from: com.google.ads.internal.c$c  reason: collision with other inner class name */
    private class C0000c implements Runnable {
        private final String b;
        private final String c;
        private final WebView d;

        public C0000c(WebView webView, String str, String str2) {
            this.d = webView;
            this.b = str;
            this.c = str2;
        }

        public void run() {
            c.this.j.c.a(Boolean.valueOf(c.this.p));
            c.this.j.a.a().b.a().l().a(c.this.p);
            if (c.this.j.a.a().e.a() != null) {
                c.this.j.a.a().e.a().setOverlayEnabled(!c.this.p);
            }
            if (this.c != null) {
                this.d.loadDataWithBaseURL(this.b, this.c, "text/html", "utf-8", null);
            } else {
                this.d.loadUrl(this.b);
            }
        }
    }

    public enum d {
        ONLINE_USING_BUFFERED_ADS("online_buffered"),
        ONLINE_SERVER_REQUEST("online_request"),
        OFFLINE_USING_BUFFERED_ADS("offline_buffered"),
        OFFLINE_EMPTY("offline_empty");
        
        public String e;

        private d(String str) {
            this.e = str;
        }
    }

    private class e implements Runnable {
        private final d b;
        private final WebView c;
        private final LinkedList<String> d;
        private final int e;
        private final boolean f;
        private final String g;
        private final AdSize h;

        public e(d dVar, WebView webView, LinkedList<String> linkedList, int i, boolean z, String str, AdSize adSize) {
            this.b = dVar;
            this.c = webView;
            this.d = linkedList;
            this.e = i;
            this.f = z;
            this.g = str;
            this.h = adSize;
        }

        public void run() {
            if (this.c != null) {
                this.c.stopLoading();
                this.c.destroy();
            }
            this.b.a(this.d);
            this.b.a(this.e);
            this.b.a(this.f);
            this.b.a(this.g);
            if (this.h != null) {
                c.this.j.a.a().g.a().b(this.h);
                this.b.l().setAdSize(this.h);
            }
            this.b.E();
        }
    }

    protected c() {
    }

    public c(l lVar) {
        this.j = lVar;
        this.k = null;
        this.b = null;
        this.c = null;
        this.d = null;
        this.m = new LinkedList<>();
        this.s = null;
        this.t = false;
        this.u = -1;
        this.f = false;
        this.r = false;
        this.n = null;
        this.o = null;
        if (lVar.a.a().c.a() != null) {
            this.i = new AdWebView(lVar.a.a(), null);
            this.i.setWebViewClient(i.a(lVar.a.a().b.a(), a.b, false, false));
            this.i.setVisibility(8);
            this.i.setWillNotDraw(true);
            this.g = new f(lVar);
            return;
        }
        this.i = null;
        this.g = null;
        com.google.ads.util.b.e("activity was null while trying to create an AdLoader.");
    }

    static void a(String str, com.google.ads.c cVar, com.google.ads.d dVar) {
        if (str != null && !str.contains("no-store") && !str.contains("no-cache")) {
            Matcher matcher = Pattern.compile("max-age\\s*=\\s*(\\d+)").matcher(str);
            if (matcher.find()) {
                try {
                    int parseInt = Integer.parseInt(matcher.group(1));
                    dVar.a(cVar, parseInt);
                    com.google.ads.util.b.c(String.format(Locale.US, "Caching gWhirl configuration for: %d seconds", Integer.valueOf(parseInt)));
                } catch (NumberFormatException e2) {
                    com.google.ads.util.b.b("Caught exception trying to parse cache control directive. Overflow?", e2);
                }
            } else {
                com.google.ads.util.b.c("Unrecognized cacheControlDirective: '" + str + "'. Not caching configuration.");
            }
        }
    }

    private void b(String str, String str2) {
        m.a().c.a().post(new C0000c(this.i, str2, str));
    }

    private String d() {
        return this.h instanceof SearchAdRequest ? "AFMA_buildAdURL" : "AFMA_buildAdURL";
    }

    private String e() {
        return this.h instanceof SearchAdRequest ? "AFMA_getSdkConstants();" : "AFMA_getSdkConstants();";
    }

    private String f() {
        return this.h instanceof SearchAdRequest ? "http://www.gstatic.com/safa/" : "http://media.admob.com/";
    }

    private String g() {
        return this.h instanceof SearchAdRequest ? "<html><head><script src=\"http://www.gstatic.com/safa/sdk-core-v40.js\"></script><script>" : "<html><head><script src=\"http://media.admob.com/sdk-core-v40.js\"></script><script>";
    }

    private String h() {
        return this.h instanceof SearchAdRequest ? "</script></head><body></body></html>" : "</script></head><body></body></html>";
    }

    private void i() {
        AdWebView l2 = this.j.a.a().b.a().l();
        this.j.a.a().b.a().m().c(true);
        this.j.a.a().b.a().n().h();
        m.a().c.a().post(new C0000c(l2, this.b, this.c));
    }

    private void j() {
        m.a().c.a().post(new e(this.j.a.a().b.a(), this.i, this.m, this.u, this.r, this.n, this.o));
    }

    /* JADX WARN: Type inference failed for: r11v0, types: [java.util.Map<java.lang.String, java.lang.Object>, java.util.Map] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String a(java.util.Map<java.lang.String, java.lang.Object> r11, android.app.Activity r12) throws com.google.ads.internal.c.b {
        /*
            r10 = this;
            r8 = 0
            r3 = 0
            r2 = 1
            android.content.Context r4 = r12.getApplicationContext()
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.internal.d> r0 = r0.b
            java.lang.Object r0 = r0.a()
            com.google.ads.internal.d r0 = (com.google.ads.internal.d) r0
            com.google.ads.internal.g r0 = r0.n()
            long r6 = r0.m()
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 <= 0) goto L_0x002f
            java.lang.String r1 = "prl"
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
        L_0x002f:
            long r6 = r0.n()
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 <= 0) goto L_0x0040
            java.lang.String r1 = "prnl"
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
        L_0x0040:
            java.lang.String r1 = r0.l()
            if (r1 == 0) goto L_0x004b
            java.lang.String r5 = "ppcl"
            r11.put(r5, r1)
        L_0x004b:
            java.lang.String r1 = r0.k()
            if (r1 == 0) goto L_0x0056
            java.lang.String r5 = "pcl"
            r11.put(r5, r1)
        L_0x0056:
            long r6 = r0.j()
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 <= 0) goto L_0x0067
            java.lang.String r1 = "pcc"
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
        L_0x0067:
            java.lang.String r1 = "preqs"
            long r6 = r0.o()
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
            java.lang.String r1 = "oar"
            long r6 = r0.p()
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
            java.lang.String r1 = "bas_on"
            long r6 = r0.s()
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
            java.lang.String r1 = "bas_off"
            long r6 = r0.v()
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
            boolean r1 = r0.y()
            if (r1 == 0) goto L_0x00a8
            java.lang.String r1 = "aoi_timeout"
            java.lang.String r5 = "true"
            r11.put(r1, r5)
        L_0x00a8:
            boolean r1 = r0.A()
            if (r1 == 0) goto L_0x00b5
            java.lang.String r1 = "aoi_nofill"
            java.lang.String r5 = "true"
            r11.put(r1, r5)
        L_0x00b5:
            java.lang.String r1 = r0.D()
            if (r1 == 0) goto L_0x00c0
            java.lang.String r5 = "pit"
            r11.put(r5, r1)
        L_0x00c0:
            java.lang.String r1 = "ptime"
            long r6 = com.google.ads.internal.g.E()
            java.lang.Long r5 = java.lang.Long.valueOf(r6)
            r11.put(r1, r5)
            r0.a()
            r0.i()
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            boolean r0 = r0.b()
            if (r0 == 0) goto L_0x030a
            java.lang.String r0 = "format"
            java.lang.String r1 = "interstitial_mb"
            r11.put(r0, r1)
        L_0x00ea:
            java.lang.String r1 = "slotname"
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<java.lang.String> r0 = r0.h
            java.lang.Object r0 = r0.a()
            r11.put(r1, r0)
            java.lang.String r0 = "js"
            java.lang.String r1 = "afma-sdk-a-v6.4.1"
            r11.put(r0, r1)
            java.lang.String r0 = r4.getPackageName()
            android.content.pm.PackageManager r1 = r4.getPackageManager()     // Catch:{ NameNotFoundException -> 0x0371 }
            r5 = 0
            android.content.pm.PackageInfo r0 = r1.getPackageInfo(r0, r5)     // Catch:{ NameNotFoundException -> 0x0371 }
            int r1 = r0.versionCode
            java.lang.String r0 = com.google.ads.util.AdUtil.f(r4)
            boolean r5 = android.text.TextUtils.isEmpty(r0)
            if (r5 != 0) goto L_0x0124
            java.lang.String r5 = "mv"
            r11.put(r5, r0)
        L_0x0124:
            com.google.ads.m r0 = com.google.ads.m.a()
            com.google.ads.util.i$c<java.lang.String> r0 = r0.a
            java.lang.Object r0 = r0.a()
            java.lang.String r0 = (java.lang.String) r0
            boolean r5 = android.text.TextUtils.isEmpty(r0)
            if (r5 != 0) goto L_0x013b
            java.lang.String r5 = "imbf"
            r11.put(r5, r0)
        L_0x013b:
            java.lang.String r0 = "msid"
            java.lang.String r5 = r4.getPackageName()
            r11.put(r0, r5)
            java.lang.String r0 = "app_name"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.StringBuilder r1 = r5.append(r1)
            java.lang.String r5 = ".android."
            java.lang.StringBuilder r1 = r1.append(r5)
            java.lang.String r5 = r4.getPackageName()
            java.lang.StringBuilder r1 = r1.append(r5)
            java.lang.String r1 = r1.toString()
            r11.put(r0, r1)
            java.lang.String r0 = "isu"
            java.lang.String r1 = com.google.ads.util.AdUtil.a(r4)
            r11.put(r0, r1)
            java.lang.String r0 = com.google.ads.util.AdUtil.d(r4)
            if (r0 != 0) goto L_0x0175
            java.lang.String r0 = "null"
        L_0x0175:
            java.lang.String r1 = "net"
            r11.put(r1, r0)
            java.lang.String r0 = com.google.ads.util.AdUtil.e(r4)
            if (r0 == 0) goto L_0x018b
            int r1 = r0.length()
            if (r1 == 0) goto L_0x018b
            java.lang.String r1 = "cap"
            r11.put(r1, r0)
        L_0x018b:
            java.lang.String r0 = "u_audio"
            com.google.ads.util.AdUtil$a r1 = com.google.ads.util.AdUtil.g(r4)
            int r1 = r1.ordinal()
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r11.put(r0, r1)
            android.util.DisplayMetrics r0 = com.google.ads.util.AdUtil.a(r12)
            java.lang.String r1 = "u_sd"
            float r5 = r0.density
            java.lang.Float r5 = java.lang.Float.valueOf(r5)
            r11.put(r1, r5)
            java.lang.String r1 = "u_h"
            int r5 = com.google.ads.util.AdUtil.a(r4, r0)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            r11.put(r1, r5)
            java.lang.String r1 = "u_w"
            int r0 = com.google.ads.util.AdUtil.b(r4, r0)
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r11.put(r1, r0)
            java.lang.String r0 = "hl"
            java.util.Locale r1 = java.util.Locale.getDefault()
            java.lang.String r1 = r1.getLanguage()
            r11.put(r0, r1)
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$c<com.google.ads.ak> r1 = r0.r
            java.lang.Object r1 = r1.a()
            com.google.ads.ak r1 = (com.google.ads.ak) r1
            if (r1 != 0) goto L_0x01fb
            java.lang.String r1 = "afma-sdk-a-v6.4.1"
            com.google.ads.ak r1 = com.google.ads.ak.a(r1, r12)
            com.google.ads.util.i$c<com.google.ads.ak> r5 = r0.r
            r5.a(r1)
            com.google.ads.util.i$c<com.google.ads.al> r0 = r0.s
            com.google.ads.al r5 = new com.google.ads.al
            r5.<init>(r1)
            r0.a(r5)
        L_0x01fb:
            java.lang.String r0 = "ms"
            java.lang.String r1 = r1.a(r4)
            r11.put(r0, r1)
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.AdView> r0 = r0.j
            if (r0 == 0) goto L_0x02bc
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.AdView> r0 = r0.j
            java.lang.Object r0 = r0.a()
            if (r0 == 0) goto L_0x02bc
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.AdView> r0 = r0.j
            java.lang.Object r0 = r0.a()
            com.google.ads.AdView r0 = (com.google.ads.AdView) r0
            android.view.ViewParent r1 = r0.getParent()
            if (r1 == 0) goto L_0x02bc
            r1 = 2
            int[] r1 = new int[r1]
            r0.getLocationOnScreen(r1)
            r5 = r1[r3]
            r6 = r1[r2]
            com.google.ads.l r1 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r1 = r1.a
            java.lang.Object r1 = r1.a()
            com.google.ads.n r1 = (com.google.ads.n) r1
            com.google.ads.util.i$b<android.content.Context> r1 = r1.f
            java.lang.Object r1 = r1.a()
            android.content.Context r1 = (android.content.Context) r1
            android.content.res.Resources r1 = r1.getResources()
            android.util.DisplayMetrics r1 = r1.getDisplayMetrics()
            int r7 = r1.widthPixels
            int r1 = r1.heightPixels
            boolean r8 = r0.isShown()
            if (r8 == 0) goto L_0x04d5
            int r8 = r0.getWidth()
            int r8 = r8 + r5
            if (r8 <= 0) goto L_0x04d5
            int r8 = r0.getHeight()
            int r8 = r8 + r6
            if (r8 <= 0) goto L_0x04d5
            if (r5 > r7) goto L_0x04d5
            if (r6 > r1) goto L_0x04d5
            r1 = r2
        L_0x027d:
            java.util.HashMap r7 = new java.util.HashMap
            r7.<init>()
            java.lang.String r8 = "x"
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            r7.put(r8, r5)
            java.lang.String r5 = "y"
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r7.put(r5, r6)
            java.lang.String r5 = "width"
            int r6 = r0.getWidth()
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r7.put(r5, r6)
            java.lang.String r5 = "height"
            int r0 = r0.getHeight()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r7.put(r5, r0)
            java.lang.String r0 = "visible"
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r7.put(r0, r1)
            java.lang.String r0 = "ad_pos"
            r11.put(r0, r7)
        L_0x02bc:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$c<com.google.ads.AdSize[]> r0 = r0.n
            java.lang.Object r0 = r0.a()
            com.google.ads.AdSize[] r0 = (com.google.ads.AdSize[]) r0
            if (r0 == 0) goto L_0x0383
            int r5 = r0.length
        L_0x02d6:
            if (r3 >= r5) goto L_0x037a
            r6 = r0[r3]
            int r7 = r1.length()
            if (r7 == 0) goto L_0x02e5
            java.lang.String r7 = "|"
            r1.append(r7)
        L_0x02e5:
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            int r8 = r6.getWidth()
            java.lang.StringBuilder r7 = r7.append(r8)
            java.lang.String r8 = "x"
            java.lang.StringBuilder r7 = r7.append(r8)
            int r6 = r6.getHeight()
            java.lang.StringBuilder r6 = r7.append(r6)
            java.lang.String r6 = r6.toString()
            r1.append(r6)
            int r3 = r3 + 1
            goto L_0x02d6
        L_0x030a:
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.internal.h> r0 = r0.g
            java.lang.Object r0 = r0.a()
            com.google.ads.internal.h r0 = (com.google.ads.internal.h) r0
            com.google.ads.AdSize r0 = r0.c()
            boolean r1 = r0.isFullWidth()
            if (r1 == 0) goto L_0x032d
            java.lang.String r1 = "smart_w"
            java.lang.String r5 = "full"
            r11.put(r1, r5)
        L_0x032d:
            boolean r1 = r0.isAutoHeight()
            if (r1 == 0) goto L_0x033a
            java.lang.String r1 = "smart_h"
            java.lang.String r5 = "auto"
            r11.put(r1, r5)
        L_0x033a:
            boolean r1 = r0.isCustomAdSize()
            if (r1 != 0) goto L_0x034b
            java.lang.String r1 = "format"
            java.lang.String r0 = r0.toString()
            r11.put(r1, r0)
            goto L_0x00ea
        L_0x034b:
            java.util.HashMap r1 = new java.util.HashMap
            r1.<init>()
            java.lang.String r5 = "w"
            int r6 = r0.getWidth()
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r1.put(r5, r6)
            java.lang.String r5 = "h"
            int r0 = r0.getHeight()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r1.put(r5, r0)
            java.lang.String r0 = "ad_frame"
            r11.put(r0, r1)
            goto L_0x00ea
        L_0x0371:
            r0 = move-exception
            com.google.ads.internal.c$b r0 = new com.google.ads.internal.c$b
            java.lang.String r1 = "NameNotFoundException"
            r0.<init>(r1)
            throw r0
        L_0x037a:
            java.lang.String r0 = "sz"
            java.lang.String r1 = r1.toString()
            r11.put(r0, r1)
        L_0x0383:
            java.lang.String r0 = "phone"
            java.lang.Object r0 = r4.getSystemService(r0)
            android.telephony.TelephonyManager r0 = (android.telephony.TelephonyManager) r0
            java.lang.String r1 = r0.getNetworkOperator()
            boolean r3 = android.text.TextUtils.isEmpty(r1)
            if (r3 != 0) goto L_0x039a
            java.lang.String r3 = "carrier"
            r11.put(r3, r1)
        L_0x039a:
            java.lang.String r1 = "pt"
            int r3 = r0.getPhoneType()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r11.put(r1, r3)
            java.lang.String r1 = "gnt"
            int r0 = r0.getNetworkType()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r11.put(r1, r0)
            boolean r0 = com.google.ads.util.AdUtil.c()
            if (r0 == 0) goto L_0x03c3
            java.lang.String r0 = "simulator"
            java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
            r11.put(r0, r1)
        L_0x03c3:
            java.lang.String r0 = "session_id"
            com.google.ads.b r1 = com.google.ads.b.a()
            java.math.BigInteger r1 = r1.b()
            java.lang.String r1 = r1.toString()
            r11.put(r0, r1)
            java.lang.String r0 = "seq_num"
            com.google.ads.b r1 = com.google.ads.b.a()
            java.math.BigInteger r1 = r1.c()
            java.lang.String r1 = r1.toString()
            r11.put(r0, r1)
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.internal.h> r0 = r0.g
            java.lang.Object r0 = r0.a()
            com.google.ads.internal.h r0 = (com.google.ads.internal.h) r0
            boolean r0 = r0.b()
            if (r0 == 0) goto L_0x0406
            java.lang.String r0 = "swipeable"
            java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
            r11.put(r0, r1)
        L_0x0406:
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$c<java.lang.Boolean> r0 = r0.t
            java.lang.Object r0 = r0.a()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x0427
            java.lang.String r0 = "d_imp_hdr"
            java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
            r11.put(r0, r1)
        L_0x0427:
            java.lang.String r1 = com.google.ads.util.AdUtil.a(r11)
            com.google.ads.l r0 = r10.j
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a
            java.lang.Object r0 = r0.a()
            com.google.ads.n r0 = (com.google.ads.n) r0
            com.google.ads.util.i$b<com.google.ads.m> r0 = r0.d
            java.lang.Object r0 = r0.a()
            com.google.ads.m r0 = (com.google.ads.m) r0
            com.google.ads.util.i$b<com.google.ads.m$a> r0 = r0.b
            java.lang.Object r0 = r0.a()
            com.google.ads.m$a r0 = (com.google.ads.m.a) r0
            com.google.ads.util.i$c<java.lang.Boolean> r0 = r0.o
            java.lang.Object r0 = r0.a()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x049b
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r2 = r10.g()
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r2 = r10.d()
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r2 = "("
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = ");"
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = r10.h()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
        L_0x0484:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "adRequestUrlHtml: "
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r0)
            java.lang.String r1 = r1.toString()
            com.google.ads.util.b.c(r1)
            return r0
        L_0x049b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r2 = r10.g()
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r2 = r10.e()
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r2 = r10.d()
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r2 = "("
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = ");"
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = r10.h()
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            goto L_0x0484
        L_0x04d5:
            r1 = r3
            goto L_0x027d
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.ads.internal.c.a(java.util.Map, android.app.Activity):java.lang.String");
    }

    /* access modifiers changed from: protected */
    public void a() {
        com.google.ads.util.b.a("AdLoader cancelled.");
        if (this.i != null) {
            this.i.stopLoading();
            this.i.destroy();
        }
        if (this.v != null) {
            this.v.interrupt();
            this.v = null;
        }
        if (this.g != null) {
            this.g.a();
        }
        this.q = true;
    }

    public void a(int i2) {
        synchronized (this) {
            this.u = i2;
        }
    }

    public void a(AdRequest.ErrorCode errorCode) {
        synchronized (this) {
            this.s = errorCode;
            notify();
        }
    }

    /* access modifiers changed from: protected */
    public void a(AdRequest.ErrorCode errorCode, boolean z) {
        m.a().c.a().post(new a(this.j.a.a().b.a(), this.i, this.g, errorCode, z));
    }

    /* access modifiers changed from: protected */
    public void a(AdRequest adRequest) {
        this.h = adRequest;
        this.q = false;
        this.v = new Thread(this);
        this.v.start();
    }

    public void a(AdSize adSize) {
        synchronized (this) {
            this.o = adSize;
        }
    }

    public void a(d dVar) {
        synchronized (this) {
            this.x = dVar;
        }
    }

    /* access modifiers changed from: protected */
    public void a(String str) {
        synchronized (this) {
            this.m.add(str);
        }
    }

    /* access modifiers changed from: protected */
    public void a(String str, String str2) {
        synchronized (this) {
            this.b = str2;
            this.c = str;
            notify();
        }
    }

    public void a(boolean z) {
        synchronized (this) {
            this.p = z;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.google.ads.internal.c.a(com.google.ads.AdRequest$ErrorCode, boolean):void
     arg types: [com.google.ads.AdRequest$ErrorCode, int]
     candidates:
      com.google.ads.internal.c.a(java.util.Map<java.lang.String, java.lang.Object>, android.app.Activity):java.lang.String
      com.google.ads.internal.c.a(java.lang.String, java.lang.String):void
      com.google.ads.internal.c.a(com.google.ads.AdRequest$ErrorCode, boolean):void */
    /* access modifiers changed from: protected */
    public void b() {
        try {
            if (TextUtils.isEmpty(this.e)) {
                com.google.ads.util.b.b("Got a mediation response with no content type. Aborting mediation.");
                a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
            } else if (!this.e.startsWith("application/json")) {
                com.google.ads.util.b.b("Got a mediation response with a content type: '" + this.e + "'. Expected something starting with 'application/json'. Aborting mediation.");
                a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
            } else {
                final com.google.ads.c a2 = com.google.ads.c.a(this.c);
                a(this.d, a2, this.j.a.a().b.a().j());
                m.a().c.a().post(new Runnable() {
                    /* class com.google.ads.internal.c.AnonymousClass2 */

                    public void run() {
                        if (c.this.i != null) {
                            c.this.i.stopLoading();
                            c.this.i.destroy();
                        }
                        c.this.j.a.a().b.a().a(c.this.n);
                        if (c.this.o != null) {
                            c.this.j.a.a().g.a().b(c.this.o);
                        }
                        c.this.j.a.a().b.a().a(a2);
                    }
                });
            }
        } catch (JSONException e2) {
            com.google.ads.util.b.b("AdLoader can't parse gWhirl server configuration.", e2);
            a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
        }
    }

    /* access modifiers changed from: protected */
    public void b(String str) {
        synchronized (this) {
            this.e = str;
        }
    }

    /* access modifiers changed from: protected */
    public void b(boolean z) {
        synchronized (this) {
            this.f = z;
        }
    }

    /* access modifiers changed from: protected */
    public void c() {
        synchronized (this) {
            this.t = true;
            notify();
        }
    }

    /* access modifiers changed from: protected */
    public void c(String str) {
        synchronized (this) {
            this.d = str;
        }
    }

    public void c(boolean z) {
        synchronized (this) {
            this.r = z;
        }
    }

    public void d(String str) {
        synchronized (this) {
            this.k = str;
            notify();
        }
    }

    public void d(boolean z) {
        synchronized (this) {
            this.w = z;
        }
    }

    public void e(String str) {
        synchronized (this) {
            this.l = str;
        }
    }

    public void e(boolean z) {
        synchronized (this) {
            this.a = z;
        }
    }

    public void f(String str) {
        synchronized (this) {
            this.n = str;
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.google.ads.internal.c.a(com.google.ads.AdRequest$ErrorCode, boolean):void
     arg types: [com.google.ads.AdRequest$ErrorCode, int]
     candidates:
      com.google.ads.internal.c.a(java.util.Map<java.lang.String, java.lang.Object>, android.app.Activity):java.lang.String
      com.google.ads.internal.c.a(java.lang.String, java.lang.String):void
      com.google.ads.internal.c.a(com.google.ads.AdRequest$ErrorCode, boolean):void */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x01e9 A[Catch:{ Throwable -> 0x0115 }] */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x02f2 A[SYNTHETIC, Splitter:B:147:0x02f2] */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0313 A[Catch:{ Throwable -> 0x0115 }] */
    /* JADX WARNING: Removed duplicated region for block: B:197:0x042b A[Catch:{ InterruptedException -> 0x042f }, LOOP:1: B:186:0x03fa->B:197:0x042b, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:206:0x044d A[Catch:{ Throwable -> 0x0115 }] */
    /* JADX WARNING: Removed duplicated region for block: B:207:0x0452 A[Catch:{ Throwable -> 0x0115 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r12 = this;
            r10 = 0
            r3 = 0
            monitor-enter(r12)
            android.webkit.WebView r0 = r12.i     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x000c
            com.google.ads.internal.f r0 = r12.g     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x0019
        L_0x000c:
            java.lang.String r0 = "adRequestWebView was null while trying to load an ad."
            com.google.ads.util.b.e(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
        L_0x0018:
            return
        L_0x0019:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$d<android.app.Activity> r0 = r0.c     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            android.app.Activity r0 = (android.app.Activity) r0     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x003d
            java.lang.String r0 = "activity was null while forming an ad request."
            com.google.ads.util.b.e(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x003a:
            r0 = move-exception
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            throw r0
        L_0x003d:
            com.google.ads.l r1 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r1 = r1.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r1 = (com.google.ads.n) r1     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.d> r1 = r1.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.d r1 = (com.google.ads.internal.d) r1     // Catch:{ Throwable -> 0x0115 }
            long r4 = r1.p()     // Catch:{ Throwable -> 0x0115 }
            long r6 = android.os.SystemClock.elapsedRealtime()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest r2 = r12.h     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.l r1 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r1 = r1.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r1 = (com.google.ads.n) r1     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<android.content.Context> r1 = r1.f     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            android.content.Context r1 = (android.content.Context) r1     // Catch:{ Throwable -> 0x0115 }
            java.util.Map r8 = r2.getRequestMap(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "extras"
            java.lang.Object r1 = r8.get(r1)     // Catch:{ Throwable -> 0x0115 }
            boolean r2 = r1 instanceof java.util.Map     // Catch:{ Throwable -> 0x0115 }
            if (r2 == 0) goto L_0x00e1
            java.util.Map r1 = (java.util.Map) r1     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "_adUrl"
            java.lang.Object r2 = r1.get(r2)     // Catch:{ Throwable -> 0x0115 }
            boolean r9 = r2 instanceof java.lang.String     // Catch:{ Throwable -> 0x0115 }
            if (r9 == 0) goto L_0x0089
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Throwable -> 0x0115 }
            r12.b = r2     // Catch:{ Throwable -> 0x0115 }
        L_0x0089:
            java.lang.String r2 = "_requestUrl"
            java.lang.Object r2 = r1.get(r2)     // Catch:{ Throwable -> 0x0115 }
            boolean r9 = r2 instanceof java.lang.String     // Catch:{ Throwable -> 0x0115 }
            if (r9 == 0) goto L_0x0097
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Throwable -> 0x0115 }
            r12.k = r2     // Catch:{ Throwable -> 0x0115 }
        L_0x0097:
            java.lang.String r2 = "_activationOverlayUrl"
            java.lang.Object r2 = r1.get(r2)     // Catch:{ Throwable -> 0x0115 }
            boolean r9 = r2 instanceof java.lang.String     // Catch:{ Throwable -> 0x0115 }
            if (r9 == 0) goto L_0x00a5
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Throwable -> 0x0115 }
            r12.l = r2     // Catch:{ Throwable -> 0x0115 }
        L_0x00a5:
            java.lang.String r2 = "_orientation"
            java.lang.Object r2 = r1.get(r2)     // Catch:{ Throwable -> 0x0115 }
            boolean r9 = r2 instanceof java.lang.String     // Catch:{ Throwable -> 0x0115 }
            if (r9 == 0) goto L_0x00ba
            java.lang.String r9 = "p"
            boolean r9 = r2.equals(r9)     // Catch:{ Throwable -> 0x0115 }
            if (r9 == 0) goto L_0x0109
            r2 = 1
            r12.u = r2     // Catch:{ Throwable -> 0x0115 }
        L_0x00ba:
            java.lang.String r2 = "_norefresh"
            java.lang.Object r1 = r1.get(r2)     // Catch:{ Throwable -> 0x0115 }
            boolean r2 = r1 instanceof java.lang.String     // Catch:{ Throwable -> 0x0115 }
            if (r2 == 0) goto L_0x00e1
            java.lang.String r2 = "t"
            boolean r1 = r1.equals(r2)     // Catch:{ Throwable -> 0x0115 }
            if (r1 == 0) goto L_0x00e1
            com.google.ads.l r1 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r1 = r1.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r1 = (com.google.ads.n) r1     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.d> r1 = r1.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r1 = r1.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.d r1 = (com.google.ads.internal.d) r1     // Catch:{ Throwable -> 0x0115 }
            r1.e()     // Catch:{ Throwable -> 0x0115 }
        L_0x00e1:
            java.lang.String r1 = r12.b     // Catch:{ Throwable -> 0x0115 }
            if (r1 != 0) goto L_0x030e
            java.lang.String r1 = r12.k     // Catch:{ Throwable -> 0x0115 }
            if (r1 != 0) goto L_0x01c2
            java.lang.String r0 = r12.a(r8, r0)     // Catch:{ b -> 0x0124 }
            java.lang.String r1 = r12.f()     // Catch:{ Throwable -> 0x0115 }
            r12.b(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            long r0 = android.os.SystemClock.elapsedRealtime()     // Catch:{ Throwable -> 0x0115 }
            long r0 = r0 - r6
            long r0 = r4 - r0
            int r2 = (r0 > r10 ? 1 : (r0 == r10 ? 0 : -1))
            if (r2 <= 0) goto L_0x0102
            r12.wait(r0)     // Catch:{ InterruptedException -> 0x0144 }
        L_0x0102:
            boolean r0 = r12.q     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x015e
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0109:
            java.lang.String r9 = "l"
            boolean r2 = r2.equals(r9)     // Catch:{ Throwable -> 0x0115 }
            if (r2 == 0) goto L_0x00ba
            r2 = 0
            r12.u = r2     // Catch:{ Throwable -> 0x0115 }
            goto L_0x00ba
        L_0x0115:
            r0 = move-exception
            java.lang.String r1 = "An unknown error occurred in AdLoader."
            com.google.ads.util.b.b(r1, r0)     // Catch:{ all -> 0x003a }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ all -> 0x003a }
            r1 = 1
            r12.a(r0, r1)     // Catch:{ all -> 0x003a }
        L_0x0121:
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0124:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r1.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "Caught internal exception: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r1.append(r0)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0144:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r1.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "AdLoader InterruptedException while getting the URL: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r1.append(r0)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.a(r0)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x015e:
            com.google.ads.AdRequest$ErrorCode r0 = r12.s     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x016b
            com.google.ads.AdRequest$ErrorCode r0 = r12.s     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x016b:
            java.lang.String r0 = r12.k     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x0194
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "AdLoader timed out after "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "ms while getting the URL."
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.NETWORK_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0194:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.h> r0 = r0.g     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.h r0 = (com.google.ads.internal.h) r0     // Catch:{ Throwable -> 0x0115 }
            boolean r0 = r0.b()     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x01c2
            java.lang.String r0 = r12.l     // Catch:{ Throwable -> 0x0115 }
            boolean r0 = android.text.TextUtils.isEmpty(r0)     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x01c2
            java.lang.String r0 = "AdLoader doesn't have a URL for the activation overlay"
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x01c2:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.d> r0 = r0.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.d r0 = (com.google.ads.internal.d) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.g r0 = r0.n()     // Catch:{ Throwable -> 0x0115 }
            int[] r1 = com.google.ads.internal.c.AnonymousClass3.a     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.c$d r2 = r12.x     // Catch:{ Throwable -> 0x0115 }
            int r2 = r2.ordinal()     // Catch:{ Throwable -> 0x0115 }
            r1 = r1[r2]     // Catch:{ Throwable -> 0x0115 }
            switch(r1) {
                case 1: goto L_0x0278;
                case 2: goto L_0x0288;
                case 3: goto L_0x0292;
                case 4: goto L_0x029f;
                default: goto L_0x01e5;
            }     // Catch:{ Throwable -> 0x0115 }
        L_0x01e5:
            boolean r0 = r12.a     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x02f2
            java.lang.String r0 = "Not using loadUrl()."
            com.google.ads.util.b.a(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.f r0 = r12.g     // Catch:{ Throwable -> 0x0115 }
            boolean r1 = r12.w     // Catch:{ Throwable -> 0x0115 }
            r0.a(r1)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.h> r0 = r0.g     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.h r0 = (com.google.ads.internal.h) r0     // Catch:{ Throwable -> 0x0115 }
            boolean r0 = r0.b()     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x0479
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.ActivationOverlay> r0 = r0.e     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.ActivationOverlay r0 = (com.google.ads.internal.ActivationOverlay) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.i r3 = r0.e()     // Catch:{ Throwable -> 0x0115 }
            r0 = 1
            r3.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.m r0 = com.google.ads.m.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<android.os.Handler> r0 = r0.c     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            android.os.Handler r0 = (android.os.Handler) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.c$1 r1 = new com.google.ads.internal.c$1     // Catch:{ Throwable -> 0x0115 }
            r1.<init>()     // Catch:{ Throwable -> 0x0115 }
            r0.post(r1)     // Catch:{ Throwable -> 0x0115 }
            r0 = r3
        L_0x023c:
            com.google.ads.internal.f r1 = r12.g     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = r12.k     // Catch:{ Throwable -> 0x0115 }
            r1.a(r2)     // Catch:{ Throwable -> 0x0115 }
        L_0x0243:
            boolean r1 = r12.q     // Catch:{ InterruptedException -> 0x025e }
            if (r1 != 0) goto L_0x02b5
            com.google.ads.AdRequest$ErrorCode r1 = r12.s     // Catch:{ InterruptedException -> 0x025e }
            if (r1 != 0) goto L_0x02b5
            java.lang.String r1 = r12.c     // Catch:{ InterruptedException -> 0x025e }
            if (r1 != 0) goto L_0x02b5
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ InterruptedException -> 0x025e }
            long r2 = r2 - r6
            long r2 = r4 - r2
            int r1 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1))
            if (r1 <= 0) goto L_0x02b5
            r12.wait(r2)     // Catch:{ InterruptedException -> 0x025e }
            goto L_0x0243
        L_0x025e:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r1.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "AdLoader InterruptedException while getting the ad server's response: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r1.append(r0)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.a(r0)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0278:
            r0.r()     // Catch:{ Throwable -> 0x0115 }
            r0.u()     // Catch:{ Throwable -> 0x0115 }
            r0.x()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = "Request scenario: Online server request."
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            goto L_0x01e5
        L_0x0288:
            r0.t()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = "Request scenario: Online using buffered ads."
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            goto L_0x01e5
        L_0x0292:
            r0.w()     // Catch:{ Throwable -> 0x0115 }
            r0.q()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = "Request scenario: Offline using buffered ads."
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            goto L_0x01e5
        L_0x029f:
            r0.q()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = "Request scenario: Offline with no buffered ads."
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = "Network is unavailable.  Aborting ad request."
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.NETWORK_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x02b5:
            boolean r1 = r12.q     // Catch:{ Throwable -> 0x0115 }
            if (r1 == 0) goto L_0x02bc
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x02bc:
            com.google.ads.AdRequest$ErrorCode r1 = r12.s     // Catch:{ Throwable -> 0x0115 }
            if (r1 == 0) goto L_0x02c9
            com.google.ads.AdRequest$ErrorCode r0 = r12.s     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x02c9:
            java.lang.String r1 = r12.c     // Catch:{ Throwable -> 0x0115 }
            if (r1 != 0) goto L_0x0476
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "AdLoader timed out after "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "ms while waiting for the ad server's response."
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.NETWORK_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x02f2:
            java.lang.String r0 = r12.k     // Catch:{ Throwable -> 0x0115 }
            r12.b = r0     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "Using loadUrl.  adBaseUrl: "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = r12.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.a(r0)     // Catch:{ Throwable -> 0x0115 }
        L_0x030e:
            r1 = r3
        L_0x030f:
            boolean r0 = r12.a     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x03e1
            boolean r0 = r12.f     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x0333
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.d> r0 = r0.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.d r0 = (com.google.ads.internal.d) r0     // Catch:{ Throwable -> 0x0115 }
            r1 = 1
            r0.b(r1)     // Catch:{ Throwable -> 0x0115 }
            r12.b()     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0333:
            java.lang.String r0 = r12.e     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x0372
            java.lang.String r0 = r12.e     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "application/json"
            boolean r0 = r0.startsWith(r2)     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x034b
            java.lang.String r0 = r12.e     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "text/javascript"
            boolean r0 = r0.startsWith(r2)     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x0372
        L_0x034b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "Expected HTML but received "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = r12.e     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "."
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.b(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0372:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$c<com.google.ads.AdSize[]> r0 = r0.n     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x03d5
            com.google.ads.AdSize r0 = r12.o     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x0396
            java.lang.String r0 = "Multiple supported ad sizes were specified, but the server did not respond with a size."
            com.google.ads.util.b.b(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0396:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$c<com.google.ads.AdSize[]> r0 = r0.n     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object[] r0 = (java.lang.Object[]) r0     // Catch:{ Throwable -> 0x0115 }
            java.util.List r0 = java.util.Arrays.asList(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdSize r2 = r12.o     // Catch:{ Throwable -> 0x0115 }
            boolean r0 = r0.contains(r2)     // Catch:{ Throwable -> 0x0115 }
            if (r0 != 0) goto L_0x03e1
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "The ad server did not respond with a supported AdSize: "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdSize r1 = r12.o     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.b(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 0
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x03d5:
            com.google.ads.AdSize r0 = r12.o     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x03e1
            java.lang.String r0 = "adSize was expected to be null in AdLoader."
            com.google.ads.util.b.e(r0)     // Catch:{ Throwable -> 0x0115 }
            r0 = 0
            r12.o = r0     // Catch:{ Throwable -> 0x0115 }
        L_0x03e1:
            com.google.ads.l r0 = r12.j     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.i$b<com.google.ads.internal.d> r0 = r0.b     // Catch:{ Throwable -> 0x0115 }
            java.lang.Object r0 = r0.a()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.internal.d r0 = (com.google.ads.internal.d) r0     // Catch:{ Throwable -> 0x0115 }
            r2 = 0
            r0.b(r2)     // Catch:{ Throwable -> 0x0115 }
            r12.i()     // Catch:{ Throwable -> 0x0115 }
        L_0x03fa:
            boolean r0 = r12.q     // Catch:{ InterruptedException -> 0x042f }
            if (r0 != 0) goto L_0x0449
            boolean r0 = r12.t     // Catch:{ InterruptedException -> 0x042f }
            if (r0 == 0) goto L_0x0420
            com.google.ads.l r0 = r12.j     // Catch:{ InterruptedException -> 0x042f }
            com.google.ads.util.i$b<com.google.ads.n> r0 = r0.a     // Catch:{ InterruptedException -> 0x042f }
            java.lang.Object r0 = r0.a()     // Catch:{ InterruptedException -> 0x042f }
            com.google.ads.n r0 = (com.google.ads.n) r0     // Catch:{ InterruptedException -> 0x042f }
            com.google.ads.util.i$b<com.google.ads.internal.h> r0 = r0.g     // Catch:{ InterruptedException -> 0x042f }
            java.lang.Object r0 = r0.a()     // Catch:{ InterruptedException -> 0x042f }
            com.google.ads.internal.h r0 = (com.google.ads.internal.h) r0     // Catch:{ InterruptedException -> 0x042f }
            boolean r0 = r0.b()     // Catch:{ InterruptedException -> 0x042f }
            if (r0 == 0) goto L_0x0449
            boolean r0 = r1.a()     // Catch:{ InterruptedException -> 0x042f }
            if (r0 == 0) goto L_0x0449
        L_0x0420:
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ InterruptedException -> 0x042f }
            long r2 = r2 - r6
            long r2 = r4 - r2
            int r0 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1))
            if (r0 <= 0) goto L_0x0449
            r12.wait(r2)     // Catch:{ InterruptedException -> 0x042f }
            goto L_0x03fa
        L_0x042f:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r1.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r2 = "AdLoader InterruptedException while loading the HTML: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r1.append(r0)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.a(r0)     // Catch:{ Throwable -> 0x0115 }
            monitor-exit(r12)     // Catch:{ all -> 0x003a }
            goto L_0x0018
        L_0x0449:
            boolean r0 = r12.t     // Catch:{ Throwable -> 0x0115 }
            if (r0 == 0) goto L_0x0452
            r12.j()     // Catch:{ Throwable -> 0x0115 }
            goto L_0x0121
        L_0x0452:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0115 }
            r0.<init>()     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "AdLoader timed out after "
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r1 = "ms while loading the HTML."
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ Throwable -> 0x0115 }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.util.b.c(r0)     // Catch:{ Throwable -> 0x0115 }
            com.google.ads.AdRequest$ErrorCode r0 = com.google.ads.AdRequest.ErrorCode.NETWORK_ERROR     // Catch:{ Throwable -> 0x0115 }
            r1 = 1
            r12.a(r0, r1)     // Catch:{ Throwable -> 0x0115 }
            goto L_0x0121
        L_0x0476:
            r1 = r0
            goto L_0x030f
        L_0x0479:
            r0 = r3
            goto L_0x023c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.ads.internal.c.run():void");
    }
}

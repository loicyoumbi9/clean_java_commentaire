package com.google.ads;

import android.webkit.WebView;
import com.google.ads.internal.d;
import java.util.HashMap;

public interface o {
    void a(d dVar, HashMap<String, String> hashMap, WebView webView);
}

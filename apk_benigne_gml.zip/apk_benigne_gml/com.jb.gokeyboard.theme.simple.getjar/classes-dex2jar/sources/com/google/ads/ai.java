package com.google.ads;

import android.content.Context;

public interface ai {
    String a(Context context);

    String a(Context context, String str);
}

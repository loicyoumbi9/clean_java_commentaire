package com.google.ads;

import android.app.Activity;
import com.google.ads.internal.d;

public class InterstitialAd implements Ad {
    private d a;

    public InterstitialAd(Activity activity, String str) {
        this(activity, str, false);
    }

    public InterstitialAd(Activity activity, String str, boolean z) {
        this.a = new d(this, activity, null, str, null, z);
    }

    @Override // com.google.ads.Ad
    public boolean isReady() {
        return this.a.s();
    }

    @Override // com.google.ads.Ad
    public void loadAd(AdRequest adRequest) {
        this.a.a(adRequest);
    }

    @Override // com.google.ads.Ad
    public void setAdListener(AdListener adListener) {
        this.a.i().o.a(adListener);
    }

    /* access modifiers changed from: protected */
    public void setAppEventListener(AppEventListener appEventListener) {
        this.a.i().p.a(appEventListener);
    }

    public void show() {
        this.a.B();
    }

    @Override // com.google.ads.Ad
    public void stopLoading() {
        this.a.C();
    }
}

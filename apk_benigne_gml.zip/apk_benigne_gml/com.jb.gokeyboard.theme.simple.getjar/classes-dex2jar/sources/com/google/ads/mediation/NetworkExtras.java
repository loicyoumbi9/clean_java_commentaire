package com.google.ads.mediation;

public interface NetworkExtras {
}

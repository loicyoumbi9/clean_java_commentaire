package com.google.ads;

public interface AppEventListener {
    void onAppEvent(Ad ad, String str, String str2);
}

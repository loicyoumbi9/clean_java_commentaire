package com.google.ads.mediation;

public final class EmptyNetworkExtras implements NetworkExtras {
}

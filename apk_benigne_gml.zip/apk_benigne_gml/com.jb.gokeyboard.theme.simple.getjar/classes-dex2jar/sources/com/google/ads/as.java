package com.google.ads;

import android.net.Uri;

public class as {
    public static final Uri a = Uri.parse("content://com.google.plus.platform/token");
    public static final String[] b = {"drt"};
}

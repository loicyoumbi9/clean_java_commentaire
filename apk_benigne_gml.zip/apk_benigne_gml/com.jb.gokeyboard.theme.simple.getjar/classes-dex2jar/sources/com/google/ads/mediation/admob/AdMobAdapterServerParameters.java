package com.google.ads.mediation.admob;

import com.android.vending.util.Base64;
import com.google.ads.mediation.MediationServerParameters;

public final class AdMobAdapterServerParameters extends MediationServerParameters {
    @MediationServerParameters.Parameter(name = "pubid")
    public String adUnitId;
    @MediationServerParameters.Parameter(name = "mad_hac", required = Base64.DECODE)
    public String allowHouseAds = null;
}

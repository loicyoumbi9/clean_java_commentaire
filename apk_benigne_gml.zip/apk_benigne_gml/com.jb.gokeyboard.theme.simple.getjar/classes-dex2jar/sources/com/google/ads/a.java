package com.google.ads;

import java.util.HashMap;
import java.util.List;

public class a {
    private final String a;
    private final String b;
    private final List<String> c;
    private final List<String> d;
    private final HashMap<String, String> e;

    public a(String str, String str2, List<String> list, List<String> list2, HashMap<String, String> hashMap) {
        com.google.ads.util.a.a(str2);
        if (str != null) {
            com.google.ads.util.a.a(str);
        }
        this.a = str;
        this.b = str2;
        this.c = list;
        this.e = hashMap;
        this.d = list2;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public List<String> c() {
        return this.c;
    }

    public List<String> d() {
        return this.d;
    }

    public HashMap<String, String> e() {
        return this.e;
    }
}

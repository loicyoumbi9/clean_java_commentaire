package com.google.ads.mediation.customevent;

public interface CustomEvent {
    void destroy();
}

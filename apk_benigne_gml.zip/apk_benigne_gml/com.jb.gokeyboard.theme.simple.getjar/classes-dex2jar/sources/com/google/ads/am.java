package com.google.ads;

public class am extends Exception {
    public am() {
    }

    public am(String str) {
        super(str);
    }
}

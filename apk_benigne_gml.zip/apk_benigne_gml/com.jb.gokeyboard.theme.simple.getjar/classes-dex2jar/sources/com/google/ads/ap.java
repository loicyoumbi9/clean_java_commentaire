package com.google.ads;

public class ap extends IllegalArgumentException {
    public ap() {
    }

    public ap(String str) {
        super(str);
    }
}

package com.google.ads;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class b {
    private static b c = null;
    private final BigInteger a = d();
    private BigInteger b = BigInteger.ONE;

    private b() {
    }

    public static b a() {
        b bVar;
        synchronized (b.class) {
            try {
                if (c == null) {
                    c = new b();
                }
                bVar = c;
            } catch (Throwable th) {
                throw th;
            }
        }
        return bVar;
    }

    private static byte[] a(long j) {
        return BigInteger.valueOf(j).toByteArray();
    }

    private static BigInteger d() {
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            UUID randomUUID = UUID.randomUUID();
            instance.update(a(randomUUID.getLeastSignificantBits()));
            instance.update(a(randomUUID.getMostSignificantBits()));
            byte[] bArr = new byte[9];
            bArr[0] = 0;
            System.arraycopy(instance.digest(), 0, bArr, 1, 8);
            return new BigInteger(bArr);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Cannot find MD5 message digest algorithm.");
        }
    }

    public BigInteger b() {
        BigInteger bigInteger;
        synchronized (this) {
            bigInteger = this.a;
        }
        return bigInteger;
    }

    public BigInteger c() {
        BigInteger bigInteger;
        synchronized (this) {
            bigInteger = this.b;
            this.b = this.b.add(BigInteger.ONE);
        }
        return bigInteger;
    }
}

package com.google.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.ads.Ad;
import com.google.ads.AdActivity;
import com.google.ads.AdListener;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;
import com.google.ads.AppEventListener;
import com.google.ads.InterstitialAd;
import com.google.ads.ae;
import com.google.ads.af;
import com.google.ads.at;
import com.google.ads.b;
import com.google.ads.c;
import com.google.ads.doubleclick.SwipeableDfpAdView;
import com.google.ads.e;
import com.google.ads.f;
import com.google.ads.g;
import com.google.ads.h;
import com.google.ads.l;
import com.google.ads.m;
import com.google.ads.n;
import com.google.ads.util.AdUtil;
import com.google.ads.util.IcsUtil;
import com.google.ads.util.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

public class d {
    private static final Object a = new Object();
    private String A = null;
    private String B = null;
    private final n b;
    private c c;
    private AdRequest d;
    private g e;
    private AdWebView f;
    private i g;
    private boolean h = false;
    private long i;
    private boolean j;
    private boolean k;
    private boolean l;
    private boolean m;
    private boolean n;
    private SharedPreferences o;
    private long p;
    private af q;
    private boolean r;
    private LinkedList<String> s;
    private LinkedList<String> t;
    private LinkedList<String> u;
    private int v = -1;
    private Boolean w;
    private com.google.ads.d x;
    private e y;
    private f z;

    public d(Ad ad, Activity activity, AdSize adSize, String str, ViewGroup viewGroup, boolean z2) {
        this.r = z2;
        this.e = new g();
        this.c = null;
        this.d = null;
        this.k = false;
        this.p = 60000;
        this.l = false;
        this.n = false;
        this.m = true;
        h a2 = adSize == null ? h.a : h.a(adSize, activity.getApplicationContext());
        if (ad instanceof SwipeableDfpAdView) {
            a2.a(true);
        }
        if (activity == null) {
            this.b = new n(m.a(), ad, ad instanceof AdView ? (AdView) ad : null, ad instanceof InterstitialAd ? (InterstitialAd) ad : null, str, null, null, viewGroup, a2, this);
            return;
        }
        synchronized (a) {
            this.o = activity.getApplicationContext().getSharedPreferences("GoogleAdMobAdsPrefs", 0);
            if (z2) {
                long j2 = this.o.getLong("Timeout" + str, -1);
                if (j2 < 0) {
                    this.i = 5000;
                } else {
                    this.i = j2;
                }
            } else {
                this.i = 60000;
            }
        }
        this.b = new n(m.a(), ad, ad instanceof AdView ? (AdView) ad : null, ad instanceof InterstitialAd ? (InterstitialAd) ad : null, str, activity, activity.getApplicationContext(), viewGroup, a2, this);
        this.q = new af(this);
        this.s = new LinkedList<>();
        this.t = new LinkedList<>();
        this.u = new LinkedList<>();
        a();
        AdUtil.h(this.b.f.a());
        this.x = new com.google.ads.d();
        this.y = new e(this);
        this.w = null;
        this.z = null;
    }

    private void a(f fVar, Boolean bool) {
        List d2 = fVar.d();
        if (d2 == null) {
            d2 = new ArrayList();
            d2.add("http://e.admob.com/imp?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&ad_network_id=@gw_adnetid@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@&nr=@gw_adnetrefresh@&adt=@gw_adt@&aec=@gw_aec@");
        }
        a(d2, fVar.a(), fVar.b(), fVar.c(), bool, this.e.d(), this.e.e());
    }

    private void a(List<String> list, String str) {
        List<String> list2;
        if (list == null) {
            list2 = new ArrayList<>();
            list2.add("http://e.admob.com/nofill?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@&adt=@gw_adt@&aec=@gw_aec@");
        } else {
            list2 = list;
        }
        a(list2, null, null, str, null, this.e.d(), this.e.e());
    }

    private void a(List<String> list, String str, String str2, String str3, Boolean bool, String str4, String str5) {
        String a2 = AdUtil.a(this.b.f.a());
        b a3 = b.a();
        String bigInteger = a3.b().toString();
        String bigInteger2 = a3.c().toString();
        for (String str6 : list) {
            new Thread(new ae(g.a(str6, this.b.h.a(), bool, a2, str, str2, str3, bigInteger, bigInteger2, str4, str5), this.b.f.a())).start();
        }
        this.e.b();
    }

    private void b(f fVar, Boolean bool) {
        List e2 = fVar.e();
        if (e2 == null) {
            e2 = new ArrayList();
            e2.add("http://e.admob.com/clk?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&ad_network_id=@gw_adnetid@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@&nr=@gw_adnetrefresh@");
        }
        a(e2, fVar.a(), fVar.b(), fVar.c(), bool, null, null);
    }

    public void A() {
        synchronized (this) {
            if (!this.h) {
                if (this.d == null) {
                    com.google.ads.util.b.a("Tried to refresh before calling loadAd().");
                } else if (this.b.a()) {
                    if (!this.b.j.a().isShown() || !AdUtil.d()) {
                        com.google.ads.util.b.a("Not refreshing because the ad is not visible.");
                    } else {
                        com.google.ads.util.b.c("Refreshing ad.");
                        a(this.d);
                    }
                    if (this.n) {
                        f();
                    } else {
                        m.a().c.a().postDelayed(this.q, this.p);
                    }
                } else {
                    com.google.ads.util.b.a("Tried to refresh an ad that wasn't an AdView.");
                }
            }
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: com.google.ads.internal.d.a(com.google.ads.f, java.lang.Boolean):void
     arg types: [com.google.ads.f, int]
     candidates:
      com.google.ads.internal.d.a(java.util.List<java.lang.String>, java.lang.String):void
      com.google.ads.internal.d.a(com.google.ads.f, boolean):void
      com.google.ads.internal.d.a(java.lang.String, java.lang.String):void
      com.google.ads.internal.d.a(com.google.ads.f, java.lang.Boolean):void */
    public void B() {
        synchronized (this) {
            a.a(this.b.b());
            if (this.k) {
                this.k = false;
                if (this.w == null) {
                    com.google.ads.util.b.b("isMediationFlag is null in show() with isReady() true. we should have an ad and know whether this is a mediation request or not. ");
                } else if (!this.w.booleanValue()) {
                    AdActivity.launchAdActivity(this, new e("interstitial"));
                    y();
                } else if (this.y.c()) {
                    a(this.z, (Boolean) false);
                }
            } else {
                com.google.ads.util.b.c("Cannot show interstitial because it is not loaded and ready.");
            }
        }
    }

    public void C() {
        synchronized (this) {
            if (this.c != null) {
                this.c.a();
                this.c = null;
            }
            if (this.f != null) {
                this.f.stopLoading();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void D() {
        synchronized (this) {
            Activity a2 = this.b.c.a();
            if (a2 == null) {
                com.google.ads.util.b.e("activity was null while trying to ping click tracking URLs.");
            } else {
                Iterator<String> it = this.u.iterator();
                while (it.hasNext()) {
                    new Thread(new ae(it.next(), a2.getApplicationContext())).start();
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void E() {
        synchronized (this) {
            this.c = null;
            this.k = true;
            this.f.setVisibility(0);
            if (this.b.a()) {
                a(this.f);
            }
            this.e.g();
            if (this.b.a()) {
                y();
            }
            com.google.ads.util.b.c("onReceiveAd()");
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onReceiveAd(this.b.a.a());
            }
            this.b.l.a(this.b.m.a());
            this.b.m.a(null);
        }
    }

    public LinkedList<String> F() {
        return this.t;
    }

    public void a() {
        synchronized (this) {
            AdSize c2 = this.b.g.a().c();
            this.f = AdUtil.a >= 14 ? new IcsUtil.IcsAdWebView(this.b, c2) : new AdWebView(this.b, c2);
            this.f.setVisibility(8);
            this.g = i.a(this, a.d, true, this.b.b());
            this.f.setWebViewClient(this.g);
            if (AdUtil.a < this.b.d.a().b.a().b.a().intValue() && !this.b.g.a().a()) {
                com.google.ads.util.b.a("Disabling hardware acceleration for a banner.");
                this.f.g();
            }
        }
    }

    public void a(float f2) {
        synchronized (this) {
            long j2 = this.p;
            this.p = (long) (1000.0f * f2);
            if (t() && this.p != j2) {
                f();
                g();
            }
        }
    }

    public void a(int i2) {
        synchronized (this) {
            this.v = i2;
        }
    }

    public void a(int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        ActivationOverlay a2 = this.b.e.a();
        int a3 = AdUtil.a(this.b.f.a(), i4 < 0 ? this.b.g.a().c().getWidth() : i4);
        Context a4 = this.b.f.a();
        if (i5 < 0) {
            i5 = this.b.g.a().c().getHeight();
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(a3, AdUtil.a(a4, i5));
        if (i4 < 0) {
            i6 = 0;
            i7 = 0;
        } else {
            i6 = i2;
            i7 = i3;
        }
        int d2 = i6 < 0 ? this.b.e.a().d() : i6;
        if (i7 < 0) {
            i7 = this.b.e.a().c();
        }
        this.b.e.a().setXPosition(d2);
        this.b.e.a().setYPosition(i7);
        layoutParams.setMargins(AdUtil.a(this.b.f.a(), d2), AdUtil.a(this.b.f.a(), i7), 0, 0);
        a2.setLayoutParams(layoutParams);
    }

    public void a(long j2) {
        synchronized (a) {
            SharedPreferences.Editor edit = this.o.edit();
            edit.putLong("Timeout" + this.b.h, j2);
            edit.commit();
            if (this.r) {
                this.i = j2;
            }
        }
    }

    public void a(View view) {
        this.b.i.a().setVisibility(0);
        this.b.i.a().removeAllViews();
        this.b.i.a().addView(view);
        if (this.b.g.a().b()) {
            this.b.b.a().a(this.b.l.a(), false, -1, -1, -1, -1);
            if (this.b.e.a().a()) {
                this.b.i.a().addView(this.b.e.a(), AdUtil.a(this.b.f.a(), this.b.g.a().c().getWidth()), AdUtil.a(this.b.f.a(), this.b.g.a().c().getHeight()));
            }
        }
    }

    public void a(View view, h hVar, f fVar, boolean z2) {
        synchronized (this) {
            com.google.ads.util.b.a("AdManager.onReceiveGWhirlAd() called.");
            this.k = true;
            this.z = fVar;
            if (this.b.a()) {
                a(view);
                a(fVar, Boolean.valueOf(z2));
            }
            this.y.d(hVar);
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onReceiveAd(this.b.a.a());
            }
        }
    }

    public void a(AdRequest.ErrorCode errorCode) {
        synchronized (this) {
            this.c = null;
            if (errorCode == AdRequest.ErrorCode.NETWORK_ERROR) {
                a(60.0f);
                if (!t()) {
                    h();
                }
            }
            if (this.b.b()) {
                if (errorCode == AdRequest.ErrorCode.NO_FILL) {
                    this.e.B();
                } else if (errorCode == AdRequest.ErrorCode.NETWORK_ERROR) {
                    this.e.z();
                }
            }
            com.google.ads.util.b.c("onFailedToReceiveAd(" + errorCode + ")");
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onFailedToReceiveAd(this.b.a.a(), errorCode);
            }
        }
    }

    public void a(AdRequest adRequest) {
        synchronized (this) {
            com.google.ads.util.b.d("v6.4.1 RC00");
            if (this.h) {
                com.google.ads.util.b.e("loadAd called after ad was destroyed.");
            } else if (q()) {
                com.google.ads.util.b.e("loadAd called while the ad is already loading, so aborting.");
            } else if (AdActivity.isShowing()) {
                com.google.ads.util.b.e("loadAd called while an interstitial or landing page is displayed, so aborting");
            } else if (AdUtil.c(this.b.f.a()) && AdUtil.b(this.b.f.a())) {
                if (at.a(this.b.f.a(), this.o.getLong("GoogleAdMobDoritosLife", 60000))) {
                    at.a(this.b.c.a());
                }
                this.k = false;
                this.s.clear();
                this.t.clear();
                this.d = adRequest;
                if (this.x.a()) {
                    this.y.a(this.x.b(), adRequest);
                } else {
                    l lVar = new l(this.b);
                    this.b.m.a(lVar);
                    this.c = lVar.b.a();
                    this.c.a(adRequest);
                }
            }
        }
    }

    public void a(c cVar) {
        synchronized (this) {
            this.c = null;
            this.y.a(cVar, this.d);
        }
    }

    public void a(f fVar, boolean z2) {
        synchronized (this) {
            com.google.ads.util.b.a(String.format(Locale.US, "AdManager.onGWhirlAdClicked(%b) called.", Boolean.valueOf(z2)));
            b(fVar, Boolean.valueOf(z2));
        }
    }

    public void a(l lVar, boolean z2, int i2, int i3, int i4, int i5) {
        this.b.e.a().setOverlayActivated(!z2);
        a(i2, i3, i4, i5);
        if (this.b.q.a() == null) {
            return;
        }
        if (z2) {
            this.b.q.a().onAdActivated(this.b.a.a());
        } else {
            this.b.q.a().onAdDeactivated(this.b.a.a());
        }
    }

    public void a(String str) {
        this.B = str;
        Uri build = new Uri.Builder().encodedQuery(str).build();
        StringBuilder sb = new StringBuilder();
        HashMap<String, String> b2 = AdUtil.b(build);
        for (String str2 : b2.keySet()) {
            sb.append(str2).append(" = ").append(b2.get(str2)).append("\n");
        }
        this.A = sb.toString().trim();
        if (TextUtils.isEmpty(this.A)) {
            this.A = null;
        }
    }

    public void a(String str, String str2) {
        synchronized (this) {
            AppEventListener a2 = this.b.p.a();
            if (a2 != null) {
                a2.onAppEvent(this.b.a.a(), str, str2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void a(LinkedList<String> linkedList) {
        synchronized (this) {
            Iterator<String> it = linkedList.iterator();
            while (it.hasNext()) {
                com.google.ads.util.b.a("Adding a click tracking URL: " + it.next());
            }
            this.u = linkedList;
        }
    }

    public void a(boolean z2) {
        synchronized (this) {
            this.j = z2;
        }
    }

    public void b() {
        synchronized (this) {
            if (this.y != null) {
                this.y.b();
            }
            this.b.o.a(null);
            this.b.p.a(null);
            C();
            f();
            if (this.f != null) {
                this.f.destroy();
            }
            this.h = true;
        }
    }

    public void b(long j2) {
        synchronized (this) {
            if (j2 > 0) {
                this.o.edit().putLong("GoogleAdMobDoritosLife", j2).commit();
            }
        }
    }

    public void b(c cVar) {
        synchronized (this) {
            com.google.ads.util.b.a("AdManager.onGWhirlNoFill() called.");
            a(cVar.i(), cVar.c());
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onFailedToReceiveAd(this.b.a.a(), AdRequest.ErrorCode.NO_FILL);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void b(String str) {
        synchronized (this) {
            com.google.ads.util.b.a("Adding a tracking URL: " + str);
            this.s.add(str);
        }
    }

    public void b(boolean z2) {
        this.w = Boolean.valueOf(z2);
    }

    public String c() {
        return this.A;
    }

    /* access modifiers changed from: protected */
    public void c(String str) {
        synchronized (this) {
            com.google.ads.util.b.a("Adding a manual tracking URL: " + str);
            F().add(str);
        }
    }

    public String d() {
        return this.B;
    }

    public void e() {
        synchronized (this) {
            this.m = false;
            com.google.ads.util.b.a("Refreshing is no longer allowed on this AdView.");
        }
    }

    public void f() {
        synchronized (this) {
            if (this.l) {
                com.google.ads.util.b.a("Disabling refreshing.");
                m.a().c.a().removeCallbacks(this.q);
                this.l = false;
            } else {
                com.google.ads.util.b.a("Refreshing is already disabled.");
            }
        }
    }

    public void g() {
        synchronized (this) {
            this.n = false;
            if (!this.b.a()) {
                com.google.ads.util.b.a("Tried to enable refreshing on something other than an AdView.");
            } else if (!this.m) {
                com.google.ads.util.b.a("Refreshing disabled on this AdView");
            } else if (!this.l) {
                com.google.ads.util.b.a("Enabling refreshing every " + this.p + " milliseconds.");
                m.a().c.a().postDelayed(this.q, this.p);
                this.l = true;
            } else {
                com.google.ads.util.b.a("Refreshing is already enabled.");
            }
        }
    }

    public void h() {
        g();
        this.n = true;
    }

    public n i() {
        return this.b;
    }

    public com.google.ads.d j() {
        com.google.ads.d dVar;
        synchronized (this) {
            dVar = this.x;
        }
        return dVar;
    }

    public c k() {
        c cVar;
        synchronized (this) {
            cVar = this.c;
        }
        return cVar;
    }

    public AdWebView l() {
        AdWebView adWebView;
        synchronized (this) {
            adWebView = this.f;
        }
        return adWebView;
    }

    public i m() {
        i iVar;
        synchronized (this) {
            iVar = this.g;
        }
        return iVar;
    }

    public g n() {
        return this.e;
    }

    public int o() {
        int i2;
        synchronized (this) {
            i2 = this.v;
        }
        return i2;
    }

    public long p() {
        return this.i;
    }

    public boolean q() {
        boolean z2;
        synchronized (this) {
            z2 = this.c != null;
        }
        return z2;
    }

    public boolean r() {
        boolean z2;
        synchronized (this) {
            z2 = this.j;
        }
        return z2;
    }

    public boolean s() {
        boolean z2;
        synchronized (this) {
            z2 = this.k;
        }
        return z2;
    }

    public boolean t() {
        boolean z2;
        synchronized (this) {
            z2 = this.l;
        }
        return z2;
    }

    public void u() {
        synchronized (this) {
            this.e.C();
            com.google.ads.util.b.c("onDismissScreen()");
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onDismissScreen(this.b.a.a());
            }
        }
    }

    public void v() {
        synchronized (this) {
            com.google.ads.util.b.c("onPresentScreen()");
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onPresentScreen(this.b.a.a());
            }
        }
    }

    public void w() {
        synchronized (this) {
            com.google.ads.util.b.c("onLeaveApplication()");
            AdListener a2 = this.b.o.a();
            if (a2 != null) {
                a2.onLeaveApplication(this.b.a.a());
            }
        }
    }

    public void x() {
        this.e.f();
        D();
    }

    public void y() {
        synchronized (this) {
            Activity a2 = this.b.c.a();
            if (a2 == null) {
                com.google.ads.util.b.e("activity was null while trying to ping tracking URLs.");
            } else {
                Iterator<String> it = this.s.iterator();
                while (it.hasNext()) {
                    new Thread(new ae(it.next(), a2.getApplicationContext())).start();
                }
            }
        }
    }

    public void z() {
        synchronized (this) {
            Activity a2 = this.b.c.a();
            if (a2 == null) {
                com.google.ads.util.b.e("activity was null while trying to ping manual tracking URLs.");
            } else {
                Iterator<String> it = this.t.iterator();
                while (it.hasNext()) {
                    new Thread(new ae(it.next(), a2.getApplicationContext())).start();
                }
            }
        }
    }
}

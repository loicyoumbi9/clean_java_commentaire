package com.google.tagmanager;

interface HitStoreStateListener {
    void reportStoreIsEmpty(boolean z);
}

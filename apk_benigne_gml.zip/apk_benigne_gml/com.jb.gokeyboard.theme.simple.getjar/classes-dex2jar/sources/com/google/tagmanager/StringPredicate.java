package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

abstract class StringPredicate extends Predicate {
    public StringPredicate(String str) {
        super(str);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.Predicate
    public boolean evaluateNoDefaultValues(TypeSystem.Value value, TypeSystem.Value value2, Map<String, TypeSystem.Value> map) {
        String valueToString = Types.valueToString(value);
        String valueToString2 = Types.valueToString(value2);
        if (valueToString == Types.getDefaultString() || valueToString2 == Types.getDefaultString()) {
            return false;
        }
        return evaluateString(valueToString, valueToString2, map);
    }

    /* access modifiers changed from: protected */
    public abstract boolean evaluateString(String str, String str2, Map<String, TypeSystem.Value> map);
}

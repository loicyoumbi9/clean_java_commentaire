package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

class RegexGroupMacro extends FunctionCallImplementation {
    private static final String GROUP = Key.GROUP.toString();
    private static final String ID = FunctionType.REGEX_GROUP.toString();
    private static final String IGNORE_CASE = Key.IGNORE_CASE.toString();
    private static final String REGEX = Key.ARG1.toString();
    private static final String TO_MATCH = Key.ARG0.toString();

    public RegexGroupMacro() {
        super(ID, TO_MATCH, REGEX);
    }

    public static String getFunctionId() {
        return ID;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        int i;
        TypeSystem.Value value = map.get(TO_MATCH);
        TypeSystem.Value value2 = map.get(REGEX);
        if (value == null || value == Types.getDefaultValue() || value2 == null || value2 == Types.getDefaultValue()) {
            return Types.getDefaultValue();
        }
        int i2 = 64;
        if (Types.valueToBoolean(map.get(IGNORE_CASE)).booleanValue()) {
            i2 = 66;
        }
        TypeSystem.Value value3 = map.get(GROUP);
        if (value3 != null) {
            Long valueToInt64 = Types.valueToInt64(value3);
            if (valueToInt64 == Types.getDefaultInt64()) {
                return Types.getDefaultValue();
            }
            i = valueToInt64.intValue();
            if (i < 0) {
                return Types.getDefaultValue();
            }
        } else {
            i = 1;
        }
        try {
            String valueToString = Types.valueToString(value);
            String str = null;
            Matcher matcher = Pattern.compile(Types.valueToString(value2), i2).matcher(valueToString);
            if (matcher.find() && matcher.groupCount() >= i) {
                str = matcher.group(i);
            }
            return str == null ? Types.getDefaultValue() : Types.objectToValue(str);
        } catch (PatternSyntaxException e) {
            return Types.getDefaultValue();
        }
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return true;
    }
}

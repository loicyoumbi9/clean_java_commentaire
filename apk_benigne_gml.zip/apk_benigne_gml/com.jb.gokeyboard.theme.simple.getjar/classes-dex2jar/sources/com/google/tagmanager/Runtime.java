package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.tagmanager.CacheFactory;
import com.google.tagmanager.CustomFunctionCall;
import com.google.tagmanager.ResourceUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

class Runtime {
    static final String DEFAULT_RULE_NAME = "Unknown";
    private static final ObjectAndStatic<TypeSystem.Value> DEFAULT_VALUE_AND_STATIC = new ObjectAndStatic<>(Types.getDefaultValue(), true);
    private static final int MAX_CACHE_SIZE = 1048576;
    private final EventInfoDistributor eventInfoDistributor;
    private volatile String mCurrentEventName;
    private final Cache<ResourceUtil.ExpandedFunctionCall, ObjectAndStatic<TypeSystem.Value>> mFunctionCallCache;
    private final Cache<String, ObjectAndStatic<TypeSystem.Value>> mMacroEvaluationCache;
    private final Map<String, MacroInfo> mMacroLookup;
    private final Map<String, FunctionCallImplementation> mMacroMap;
    private final Map<String, FunctionCallImplementation> mPredicateMap;
    private final ResourceUtil.ExpandedResource mResource;
    private final Set<ResourceUtil.ExpandedRule> mRules;
    private final Map<String, FunctionCallImplementation> mTrackingTagMap;

    interface AddRemoveSetPopulator {
        void rulePassed(ResourceUtil.ExpandedRule expandedRule, Set<ResourceUtil.ExpandedFunctionCall> set, Set<ResourceUtil.ExpandedFunctionCall> set2, ResolvedRuleBuilder resolvedRuleBuilder);
    }

    private static class MacroInfo {
        private final Map<ResourceUtil.ExpandedRule, List<String>> mAddMacroNames = new HashMap();
        private final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> mAddMacros = new HashMap();
        private ResourceUtil.ExpandedFunctionCall mDefault;
        private final Map<ResourceUtil.ExpandedRule, List<String>> mRemoveMacroNames = new HashMap();
        private final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> mRemoveMacros = new HashMap();
        private final Set<ResourceUtil.ExpandedRule> mRules = new HashSet();

        public void addAddMacroForRule(ResourceUtil.ExpandedRule expandedRule, ResourceUtil.ExpandedFunctionCall expandedFunctionCall) {
            List<ResourceUtil.ExpandedFunctionCall> list = this.mAddMacros.get(expandedRule);
            if (list == null) {
                list = new ArrayList<>();
                this.mAddMacros.put(expandedRule, list);
            }
            list.add(expandedFunctionCall);
        }

        public void addAddMacroRuleNameForRule(ResourceUtil.ExpandedRule expandedRule, String str) {
            List<String> list = this.mAddMacroNames.get(expandedRule);
            if (list == null) {
                list = new ArrayList<>();
                this.mAddMacroNames.put(expandedRule, list);
            }
            list.add(str);
        }

        public void addRemoveMacroForRule(ResourceUtil.ExpandedRule expandedRule, ResourceUtil.ExpandedFunctionCall expandedFunctionCall) {
            List<ResourceUtil.ExpandedFunctionCall> list = this.mRemoveMacros.get(expandedRule);
            if (list == null) {
                list = new ArrayList<>();
                this.mRemoveMacros.put(expandedRule, list);
            }
            list.add(expandedFunctionCall);
        }

        public void addRemoveMacroRuleNameForRule(ResourceUtil.ExpandedRule expandedRule, String str) {
            List<String> list = this.mRemoveMacroNames.get(expandedRule);
            if (list == null) {
                list = new ArrayList<>();
                this.mRemoveMacroNames.put(expandedRule, list);
            }
            list.add(str);
        }

        public void addRule(ResourceUtil.ExpandedRule expandedRule) {
            this.mRules.add(expandedRule);
        }

        public Map<ResourceUtil.ExpandedRule, List<String>> getAddMacroRuleNames() {
            return this.mAddMacroNames;
        }

        public Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> getAddMacros() {
            return this.mAddMacros;
        }

        public ResourceUtil.ExpandedFunctionCall getDefault() {
            return this.mDefault;
        }

        public Map<ResourceUtil.ExpandedRule, List<String>> getRemoveMacroRuleNames() {
            return this.mRemoveMacroNames;
        }

        public Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> getRemoveMacros() {
            return this.mRemoveMacros;
        }

        public Set<ResourceUtil.ExpandedRule> getRules() {
            return this.mRules;
        }

        public void setDefault(ResourceUtil.ExpandedFunctionCall expandedFunctionCall) {
            this.mDefault = expandedFunctionCall;
        }
    }

    public Runtime(Context context, ResourceUtil.ExpandedResource expandedResource, DataLayer dataLayer, CustomFunctionCall.CustomEvaluator customEvaluator, CustomFunctionCall.CustomEvaluator customEvaluator2) {
        this(context, expandedResource, dataLayer, customEvaluator, customEvaluator2, new NoopEventInfoDistributor());
    }

    public Runtime(Context context, ResourceUtil.ExpandedResource expandedResource, DataLayer dataLayer, CustomFunctionCall.CustomEvaluator customEvaluator, CustomFunctionCall.CustomEvaluator customEvaluator2, EventInfoDistributor eventInfoDistributor2) {
        if (expandedResource == null) {
            throw new NullPointerException("resource cannot be null");
        }
        this.mResource = expandedResource;
        this.mRules = new HashSet(expandedResource.getRules());
        this.eventInfoDistributor = eventInfoDistributor2;
        this.mFunctionCallCache = new CacheFactory().createCache(MAX_CACHE_SIZE, new CacheFactory.CacheSizeManager<ResourceUtil.ExpandedFunctionCall, ObjectAndStatic<TypeSystem.Value>>() {
            /* class com.google.tagmanager.Runtime.AnonymousClass1 */

            public int sizeOf(ResourceUtil.ExpandedFunctionCall expandedFunctionCall, ObjectAndStatic<TypeSystem.Value> objectAndStatic) {
                return objectAndStatic.getObject().toByteArray().length;
            }
        });
        this.mMacroEvaluationCache = new CacheFactory().createCache(MAX_CACHE_SIZE, new CacheFactory.CacheSizeManager<String, ObjectAndStatic<TypeSystem.Value>>() {
            /* class com.google.tagmanager.Runtime.AnonymousClass2 */

            public int sizeOf(String str, ObjectAndStatic<TypeSystem.Value> objectAndStatic) {
                return objectAndStatic.getObject().toByteArray().length + str.length();
            }
        });
        this.mTrackingTagMap = new HashMap();
        addTrackingTag(new ArbitraryPixelTag(context));
        addTrackingTag(new CustomFunctionCall(customEvaluator2));
        addTrackingTag(new UniversalAnalyticsTag(context, dataLayer));
        this.mPredicateMap = new HashMap();
        addPredicate(new ContainsPredicate());
        addPredicate(new EndsWithPredicate());
        addPredicate(new EqualsPredicate());
        addPredicate(new GreaterEqualsPredicate());
        addPredicate(new GreaterThanPredicate());
        addPredicate(new LessEqualsPredicate());
        addPredicate(new LessThanPredicate());
        addPredicate(new RegexPredicate());
        addPredicate(new StartsWithPredicate());
        this.mMacroMap = new HashMap();
        addMacro(new AdvertiserIdMacro(context));
        addMacro(new AdvertisingTrackingEnabledMacro());
        addMacro(new AdwordsClickReferrerMacro(context));
        addMacro(new AppIdMacro(context));
        addMacro(new AppNameMacro(context));
        addMacro(new AppVersionMacro(context));
        addMacro(new ConstantMacro());
        addMacro(new CustomFunctionCall(customEvaluator));
        addMacro(new DataLayerMacro(dataLayer));
        addMacro(new DeviceIdMacro(context));
        addMacro(new DeviceNameMacro());
        addMacro(new EncodeMacro());
        addMacro(new EventMacro(this));
        addMacro(new GtmVersionMacro());
        addMacro(new HashMacro());
        addMacro(new InstallReferrerMacro(context));
        addMacro(new JoinerMacro());
        addMacro(new LanguageMacro());
        addMacro(new MobileAdwordsUniqueIdMacro(context));
        addMacro(new OsVersionMacro());
        addMacro(new PlatformMacro());
        addMacro(new RandomMacro());
        addMacro(new RegexGroupMacro());
        addMacro(new ResolutionMacro(context));
        addMacro(new RuntimeVersionMacro());
        addMacro(new SdkVersionMacro());
        addMacro(new TimeMacro());
        this.mMacroLookup = new HashMap();
        for (ResourceUtil.ExpandedRule expandedRule : this.mRules) {
            if (eventInfoDistributor2.debugMode()) {
                verifyFunctionAndNameListSizes(expandedRule.getAddMacros(), expandedRule.getAddMacroRuleNames(), "add macro");
                verifyFunctionAndNameListSizes(expandedRule.getRemoveMacros(), expandedRule.getRemoveMacroRuleNames(), "remove macro");
                verifyFunctionAndNameListSizes(expandedRule.getAddTags(), expandedRule.getAddTagRuleNames(), "add tag");
                verifyFunctionAndNameListSizes(expandedRule.getRemoveTags(), expandedRule.getRemoveTagRuleNames(), "remove tag");
            }
            for (int i = 0; i < expandedRule.getAddMacros().size(); i++) {
                ResourceUtil.ExpandedFunctionCall expandedFunctionCall = expandedRule.getAddMacros().get(i);
                String str = DEFAULT_RULE_NAME;
                if (eventInfoDistributor2.debugMode() && i < expandedRule.getAddMacroRuleNames().size()) {
                    str = expandedRule.getAddMacroRuleNames().get(i);
                }
                MacroInfo orAddMacroInfo = getOrAddMacroInfo(this.mMacroLookup, getFunctionName(expandedFunctionCall));
                orAddMacroInfo.addRule(expandedRule);
                orAddMacroInfo.addAddMacroForRule(expandedRule, expandedFunctionCall);
                orAddMacroInfo.addAddMacroRuleNameForRule(expandedRule, str);
            }
            for (int i2 = 0; i2 < expandedRule.getRemoveMacros().size(); i2++) {
                ResourceUtil.ExpandedFunctionCall expandedFunctionCall2 = expandedRule.getRemoveMacros().get(i2);
                String str2 = DEFAULT_RULE_NAME;
                if (eventInfoDistributor2.debugMode() && i2 < expandedRule.getRemoveMacroRuleNames().size()) {
                    str2 = expandedRule.getRemoveMacroRuleNames().get(i2);
                }
                MacroInfo orAddMacroInfo2 = getOrAddMacroInfo(this.mMacroLookup, getFunctionName(expandedFunctionCall2));
                orAddMacroInfo2.addRule(expandedRule);
                orAddMacroInfo2.addRemoveMacroForRule(expandedRule, expandedFunctionCall2);
                orAddMacroInfo2.addRemoveMacroRuleNameForRule(expandedRule, str2);
            }
        }
        for (Map.Entry<String, List<ResourceUtil.ExpandedFunctionCall>> entry : this.mResource.getAllMacros().entrySet()) {
            for (ResourceUtil.ExpandedFunctionCall expandedFunctionCall3 : entry.getValue()) {
                if (!Types.valueToBoolean(expandedFunctionCall3.getProperties().get(Key.NOT_DEFAULT_MACRO.toString())).booleanValue()) {
                    getOrAddMacroInfo(this.mMacroLookup, entry.getKey()).setDefault(expandedFunctionCall3);
                }
            }
        }
    }

    private static void addFunctionImplToMap(Map<String, FunctionCallImplementation> map, FunctionCallImplementation functionCallImplementation) {
        if (map.containsKey(functionCallImplementation.getInstanceFunctionId())) {
            throw new IllegalArgumentException("Duplicate function type name: " + functionCallImplementation.getInstanceFunctionId());
        }
        map.put(functionCallImplementation.getInstanceFunctionId(), functionCallImplementation);
    }

    private ObjectAndStatic<Set<ResourceUtil.ExpandedFunctionCall>> calculateGenericToRun(Set<ResourceUtil.ExpandedRule> set, Set<String> set2, AddRemoveSetPopulator addRemoveSetPopulator, RuleEvaluationStepInfoBuilder ruleEvaluationStepInfoBuilder) {
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        boolean z = true;
        for (ResourceUtil.ExpandedRule expandedRule : set) {
            ResolvedRuleBuilder createResolvedRuleBuilder = ruleEvaluationStepInfoBuilder.createResolvedRuleBuilder();
            ObjectAndStatic<Boolean> evaluatePredicatesInRule = evaluatePredicatesInRule(expandedRule, set2, createResolvedRuleBuilder);
            if (evaluatePredicatesInRule.getObject().booleanValue()) {
                addRemoveSetPopulator.rulePassed(expandedRule, hashSet, hashSet2, createResolvedRuleBuilder);
            }
            z = z && evaluatePredicatesInRule.isStatic();
        }
        hashSet.removeAll(hashSet2);
        ruleEvaluationStepInfoBuilder.setEnabledFunctions(hashSet);
        return new ObjectAndStatic<>(hashSet, z);
    }

    private ObjectAndStatic<TypeSystem.Value> evaluateMacroReferenceCycleDetection(String str, Set<String> set, MacroEvaluationInfoBuilder macroEvaluationInfoBuilder) {
        ResourceUtil.ExpandedFunctionCall next;
        ObjectAndStatic<TypeSystem.Value> objectAndStatic = this.mMacroEvaluationCache.get(str);
        if (objectAndStatic != null && !this.eventInfoDistributor.debugMode()) {
            return objectAndStatic;
        }
        MacroInfo macroInfo = this.mMacroLookup.get(str);
        if (macroInfo == null) {
            Log.e("Invalid macro: " + str);
            return DEFAULT_VALUE_AND_STATIC;
        }
        ObjectAndStatic<Set<ResourceUtil.ExpandedFunctionCall>> calculateMacrosToRun = calculateMacrosToRun(str, macroInfo.getRules(), macroInfo.getAddMacros(), macroInfo.getAddMacroRuleNames(), macroInfo.getRemoveMacros(), macroInfo.getRemoveMacroRuleNames(), set, macroEvaluationInfoBuilder.createRulesEvaluation());
        if (calculateMacrosToRun.getObject().isEmpty()) {
            next = macroInfo.getDefault();
        } else {
            if (calculateMacrosToRun.getObject().size() > 1) {
                Log.w("Multiple macros active for macroName " + str);
            }
            next = calculateMacrosToRun.getObject().iterator().next();
        }
        if (next == null) {
            return DEFAULT_VALUE_AND_STATIC;
        }
        ObjectAndStatic<TypeSystem.Value> executeFunction = executeFunction(this.mMacroMap, next, set, macroEvaluationInfoBuilder.createResult());
        ObjectAndStatic<TypeSystem.Value> objectAndStatic2 = executeFunction == DEFAULT_VALUE_AND_STATIC ? DEFAULT_VALUE_AND_STATIC : new ObjectAndStatic<>(executeFunction.getObject(), calculateMacrosToRun.isStatic() && executeFunction.isStatic());
        if (!objectAndStatic2.isStatic()) {
            return objectAndStatic2;
        }
        this.mMacroEvaluationCache.put(str, objectAndStatic2);
        return objectAndStatic2;
    }

    private ObjectAndStatic<TypeSystem.Value> executeFunction(Map<String, FunctionCallImplementation> map, ResourceUtil.ExpandedFunctionCall expandedFunctionCall, Set<String> set, ResolvedFunctionCallBuilder resolvedFunctionCallBuilder) {
        boolean z;
        boolean z2 = true;
        TypeSystem.Value value = expandedFunctionCall.getProperties().get(Key.FUNCTION.toString());
        if (value == null) {
            Log.e("No function id in properties");
            return DEFAULT_VALUE_AND_STATIC;
        }
        String functionId = value.getFunctionId();
        FunctionCallImplementation functionCallImplementation = map.get(functionId);
        if (functionCallImplementation == null) {
            Log.e(functionId + " has no backing implementation.");
            return DEFAULT_VALUE_AND_STATIC;
        }
        ObjectAndStatic<TypeSystem.Value> objectAndStatic = this.mFunctionCallCache.get(expandedFunctionCall);
        if (objectAndStatic != null && !this.eventInfoDistributor.debugMode()) {
            return objectAndStatic;
        }
        HashMap hashMap = new HashMap();
        boolean z3 = true;
        for (Map.Entry<String, TypeSystem.Value> entry : expandedFunctionCall.getProperties().entrySet()) {
            ObjectAndStatic<TypeSystem.Value> macroExpandValue = macroExpandValue(entry.getValue(), set, resolvedFunctionCallBuilder.createResolvedPropertyBuilder(entry.getKey()).createPropertyValueBuilder(entry.getValue()));
            if (macroExpandValue == DEFAULT_VALUE_AND_STATIC) {
                return DEFAULT_VALUE_AND_STATIC;
            }
            if (macroExpandValue.isStatic()) {
                expandedFunctionCall.updateCacheableProperty(entry.getKey(), macroExpandValue.getObject());
                z = z3;
            } else {
                z = false;
            }
            hashMap.put(entry.getKey(), macroExpandValue.getObject());
            z3 = z;
        }
        if (!functionCallImplementation.hasRequiredKeys(hashMap.keySet())) {
            Log.e("Incorrect keys for function " + functionId + " required " + functionCallImplementation.getRequiredKeys() + " had " + hashMap.keySet());
            return DEFAULT_VALUE_AND_STATIC;
        }
        if (!z3 || !functionCallImplementation.isCacheable()) {
            z2 = false;
        }
        ObjectAndStatic<TypeSystem.Value> objectAndStatic2 = new ObjectAndStatic<>(functionCallImplementation.evaluate(hashMap), z2);
        if (z2) {
            this.mFunctionCallCache.put(expandedFunctionCall, objectAndStatic2);
        }
        resolvedFunctionCallBuilder.setFunctionResult(objectAndStatic2.getObject());
        return objectAndStatic2;
    }

    private static String getFunctionName(ResourceUtil.ExpandedFunctionCall expandedFunctionCall) {
        return Types.valueToString(expandedFunctionCall.getProperties().get(Key.INSTANCE_NAME.toString()));
    }

    private static MacroInfo getOrAddMacroInfo(Map<String, MacroInfo> map, String str) {
        MacroInfo macroInfo = map.get(str);
        if (macroInfo != null) {
            return macroInfo;
        }
        MacroInfo macroInfo2 = new MacroInfo();
        map.put(str, macroInfo2);
        return macroInfo2;
    }

    private ObjectAndStatic<TypeSystem.Value> macroExpandValue(TypeSystem.Value value, Set<String> set, ValueBuilder valueBuilder) {
        if (!value.getContainsReferences()) {
            return new ObjectAndStatic<>(value, true);
        }
        switch (value.getType()) {
            case LIST:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue = ResourceUtil.newValueBuilderBasedOnValue(value);
                for (int i = 0; i < value.getListItemCount(); i++) {
                    ObjectAndStatic<TypeSystem.Value> macroExpandValue = macroExpandValue(value.getListItem(i), set, valueBuilder.getListItem(i));
                    if (macroExpandValue == DEFAULT_VALUE_AND_STATIC) {
                        return DEFAULT_VALUE_AND_STATIC;
                    }
                    newValueBuilderBasedOnValue.addListItem(macroExpandValue.getObject());
                }
                return new ObjectAndStatic<>(newValueBuilderBasedOnValue.build(), false);
            case MAP:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue2 = ResourceUtil.newValueBuilderBasedOnValue(value);
                if (value.getMapKeyCount() != value.getMapValueCount()) {
                    Log.e("Invalid serving value: " + value.toString());
                    return DEFAULT_VALUE_AND_STATIC;
                }
                for (int i2 = 0; i2 < value.getMapKeyCount(); i2++) {
                    ObjectAndStatic<TypeSystem.Value> macroExpandValue2 = macroExpandValue(value.getMapKey(i2), set, valueBuilder.getMapKey(i2));
                    ObjectAndStatic<TypeSystem.Value> macroExpandValue3 = macroExpandValue(value.getMapValue(i2), set, valueBuilder.getMapValue(i2));
                    if (macroExpandValue2 == DEFAULT_VALUE_AND_STATIC || macroExpandValue3 == DEFAULT_VALUE_AND_STATIC) {
                        return DEFAULT_VALUE_AND_STATIC;
                    }
                    newValueBuilderBasedOnValue2.addMapKey(macroExpandValue2.getObject());
                    newValueBuilderBasedOnValue2.addMapValue(macroExpandValue3.getObject());
                }
                return new ObjectAndStatic<>(newValueBuilderBasedOnValue2.build(), false);
            case MACRO_REFERENCE:
                if (set.contains(value.getMacroReference())) {
                    Log.e("Macro cycle detected.  Current macro reference: " + value.getMacroReference() + "." + "  Previous macro references: " + set.toString() + ".");
                    return DEFAULT_VALUE_AND_STATIC;
                }
                set.add(value.getMacroReference());
                ObjectAndStatic<TypeSystem.Value> applyEscapings = ValueEscapeUtil.applyEscapings(evaluateMacroReferenceCycleDetection(value.getMacroReference(), set, valueBuilder.createValueMacroEvaluationInfoExtension()), value.getEscapingList());
                set.remove(value.getMacroReference());
                return applyEscapings;
            case TEMPLATE:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue3 = ResourceUtil.newValueBuilderBasedOnValue(value);
                for (int i3 = 0; i3 < value.getTemplateTokenCount(); i3++) {
                    ObjectAndStatic<TypeSystem.Value> macroExpandValue4 = macroExpandValue(value.getTemplateToken(i3), set, valueBuilder.getTemplateToken(i3));
                    if (macroExpandValue4 == DEFAULT_VALUE_AND_STATIC) {
                        return DEFAULT_VALUE_AND_STATIC;
                    }
                    newValueBuilderBasedOnValue3.addTemplateToken(macroExpandValue4.getObject());
                }
                return new ObjectAndStatic<>(newValueBuilderBasedOnValue3.build(), false);
            default:
                Log.e("Unknown type: " + value.getType());
                return DEFAULT_VALUE_AND_STATIC;
        }
    }

    private static void verifyFunctionAndNameListSizes(List<ResourceUtil.ExpandedFunctionCall> list, List<String> list2, String str) {
        if (list.size() != list2.size()) {
            Log.i("Invalid resource: imbalance of rule names of functions for " + str + " operation. Using default rule name instead");
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void addMacro(FunctionCallImplementation functionCallImplementation) {
        addFunctionImplToMap(this.mMacroMap, functionCallImplementation);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void addPredicate(FunctionCallImplementation functionCallImplementation) {
        addFunctionImplToMap(this.mPredicateMap, functionCallImplementation);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void addTrackingTag(FunctionCallImplementation functionCallImplementation) {
        addFunctionImplToMap(this.mTrackingTagMap, functionCallImplementation);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public ObjectAndStatic<Set<ResourceUtil.ExpandedFunctionCall>> calculateMacrosToRun(String str, Set<ResourceUtil.ExpandedRule> set, final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> map, final Map<ResourceUtil.ExpandedRule, List<String>> map2, final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> map3, final Map<ResourceUtil.ExpandedRule, List<String>> map4, Set<String> set2, RuleEvaluationStepInfoBuilder ruleEvaluationStepInfoBuilder) {
        return calculateGenericToRun(set, set2, new AddRemoveSetPopulator() {
            /* class com.google.tagmanager.Runtime.AnonymousClass3 */

            /* JADX WARN: Type inference failed for: r5v0, types: [java.util.Set<com.google.tagmanager.ResourceUtil$ExpandedFunctionCall>, java.util.Set] */
            /* JADX WARN: Type inference failed for: r6v0, types: [java.util.Set<com.google.tagmanager.ResourceUtil$ExpandedFunctionCall>, java.util.Set] */
            /* JADX WARNING: Unknown variable types count: 2 */
            @Override // com.google.tagmanager.Runtime.AddRemoveSetPopulator
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void rulePassed(com.google.tagmanager.ResourceUtil.ExpandedRule r4, java.util.Set<com.google.tagmanager.ResourceUtil.ExpandedFunctionCall> r5, java.util.Set<com.google.tagmanager.ResourceUtil.ExpandedFunctionCall> r6, com.google.tagmanager.ResolvedRuleBuilder r7) {
                /*
                    r3 = this;
                    java.util.Map r0 = r9
                    java.lang.Object r0 = r0.get(r4)
                    java.util.List r0 = (java.util.List) r0
                    java.util.Map r1 = r10
                    java.lang.Object r1 = r1.get(r4)
                    java.util.List r1 = (java.util.List) r1
                    if (r0 == 0) goto L_0x001c
                    r5.addAll(r0)
                    com.google.tagmanager.ResolvedFunctionCallTranslatorList r2 = r7.getAddedMacroFunctions()
                    r2.translateAndAddAll(r0, r1)
                L_0x001c:
                    java.util.Map r0 = r11
                    java.lang.Object r0 = r0.get(r4)
                    java.util.List r0 = (java.util.List) r0
                    java.util.Map r1 = r12
                    java.lang.Object r1 = r1.get(r4)
                    java.util.List r1 = (java.util.List) r1
                    if (r0 == 0) goto L_0x0038
                    r6.addAll(r0)
                    com.google.tagmanager.ResolvedFunctionCallTranslatorList r2 = r7.getRemovedMacroFunctions()
                    r2.translateAndAddAll(r0, r1)
                L_0x0038:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.Runtime.AnonymousClass3.rulePassed(com.google.tagmanager.ResourceUtil$ExpandedRule, java.util.Set, java.util.Set, com.google.tagmanager.ResolvedRuleBuilder):void");
            }
        }, ruleEvaluationStepInfoBuilder);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public ObjectAndStatic<Set<ResourceUtil.ExpandedFunctionCall>> calculateTagsToRun(Set<ResourceUtil.ExpandedRule> set, RuleEvaluationStepInfoBuilder ruleEvaluationStepInfoBuilder) {
        return calculateGenericToRun(set, new HashSet(), new AddRemoveSetPopulator() {
            /* class com.google.tagmanager.Runtime.AnonymousClass4 */

            @Override // com.google.tagmanager.Runtime.AddRemoveSetPopulator
            public void rulePassed(ResourceUtil.ExpandedRule expandedRule, Set<ResourceUtil.ExpandedFunctionCall> set, Set<ResourceUtil.ExpandedFunctionCall> set2, ResolvedRuleBuilder resolvedRuleBuilder) {
                set.addAll(expandedRule.getAddTags());
                set2.addAll(expandedRule.getRemoveTags());
                resolvedRuleBuilder.getAddedTagFunctions().translateAndAddAll(expandedRule.getAddTags(), expandedRule.getAddTagRuleNames());
                resolvedRuleBuilder.getRemovedTagFunctions().translateAndAddAll(expandedRule.getRemoveTags(), expandedRule.getRemoveTagRuleNames());
            }
        }, ruleEvaluationStepInfoBuilder);
    }

    public ObjectAndStatic<TypeSystem.Value> evaluateMacroReference(String str) {
        EventInfoBuilder createMacroEvalutionEventInfo = this.eventInfoDistributor.createMacroEvalutionEventInfo(str);
        ObjectAndStatic<TypeSystem.Value> evaluateMacroReferenceCycleDetection = evaluateMacroReferenceCycleDetection(str, new HashSet(), createMacroEvalutionEventInfo.createMacroEvaluationInfoBuilder());
        createMacroEvalutionEventInfo.processEventInfo();
        return evaluateMacroReferenceCycleDetection;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public ObjectAndStatic<Boolean> evaluatePredicate(ResourceUtil.ExpandedFunctionCall expandedFunctionCall, Set<String> set, ResolvedFunctionCallBuilder resolvedFunctionCallBuilder) {
        ObjectAndStatic<TypeSystem.Value> executeFunction = executeFunction(this.mPredicateMap, expandedFunctionCall, set, resolvedFunctionCallBuilder);
        Boolean valueToBoolean = Types.valueToBoolean(executeFunction.getObject());
        resolvedFunctionCallBuilder.setFunctionResult(Types.objectToValue(valueToBoolean));
        return new ObjectAndStatic<>(valueToBoolean, executeFunction.isStatic());
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public ObjectAndStatic<Boolean> evaluatePredicatesInRule(ResourceUtil.ExpandedRule expandedRule, Set<String> set, ResolvedRuleBuilder resolvedRuleBuilder) {
        boolean z = true;
        for (ResourceUtil.ExpandedFunctionCall expandedFunctionCall : expandedRule.getNegativePredicates()) {
            ObjectAndStatic<Boolean> evaluatePredicate = evaluatePredicate(expandedFunctionCall, set, resolvedRuleBuilder.createNegativePredicate());
            if (evaluatePredicate.getObject().booleanValue()) {
                resolvedRuleBuilder.setValue(Types.objectToValue(false));
                return new ObjectAndStatic<>(false, evaluatePredicate.isStatic());
            }
            z = z && evaluatePredicate.isStatic();
        }
        for (ResourceUtil.ExpandedFunctionCall expandedFunctionCall2 : expandedRule.getPositivePredicates()) {
            ObjectAndStatic<Boolean> evaluatePredicate2 = evaluatePredicate(expandedFunctionCall2, set, resolvedRuleBuilder.createPositivePredicate());
            if (!evaluatePredicate2.getObject().booleanValue()) {
                resolvedRuleBuilder.setValue(Types.objectToValue(false));
                return new ObjectAndStatic<>(false, evaluatePredicate2.isStatic());
            }
            z = z && evaluatePredicate2.isStatic();
        }
        resolvedRuleBuilder.setValue(Types.objectToValue(true));
        return new ObjectAndStatic<>(true, z);
    }

    public void evaluateTags(String str) {
        synchronized (this) {
            setCurrentEventName(str);
            EventInfoBuilder createDataLayerEventEvaluationEventInfo = this.eventInfoDistributor.createDataLayerEventEvaluationEventInfo(str);
            DataLayerEventEvaluationInfoBuilder createDataLayerEventEvaluationInfoBuilder = createDataLayerEventEvaluationEventInfo.createDataLayerEventEvaluationInfoBuilder();
            for (ResourceUtil.ExpandedFunctionCall expandedFunctionCall : calculateTagsToRun(this.mRules, createDataLayerEventEvaluationInfoBuilder.createRulesEvaluation()).getObject()) {
                executeFunction(this.mTrackingTagMap, expandedFunctionCall, new HashSet(), createDataLayerEventEvaluationInfoBuilder.createAndAddResult());
            }
            createDataLayerEventEvaluationEventInfo.processEventInfo();
            setCurrentEventName(null);
        }
    }

    /* access modifiers changed from: package-private */
    public String getCurrentEventName() {
        String str;
        synchronized (this) {
            str = this.mCurrentEventName;
        }
        return str;
    }

    public ResourceUtil.ExpandedResource getResource() {
        return this.mResource;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setCurrentEventName(String str) {
        synchronized (this) {
            this.mCurrentEventName = str;
        }
    }
}

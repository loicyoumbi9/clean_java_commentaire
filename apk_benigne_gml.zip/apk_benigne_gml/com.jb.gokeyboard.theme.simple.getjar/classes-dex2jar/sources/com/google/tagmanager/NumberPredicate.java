package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

abstract class NumberPredicate extends Predicate {
    public NumberPredicate(String str) {
        super(str);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.Predicate
    public boolean evaluateNoDefaultValues(TypeSystem.Value value, TypeSystem.Value value2, Map<String, TypeSystem.Value> map) {
        TypedNumber valueToNumber = Types.valueToNumber(value);
        TypedNumber valueToNumber2 = Types.valueToNumber(value2);
        if (valueToNumber == Types.getDefaultNumber() || valueToNumber2 == Types.getDefaultNumber()) {
            return false;
        }
        return evaluateNumber(valueToNumber, valueToNumber2, map);
    }

    /* access modifiers changed from: protected */
    public abstract boolean evaluateNumber(TypedNumber typedNumber, TypedNumber typedNumber2, Map<String, TypeSystem.Value> map);
}

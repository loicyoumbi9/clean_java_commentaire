package com.google.tagmanager;

import com.google.tagmanager.LoadCallback;

class TypeOrFailure<T> {
    private LoadCallback.Failure mFailure;
    private T mType;

    public TypeOrFailure(LoadCallback.Failure failure) {
        this.mFailure = failure;
    }

    public TypeOrFailure(T t) {
        this.mType = t;
    }

    public LoadCallback.Failure getFailure() {
        return this.mFailure;
    }

    public T getType() {
        return this.mType;
    }
}

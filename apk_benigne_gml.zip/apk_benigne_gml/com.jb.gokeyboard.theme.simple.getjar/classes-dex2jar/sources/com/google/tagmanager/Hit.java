package com.google.tagmanager;

import android.text.TextUtils;

class Hit {
    private final long mHitFirstDispatchTime;
    private final long mHitId;
    private final long mHitTime;
    private String mHitUrl;

    Hit(long j, long j2) {
        this.mHitId = j;
        this.mHitTime = j2;
        this.mHitFirstDispatchTime = 0;
    }

    Hit(long j, long j2, long j3) {
        this.mHitId = j;
        this.mHitTime = j2;
        this.mHitFirstDispatchTime = j3;
    }

    /* access modifiers changed from: package-private */
    public long getHitFirstDispatchTime() {
        return this.mHitFirstDispatchTime;
    }

    /* access modifiers changed from: package-private */
    public long getHitId() {
        return this.mHitId;
    }

    /* access modifiers changed from: package-private */
    public long getHitTime() {
        return this.mHitTime;
    }

    /* access modifiers changed from: package-private */
    public String getHitUrl() {
        return this.mHitUrl;
    }

    /* access modifiers changed from: package-private */
    public void setHitUrl(String str) {
        if (str != null && !TextUtils.isEmpty(str.trim())) {
            this.mHitUrl = str;
        }
    }
}

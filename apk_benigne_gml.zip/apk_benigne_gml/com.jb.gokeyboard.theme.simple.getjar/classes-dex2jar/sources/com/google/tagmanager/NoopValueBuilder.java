package com.google.tagmanager;

class NoopValueBuilder implements ValueBuilder {
    NoopValueBuilder() {
    }

    @Override // com.google.tagmanager.ValueBuilder
    public MacroEvaluationInfoBuilder createValueMacroEvaluationInfoExtension() {
        return new NoopMacroEvaluationInfoBuilder();
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getListItem(int i) {
        return new NoopValueBuilder();
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getMapKey(int i) {
        return new NoopValueBuilder();
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getMapValue(int i) {
        return new NoopValueBuilder();
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getTemplateToken(int i) {
        return new NoopValueBuilder();
    }
}

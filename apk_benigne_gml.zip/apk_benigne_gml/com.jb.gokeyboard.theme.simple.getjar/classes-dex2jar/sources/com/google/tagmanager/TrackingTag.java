package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

abstract class TrackingTag extends FunctionCallImplementation {
    public TrackingTag(String str, String... strArr) {
        super(str, strArr);
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        evaluateTrackingTag(map);
        return Types.getDefaultValue();
    }

    public abstract void evaluateTrackingTag(Map<String, TypeSystem.Value> map);

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return false;
    }
}

package com.google.tagmanager;

class TagManagerConstants {
    static final String TAG_MANAGER_PRODUCT = "GoogleTagManager";
    static final String TAG_MANAGER_VERSION = "3.01";

    TagManagerConstants() {
    }
}

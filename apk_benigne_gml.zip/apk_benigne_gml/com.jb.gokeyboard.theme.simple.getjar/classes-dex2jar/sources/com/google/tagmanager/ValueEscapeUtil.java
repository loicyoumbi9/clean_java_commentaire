package com.google.tagmanager;

import com.getjar.sdk.utilities.Constants;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

class ValueEscapeUtil {
    private ValueEscapeUtil() {
    }

    private static ObjectAndStatic<TypeSystem.Value> applyEscaping(ObjectAndStatic<TypeSystem.Value> objectAndStatic, TypeSystem.Value.Escaping escaping) {
        if (!isValidStringType(objectAndStatic.getObject())) {
            Log.e("Escaping can only be applied to strings.");
            return objectAndStatic;
        }
        switch (escaping) {
            case ESCAPE_URI:
                return escapeUri(objectAndStatic);
            default:
                Log.e("Unsupported Value Escaping: " + escaping);
                return objectAndStatic;
        }
    }

    static ObjectAndStatic<TypeSystem.Value> applyEscapings(ObjectAndStatic<TypeSystem.Value> objectAndStatic, List<TypeSystem.Value.Escaping> list) {
        for (TypeSystem.Value.Escaping escaping : list) {
            objectAndStatic = applyEscaping(objectAndStatic, escaping);
        }
        return objectAndStatic;
    }

    private static ObjectAndStatic<TypeSystem.Value> escapeUri(ObjectAndStatic<TypeSystem.Value> objectAndStatic) {
        try {
            return new ObjectAndStatic<>(Types.objectToValue(urlEncode(objectAndStatic.getObject().getString())), objectAndStatic.isStatic());
        } catch (UnsupportedEncodingException e) {
            Log.e("Escape URI: unsupported encoding", e);
            return objectAndStatic;
        }
    }

    private static boolean isValidStringType(TypeSystem.Value value) {
        return value.hasType() && value.getType().equals(TypeSystem.Value.Type.STRING) && value.hasString();
    }

    static String urlEncode(String str) throws UnsupportedEncodingException {
        return URLEncoder.encode(str, Constants.ENCODING_CHARSET).replaceAll("\\+", "%20");
    }
}

package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;

class NoopResolvedFunctionCallBuilder implements ResolvedFunctionCallBuilder {
    NoopResolvedFunctionCallBuilder() {
    }

    @Override // com.google.tagmanager.ResolvedFunctionCallBuilder
    public ResolvedPropertyBuilder createResolvedPropertyBuilder(String str) {
        return new NoopResolvedPropertyBuilder();
    }

    @Override // com.google.tagmanager.ResolvedFunctionCallBuilder
    public void setFunctionResult(TypeSystem.Value value) {
    }
}

package com.google.tagmanager;

import android.content.Context;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.concurrent.LinkedBlockingQueue;

class HitSendingThreadImpl extends Thread implements HitSendingThread {
    private static HitSendingThreadImpl sInstance;
    private volatile boolean mClosed = false;
    /* access modifiers changed from: private */
    public final Context mContext;
    private volatile boolean mDisabled = false;
    /* access modifiers changed from: private */
    public volatile HitStore mUrlStore;
    private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();

    private HitSendingThreadImpl(Context context) {
        super("GAThread");
        if (context != null) {
            this.mContext = context.getApplicationContext();
        } else {
            this.mContext = context;
        }
        start();
    }

    @VisibleForTesting
    HitSendingThreadImpl(Context context, HitStore hitStore) {
        super("GAThread");
        if (context != null) {
            this.mContext = context.getApplicationContext();
        } else {
            this.mContext = context;
        }
        this.mUrlStore = hitStore;
        start();
    }

    static HitSendingThreadImpl getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new HitSendingThreadImpl(context);
        }
        return sInstance;
    }

    private String printStackTrace(Throwable th) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(byteArrayOutputStream);
        th.printStackTrace(printStream);
        printStream.flush();
        return new String(byteArrayOutputStream.toByteArray());
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void close() {
        this.mClosed = true;
        interrupt();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public int getQueueSize() {
        return this.queue.size();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public HitStore getStore() {
        return this.mUrlStore;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public boolean isDisabled() {
        return this.mDisabled;
    }

    @Override // com.google.tagmanager.HitSendingThread
    public void queueToThread(Runnable runnable) {
        this.queue.add(runnable);
    }

    public void run() {
        while (!this.mClosed) {
            try {
                Runnable take = this.queue.take();
                if (!this.mDisabled) {
                    take.run();
                }
            } catch (InterruptedException e) {
                Log.i(e.toString());
            } catch (Throwable th) {
                Log.e("Error on GAThread: " + printStackTrace(th));
                Log.e("Google Analytics is shutting down.");
                this.mDisabled = true;
            }
        }
    }

    @Override // com.google.tagmanager.HitSendingThread
    public void sendHit(String str) {
        sendHit(str, System.currentTimeMillis());
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void sendHit(final String str, final long j) {
        queueToThread(new Runnable() {
            /* class com.google.tagmanager.HitSendingThreadImpl.AnonymousClass1 */

            public void run() {
                if (HitSendingThreadImpl.this.mUrlStore == null) {
                    ServiceManagerImpl instance = ServiceManagerImpl.getInstance();
                    instance.initialize(HitSendingThreadImpl.this.mContext, this);
                    HitStore unused = HitSendingThreadImpl.this.mUrlStore = instance.getStore();
                }
                HitSendingThreadImpl.this.mUrlStore.putHit(j, str);
            }
        });
    }
}

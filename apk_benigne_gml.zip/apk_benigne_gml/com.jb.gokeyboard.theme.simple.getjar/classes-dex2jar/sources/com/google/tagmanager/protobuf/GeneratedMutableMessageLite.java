package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.GeneratedMessageLite;
import com.google.tagmanager.protobuf.GeneratedMutableMessageLite;
import com.google.tagmanager.protobuf.MessageLite;
import com.google.tagmanager.protobuf.WireFormat;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class GeneratedMutableMessageLite<MessageType extends GeneratedMutableMessageLite<MessageType>> extends AbstractMutableMessageLite implements Serializable {
    private static final long serialVersionUID = 1;
    protected ByteString unknownFields = ByteString.EMPTY;

    public static abstract class ExtendableMutableMessage<MessageType extends ExtendableMutableMessage<MessageType>> extends GeneratedMutableMessageLite<MessageType> {
        /* access modifiers changed from: private */
        public FieldSet<GeneratedMessageLite.ExtensionDescriptor> extensions = FieldSet.emptySet();

        protected class ExtensionWriter {
            private final Iterator<Map.Entry<GeneratedMessageLite.ExtensionDescriptor, Object>> iter;
            private final boolean messageSetWireFormat;
            private Map.Entry<GeneratedMessageLite.ExtensionDescriptor, Object> next;

            private ExtensionWriter(boolean z) {
                this.iter = ExtendableMutableMessage.this.extensions.iterator();
                if (this.iter.hasNext()) {
                    this.next = this.iter.next();
                }
                this.messageSetWireFormat = z;
            }

            public void writeUntil(int i, CodedOutputStream codedOutputStream) throws IOException {
                while (this.next != null && this.next.getKey().getNumber() < i) {
                    GeneratedMessageLite.ExtensionDescriptor key = this.next.getKey();
                    if (!this.messageSetWireFormat || key.getLiteJavaType() != WireFormat.JavaType.MESSAGE || key.isRepeated()) {
                        FieldSet.writeField(key, this.next.getValue(), codedOutputStream);
                    } else {
                        codedOutputStream.writeMessageSetExtension(key.getNumber(), (MessageLite) this.next.getValue());
                    }
                    if (this.iter.hasNext()) {
                        this.next = this.iter.next();
                    } else {
                        this.next = null;
                    }
                }
            }
        }

        protected ExtendableMutableMessage() {
        }

        private void ensureExtensionsIsMutable() {
            if (this.extensions.isImmutable()) {
                this.extensions = this.extensions.clone();
            }
        }

        private void verifyExtensionContainingType(GeneratedMessageLite.GeneratedExtension<MessageType, ?> generatedExtension) {
            if (generatedExtension.getContainingTypeDefaultInstance() != getDefaultInstanceForType()) {
                throw new IllegalArgumentException("This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.");
            }
        }

        public final <Type> MessageType addExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> generatedExtension, Type type) {
            assertMutable();
            verifyExtensionContainingType(generatedExtension);
            ensureExtensionsIsMutable();
            this.extensions.addRepeatedField(generatedExtension.descriptor, generatedExtension.singularToFieldSetType(type));
            return this;
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageType clear() {
            assertMutable();
            this.extensions = FieldSet.emptySet();
            return GeneratedMutableMessageLite.super.clear();
        }

        public final <Type> MessageType clearExtension(GeneratedMessageLite.GeneratedExtension<MessageType, ?> generatedExtension) {
            assertMutable();
            verifyExtensionContainingType(generatedExtension);
            ensureExtensionsIsMutable();
            this.extensions.clearField(generatedExtension.descriptor);
            return this;
        }

        /* access modifiers changed from: protected */
        public boolean extensionsAreInitialized() {
            return this.extensions.isInitialized();
        }

        /* access modifiers changed from: protected */
        public int extensionsSerializedSize() {
            return this.extensions.getSerializedSize();
        }

        /* access modifiers changed from: protected */
        public int extensionsSerializedSizeAsMessageSet() {
            return this.extensions.getMessageSetSerializedSize();
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
        public /* bridge */ /* synthetic */ MessageLite getDefaultInstanceForType() {
            return GeneratedMutableMessageLite.super.getDefaultInstanceForType();
        }

        public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> generatedExtension) {
            verifyExtensionContainingType(generatedExtension);
            Object field = this.extensions.getField(generatedExtension.descriptor);
            return field == null ? generatedExtension.defaultValue : generatedExtension.descriptor.isRepeated ? Collections.unmodifiableList((List) generatedExtension.fromFieldSetType(field)) : generatedExtension.fromFieldSetType(field);
        }

        public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> generatedExtension, int i) {
            verifyExtensionContainingType(generatedExtension);
            return generatedExtension.singularFromFieldSetType(this.extensions.getRepeatedField(generatedExtension.descriptor, i));
        }

        public final <Type> int getExtensionCount(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> generatedExtension) {
            verifyExtensionContainingType(generatedExtension);
            return this.extensions.getRepeatedFieldCount(generatedExtension.descriptor);
        }

        public final <Type extends MutableMessageLite> Type getMutableExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> generatedExtension) {
            assertMutable();
            verifyExtensionContainingType(generatedExtension);
            ensureExtensionsIsMutable();
            GeneratedMessageLite.ExtensionDescriptor extensionDescriptor = generatedExtension.descriptor;
            if (extensionDescriptor.getLiteJavaType() != WireFormat.JavaType.MESSAGE) {
                throw new UnsupportedOperationException("getMutableExtension() called on a non-Message type.");
            } else if (extensionDescriptor.isRepeated()) {
                throw new UnsupportedOperationException("getMutableExtension() called on a repeated type.");
            } else {
                Type field = this.extensions.getField(generatedExtension.descriptor);
                if (field != null) {
                    return field;
                }
                Type newMessageForType = generatedExtension.defaultValue.newMessageForType();
                this.extensions.setField(generatedExtension.descriptor, newMessageForType);
                return newMessageForType;
            }
        }

        public final <Type> boolean hasExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> generatedExtension) {
            verifyExtensionContainingType(generatedExtension);
            return this.extensions.hasField(generatedExtension.descriptor);
        }

        @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public MessageLite immutableCopy() {
            GeneratedMessageLite.ExtendableBuilder extendableBuilder = (GeneratedMessageLite.ExtendableBuilder) internalCopyToBuilder(this, internalImmutableDefault());
            extendableBuilder.internalSetExtensionSet(this.extensions.cloneWithAllFieldsToImmutable());
            return extendableBuilder.buildPartial();
        }

        /* access modifiers changed from: package-private */
        public void internalSetExtensionSet(FieldSet<GeneratedMessageLite.ExtensionDescriptor> fieldSet) {
            this.extensions = fieldSet;
        }

        /* access modifiers changed from: protected */
        public final void mergeExtensionFields(MessageType messagetype) {
            ensureExtensionsIsMutable();
            this.extensions.mergeFrom(messagetype.extensions);
        }

        /* access modifiers changed from: protected */
        public ExtendableMutableMessage<MessageType>.ExtensionWriter newExtensionWriter() {
            return new ExtensionWriter(false);
        }

        /* access modifiers changed from: protected */
        public ExtendableMutableMessage<MessageType>.ExtensionWriter newMessageSetExtensionWriter() {
            return new ExtensionWriter(true);
        }

        /* access modifiers changed from: protected */
        @Override // com.google.tagmanager.protobuf.GeneratedMutableMessageLite
        public boolean parseUnknownField(CodedInputStream codedInputStream, CodedOutputStream codedOutputStream, ExtensionRegistryLite extensionRegistryLite, int i) throws IOException {
            ensureExtensionsIsMutable();
            return GeneratedMutableMessageLite.parseUnknownField(this.extensions, getDefaultInstanceForType(), codedInputStream, codedOutputStream, extensionRegistryLite, i);
        }

        public final <Type> MessageType setExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> generatedExtension, int i, Type type) {
            assertMutable();
            verifyExtensionContainingType(generatedExtension);
            ensureExtensionsIsMutable();
            this.extensions.setRepeatedField(generatedExtension.descriptor, i, generatedExtension.singularToFieldSetType(type));
            return this;
        }

        public final <Type> MessageType setExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> generatedExtension, Type type) {
            assertMutable();
            verifyExtensionContainingType(generatedExtension);
            ensureExtensionsIsMutable();
            this.extensions.setField(generatedExtension.descriptor, generatedExtension.toFieldSetType(type));
            return this;
        }
    }

    static final class SerializedForm implements Serializable {
        private static final long serialVersionUID = 0;
        private byte[] asBytes;
        private String messageClassName;

        SerializedForm(MutableMessageLite mutableMessageLite) {
            this.messageClassName = mutableMessageLite.getClass().getName();
            this.asBytes = mutableMessageLite.toByteArray();
        }

        /* access modifiers changed from: protected */
        public Object readResolve() throws ObjectStreamException {
            try {
                MutableMessageLite mutableMessageLite = (MutableMessageLite) Class.forName(this.messageClassName).getMethod("newMessage", new Class[0]).invoke(null, new Object[0]);
                if (mutableMessageLite.mergeFrom(CodedInputStream.newInstance(this.asBytes))) {
                    return mutableMessageLite;
                }
                throw new RuntimeException("Unable to understand proto buffer");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException("Unable to find proto buffer class", e);
            } catch (NoSuchMethodException e2) {
                throw new RuntimeException("Unable to find newMessage method", e2);
            } catch (IllegalAccessException e3) {
                throw new RuntimeException("Unable to call newMessage method", e3);
            } catch (InvocationTargetException e4) {
                throw new RuntimeException("Error calling newMessage", e4.getCause());
            }
        }
    }

    static MessageLite.Builder internalCopyToBuilder(MutableMessageLite mutableMessageLite, MessageLite messageLite) {
        MessageLite.Builder newBuilderForType = messageLite.newBuilderForType();
        try {
            newBuilderForType.mergeFrom(mutableMessageLite.toByteArray());
            return newBuilderForType;
        } catch (InvalidProtocolBufferException e) {
            throw new RuntimeException("Failed to parse serialized bytes (should not happen)");
        }
    }

    protected static MessageLite internalImmutableDefault(String str) {
        try {
            return (MessageLite) GeneratedMessageLite.invokeOrDie(GeneratedMessageLite.getMethodOrDie(Class.forName(str), "getDefaultInstance", new Class[0]), null, new Object[0]);
        } catch (ClassNotFoundException e) {
            throw new UnsupportedOperationException("Cannot load the corresponding immutable class. Please add necessary dependencies.");
        }
    }

    /* JADX INFO: additional move instructions added (1) to help type inference */
    /* JADX INFO: additional move instructions added (2) to help type inference */
    static <MessageType extends MutableMessageLite> boolean parseUnknownField(FieldSet<GeneratedMessageLite.ExtensionDescriptor> fieldSet, MessageType messagetype, CodedInputStream codedInputStream, CodedOutputStream codedOutputStream, ExtensionRegistryLite extensionRegistryLite, int i) throws IOException {
        boolean z;
        boolean z2;
        MutableMessageLite mutableMessageLite;
        int tagWireType = WireFormat.getTagWireType(i);
        GeneratedMessageLite.GeneratedExtension findLiteExtensionByNumber = extensionRegistryLite.findLiteExtensionByNumber(messagetype, WireFormat.getTagFieldNumber(i));
        if (findLiteExtensionByNumber == null) {
            z = true;
            z2 = false;
        } else if (tagWireType == FieldSet.getWireFormatForFieldType(findLiteExtensionByNumber.descriptor.getLiteType(), false)) {
            z = false;
            z2 = false;
        } else if (!findLiteExtensionByNumber.descriptor.isRepeated || !findLiteExtensionByNumber.descriptor.type.isPackable() || tagWireType != FieldSet.getWireFormatForFieldType(findLiteExtensionByNumber.descriptor.getLiteType(), true)) {
            z = true;
            z2 = false;
        } else {
            z = false;
            z2 = true;
        }
        if (z) {
            return codedInputStream.skipField(i, codedOutputStream);
        }
        if (z2) {
            int pushLimit = codedInputStream.pushLimit(codedInputStream.readRawVarint32());
            if (findLiteExtensionByNumber.descriptor.getLiteType() == WireFormat.FieldType.ENUM) {
                while (codedInputStream.getBytesUntilLimit() > 0) {
                    Object findValueByNumber = findLiteExtensionByNumber.descriptor.getEnumType().findValueByNumber(codedInputStream.readEnum());
                    if (findValueByNumber == null) {
                        return true;
                    }
                    fieldSet.addRepeatedField(findLiteExtensionByNumber.descriptor, findLiteExtensionByNumber.singularToFieldSetType(findValueByNumber));
                }
            } else {
                while (codedInputStream.getBytesUntilLimit() > 0) {
                    fieldSet.addRepeatedField(findLiteExtensionByNumber.descriptor, FieldSet.readPrimitiveFieldForMutable(codedInputStream, findLiteExtensionByNumber.descriptor.getLiteType(), false));
                }
            }
            codedInputStream.popLimit(pushLimit);
        } else {
            switch (findLiteExtensionByNumber.descriptor.getLiteJavaType()) {
                case MESSAGE:
                    MutableMessageLite newMessageForType = ((MutableMessageLite) findLiteExtensionByNumber.messageDefaultInstance).newMessageForType();
                    if (findLiteExtensionByNumber.descriptor.getLiteType() != WireFormat.FieldType.GROUP) {
                        codedInputStream.readMessage(newMessageForType, extensionRegistryLite);
                        mutableMessageLite = newMessageForType;
                        break;
                    } else {
                        codedInputStream.readGroup(findLiteExtensionByNumber.getNumber(), newMessageForType, extensionRegistryLite);
                        mutableMessageLite = newMessageForType;
                        break;
                    }
                case ENUM:
                    int readEnum = codedInputStream.readEnum();
                    Object findValueByNumber2 = findLiteExtensionByNumber.descriptor.getEnumType().findValueByNumber(readEnum);
                    mutableMessageLite = findValueByNumber2;
                    if (findValueByNumber2 == null) {
                        codedOutputStream.writeRawVarint32(i);
                        codedOutputStream.writeUInt32NoTag(readEnum);
                        return true;
                    }
                    break;
                default:
                    mutableMessageLite = FieldSet.readPrimitiveFieldForMutable(codedInputStream, findLiteExtensionByNumber.descriptor.getLiteType(), false);
                    break;
            }
            if (findLiteExtensionByNumber.descriptor.isRepeated()) {
                fieldSet.addRepeatedField(findLiteExtensionByNumber.descriptor, findLiteExtensionByNumber.singularToFieldSetType(mutableMessageLite));
            } else {
                fieldSet.setField(findLiteExtensionByNumber.descriptor, findLiteExtensionByNumber.singularToFieldSetType(mutableMessageLite));
            }
        }
        return true;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public MessageType clear() {
        assertMutable();
        this.unknownFields = ByteString.EMPTY;
        return this;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite, com.google.tagmanager.protobuf.MessageLiteOrBuilder
    public abstract MessageType getDefaultInstanceForType();

    @Override // com.google.tagmanager.protobuf.MessageLite
    public Parser<MessageType> getParserForType() {
        throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public MessageLite immutableCopy() {
        MessageLite internalImmutableDefault = internalImmutableDefault();
        return this == getDefaultInstanceForType() ? internalImmutableDefault : internalCopyToBuilder(this, internalImmutableDefault).buildPartial();
    }

    /* access modifiers changed from: protected */
    public abstract MessageLite internalImmutableDefault();

    public abstract MessageType mergeFrom(MessageType messagetype);

    /* access modifiers changed from: protected */
    public boolean parseUnknownField(CodedInputStream codedInputStream, CodedOutputStream codedOutputStream, ExtensionRegistryLite extensionRegistryLite, int i) throws IOException {
        return codedInputStream.skipField(i, codedOutputStream);
    }

    /* access modifiers changed from: protected */
    public Object writeReplace() throws ObjectStreamException {
        return new SerializedForm(this);
    }
}

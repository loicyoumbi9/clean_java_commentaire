package com.google.tagmanager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

class SharedPreferencesUtil {
    SharedPreferencesUtil() {
    }

    @SuppressLint({"CommitPrefEdits"})
    static void saveAsync(Context context, String str, String str2, String str3) {
        SharedPreferences.Editor edit = context.getSharedPreferences(str, 0).edit();
        edit.putString(str2, str3);
        saveEditorAsync(edit);
    }

    static void saveEditorAsync(final SharedPreferences.Editor editor) {
        if (Build.VERSION.SDK_INT >= 9) {
            editor.apply();
        } else {
            new Thread(new Runnable() {
                /* class com.google.tagmanager.SharedPreferencesUtil.AnonymousClass1 */

                public void run() {
                    editor.commit();
                }
            }).start();
        }
    }
}

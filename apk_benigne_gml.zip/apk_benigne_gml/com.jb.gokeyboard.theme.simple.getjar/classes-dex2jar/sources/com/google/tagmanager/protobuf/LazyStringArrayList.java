package com.google.tagmanager.protobuf;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public class LazyStringArrayList extends AbstractList<String> implements LazyStringList, RandomAccess {
    public static final LazyStringList EMPTY = new UnmodifiableLazyStringList(new LazyStringArrayList());
    private final List<Object> list;

    private static class ByteArrayListView extends AbstractList<byte[]> {
        private final List<Object> list;

        ByteArrayListView(List<Object> list2) {
            this.list = list2;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void add(int r2, byte[] r3) {
            /*
                r1 = this;
                java.util.List<java.lang.Object> r0 = r1.list
                r0.add(r2, r3)
                int r0 = r1.modCount
                int r0 = r0 + 1
                r1.modCount = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.ByteArrayListView.add(int, byte[]):void");
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: byte[]} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.util.List<java.lang.Object>} */
        /* JADX WARNING: Multi-variable type inference failed */
        @Override // java.util.List, java.util.AbstractList
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public byte[] get(int r3) {
            /*
                r2 = this;
                java.util.List<java.lang.Object> r0 = r2.list
                java.lang.Object r0 = r0.get(r3)
                byte[] r1 = com.google.tagmanager.protobuf.LazyStringArrayList.asByteArray(r0)
                if (r1 == r0) goto L_0x0011
                java.util.List<java.lang.Object> r0 = r2.list
                r0.set(r3, r1)
            L_0x0011:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.ByteArrayListView.get(int):byte[]");
        }

        @Override // java.util.List, java.util.AbstractList
        public byte[] remove(int i) {
            Object remove = this.list.remove(i);
            this.modCount++;
            return LazyStringArrayList.asByteArray(remove);
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public byte[] set(int r2, byte[] r3) {
            /*
                r1 = this;
                java.util.List<java.lang.Object> r0 = r1.list
                java.lang.Object r0 = r0.set(r2, r3)
                byte[] r0 = com.google.tagmanager.protobuf.LazyStringArrayList.asByteArray(r0)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.ByteArrayListView.set(int, byte[]):byte[]");
        }

        public int size() {
            return this.list.size();
        }
    }

    public LazyStringArrayList() {
        this.list = new ArrayList();
    }

    public LazyStringArrayList(LazyStringList lazyStringList) {
        this.list = new ArrayList(lazyStringList.size());
        addAll(lazyStringList);
    }

    public LazyStringArrayList(List<String> list2) {
        this.list = new ArrayList(list2);
    }

    /* access modifiers changed from: private */
    public static byte[] asByteArray(Object obj) {
        return obj instanceof byte[] ? (byte[]) obj : obj instanceof String ? Internal.toByteArray((String) obj) : ((ByteString) obj).toByteArray();
    }

    private static ByteString asByteString(Object obj) {
        return obj instanceof ByteString ? (ByteString) obj : obj instanceof String ? ByteString.copyFromUtf8((String) obj) : ByteString.copyFrom((byte[]) obj);
    }

    private static String asString(Object obj) {
        return obj instanceof String ? (String) obj : obj instanceof ByteString ? ((ByteString) obj).toStringUtf8() : Internal.toStringUtf8((byte[]) obj);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void add(int r2, java.lang.String r3) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            r0.add(r2, r3)
            int r0 = r1.modCount
            int r0 = r0 + 1
            r1.modCount = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.add(int, java.lang.String):void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void add(com.google.tagmanager.protobuf.ByteString r2) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            r0.add(r2)
            int r0 = r1.modCount
            int r0 = r0 + 1
            r1.modCount = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.add(com.google.tagmanager.protobuf.ByteString):void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void add(byte[] r2) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            r0.add(r2)
            int r0 = r1.modCount
            int r0 = r0 + 1
            r1.modCount = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.add(byte[]):void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // java.util.List, java.util.AbstractList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean addAll(int r3, java.util.Collection<? extends java.lang.String> r4) {
        /*
            r2 = this;
            boolean r0 = r4 instanceof com.google.tagmanager.protobuf.LazyStringList
            if (r0 == 0) goto L_0x000a
            com.google.tagmanager.protobuf.LazyStringList r4 = (com.google.tagmanager.protobuf.LazyStringList) r4
            java.util.List r4 = r4.getUnderlyingElements()
        L_0x000a:
            java.util.List<java.lang.Object> r0 = r2.list
            boolean r0 = r0.addAll(r3, r4)
            int r1 = r2.modCount
            int r1 = r1 + 1
            r2.modCount = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.addAll(int, java.util.Collection):boolean");
    }

    @Override // java.util.AbstractCollection, java.util.List, java.util.Collection
    public boolean addAll(Collection<? extends String> collection) {
        return addAll(size(), collection);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean addAllByteArray(java.util.Collection<byte[]> r3) {
        /*
            r2 = this;
            java.util.List<java.lang.Object> r0 = r2.list
            boolean r0 = r0.addAll(r3)
            int r1 = r2.modCount
            int r1 = r1 + 1
            r2.modCount = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.addAllByteArray(java.util.Collection):boolean");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean addAllByteString(java.util.Collection<? extends com.google.tagmanager.protobuf.ByteString> r3) {
        /*
            r2 = this;
            java.util.List<java.lang.Object> r0 = r2.list
            boolean r0 = r0.addAll(r3)
            int r1 = r2.modCount
            int r1 = r1 + 1
            r2.modCount = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.addAllByteString(java.util.Collection):boolean");
    }

    @Override // com.google.tagmanager.protobuf.LazyStringList
    public List<byte[]> asByteArrayList() {
        return new ByteArrayListView(this.list);
    }

    public void clear() {
        this.list.clear();
        this.modCount++;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v6, resolved type: java.util.List<java.lang.Object>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v9, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // java.util.List, java.util.AbstractList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String get(int r3) {
        /*
            r2 = this;
            java.util.List<java.lang.Object> r0 = r2.list
            java.lang.Object r0 = r0.get(r3)
            boolean r1 = r0 instanceof java.lang.String
            if (r1 == 0) goto L_0x000e
            java.lang.String r0 = (java.lang.String) r0
        L_0x000c:
            r1 = r0
        L_0x000d:
            return r1
        L_0x000e:
            boolean r1 = r0 instanceof com.google.tagmanager.protobuf.ByteString
            if (r1 == 0) goto L_0x0024
            com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
            java.lang.String r1 = r0.toStringUtf8()
            boolean r0 = r0.isValidUtf8()
            if (r0 == 0) goto L_0x0038
            java.util.List<java.lang.Object> r0 = r2.list
            r0.set(r3, r1)
            goto L_0x000d
        L_0x0024:
            byte[] r0 = (byte[]) r0
            byte[] r0 = (byte[]) r0
            java.lang.String r1 = com.google.tagmanager.protobuf.Internal.toStringUtf8(r0)
            boolean r0 = com.google.tagmanager.protobuf.Internal.isValidUtf8(r0)
            if (r0 == 0) goto L_0x0038
            java.util.List<java.lang.Object> r0 = r2.list
            r0.set(r3, r1)
            goto L_0x000d
        L_0x0038:
            r0 = r1
            goto L_0x000c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.get(int):java.lang.String");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public byte[] getByteArray(int r3) {
        /*
            r2 = this;
            java.util.List<java.lang.Object> r0 = r2.list
            java.lang.Object r0 = r0.get(r3)
            byte[] r1 = asByteArray(r0)
            if (r1 == r0) goto L_0x0011
            java.util.List<java.lang.Object> r0 = r2.list
            r0.set(r3, r1)
        L_0x0011:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.getByteArray(int):byte[]");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.tagmanager.protobuf.ByteString getByteString(int r3) {
        /*
            r2 = this;
            java.util.List<java.lang.Object> r0 = r2.list
            java.lang.Object r0 = r0.get(r3)
            com.google.tagmanager.protobuf.ByteString r1 = asByteString(r0)
            if (r1 == r0) goto L_0x0011
            java.util.List<java.lang.Object> r0 = r2.list
            r0.set(r3, r1)
        L_0x0011:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.getByteString(int):com.google.tagmanager.protobuf.ByteString");
    }

    @Override // com.google.tagmanager.protobuf.LazyStringList
    public List<?> getUnderlyingElements() {
        return Collections.unmodifiableList(this.list);
    }

    @Override // com.google.tagmanager.protobuf.LazyStringList
    public void mergeFrom(LazyStringList lazyStringList) {
        for (Object obj : lazyStringList.getUnderlyingElements()) {
            if (obj instanceof byte[]) {
                byte[] bArr = (byte[]) obj;
                this.list.add(Arrays.copyOf(bArr, bArr.length));
            } else {
                this.list.add(obj);
            }
        }
    }

    @Override // java.util.List, java.util.AbstractList
    public String remove(int i) {
        Object remove = this.list.remove(i);
        this.modCount++;
        return asString(remove);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String set(int r2, java.lang.String r3) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            java.lang.Object r0 = r0.set(r2, r3)
            java.lang.String r0 = asString(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.set(int, java.lang.String):java.lang.String");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void set(int r2, com.google.tagmanager.protobuf.ByteString r3) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            r0.set(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.set(int, com.google.tagmanager.protobuf.ByteString):void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.List<java.lang.Object>} */
    /* JADX WARNING: Multi-variable type inference failed */
    @Override // com.google.tagmanager.protobuf.LazyStringList
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void set(int r2, byte[] r3) {
        /*
            r1 = this;
            java.util.List<java.lang.Object> r0 = r1.list
            r0.set(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.LazyStringArrayList.set(int, byte[]):void");
    }

    public int size() {
        return this.list.size();
    }
}

package com.google.tagmanager;

import com.google.android.gms.common.util.VisibleForTesting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

public class DataLayer {
    static final int MAX_QUEUE_DEPTH = 500;
    public static final Object OBJECT_NOT_PRESENT = new Object();
    private final ConcurrentHashMap<Listener, Integer> mListeners = new ConcurrentHashMap<>();
    private final Map<Object, Object> mModel = new HashMap();
    private final ReentrantLock mPushLock = new ReentrantLock();
    private final LinkedList<Map<Object, Object>> mUpdateQueue = new LinkedList<>();

    interface Listener {
        void changed(Map<Object, Object> map);
    }

    DataLayer() {
    }

    public static List<Object> listOf(Object... objArr) {
        ArrayList arrayList = new ArrayList();
        for (Object obj : objArr) {
            arrayList.add(obj);
        }
        return arrayList;
    }

    public static Map<Object, Object> mapOf(Object... objArr) {
        if (objArr.length % 2 != 0) {
            throw new IllegalArgumentException("expected even number of key-value pairs");
        }
        HashMap hashMap = new HashMap();
        for (int i = 0; i < objArr.length; i += 2) {
            hashMap.put(objArr[i], objArr[i + 1]);
        }
        return hashMap;
    }

    private void notifyListeners(Map<Object, Object> map) {
        for (Listener listener : this.mListeners.keySet()) {
            listener.changed(map);
        }
    }

    private void processQueuedUpdates() {
        int i = 0;
        while (true) {
            int i2 = i;
            Map<Object, Object> poll = this.mUpdateQueue.poll();
            if (poll != null) {
                processUpdate(poll);
                i = i2 + 1;
                if (i > 500) {
                    this.mUpdateQueue.clear();
                    throw new RuntimeException("Seems like an infinite loop of pushing to the data layer");
                }
            } else {
                return;
            }
        }
    }

    private void processUpdate(Map<Object, Object> map) {
        synchronized (this.mModel) {
            for (Object obj : map.keySet()) {
                mergeMap(expandKeyValue(obj, map.get(obj)), this.mModel);
            }
        }
        notifyListeners(map);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public Map<Object, Object> expandKeyValue(Object obj, Object obj2) {
        HashMap hashMap = new HashMap();
        String[] split = obj.toString().split("\\.");
        HashMap hashMap2 = hashMap;
        int i = 0;
        while (i < split.length - 1) {
            HashMap hashMap3 = new HashMap();
            hashMap2.put(split[i], hashMap3);
            i++;
            hashMap2 = hashMap3;
        }
        hashMap2.put(split[split.length - 1], obj2);
        return hashMap;
    }

    public Object get(String str) {
        synchronized (this.mModel) {
            Object obj = this.mModel;
            String[] split = str.split("\\.");
            for (String str2 : split) {
                if (!(obj instanceof Map)) {
                    return null;
                }
                obj = ((Map) obj).get(str2);
                if (obj == null) {
                    return null;
                }
            }
            return obj;
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void mergeList(List<Object> list, List<Object> list2) {
        while (list2.size() < list.size()) {
            list2.add(null);
        }
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < list.size()) {
                Object obj = list.get(i2);
                if (obj instanceof List) {
                    if (!(list2.get(i2) instanceof List)) {
                        list2.set(i2, new ArrayList());
                    }
                    mergeList((List) obj, (List) list2.get(i2));
                } else if (obj instanceof Map) {
                    if (!(list2.get(i2) instanceof Map)) {
                        list2.set(i2, new HashMap());
                    }
                    mergeMap((Map) obj, (Map) list2.get(i2));
                } else if (obj != OBJECT_NOT_PRESENT) {
                    list2.set(i2, obj);
                }
                i = i2 + 1;
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void mergeMap(Map<Object, Object> map, Map<Object, Object> map2) {
        for (Object obj : map.keySet()) {
            Object obj2 = map.get(obj);
            if (obj2 instanceof List) {
                if (!(map2.get(obj) instanceof List)) {
                    map2.put(obj, new ArrayList());
                }
                mergeList((List) obj2, (List) map2.get(obj));
            } else if (obj2 instanceof Map) {
                if (!(map2.get(obj) instanceof Map)) {
                    map2.put(obj, new HashMap());
                }
                mergeMap((Map) obj2, (Map) map2.get(obj));
            } else {
                map2.put(obj, obj2);
            }
        }
    }

    public void push(Object obj, Object obj2) {
        push(expandKeyValue(obj, obj2));
    }

    public void push(Map<Object, Object> map) {
        this.mPushLock.lock();
        try {
            this.mUpdateQueue.offer(map);
            if (this.mPushLock.getHoldCount() == 1) {
                processQueuedUpdates();
            }
        } finally {
            this.mPushLock.unlock();
        }
    }

    /* access modifiers changed from: package-private */
    public void registerListener(Listener listener) {
        this.mListeners.put(listener, 0);
    }

    /* access modifiers changed from: package-private */
    public void unregisterListener(Listener listener) {
        this.mListeners.remove(listener);
    }
}

package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

class EncodeMacro extends FunctionCallImplementation {
    private static final String ARG0 = Key.ARG0.toString();
    private static final String DEFAULT_INPUT_FORMAT = "text";
    private static final String DEFAULT_OUTPUT_FORMAT = "base16";
    private static final String ID = FunctionType.ENCODE.toString();
    private static final String INPUT_FORMAT = Key.INPUT_FORMAT.toString();
    private static final String NO_PADDING = Key.NO_PADDING.toString();
    private static final String OUTPUT_FORMAT = Key.OUTPUT_FORMAT.toString();

    public EncodeMacro() {
        super(ID, ARG0);
    }

    public static String getFunctionId() {
        return ID;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        byte[] decode;
        String encodeToString;
        TypeSystem.Value value = map.get(ARG0);
        if (value == null || value == Types.getDefaultValue()) {
            return Types.getDefaultValue();
        }
        String valueToString = Types.valueToString(value);
        TypeSystem.Value value2 = map.get(INPUT_FORMAT);
        String valueToString2 = value2 == null ? DEFAULT_INPUT_FORMAT : Types.valueToString(value2);
        TypeSystem.Value value3 = map.get(OUTPUT_FORMAT);
        String valueToString3 = value3 == null ? DEFAULT_OUTPUT_FORMAT : Types.valueToString(value3);
        map.get(INPUT_FORMAT);
        int i = 0;
        TypeSystem.Value value4 = map.get(NO_PADDING);
        if (value4 != null && Types.valueToBoolean(value4).booleanValue()) {
            i = 1;
        }
        try {
            if (DEFAULT_INPUT_FORMAT.equals(valueToString2)) {
                decode = valueToString.getBytes();
            } else if (DEFAULT_OUTPUT_FORMAT.equals(valueToString2)) {
                decode = Base16.decode(valueToString);
            } else if ("base64".equals(valueToString2)) {
                decode = Base64Encoder.decode(valueToString, i);
            } else if ("base64url".equals(valueToString2)) {
                decode = Base64Encoder.decode(valueToString, i | 2);
            } else {
                Log.e("Encode: unknown input format: " + valueToString2);
                return Types.getDefaultValue();
            }
            if (DEFAULT_OUTPUT_FORMAT.equals(valueToString3)) {
                encodeToString = Base16.encode(decode);
            } else if ("base64".equals(valueToString3)) {
                encodeToString = Base64Encoder.encodeToString(decode, i);
            } else if ("base64url".equals(valueToString3)) {
                encodeToString = Base64Encoder.encodeToString(decode, i | 2);
            } else {
                Log.e("Encode: unknown output format: " + valueToString3);
                return Types.getDefaultValue();
            }
            return Types.objectToValue(encodeToString);
        } catch (IllegalArgumentException e) {
            Log.e("Encode: invalid input:");
            return Types.getDefaultValue();
        }
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return true;
    }
}

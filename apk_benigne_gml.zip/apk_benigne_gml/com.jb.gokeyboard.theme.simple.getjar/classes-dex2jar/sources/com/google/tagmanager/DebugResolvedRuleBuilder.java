package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.tagmanager.ResourceUtil;
import java.util.List;
import java.util.Map;

class DebugResolvedRuleBuilder implements ResolvedRuleBuilder {
    ResolvedFunctionCallTranslatorList addMacrosHolder = new DebugResolvedFunctionCallListTranslator(this.resolvedRule.getMutableAddMacrosList());
    ResolvedFunctionCallTranslatorList addTagsHolder = new DebugResolvedFunctionCallListTranslator(this.resolvedRule.getMutableAddTagsList());
    ResolvedFunctionCallTranslatorList removeMacrosHolder = new DebugResolvedFunctionCallListTranslator(this.resolvedRule.getMutableRemoveMacrosList());
    ResolvedFunctionCallTranslatorList removeTagsHolder = new DebugResolvedFunctionCallListTranslator(this.resolvedRule.getMutableRemoveTagsList());
    MutableDebug.ResolvedRule resolvedRule;

    class DebugResolvedFunctionCallListTranslator implements ResolvedFunctionCallTranslatorList {
        @VisibleForTesting
        List<MutableDebug.ResolvedFunctionCall> toBuild;

        DebugResolvedFunctionCallListTranslator(List<MutableDebug.ResolvedFunctionCall> list) {
            this.toBuild = list;
        }

        @Override // com.google.tagmanager.ResolvedFunctionCallTranslatorList
        public void translateAndAddAll(List<ResourceUtil.ExpandedFunctionCall> list, List<String> list2) {
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 < list.size()) {
                    this.toBuild.add(DebugResolvedRuleBuilder.translateExpandedFunctionCall(list.get(i2)));
                    if (i2 < list2.size()) {
                        this.toBuild.get(i2).setAssociatedRuleName(list2.get(i2));
                    } else {
                        this.toBuild.get(i2).setAssociatedRuleName("Unknown");
                    }
                    i = i2 + 1;
                } else {
                    return;
                }
            }
        }
    }

    public DebugResolvedRuleBuilder(MutableDebug.ResolvedRule resolvedRule2) {
        this.resolvedRule = resolvedRule2;
    }

    public static MutableDebug.ResolvedFunctionCall translateExpandedFunctionCall(ResourceUtil.ExpandedFunctionCall expandedFunctionCall) {
        MutableDebug.ResolvedFunctionCall newMessage = MutableDebug.ResolvedFunctionCall.newMessage();
        for (Map.Entry<String, TypeSystem.Value> entry : expandedFunctionCall.getProperties().entrySet()) {
            MutableDebug.ResolvedProperty newMessage2 = MutableDebug.ResolvedProperty.newMessage();
            newMessage2.setKey(entry.getKey());
            newMessage2.setValue(DebugValueBuilder.copyImmutableValue(entry.getValue()));
            newMessage.addProperties(newMessage2);
        }
        return newMessage;
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallBuilder createNegativePredicate() {
        return new DebugResolvedFunctionCallBuilder(this.resolvedRule.addNegativePredicates());
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallBuilder createPositivePredicate() {
        return new DebugResolvedFunctionCallBuilder(this.resolvedRule.addPositivePredicates());
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallTranslatorList getAddedMacroFunctions() {
        return this.addMacrosHolder;
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallTranslatorList getAddedTagFunctions() {
        return this.addTagsHolder;
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallTranslatorList getRemovedMacroFunctions() {
        return this.removeMacrosHolder;
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public ResolvedFunctionCallTranslatorList getRemovedTagFunctions() {
        return this.removeTagsHolder;
    }

    @Override // com.google.tagmanager.ResolvedRuleBuilder
    public void setValue(TypeSystem.Value value) {
        this.resolvedRule.setResult(DebugValueBuilder.copyImmutableValue(value));
    }
}

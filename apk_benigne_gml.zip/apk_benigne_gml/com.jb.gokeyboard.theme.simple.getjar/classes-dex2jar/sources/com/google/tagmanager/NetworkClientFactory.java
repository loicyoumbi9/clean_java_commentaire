package com.google.tagmanager;

import android.os.Build;
import com.google.android.gms.common.util.VisibleForTesting;

class NetworkClientFactory {
    NetworkClientFactory() {
    }

    public NetworkClient createNetworkClient() {
        return getSdkVersion() < 8 ? new HttpNetworkClient() : new HttpUrlConnectionNetworkClient();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public int getSdkVersion() {
        return Build.VERSION.SDK_INT;
    }
}

package com.google.tagmanager.protobuf;

public interface MessageLiteOrBuilder {
    MessageLite getDefaultInstanceForType();

    boolean isInitialized();
}

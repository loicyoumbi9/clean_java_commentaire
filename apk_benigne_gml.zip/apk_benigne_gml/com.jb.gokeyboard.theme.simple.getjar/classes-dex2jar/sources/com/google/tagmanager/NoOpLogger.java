package com.google.tagmanager;

import com.google.tagmanager.Logger;

class NoOpLogger implements Logger {
    NoOpLogger() {
    }

    @Override // com.google.tagmanager.Logger
    public void d(String str) {
    }

    @Override // com.google.tagmanager.Logger
    public void d(String str, Throwable th) {
    }

    @Override // com.google.tagmanager.Logger
    public void e(String str) {
    }

    @Override // com.google.tagmanager.Logger
    public void e(String str, Throwable th) {
    }

    @Override // com.google.tagmanager.Logger
    public Logger.LogLevel getLogLevel() {
        return Logger.LogLevel.NONE;
    }

    @Override // com.google.tagmanager.Logger
    public void i(String str) {
    }

    @Override // com.google.tagmanager.Logger
    public void i(String str, Throwable th) {
    }

    @Override // com.google.tagmanager.Logger
    public void setLogLevel(Logger.LogLevel logLevel) {
    }

    @Override // com.google.tagmanager.Logger
    public void v(String str) {
    }

    @Override // com.google.tagmanager.Logger
    public void v(String str, Throwable th) {
    }

    @Override // com.google.tagmanager.Logger
    public void w(String str) {
    }

    @Override // com.google.tagmanager.Logger
    public void w(String str, Throwable th) {
    }
}

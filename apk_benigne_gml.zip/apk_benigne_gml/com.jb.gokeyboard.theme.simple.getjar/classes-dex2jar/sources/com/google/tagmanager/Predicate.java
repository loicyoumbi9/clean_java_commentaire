package com.google.tagmanager;

import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

abstract class Predicate extends FunctionCallImplementation {
    private static final String ARG0 = Key.ARG0.toString();
    private static final String ARG1 = Key.ARG1.toString();

    public Predicate(String str) {
        super(str, ARG0, ARG1);
    }

    public static String getArg0Key() {
        return ARG0;
    }

    public static String getArg1Key() {
        return ARG1;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        for (TypeSystem.Value value : map.values()) {
            if (value == Types.getDefaultValue()) {
                return Types.objectToValue(false);
            }
        }
        TypeSystem.Value value2 = map.get(ARG0);
        TypeSystem.Value value3 = map.get(ARG1);
        return Types.objectToValue(Boolean.valueOf(value2 != null ? value3 == null ? false : evaluateNoDefaultValues(value2, value3, map) : false));
    }

    /* access modifiers changed from: protected */
    public abstract boolean evaluateNoDefaultValues(TypeSystem.Value value, TypeSystem.Value value2, Map<String, TypeSystem.Value> map);

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return true;
    }
}

package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.IOException;

class CtfeDebugInformationHandler implements DebugInformationHandler {
    @VisibleForTesting
    static final String CTFE_URL_PATH_PREFIX = "/d?";
    @VisibleForTesting
    static final int NUM_EVENTS_PER_SEND = 1;
    private int currentDebugEventNumber;
    private NetworkClient mClient;
    private CtfeHost mCtfeHost;
    private MutableDebug.DebugEvents mDebugEvents;

    public CtfeDebugInformationHandler(CtfeHost ctfeHost) {
        this(new NetworkClientFactory().createNetworkClient(), ctfeHost);
    }

    @VisibleForTesting
    CtfeDebugInformationHandler(NetworkClient networkClient, CtfeHost ctfeHost) {
        this.mCtfeHost = ctfeHost;
        this.mClient = networkClient;
        this.mDebugEvents = MutableDebug.DebugEvents.newMessage();
    }

    private byte[] getDebugEventsAsBytes() {
        return this.mDebugEvents.toByteArray();
    }

    private boolean sendDebugInformationtoCtfe() {
        try {
            NetworkClient networkClient = this.mClient;
            CtfeHost ctfeHost = this.mCtfeHost;
            int i = this.currentDebugEventNumber;
            this.currentDebugEventNumber = i + 1;
            networkClient.sendPostRequest(ctfeHost.constructCtfeDebugUrl(i), getDebugEventsAsBytes());
            return true;
        } catch (IOException e) {
            Log.e("CtfeDebugInformationHandler: Error sending information to server that handles debug information: " + e.getMessage());
            return false;
        }
    }

    @Override // com.google.tagmanager.DebugInformationHandler
    public void receiveEventInfo(MutableDebug.EventInfo eventInfo) {
        synchronized (this) {
            this.mDebugEvents.addEvent(eventInfo);
            if (this.mDebugEvents.getEventCount() >= 1 && sendDebugInformationtoCtfe()) {
                this.mDebugEvents = this.mDebugEvents.clear();
            }
        }
    }
}

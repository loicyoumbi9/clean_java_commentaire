package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;
import com.google.tagmanager.ResourceUtil;
import java.util.Set;

class DebugRuleEvaluationStepInfoBuilder implements RuleEvaluationStepInfoBuilder {
    private MutableDebug.RuleEvaluationStepInfo ruleEvaluationStepInfo;

    public DebugRuleEvaluationStepInfoBuilder(MutableDebug.RuleEvaluationStepInfo ruleEvaluationStepInfo2) {
        this.ruleEvaluationStepInfo = ruleEvaluationStepInfo2;
    }

    @Override // com.google.tagmanager.RuleEvaluationStepInfoBuilder
    public ResolvedRuleBuilder createResolvedRuleBuilder() {
        return new DebugResolvedRuleBuilder(this.ruleEvaluationStepInfo.addRules());
    }

    @Override // com.google.tagmanager.RuleEvaluationStepInfoBuilder
    public void setEnabledFunctions(Set<ResourceUtil.ExpandedFunctionCall> set) {
        for (ResourceUtil.ExpandedFunctionCall expandedFunctionCall : set) {
            this.ruleEvaluationStepInfo.addEnabledFunctions(DebugResolvedRuleBuilder.translateExpandedFunctionCall(expandedFunctionCall));
        }
    }
}

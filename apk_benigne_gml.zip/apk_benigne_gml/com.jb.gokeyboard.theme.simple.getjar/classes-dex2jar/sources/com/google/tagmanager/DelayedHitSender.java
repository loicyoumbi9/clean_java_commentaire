package com.google.tagmanager;

import android.content.Context;
import com.getjar.sdk.utilities.Constants;
import com.getjar.sdk.utilities.Utility;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

class DelayedHitSender implements HitSender {
    private static DelayedHitSender sInstance;
    private static final Object sInstanceLock = new Object();
    private RateLimiter mRateLimiter;
    private HitSendingThread mSendingThread;
    private String mWrapperQueryParameter;
    private String mWrapperUrl;

    private DelayedHitSender(Context context) {
        this(HitSendingThreadImpl.getInstance(context), new SendHitRateLimiter());
    }

    @VisibleForTesting
    DelayedHitSender(HitSendingThread hitSendingThread, RateLimiter rateLimiter) {
        this.mSendingThread = hitSendingThread;
        this.mRateLimiter = rateLimiter;
    }

    public static HitSender getInstance(Context context) {
        DelayedHitSender delayedHitSender;
        synchronized (sInstanceLock) {
            if (sInstance == null) {
                sInstance = new DelayedHitSender(context);
            }
            delayedHitSender = sInstance;
        }
        return delayedHitSender;
    }

    @Override // com.google.tagmanager.HitSender
    public boolean sendHit(String str) {
        if (!this.mRateLimiter.tokenAvailable()) {
            Log.w("Too many urls sent too quickly with the TagManagerSender, rate limiting invoked.");
            return false;
        }
        if (!(this.mWrapperUrl == null || this.mWrapperQueryParameter == null)) {
            try {
                str = this.mWrapperUrl + Utility.QUERY_START + this.mWrapperQueryParameter + "=" + URLEncoder.encode(str, Constants.ENCODING_CHARSET);
                Log.v("Sending wrapped url hit: " + str);
            } catch (UnsupportedEncodingException e) {
                Log.w("Error wrapping URL for testing.", e);
                return false;
            }
        }
        this.mSendingThread.sendHit(str);
        return true;
    }

    @Override // com.google.tagmanager.HitSender
    public void setUrlWrapModeForTesting(String str, String str2) {
        this.mWrapperUrl = str;
        this.mWrapperQueryParameter = str2;
    }
}

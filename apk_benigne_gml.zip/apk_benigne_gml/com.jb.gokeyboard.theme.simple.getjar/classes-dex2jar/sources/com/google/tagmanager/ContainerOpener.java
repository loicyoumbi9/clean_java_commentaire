package com.google.tagmanager;

import com.google.tagmanager.Container;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;

public class ContainerOpener {
    public static final long DEFAULT_TIMEOUT_IN_MILLIS = 2000;
    private static final Map<String, List<Notifier>> mContainerIdNotifiersMap = new HashMap();
    private Clock mClock = new Clock() {
        /* class com.google.tagmanager.ContainerOpener.AnonymousClass1 */

        @Override // com.google.tagmanager.Clock
        public long currentTimeMillis() {
            return System.currentTimeMillis();
        }
    };
    /* access modifiers changed from: private */
    public volatile Container mContainer;
    private final String mContainerId;
    private boolean mHaveNotified;
    private Notifier mNotifier;
    private final TagManager mTagManager;
    private final long mTimeoutInMillis;

    public interface ContainerFuture {
        Container get();

        boolean isDone();
    }

    private static class ContainerFutureImpl implements ContainerFuture {
        private volatile Container mContainer;
        private Semaphore mContainerIsReady;
        private volatile boolean mHaveGotten;

        private ContainerFutureImpl() {
            this.mContainerIsReady = new Semaphore(0);
        }

        @Override // com.google.tagmanager.ContainerOpener.ContainerFuture
        public Container get() {
            if (this.mHaveGotten) {
                return this.mContainer;
            }
            try {
                this.mContainerIsReady.acquire();
            } catch (InterruptedException e) {
            }
            this.mHaveGotten = true;
            return this.mContainer;
        }

        @Override // com.google.tagmanager.ContainerOpener.ContainerFuture
        public boolean isDone() {
            return this.mHaveGotten || this.mContainerIsReady.availablePermits() > 0;
        }

        public void setContainer(Container container) {
            this.mContainer = container;
            this.mContainerIsReady.release();
        }
    }

    public interface Notifier {
        void containerAvailable(Container container);
    }

    public enum OpenType {
        PREFER_NON_DEFAULT,
        PREFER_FRESH
    }

    private class WaitForFresh implements Container.Callback {
        private final long mOldestTimeToBeFresh;

        public WaitForFresh(long j) {
            this.mOldestTimeToBeFresh = j;
        }

        private boolean isFresh() {
            return this.mOldestTimeToBeFresh < ContainerOpener.this.mContainer.getLastRefreshTime();
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshBegin(Container container, Container.RefreshType refreshType) {
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshFailure(Container container, Container.RefreshType refreshType, Container.RefreshFailure refreshFailure) {
            if (refreshType == Container.RefreshType.NETWORK) {
                ContainerOpener.this.callNotifiers(container);
            }
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshSuccess(Container container, Container.RefreshType refreshType) {
            if (refreshType == Container.RefreshType.NETWORK || isFresh()) {
                ContainerOpener.this.callNotifiers(container);
            }
        }
    }

    private class WaitForNonDefaultRefresh implements Container.Callback {
        public WaitForNonDefaultRefresh() {
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshBegin(Container container, Container.RefreshType refreshType) {
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshFailure(Container container, Container.RefreshType refreshType, Container.RefreshFailure refreshFailure) {
            if (refreshType == Container.RefreshType.NETWORK) {
                ContainerOpener.this.callNotifiers(container);
            }
        }

        @Override // com.google.tagmanager.Container.Callback
        public void containerRefreshSuccess(Container container, Container.RefreshType refreshType) {
            ContainerOpener.this.callNotifiers(container);
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{java.lang.Math.max(long, long):long}
     arg types: [int, long]
     candidates:
      ClspMth{java.lang.Math.max(double, double):double}
      ClspMth{java.lang.Math.max(int, int):int}
      ClspMth{java.lang.Math.max(float, float):float}
      ClspMth{java.lang.Math.max(long, long):long} */
    private ContainerOpener(TagManager tagManager, String str, Long l, Notifier notifier) {
        this.mTagManager = tagManager;
        this.mContainerId = str;
        this.mTimeoutInMillis = l != null ? Math.max(1L, l.longValue()) : 2000;
        this.mNotifier = notifier;
    }

    /* access modifiers changed from: private */
    public void callNotifiers(Container container) {
        List<Notifier> remove;
        synchronized (this) {
            if (!this.mHaveNotified) {
                synchronized (ContainerOpener.class) {
                    try {
                        remove = mContainerIdNotifiersMap.remove(this.mContainerId);
                    } catch (Throwable th) {
                        while (true) {
                            throw th;
                        }
                    }
                }
                if (remove != null) {
                    for (Notifier notifier : remove) {
                        notifier.containerAvailable(container);
                    }
                }
                this.mHaveNotified = true;
            }
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{java.lang.Math.max(long, long):long}
     arg types: [int, long]
     candidates:
      ClspMth{java.lang.Math.max(double, double):double}
      ClspMth{java.lang.Math.max(int, int):int}
      ClspMth{java.lang.Math.max(float, float):float}
      ClspMth{java.lang.Math.max(long, long):long} */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0043, code lost:
        if (r0 == false) goto L_0x0079;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0045, code lost:
        r9.mNotifier.containerAvailable(r9.mContainer);
        r9.mNotifier = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0079, code lost:
        setTimer(java.lang.Math.max(1L, r9.mTimeoutInMillis - (r9.mClock.currentTimeMillis() - r2)));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void open(com.google.tagmanager.Container.RefreshType r10) {
        /*
            r9 = this;
            r8 = 0
            com.google.tagmanager.Clock r0 = r9.mClock
            long r2 = r0.currentTimeMillis()
            r0 = 0
            java.lang.Class<com.google.tagmanager.ContainerOpener> r1 = com.google.tagmanager.ContainerOpener.class
            monitor-enter(r1)
            com.google.tagmanager.TagManager r1 = r9.mTagManager     // Catch:{ all -> 0x005a }
            java.lang.String r4 = r9.mContainerId     // Catch:{ all -> 0x005a }
            com.google.tagmanager.Container r1 = r1.getContainer(r4)     // Catch:{ all -> 0x005a }
            r9.mContainer = r1     // Catch:{ all -> 0x005a }
            com.google.tagmanager.Container r1 = r9.mContainer     // Catch:{ all -> 0x005a }
            if (r1 != 0) goto L_0x005f
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x005a }
            r1.<init>()     // Catch:{ all -> 0x005a }
            com.google.tagmanager.ContainerOpener$Notifier r4 = r9.mNotifier     // Catch:{ all -> 0x005a }
            r1.add(r4)     // Catch:{ all -> 0x005a }
            r4 = 0
            r9.mNotifier = r4     // Catch:{ all -> 0x005a }
            java.util.Map<java.lang.String, java.util.List<com.google.tagmanager.ContainerOpener$Notifier>> r4 = com.google.tagmanager.ContainerOpener.mContainerIdNotifiersMap     // Catch:{ all -> 0x005a }
            java.lang.String r5 = r9.mContainerId     // Catch:{ all -> 0x005a }
            r4.put(r5, r1)     // Catch:{ all -> 0x005a }
            com.google.tagmanager.TagManager r4 = r9.mTagManager     // Catch:{ all -> 0x005a }
            java.lang.String r5 = r9.mContainerId     // Catch:{ all -> 0x005a }
            com.google.tagmanager.Container$RefreshType r1 = com.google.tagmanager.Container.RefreshType.SAVED     // Catch:{ all -> 0x005a }
            if (r10 != r1) goto L_0x004f
            com.google.tagmanager.ContainerOpener$WaitForNonDefaultRefresh r1 = new com.google.tagmanager.ContainerOpener$WaitForNonDefaultRefresh     // Catch:{ all -> 0x005a }
            r1.<init>()     // Catch:{ all -> 0x005a }
        L_0x003a:
            com.google.tagmanager.Container r1 = r4.openContainer(r5, r1)     // Catch:{ all -> 0x005a }
            r9.mContainer = r1     // Catch:{ all -> 0x005a }
        L_0x0040:
            java.lang.Class<com.google.tagmanager.ContainerOpener> r1 = com.google.tagmanager.ContainerOpener.class
            monitor-exit(r1)     // Catch:{ all -> 0x005a }
            if (r0 == 0) goto L_0x0079
            com.google.tagmanager.ContainerOpener$Notifier r0 = r9.mNotifier
            com.google.tagmanager.Container r1 = r9.mContainer
            r0.containerAvailable(r1)
            r9.mNotifier = r8
        L_0x004e:
            return
        L_0x004f:
            com.google.tagmanager.ContainerOpener$WaitForFresh r1 = new com.google.tagmanager.ContainerOpener$WaitForFresh     // Catch:{ all -> 0x005a }
            r6 = 43200000(0x2932e00, double:2.1343636E-316)
            long r6 = r2 - r6
            r1.<init>(r6)     // Catch:{ all -> 0x005a }
            goto L_0x003a
        L_0x005a:
            r0 = move-exception
            java.lang.Class<com.google.tagmanager.ContainerOpener> r1 = com.google.tagmanager.ContainerOpener.class
            monitor-exit(r1)     // Catch:{ all -> 0x005a }
            throw r0
        L_0x005f:
            java.util.Map<java.lang.String, java.util.List<com.google.tagmanager.ContainerOpener$Notifier>> r0 = com.google.tagmanager.ContainerOpener.mContainerIdNotifiersMap     // Catch:{ all -> 0x005a }
            java.lang.String r1 = r9.mContainerId     // Catch:{ all -> 0x005a }
            java.lang.Object r0 = r0.get(r1)     // Catch:{ all -> 0x005a }
            java.util.List r0 = (java.util.List) r0     // Catch:{ all -> 0x005a }
            if (r0 != 0) goto L_0x006d
            r0 = 1
            goto L_0x0040
        L_0x006d:
            com.google.tagmanager.ContainerOpener$Notifier r1 = r9.mNotifier     // Catch:{ all -> 0x005a }
            r0.add(r1)     // Catch:{ all -> 0x005a }
            r0 = 0
            r9.mNotifier = r0     // Catch:{ all -> 0x005a }
            java.lang.Class<com.google.tagmanager.ContainerOpener> r0 = com.google.tagmanager.ContainerOpener.class
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            goto L_0x004e
        L_0x0079:
            r0 = 1
            long r4 = r9.mTimeoutInMillis
            com.google.tagmanager.Clock r6 = r9.mClock
            long r6 = r6.currentTimeMillis()
            long r2 = r6 - r2
            long r2 = r4 - r2
            long r0 = java.lang.Math.max(r0, r2)
            r9.setTimer(r0)
            goto L_0x004e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.ContainerOpener.open(com.google.tagmanager.Container$RefreshType):void");
    }

    public static ContainerFuture openContainer(TagManager tagManager, String str, OpenType openType, Long l) {
        final ContainerFutureImpl containerFutureImpl = new ContainerFutureImpl();
        openContainer(tagManager, str, openType, l, new Notifier() {
            /* class com.google.tagmanager.ContainerOpener.AnonymousClass2 */

            @Override // com.google.tagmanager.ContainerOpener.Notifier
            public void containerAvailable(Container container) {
                containerFutureImpl.setContainer(container);
            }
        });
        return containerFutureImpl;
    }

    public static void openContainer(TagManager tagManager, String str, OpenType openType, Long l, Notifier notifier) {
        if (tagManager == null) {
            throw new NullPointerException("TagManager cannot be null.");
        } else if (str == null) {
            throw new NullPointerException("ContainerId cannot be null.");
        } else if (openType == null) {
            throw new NullPointerException("OpenType cannot be null.");
        } else if (notifier == null) {
            throw new NullPointerException("Notifier cannot be null.");
        } else {
            new ContainerOpener(tagManager, str, l, notifier).open(openType == OpenType.PREFER_FRESH ? Container.RefreshType.NETWORK : Container.RefreshType.SAVED);
        }
    }

    private void setTimer(long j) {
        new Timer("ContainerOpener").schedule(new TimerTask() {
            /* class com.google.tagmanager.ContainerOpener.AnonymousClass3 */

            public void run() {
                Log.i("Timer expired.");
                ContainerOpener.this.callNotifiers(ContainerOpener.this.mContainer);
            }
        }, j);
    }
}

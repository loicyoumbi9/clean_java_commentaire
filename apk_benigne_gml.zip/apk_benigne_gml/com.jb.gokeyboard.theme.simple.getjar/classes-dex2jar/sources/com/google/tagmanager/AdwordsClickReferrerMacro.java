package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

class AdwordsClickReferrerMacro extends FunctionCallImplementation {
    private static final String COMPONENT = Key.COMPONENT.toString();
    private static final String CONVERSION_ID = Key.CONVERSION_ID.toString();
    private static final String ID = FunctionType.ADWORDS_CLICK_REFERRER.toString();
    private final Context context;

    public AdwordsClickReferrerMacro(Context context2) {
        super(ID, CONVERSION_ID);
        this.context = context2;
    }

    public static String getFunctionId() {
        return ID;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        TypeSystem.Value value = map.get(CONVERSION_ID);
        if (value == null) {
            return Types.getDefaultValue();
        }
        String valueToString = Types.valueToString(value);
        TypeSystem.Value value2 = map.get(COMPONENT);
        String clickReferrer = InstallReferrerUtil.getClickReferrer(this.context, valueToString, value2 != null ? Types.valueToString(value2) : null);
        return clickReferrer != null ? Types.objectToValue(clickReferrer) : Types.getDefaultValue();
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return true;
    }
}

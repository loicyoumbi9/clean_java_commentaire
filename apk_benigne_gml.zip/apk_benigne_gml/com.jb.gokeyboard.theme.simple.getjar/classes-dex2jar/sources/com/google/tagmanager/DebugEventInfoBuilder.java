package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;
import com.google.android.gms.common.util.VisibleForTesting;

class DebugEventInfoBuilder implements EventInfoBuilder {
    private DebugDataLayerEventEvaluationInfoBuilder dataLayerEventBuilder;
    @VisibleForTesting
    MutableDebug.EventInfo eventInfoBuilder = MutableDebug.EventInfo.newMessage();
    private DebugInformationHandler handler;
    private DebugMacroEvaluationInfoBuilder macroBuilder;

    public DebugEventInfoBuilder(MutableDebug.EventInfo.EventType eventType, String str, String str2, String str3, DebugInformationHandler debugInformationHandler) {
        this.eventInfoBuilder.setEventType(eventType);
        this.eventInfoBuilder.setContainerVersion(str);
        this.eventInfoBuilder.setContainerId(str2);
        this.eventInfoBuilder.setKey(str3);
        this.handler = debugInformationHandler;
        if (eventType.equals(MutableDebug.EventInfo.EventType.DATA_LAYER_EVENT)) {
            this.dataLayerEventBuilder = new DebugDataLayerEventEvaluationInfoBuilder(this.eventInfoBuilder.getMutableDataLayerEventResult());
        } else {
            this.macroBuilder = new DebugMacroEvaluationInfoBuilder(this.eventInfoBuilder.getMutableMacroResult());
        }
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public DataLayerEventEvaluationInfoBuilder createDataLayerEventEvaluationInfoBuilder() {
        return this.dataLayerEventBuilder;
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public MacroEvaluationInfoBuilder createMacroEvaluationInfoBuilder() {
        return this.macroBuilder;
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public void processEventInfo() {
        this.handler.receiveEventInfo(this.eventInfoBuilder);
    }
}

package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.ByteString;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

class RopeByteString extends ByteString {
    /* access modifiers changed from: private */
    public static final int[] minLengthByDepth;
    private int hash;
    /* access modifiers changed from: private */
    public final ByteString left;
    private final int leftLength;
    /* access modifiers changed from: private */
    public final ByteString right;
    private final int totalLength;
    private final int treeDepth;

    private static class Balancer {
        private final Deque<ByteString> prefixesStack;

        private Balancer() {
            this.prefixesStack = new ArrayDeque(RopeByteString.minLengthByDepth.length);
        }

        /* access modifiers changed from: private */
        public ByteString balance(ByteString byteString, ByteString byteString2) {
            doBalance(byteString);
            doBalance(byteString2);
            RopeByteString pop = this.prefixesStack.pop();
            while (!this.prefixesStack.isEmpty()) {
                pop = new RopeByteString(this.prefixesStack.pop(), pop);
            }
            return pop;
        }

        private void doBalance(ByteString byteString) {
            if (byteString.isBalanced()) {
                insert(byteString);
            } else if (byteString instanceof RopeByteString) {
                RopeByteString ropeByteString = (RopeByteString) byteString;
                doBalance(ropeByteString.left);
                doBalance(ropeByteString.right);
            } else {
                throw new IllegalArgumentException("Has a new type of ByteString been created? Found " + byteString.getClass());
            }
        }

        private int getDepthBinForLength(int i) {
            int binarySearch = Arrays.binarySearch(RopeByteString.minLengthByDepth, i);
            return binarySearch < 0 ? (-(binarySearch + 1)) - 1 : binarySearch;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v6, resolved type: com.google.tagmanager.protobuf.RopeByteString} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void insert(com.google.tagmanager.protobuf.ByteString r6) {
            /*
                r5 = this;
                r4 = 0
                int r0 = r6.size()
                int r1 = r5.getDepthBinForLength(r0)
                int[] r0 = com.google.tagmanager.protobuf.RopeByteString.minLengthByDepth
                int r2 = r1 + 1
                r2 = r0[r2]
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                boolean r0 = r0.isEmpty()
                if (r0 != 0) goto L_0x0027
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.peek()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                int r0 = r0.size()
                if (r0 < r2) goto L_0x002d
            L_0x0027:
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                r0.push(r6)
            L_0x002c:
                return
            L_0x002d:
                int[] r0 = com.google.tagmanager.protobuf.RopeByteString.minLengthByDepth
                r3 = r0[r1]
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.pop()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                r1 = r0
            L_0x003c:
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                boolean r0 = r0.isEmpty()
                if (r0 != 0) goto L_0x0061
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.peek()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                int r0 = r0.size()
                if (r0 >= r3) goto L_0x0061
                com.google.tagmanager.protobuf.RopeByteString r2 = new com.google.tagmanager.protobuf.RopeByteString
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.pop()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                r2.<init>(r0, r1)
                r1 = r2
                goto L_0x003c
            L_0x0061:
                com.google.tagmanager.protobuf.RopeByteString r0 = new com.google.tagmanager.protobuf.RopeByteString
                r0.<init>(r1, r6)
                r1 = r0
            L_0x0067:
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                boolean r0 = r0.isEmpty()
                if (r0 != 0) goto L_0x009c
                int r0 = r1.size()
                int r0 = r5.getDepthBinForLength(r0)
                int[] r2 = com.google.tagmanager.protobuf.RopeByteString.minLengthByDepth
                int r0 = r0 + 1
                r2 = r2[r0]
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.peek()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                int r0 = r0.size()
                if (r0 >= r2) goto L_0x009c
                com.google.tagmanager.protobuf.RopeByteString r2 = new com.google.tagmanager.protobuf.RopeByteString
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                java.lang.Object r0 = r0.pop()
                com.google.tagmanager.protobuf.ByteString r0 = (com.google.tagmanager.protobuf.ByteString) r0
                r2.<init>(r0, r1)
                r1 = r2
                goto L_0x0067
            L_0x009c:
                java.util.Deque<com.google.tagmanager.protobuf.ByteString> r0 = r5.prefixesStack
                r0.push(r1)
                goto L_0x002c
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.RopeByteString.Balancer.insert(com.google.tagmanager.protobuf.ByteString):void");
        }
    }

    private static class PieceIterator implements Iterator<LiteralByteString> {
        private final Deque<RopeByteString> breadCrumbs;
        private LiteralByteString next;

        private PieceIterator(ByteString byteString) {
            this.breadCrumbs = new ArrayDeque(RopeByteString.minLengthByDepth.length);
            this.next = getLeafByLeft(byteString);
        }

        private LiteralByteString getLeafByLeft(ByteString byteString) {
            ByteString byteString2 = byteString;
            while (byteString2 instanceof RopeByteString) {
                RopeByteString ropeByteString = (RopeByteString) byteString2;
                this.breadCrumbs.push(ropeByteString);
                byteString2 = ropeByteString.left;
            }
            return (LiteralByteString) byteString2;
        }

        private LiteralByteString getNextNonEmptyLeaf() {
            while (!this.breadCrumbs.isEmpty()) {
                LiteralByteString leafByLeft = getLeafByLeft(this.breadCrumbs.pop().right);
                if (!leafByLeft.isEmpty()) {
                    return leafByLeft;
                }
            }
            return null;
        }

        public boolean hasNext() {
            return this.next != null;
        }

        @Override // java.util.Iterator
        public LiteralByteString next() {
            if (this.next == null) {
                throw new NoSuchElementException();
            }
            LiteralByteString literalByteString = this.next;
            this.next = getNextNonEmptyLeaf();
            return literalByteString;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private class RopeByteIterator implements ByteString.ByteIterator {
        private ByteString.ByteIterator bytes;
        int bytesRemaining;
        private final PieceIterator pieces;

        /* JADX WARN: Type inference failed for: r0v3, types: [com.google.tagmanager.protobuf.ByteString$ByteIterator] */
        private RopeByteIterator() {
            this.pieces = new PieceIterator(RopeByteString.this);
            this.bytes = this.pieces.next().iterator();
            this.bytesRemaining = RopeByteString.this.size();
        }

        public boolean hasNext() {
            return this.bytesRemaining > 0;
        }

        @Override // java.util.Iterator
        public Byte next() {
            return Byte.valueOf(nextByte());
        }

        /* JADX WARN: Type inference failed for: r0v8, types: [com.google.tagmanager.protobuf.ByteString$ByteIterator] */
        @Override // com.google.tagmanager.protobuf.ByteString.ByteIterator
        public byte nextByte() {
            if (!this.bytes.hasNext()) {
                this.bytes = this.pieces.next().iterator();
            }
            this.bytesRemaining--;
            return this.bytes.nextByte();
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private class RopeInputStream extends InputStream {
        private LiteralByteString currentPiece;
        private int currentPieceIndex;
        private int currentPieceOffsetInRope;
        private int currentPieceSize;
        private int mark;
        private PieceIterator pieceIterator;

        public RopeInputStream() {
            initialize();
        }

        private void advanceIfCurrentPieceFullyRead() {
            if (this.currentPiece != null && this.currentPieceIndex == this.currentPieceSize) {
                this.currentPieceOffsetInRope += this.currentPieceSize;
                this.currentPieceIndex = 0;
                if (this.pieceIterator.hasNext()) {
                    this.currentPiece = this.pieceIterator.next();
                    this.currentPieceSize = this.currentPiece.size();
                    return;
                }
                this.currentPiece = null;
                this.currentPieceSize = 0;
            }
        }

        private void initialize() {
            this.pieceIterator = new PieceIterator(RopeByteString.this);
            this.currentPiece = this.pieceIterator.next();
            this.currentPieceSize = this.currentPiece.size();
            this.currentPieceIndex = 0;
            this.currentPieceOffsetInRope = 0;
        }

        private int readSkipInternal(byte[] bArr, int i, int i2) {
            int i3 = i;
            int i4 = i2;
            while (true) {
                if (i4 <= 0) {
                    break;
                }
                advanceIfCurrentPieceFullyRead();
                if (this.currentPiece != null) {
                    int min = Math.min(this.currentPieceSize - this.currentPieceIndex, i4);
                    if (bArr != null) {
                        this.currentPiece.copyTo(bArr, this.currentPieceIndex, i3, min);
                        i3 += min;
                    }
                    this.currentPieceIndex += min;
                    i4 -= min;
                } else if (i4 == i2) {
                    return -1;
                }
            }
            return i2 - i4;
        }

        @Override // java.io.InputStream
        public int available() throws IOException {
            return RopeByteString.this.size() - (this.currentPieceOffsetInRope + this.currentPieceIndex);
        }

        public void mark(int i) {
            this.mark = this.currentPieceOffsetInRope + this.currentPieceIndex;
        }

        public boolean markSupported() {
            return true;
        }

        @Override // java.io.InputStream
        public int read() throws IOException {
            advanceIfCurrentPieceFullyRead();
            if (this.currentPiece == null) {
                return -1;
            }
            LiteralByteString literalByteString = this.currentPiece;
            int i = this.currentPieceIndex;
            this.currentPieceIndex = i + 1;
            return literalByteString.byteAt(i) & 255;
        }

        @Override // java.io.InputStream
        public int read(byte[] bArr, int i, int i2) {
            if (bArr == null) {
                throw new NullPointerException();
            } else if (i >= 0 && i2 >= 0 && i2 <= bArr.length - i) {
                return readSkipInternal(bArr, i, i2);
            } else {
                throw new IndexOutOfBoundsException();
            }
        }

        @Override // java.io.InputStream
        public void reset() {
            synchronized (this) {
                initialize();
                readSkipInternal(null, 0, this.mark);
            }
        }

        @Override // java.io.InputStream
        public long skip(long j) {
            if (j < 0) {
                throw new IndexOutOfBoundsException();
            }
            if (j > 2147483647L) {
                j = 2147483647L;
            }
            return (long) readSkipInternal(null, 0, (int) j);
        }
    }

    static {
        ArrayList arrayList = new ArrayList();
        int i = 1;
        int i2 = 1;
        while (i2 > 0) {
            arrayList.add(Integer.valueOf(i2));
            int i3 = i + i2;
            i = i2;
            i2 = i3;
        }
        arrayList.add(Integer.MAX_VALUE);
        minLengthByDepth = new int[arrayList.size()];
        int i4 = 0;
        while (true) {
            int i5 = i4;
            if (i5 < minLengthByDepth.length) {
                minLengthByDepth[i5] = ((Integer) arrayList.get(i5)).intValue();
                i4 = i5 + 1;
            } else {
                return;
            }
        }
    }

    private RopeByteString(ByteString byteString, ByteString byteString2) {
        this.hash = 0;
        this.left = byteString;
        this.right = byteString2;
        this.leftLength = byteString.size();
        this.totalLength = this.leftLength + byteString2.size();
        this.treeDepth = Math.max(byteString.getTreeDepth(), byteString2.getTreeDepth()) + 1;
    }

    static ByteString concatenate(ByteString byteString, ByteString byteString2) {
        RopeByteString ropeByteString = byteString instanceof RopeByteString ? (RopeByteString) byteString : null;
        if (byteString2.size() == 0) {
            return byteString;
        }
        if (byteString.size() == 0) {
            return byteString2;
        }
        int size = byteString.size() + byteString2.size();
        if (size < 128) {
            return concatenateBytes(byteString, byteString2);
        }
        if (ropeByteString != null && ropeByteString.right.size() + byteString2.size() < 128) {
            return new RopeByteString(ropeByteString.left, concatenateBytes(ropeByteString.right, byteString2));
        } else if (ropeByteString == null || ropeByteString.left.getTreeDepth() <= ropeByteString.right.getTreeDepth() || ropeByteString.getTreeDepth() <= byteString2.getTreeDepth()) {
            return size >= minLengthByDepth[Math.max(byteString.getTreeDepth(), byteString2.getTreeDepth()) + 1] ? new RopeByteString(byteString, byteString2) : new Balancer().balance(byteString, byteString2);
        } else {
            return new RopeByteString(ropeByteString.left, new RopeByteString(ropeByteString.right, byteString2));
        }
    }

    private static LiteralByteString concatenateBytes(ByteString byteString, ByteString byteString2) {
        int size = byteString.size();
        int size2 = byteString2.size();
        byte[] bArr = new byte[(size + size2)];
        byteString.copyTo(bArr, 0, 0, size);
        byteString2.copyTo(bArr, 0, size, size2);
        return new LiteralByteString(bArr);
    }

    private boolean equalsFragments(ByteString byteString) {
        LiteralByteString literalByteString;
        PieceIterator pieceIterator = new PieceIterator(this);
        PieceIterator pieceIterator2 = new PieceIterator(byteString);
        LiteralByteString literalByteString2 = (LiteralByteString) pieceIterator.next();
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        LiteralByteString literalByteString3 = (LiteralByteString) pieceIterator2.next();
        while (true) {
            int size = literalByteString2.size() - i2;
            int size2 = literalByteString3.size() - i3;
            int min = Math.min(size, size2);
            if (!(i2 == 0 ? literalByteString2.equalsRange(literalByteString3, i3, min) : literalByteString3.equalsRange(literalByteString2, i2, min))) {
                return false;
            }
            i += min;
            if (i < this.totalLength) {
                if (min == size) {
                    literalByteString = (LiteralByteString) pieceIterator.next();
                    i2 = 0;
                } else {
                    i2 += min;
                    literalByteString = literalByteString2;
                }
                if (min == size2) {
                    literalByteString2 = literalByteString;
                    i3 = 0;
                    literalByteString3 = (LiteralByteString) pieceIterator2.next();
                } else {
                    literalByteString2 = literalByteString;
                    i3 += min;
                }
            } else if (i == this.totalLength) {
                return true;
            } else {
                throw new IllegalStateException();
            }
        }
    }

    static RopeByteString newInstanceForTest(ByteString byteString, ByteString byteString2) {
        return new RopeByteString(byteString, byteString2);
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public ByteBuffer asReadOnlyByteBuffer() {
        return ByteBuffer.wrap(toByteArray()).asReadOnlyBuffer();
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public List<ByteBuffer> asReadOnlyByteBufferList() {
        ArrayList arrayList = new ArrayList();
        PieceIterator pieceIterator = new PieceIterator(this);
        while (pieceIterator.hasNext()) {
            arrayList.add(pieceIterator.next().asReadOnlyByteBuffer());
        }
        return arrayList;
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public byte byteAt(int i) {
        if (i < 0) {
            throw new ArrayIndexOutOfBoundsException("Index < 0: " + i);
        } else if (i <= this.totalLength) {
            return i < this.leftLength ? this.left.byteAt(i) : this.right.byteAt(i - this.leftLength);
        } else {
            throw new ArrayIndexOutOfBoundsException("Index > length: " + i + ", " + this.totalLength);
        }
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public void copyTo(ByteBuffer byteBuffer) {
        this.left.copyTo(byteBuffer);
        this.right.copyTo(byteBuffer);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public void copyToInternal(byte[] bArr, int i, int i2, int i3) {
        if (i + i3 <= this.leftLength) {
            this.left.copyToInternal(bArr, i, i2, i3);
        } else if (i >= this.leftLength) {
            this.right.copyToInternal(bArr, i - this.leftLength, i2, i3);
        } else {
            int i4 = this.leftLength - i;
            this.left.copyToInternal(bArr, i, i2, i4);
            this.right.copyToInternal(bArr, 0, i2 + i4, i3 - i4);
        }
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public boolean equals(Object obj) {
        int peekCachedHashCode;
        if (obj != this) {
            if (!(obj instanceof ByteString)) {
                return false;
            }
            ByteString byteString = (ByteString) obj;
            if (this.totalLength != byteString.size()) {
                return false;
            }
            if (this.totalLength != 0) {
                if (this.hash == 0 || (peekCachedHashCode = byteString.peekCachedHashCode()) == 0 || this.hash == peekCachedHashCode) {
                    return equalsFragments(byteString);
                }
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public int getTreeDepth() {
        return this.treeDepth;
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public int hashCode() {
        int i = this.hash;
        if (i == 0) {
            i = partialHash(this.totalLength, 0, this.totalLength);
            if (i == 0) {
                i = 1;
            }
            this.hash = i;
        }
        return i;
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public boolean isBalanced() {
        return this.totalLength >= minLengthByDepth[this.treeDepth];
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public boolean isValidUtf8() {
        return this.right.partialIsValidUtf8(this.left.partialIsValidUtf8(0, 0, this.leftLength), 0, this.right.size()) == 0;
    }

    /* Return type fixed from 'com.google.tagmanager.protobuf.ByteString$ByteIterator' to match base method */
    @Override // com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ByteString, java.lang.Iterable
    public Iterator<Byte> iterator() {
        return new RopeByteIterator();
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public CodedInputStream newCodedInput() {
        return CodedInputStream.newInstance(new RopeInputStream());
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public InputStream newInput() {
        return new RopeInputStream();
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public int partialHash(int i, int i2, int i3) {
        if (i2 + i3 <= this.leftLength) {
            return this.left.partialHash(i, i2, i3);
        }
        if (i2 >= this.leftLength) {
            return this.right.partialHash(i, i2 - this.leftLength, i3);
        }
        int i4 = this.leftLength - i2;
        return this.right.partialHash(this.left.partialHash(i, i2, i4), 0, i3 - i4);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public int partialIsValidUtf8(int i, int i2, int i3) {
        if (i2 + i3 <= this.leftLength) {
            return this.left.partialIsValidUtf8(i, i2, i3);
        }
        if (i2 >= this.leftLength) {
            return this.right.partialIsValidUtf8(i, i2 - this.leftLength, i3);
        }
        int i4 = this.leftLength - i2;
        return this.right.partialIsValidUtf8(this.left.partialIsValidUtf8(i, i2, i4), 0, i3 - i4);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString
    public int peekCachedHashCode() {
        return this.hash;
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public int size() {
        return this.totalLength;
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public ByteString substring(int i, int i2) {
        if (i < 0) {
            throw new IndexOutOfBoundsException("Beginning index: " + i + " < 0");
        } else if (i2 > this.totalLength) {
            throw new IndexOutOfBoundsException("End index: " + i2 + " > " + this.totalLength);
        } else {
            int i3 = i2 - i;
            if (i3 >= 0) {
                return i3 == 0 ? ByteString.EMPTY : i3 != this.totalLength ? i2 <= this.leftLength ? this.left.substring(i, i2) : i >= this.leftLength ? this.right.substring(i - this.leftLength, i2 - this.leftLength) : new RopeByteString(this.left.substring(i), this.right.substring(0, i2 - this.leftLength)) : this;
            }
            throw new IndexOutOfBoundsException("Beginning index larger than ending index: " + i + ", " + i2);
        }
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public String toString(String str) throws UnsupportedEncodingException {
        return new String(toByteArray(), str);
    }

    @Override // com.google.tagmanager.protobuf.ByteString
    public void writeTo(OutputStream outputStream) throws IOException {
        this.left.writeTo(outputStream);
        this.right.writeTo(outputStream);
    }

    /* access modifiers changed from: package-private */
    @Override // com.google.tagmanager.protobuf.ByteString
    public void writeToInternal(OutputStream outputStream, int i, int i2) throws IOException {
        if (i + i2 <= this.leftLength) {
            this.left.writeToInternal(outputStream, i, i2);
        } else if (i >= this.leftLength) {
            this.right.writeToInternal(outputStream, i - this.leftLength, i2);
        } else {
            int i3 = this.leftLength - i;
            this.left.writeToInternal(outputStream, i, i3);
            this.right.writeToInternal(outputStream, 0, i2 - i3);
        }
    }
}

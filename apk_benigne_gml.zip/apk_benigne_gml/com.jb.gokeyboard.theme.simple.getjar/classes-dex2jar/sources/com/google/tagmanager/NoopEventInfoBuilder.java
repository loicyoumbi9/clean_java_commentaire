package com.google.tagmanager;

class NoopEventInfoBuilder implements EventInfoBuilder {
    NoopEventInfoBuilder() {
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public DataLayerEventEvaluationInfoBuilder createDataLayerEventEvaluationInfoBuilder() {
        return new NoopDataLayerEventEvaluationInfoBuilder();
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public MacroEvaluationInfoBuilder createMacroEvaluationInfoBuilder() {
        return new NoopMacroEvaluationInfoBuilder();
    }

    @Override // com.google.tagmanager.EventInfoBuilder
    public void processEventInfo() {
    }
}

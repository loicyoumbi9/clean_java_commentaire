package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;
import com.google.analytics.midtier.proto.containertag.MutableTypeSystem;
import com.google.analytics.midtier.proto.containertag.TypeSystem;

class DebugValueBuilder implements ValueBuilder {
    private MutableTypeSystem.Value value;

    private static class TypeMismatchException extends IllegalStateException {
        public TypeMismatchException(String str, MutableTypeSystem.Value.Type type) {
            super("Attempted operation: " + str + " on object of type: " + type);
        }
    }

    public DebugValueBuilder(MutableTypeSystem.Value value2) {
        this.value = value2;
    }

    public static MutableTypeSystem.Value copyImmutableValue(TypeSystem.Value value2) {
        MutableTypeSystem.Value newMessage = MutableTypeSystem.Value.newMessage();
        if (!newMessage.mergeFrom(value2.toByteArray())) {
            Log.e("Failed to copy runtime value into debug value");
        }
        return newMessage;
    }

    private void validateType(MutableTypeSystem.Value.Type type, MutableTypeSystem.Value.Type type2, String str) {
        if (!type.equals(type2)) {
            throw new TypeMismatchException(str, type2);
        }
    }

    @Override // com.google.tagmanager.ValueBuilder
    public MacroEvaluationInfoBuilder createValueMacroEvaluationInfoExtension() {
        validateType(MutableTypeSystem.Value.Type.MACRO_REFERENCE, this.value.getType(), "set macro evaluation extension");
        return new DebugMacroEvaluationInfoBuilder((MutableDebug.MacroEvaluationInfo) this.value.getMutableExtension(MutableDebug.MacroEvaluationInfo.macro));
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getListItem(int i) {
        validateType(MutableTypeSystem.Value.Type.LIST, this.value.getType(), "add new list item");
        return new DebugValueBuilder(this.value.getListItem(i));
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getMapKey(int i) {
        validateType(MutableTypeSystem.Value.Type.MAP, this.value.getType(), "add new map key");
        return new DebugValueBuilder(this.value.getMapKey(i));
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getMapValue(int i) {
        validateType(MutableTypeSystem.Value.Type.MAP, this.value.getType(), "add new map value");
        return new DebugValueBuilder(this.value.getMapValue(i));
    }

    @Override // com.google.tagmanager.ValueBuilder
    public ValueBuilder getTemplateToken(int i) {
        validateType(MutableTypeSystem.Value.Type.TEMPLATE, this.value.getType(), "add template token");
        return new DebugValueBuilder(this.value.getTemplateToken(i));
    }
}

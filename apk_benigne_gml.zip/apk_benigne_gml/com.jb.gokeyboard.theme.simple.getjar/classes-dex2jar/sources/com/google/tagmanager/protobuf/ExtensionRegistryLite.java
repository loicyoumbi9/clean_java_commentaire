package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.GeneratedMessageLite;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ExtensionRegistryLite {
    private static final ExtensionRegistryLite EMPTY = new ExtensionRegistryLite(true);
    private static volatile boolean eagerlyParseMessageSets = false;
    private final Map<ObjectIntPair, GeneratedMessageLite.GeneratedExtension<?, ?>> extensionsByNumber;

    private static final class ObjectIntPair {
        private final int number;
        private final Object object;

        ObjectIntPair(Object obj, int i) {
            this.object = obj;
            this.number = i;
        }

        public boolean equals(Object obj) {
            if (obj instanceof ObjectIntPair) {
                ObjectIntPair objectIntPair = (ObjectIntPair) obj;
                return this.object == objectIntPair.object && this.number == objectIntPair.number;
            }
        }

        public int hashCode() {
            return (System.identityHashCode(this.object) * 65535) + this.number;
        }
    }

    ExtensionRegistryLite() {
        this.extensionsByNumber = new HashMap();
    }

    ExtensionRegistryLite(ExtensionRegistryLite extensionRegistryLite) {
        if (extensionRegistryLite == EMPTY) {
            this.extensionsByNumber = Collections.emptyMap();
        } else {
            this.extensionsByNumber = Collections.unmodifiableMap(extensionRegistryLite.extensionsByNumber);
        }
    }

    private ExtensionRegistryLite(boolean z) {
        this.extensionsByNumber = Collections.emptyMap();
    }

    public static ExtensionRegistryLite getEmptyRegistry() {
        return EMPTY;
    }

    public static boolean isEagerlyParseMessageSets() {
        return eagerlyParseMessageSets;
    }

    public static ExtensionRegistryLite newInstance() {
        return new ExtensionRegistryLite();
    }

    public static void setEagerlyParseMessageSets(boolean z) {
        eagerlyParseMessageSets = z;
    }

    public final void add(GeneratedMessageLite.GeneratedExtension<?, ?> generatedExtension) {
        this.extensionsByNumber.put(new ObjectIntPair(generatedExtension.getContainingTypeDefaultInstance(), generatedExtension.getNumber()), generatedExtension);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.util.Map<com.google.tagmanager.protobuf.ExtensionRegistryLite$ObjectIntPair, com.google.tagmanager.protobuf.GeneratedMessageLite$GeneratedExtension<?, ?>>} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <ContainingType extends com.google.tagmanager.protobuf.MessageLite> com.google.tagmanager.protobuf.GeneratedMessageLite.GeneratedExtension<ContainingType, ?> findLiteExtensionByNumber(ContainingType r3, int r4) {
        /*
            r2 = this;
            java.util.Map<com.google.tagmanager.protobuf.ExtensionRegistryLite$ObjectIntPair, com.google.tagmanager.protobuf.GeneratedMessageLite$GeneratedExtension<?, ?>> r0 = r2.extensionsByNumber
            com.google.tagmanager.protobuf.ExtensionRegistryLite$ObjectIntPair r1 = new com.google.tagmanager.protobuf.ExtensionRegistryLite$ObjectIntPair
            r1.<init>(r3, r4)
            java.lang.Object r0 = r0.get(r1)
            com.google.tagmanager.protobuf.GeneratedMessageLite$GeneratedExtension r0 = (com.google.tagmanager.protobuf.GeneratedMessageLite.GeneratedExtension) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.ExtensionRegistryLite.findLiteExtensionByNumber(com.google.tagmanager.protobuf.MessageLite, int):com.google.tagmanager.protobuf.GeneratedMessageLite$GeneratedExtension");
    }

    public ExtensionRegistryLite getUnmodifiable() {
        return new ExtensionRegistryLite(this);
    }
}

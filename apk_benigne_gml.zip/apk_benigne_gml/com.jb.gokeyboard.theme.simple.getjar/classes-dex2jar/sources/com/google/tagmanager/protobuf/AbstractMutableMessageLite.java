package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.AbstractMessageLite;
import com.google.tagmanager.protobuf.ByteString;
import com.google.tagmanager.protobuf.MessageLite;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Collection;

public abstract class AbstractMutableMessageLite implements MutableMessageLite {
    protected int cachedSize = -1;
    private boolean isMutable = true;

    protected static <T> void addAll(Iterable<T> iterable, Collection<? super T> collection) {
        AbstractMessageLite.Builder.addAll(iterable, collection);
    }

    protected static <T extends MutableMessageLite> Parser<T> internalNewParserForType(final T t) {
        return new AbstractParser<T>() {
            /* class com.google.tagmanager.protobuf.AbstractMutableMessageLite.AnonymousClass1 */

            @Override // com.google.tagmanager.protobuf.Parser
            public T parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                T newMessageForType = t.newMessageForType();
                if (newMessageForType.mergeFrom(codedInputStream, extensionRegistryLite)) {
                    return newMessageForType;
                }
                throw InvalidProtocolBufferException.parseFailure().setUnfinishedMessage(newMessageForType);
            }
        };
    }

    protected static UninitializedMessageException newUninitializedMessageException(MessageLite messageLite) {
        return new UninitializedMessageException(messageLite);
    }

    /* access modifiers changed from: protected */
    public void assertMutable() {
        if (!this.isMutable) {
            throw new IllegalStateException("Try to modify an immutable message.");
        }
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite, java.lang.Object
    public MutableMessageLite clone() {
        throw new UnsupportedOperationException("clone() should be implemented by subclasses.");
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public final int getCachedSize() {
        return this.cachedSize;
    }

    /* access modifiers changed from: protected */
    public boolean isProto1Group() {
        return false;
    }

    /* access modifiers changed from: protected */
    public void makeImmutable() {
        this.isMutable = false;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeDelimitedFrom(InputStream inputStream) {
        return mergeDelimitedFrom(inputStream, ExtensionRegistryLite.getEmptyRegistry());
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
        try {
            int read = inputStream.read();
            if (read == -1) {
                return false;
            }
            return mergeFrom(new AbstractMessageLite.Builder.LimitedInputStream(inputStream, CodedInputStream.readRawVarint32(read, inputStream)), extensionRegistryLite);
        } catch (IOException e) {
            return false;
        }
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(ByteString byteString) {
        CodedInputStream newCodedInput = byteString.newCodedInput();
        return mergeFrom(newCodedInput) && newCodedInput.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
        CodedInputStream newCodedInput = byteString.newCodedInput();
        return mergeFrom(newCodedInput, extensionRegistryLite) && newCodedInput.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(CodedInputStream codedInputStream) {
        return mergeFrom(codedInputStream, ExtensionRegistryLite.getEmptyRegistry());
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(InputStream inputStream) {
        CodedInputStream newInstance = CodedInputStream.newInstance(inputStream);
        return mergeFrom(newInstance) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
        CodedInputStream newInstance = CodedInputStream.newInstance(inputStream);
        return mergeFrom(newInstance, extensionRegistryLite) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(ByteBuffer byteBuffer) {
        CodedInputStream newInstance = CodedInputStream.newInstance(byteBuffer);
        return mergeFrom(newInstance) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
        CodedInputStream newInstance = CodedInputStream.newInstance(byteBuffer);
        return mergeFrom(newInstance, extensionRegistryLite) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(byte[] bArr) {
        return mergeFrom(bArr, 0, bArr.length);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(byte[] bArr, int i, int i2) {
        CodedInputStream newInstance = CodedInputStream.newInstance(bArr, i, i2);
        return mergeFrom(newInstance) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(byte[] bArr, int i, int i2, ExtensionRegistryLite extensionRegistryLite) {
        CodedInputStream newInstance = CodedInputStream.newInstance(bArr, i, i2);
        return mergeFrom(newInstance, extensionRegistryLite) && newInstance.getLastTag() == 0;
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergeFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
        return mergeFrom(bArr, 0, bArr.length, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean mergePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
        return mergeFrom(codedInputStream, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public MutableMessageLite mutableCopy() {
        throw new UnsupportedOperationException("mutableCopy() is not supported in mutable messages. Use clone() if you need to make a copy of the mutable message.");
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public MessageLite.Builder newBuilderForType() {
        throw new UnsupportedOperationException("newBuilderForType() is not supported in mutable messages.");
    }

    /* access modifiers changed from: package-private */
    public UninitializedMessageException newUninitializedMessageException() {
        return new UninitializedMessageException(this);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseDelimitedFrom(InputStream inputStream) {
        clear();
        return mergeDelimitedFrom(inputStream);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeDelimitedFrom(inputStream, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(ByteString byteString) {
        clear();
        return mergeFrom(byteString);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(byteString, extensionRegistryLite);
    }

    public boolean parseFrom(CodedInputStream codedInputStream) {
        clear();
        return mergeFrom(codedInputStream);
    }

    public boolean parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(codedInputStream, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(InputStream inputStream) {
        clear();
        return mergeFrom(inputStream);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(inputStream, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(ByteBuffer byteBuffer) {
        clear();
        return mergeFrom(byteBuffer);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(byteBuffer, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(byte[] bArr) {
        clear();
        return mergeFrom(bArr, 0, bArr.length);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(byte[] bArr, int i, int i2) {
        clear();
        return mergeFrom(bArr, i, i2);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(byte[] bArr, int i, int i2, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(bArr, i, i2, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MutableMessageLite
    public boolean parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
        clear();
        return mergeFrom(bArr, 0, bArr.length, extensionRegistryLite);
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public MessageLite.Builder toBuilder() {
        throw new UnsupportedOperationException("toBuilder() is not supported in mutable messages.");
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public byte[] toByteArray() {
        try {
            byte[] bArr = new byte[getSerializedSize()];
            CodedOutputStream newInstance = CodedOutputStream.newInstance(bArr);
            writeTo(newInstance);
            newInstance.checkNoSpaceLeft();
            return bArr;
        } catch (IOException e) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
        }
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public ByteString toByteString() {
        try {
            ByteString.CodedBuilder newCodedBuilder = ByteString.newCodedBuilder(getSerializedSize());
            writeTo(newCodedBuilder.getCodedOutput());
            return newCodedBuilder.build();
        } catch (IOException e) {
            throw new RuntimeException("Serializing to a ByteString threw an IOException (should never happen).", e);
        }
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public void writeDelimitedTo(OutputStream outputStream) throws IOException {
        int serializedSize = getSerializedSize();
        CodedOutputStream newInstance = CodedOutputStream.newInstance(outputStream, CodedOutputStream.computePreferredBufferSize(CodedOutputStream.computeRawVarint32Size(serializedSize) + serializedSize));
        newInstance.writeRawVarint32(serializedSize);
        writeTo(newInstance);
        newInstance.flush();
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        getSerializedSize();
        writeToWithCachedSizes(codedOutputStream);
    }

    @Override // com.google.tagmanager.protobuf.MessageLite
    public void writeTo(OutputStream outputStream) throws IOException {
        CodedOutputStream newInstance = CodedOutputStream.newInstance(outputStream, CodedOutputStream.computePreferredBufferSize(getSerializedSize()));
        writeTo(newInstance);
        newInstance.flush();
    }
}

package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Types {
    private static Boolean DEFAULT_BOOLEAN = new Boolean(false);
    private static Double DEFAULT_DOUBLE = new Double(0.0d);
    private static Long DEFAULT_INT64 = new Long(0);
    private static List<Object> DEFAULT_LIST = new ArrayList(0);
    private static Map<Object, Object> DEFAULT_MAP = new HashMap();
    private static TypedNumber DEFAULT_NUMBER = TypedNumber.numberWithInt64(0);
    private static final Object DEFAULT_OBJECT = null;
    private static String DEFAULT_STRING = new String("");
    private static TypeSystem.Value DEFAULT_VALUE = objectToValue(DEFAULT_STRING);

    private Types() {
    }

    public static TypeSystem.Value functionIdToValue(String str) {
        return TypeSystem.Value.newBuilder().setType(TypeSystem.Value.Type.FUNCTION_ID).setFunctionId(str).build();
    }

    public static Boolean getDefaultBoolean() {
        return DEFAULT_BOOLEAN;
    }

    public static Double getDefaultDouble() {
        return DEFAULT_DOUBLE;
    }

    public static Long getDefaultInt64() {
        return DEFAULT_INT64;
    }

    public static List<Object> getDefaultList() {
        return DEFAULT_LIST;
    }

    public static Map<Object, Object> getDefaultMap() {
        return DEFAULT_MAP;
    }

    public static TypedNumber getDefaultNumber() {
        return DEFAULT_NUMBER;
    }

    public static Object getDefaultObject() {
        return DEFAULT_OBJECT;
    }

    public static String getDefaultString() {
        return DEFAULT_STRING;
    }

    public static TypeSystem.Value getDefaultValue() {
        return DEFAULT_VALUE;
    }

    private static double getDouble(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue();
        }
        Log.e("getDouble received non-Number");
        return 0.0d;
    }

    private static long getInt64(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).longValue();
        }
        Log.e("getInt64 received non-Number");
        return 0;
    }

    private static boolean isDoubleableNumber(Object obj) {
        return (obj instanceof Double) || (obj instanceof Float) || ((obj instanceof TypedNumber) && ((TypedNumber) obj).isDouble());
    }

    private static boolean isInt64ableNumber(Object obj) {
        return (obj instanceof Byte) || (obj instanceof Short) || (obj instanceof Integer) || (obj instanceof Long) || ((obj instanceof TypedNumber) && ((TypedNumber) obj).isInt64());
    }

    public static TypeSystem.Value macroReferenceToValue(String str, TypeSystem.Value.Escaping... escapingArr) {
        TypeSystem.Value.Builder containsReferences = TypeSystem.Value.newBuilder().setType(TypeSystem.Value.Type.MACRO_REFERENCE).setMacroReference(str).setContainsReferences(true);
        for (TypeSystem.Value.Escaping escaping : escapingArr) {
            containsReferences.addEscaping(escaping);
        }
        return containsReferences.build();
    }

    public static Boolean objectToBoolean(Object obj) {
        return obj instanceof Boolean ? (Boolean) obj : parseBoolean(objectToString(obj));
    }

    public static Double objectToDouble(Object obj) {
        return isDoubleableNumber(obj) ? Double.valueOf(getDouble(obj)) : parseDouble(objectToString(obj));
    }

    public static Long objectToInt64(Object obj) {
        return isInt64ableNumber(obj) ? Long.valueOf(getInt64(obj)) : parseInt64(objectToString(obj));
    }

    public static TypedNumber objectToNumber(Object obj) {
        return obj instanceof TypedNumber ? (TypedNumber) obj : isInt64ableNumber(obj) ? TypedNumber.numberWithInt64(getInt64(obj)) : isDoubleableNumber(obj) ? TypedNumber.numberWithDouble(Double.valueOf(getDouble(obj))) : parseNumber(objectToString(obj));
    }

    public static String objectToString(Object obj) {
        return obj == null ? DEFAULT_STRING : obj.toString();
    }

    public static TypeSystem.Value objectToValue(Object obj) {
        boolean z = false;
        TypeSystem.Value.Builder newBuilder = TypeSystem.Value.newBuilder();
        if (obj instanceof TypeSystem.Value) {
            return (TypeSystem.Value) obj;
        }
        if (obj instanceof String) {
            newBuilder.setType(TypeSystem.Value.Type.STRING).setString((String) obj);
        } else if (obj instanceof List) {
            newBuilder.setType(TypeSystem.Value.Type.LIST);
            boolean z2 = false;
            for (Object obj2 : (List) obj) {
                TypeSystem.Value objectToValue = objectToValue(obj2);
                if (objectToValue == DEFAULT_VALUE) {
                    return DEFAULT_VALUE;
                }
                z2 = z2 || objectToValue.getContainsReferences();
                newBuilder.addListItem(objectToValue);
            }
            z = z2;
        } else if (obj instanceof Map) {
            newBuilder.setType(TypeSystem.Value.Type.MAP);
            boolean z3 = false;
            for (Map.Entry entry : ((Map) obj).entrySet()) {
                TypeSystem.Value objectToValue2 = objectToValue(entry.getKey());
                TypeSystem.Value objectToValue3 = objectToValue(entry.getValue());
                if (objectToValue2 == DEFAULT_VALUE || objectToValue3 == DEFAULT_VALUE) {
                    return DEFAULT_VALUE;
                }
                boolean z4 = z3 || objectToValue2.getContainsReferences() || objectToValue3.getContainsReferences();
                newBuilder.addMapKey(objectToValue2);
                newBuilder.addMapValue(objectToValue3);
                z3 = z4;
            }
            z = z3;
        } else if (isDoubleableNumber(obj)) {
            newBuilder.setType(TypeSystem.Value.Type.STRING).setString(obj.toString());
        } else if (isInt64ableNumber(obj)) {
            newBuilder.setType(TypeSystem.Value.Type.INTEGER).setInteger(getInt64(obj));
        } else if (obj instanceof Boolean) {
            newBuilder.setType(TypeSystem.Value.Type.BOOLEAN).setBoolean(((Boolean) obj).booleanValue());
        } else {
            Log.e("Converting to Value from unknown object type: " + (obj == null ? "null" : obj.getClass().toString()));
            return DEFAULT_VALUE;
        }
        if (z) {
            newBuilder.setContainsReferences(true);
        }
        return newBuilder.build();
    }

    private static Boolean parseBoolean(String str) {
        return "true".equalsIgnoreCase(str) ? Boolean.TRUE : "false".equalsIgnoreCase(str) ? Boolean.FALSE : DEFAULT_BOOLEAN;
    }

    private static Double parseDouble(String str) {
        TypedNumber parseNumber = parseNumber(str);
        return parseNumber == DEFAULT_NUMBER ? DEFAULT_DOUBLE : Double.valueOf(parseNumber.doubleValue());
    }

    private static Long parseInt64(String str) {
        TypedNumber parseNumber = parseNumber(str);
        return parseNumber == DEFAULT_NUMBER ? DEFAULT_INT64 : Long.valueOf(parseNumber.longValue());
    }

    private static TypedNumber parseNumber(String str) {
        try {
            return TypedNumber.numberWithString(str);
        } catch (NumberFormatException e) {
            Log.e("Failed to convert '" + str + "' to a number.");
            return DEFAULT_NUMBER;
        }
    }

    public static TypeSystem.Value templateToValue(TypeSystem.Value... valueArr) {
        TypeSystem.Value.Builder type = TypeSystem.Value.newBuilder().setType(TypeSystem.Value.Type.TEMPLATE);
        boolean z = false;
        for (TypeSystem.Value value : valueArr) {
            type.addTemplateToken(value);
            z = z || value.getContainsReferences();
        }
        if (z) {
            type.setContainsReferences(true);
        }
        return type.build();
    }

    public static Boolean valueToBoolean(TypeSystem.Value value) {
        return objectToBoolean(valueToObject(value));
    }

    public static Double valueToDouble(TypeSystem.Value value) {
        return objectToDouble(valueToObject(value));
    }

    public static Long valueToInt64(TypeSystem.Value value) {
        return objectToInt64(valueToObject(value));
    }

    public static TypedNumber valueToNumber(TypeSystem.Value value) {
        return objectToNumber(valueToObject(value));
    }

    public static Object valueToObject(TypeSystem.Value value) {
        if (value == null) {
            return DEFAULT_OBJECT;
        }
        switch (value.getType()) {
            case STRING:
                return value.getString();
            case LIST:
                ArrayList arrayList = new ArrayList(value.getListItemCount());
                for (TypeSystem.Value value2 : value.getListItemList()) {
                    Object valueToObject = valueToObject(value2);
                    if (valueToObject == DEFAULT_OBJECT) {
                        return DEFAULT_OBJECT;
                    }
                    arrayList.add(valueToObject);
                }
                return arrayList;
            case MAP:
                if (value.getMapKeyCount() != value.getMapValueCount()) {
                    Log.e("Converting an invalid value to object: " + value.toString());
                    return DEFAULT_OBJECT;
                }
                HashMap hashMap = new HashMap(value.getMapValueCount());
                for (int i = 0; i < value.getMapKeyCount(); i++) {
                    Object valueToObject2 = valueToObject(value.getMapKey(i));
                    Object valueToObject3 = valueToObject(value.getMapValue(i));
                    if (valueToObject2 == DEFAULT_OBJECT || valueToObject3 == DEFAULT_OBJECT) {
                        return DEFAULT_OBJECT;
                    }
                    hashMap.put(valueToObject2, valueToObject3);
                }
                return hashMap;
            case MACRO_REFERENCE:
                Log.e("Trying to convert a macro reference to object");
                return DEFAULT_OBJECT;
            case FUNCTION_ID:
                Log.e("Trying to convert a function id to object");
                return DEFAULT_OBJECT;
            case INTEGER:
                return Long.valueOf(value.getInteger());
            case TEMPLATE:
                StringBuffer stringBuffer = new StringBuffer();
                for (TypeSystem.Value value3 : value.getTemplateTokenList()) {
                    String valueToString = valueToString(value3);
                    if (valueToString == DEFAULT_STRING) {
                        return DEFAULT_OBJECT;
                    }
                    stringBuffer.append(valueToString);
                }
                return stringBuffer.toString();
            case BOOLEAN:
                return Boolean.valueOf(value.getBoolean());
            default:
                Log.e("Failed to convert a value of type: " + value.getType());
                return DEFAULT_OBJECT;
        }
    }

    public static String valueToString(TypeSystem.Value value) {
        return objectToString(valueToObject(value));
    }
}

package com.google.tagmanager;

interface Clock {
    long currentTimeMillis();
}

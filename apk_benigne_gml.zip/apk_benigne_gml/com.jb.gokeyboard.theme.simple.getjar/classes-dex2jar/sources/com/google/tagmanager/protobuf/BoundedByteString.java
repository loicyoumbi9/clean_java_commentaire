package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.ByteString;
import java.util.Iterator;
import java.util.NoSuchElementException;

class BoundedByteString extends LiteralByteString {
    private final int bytesLength;
    private final int bytesOffset;

    private class BoundedByteIterator implements ByteString.ByteIterator {
        private final int limit;
        private int position;

        private BoundedByteIterator() {
            this.position = BoundedByteString.this.getOffsetIntoBytes();
            this.limit = this.position + BoundedByteString.this.size();
        }

        public boolean hasNext() {
            return this.position < this.limit;
        }

        @Override // java.util.Iterator
        public Byte next() {
            return Byte.valueOf(nextByte());
        }

        @Override // com.google.tagmanager.protobuf.ByteString.ByteIterator
        public byte nextByte() {
            if (this.position >= this.limit) {
                throw new NoSuchElementException();
            }
            byte[] bArr = BoundedByteString.this.bytes;
            int i = this.position;
            this.position = i + 1;
            return bArr[i];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    BoundedByteString(byte[] bArr, int i, int i2) {
        super(bArr);
        if (i < 0) {
            throw new IllegalArgumentException("Offset too small: " + i);
        } else if (i2 < 0) {
            throw new IllegalArgumentException("Length too small: " + i);
        } else if (((long) i) + ((long) i2) > ((long) bArr.length)) {
            throw new IllegalArgumentException("Offset+Length too large: " + i + "+" + i2);
        } else {
            this.bytesOffset = i;
            this.bytesLength = i2;
        }
    }

    @Override // com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.LiteralByteString
    public byte byteAt(int i) {
        if (i < 0) {
            throw new ArrayIndexOutOfBoundsException("Index too small: " + i);
        } else if (i < size()) {
            return this.bytes[this.bytesOffset + i];
        } else {
            throw new ArrayIndexOutOfBoundsException("Index too large: " + i + ", " + size());
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.LiteralByteString
    public void copyToInternal(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.bytes, getOffsetIntoBytes() + i, bArr, i2, i3);
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.protobuf.LiteralByteString
    public int getOffsetIntoBytes() {
        return this.bytesOffset;
    }

    /* Return type fixed from 'com.google.tagmanager.protobuf.ByteString$ByteIterator' to match base method */
    @Override // com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.LiteralByteString, com.google.tagmanager.protobuf.LiteralByteString, java.lang.Iterable
    public Iterator<Byte> iterator() {
        return new BoundedByteIterator();
    }

    @Override // com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.LiteralByteString
    public int size() {
        return this.bytesLength;
    }
}

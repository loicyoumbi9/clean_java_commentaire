package com.google.tagmanager;

import com.google.analytics.containertag.common.Key;
import com.google.analytics.containertag.proto.Serving;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

class ResourceUtil {

    public static class ExpandedFunctionCall {
        private final Map<String, TypeSystem.Value> mPropertiesMap;

        private ExpandedFunctionCall(Map<String, TypeSystem.Value> map) {
            this.mPropertiesMap = map;
        }

        public static ExpandedFunctionCallBuilder newBuilder() {
            return new ExpandedFunctionCallBuilder();
        }

        public Map<String, TypeSystem.Value> getProperties() {
            return Collections.unmodifiableMap(this.mPropertiesMap);
        }

        public String toString() {
            return "Properties: " + getProperties();
        }

        public void updateCacheableProperty(String str, TypeSystem.Value value) {
            this.mPropertiesMap.put(str, value);
        }
    }

    public static class ExpandedFunctionCallBuilder {
        private final Map<String, TypeSystem.Value> mPropertiesMap;

        private ExpandedFunctionCallBuilder() {
            this.mPropertiesMap = new HashMap();
        }

        public ExpandedFunctionCallBuilder addProperty(String str, TypeSystem.Value value) {
            this.mPropertiesMap.put(str, value);
            return this;
        }

        public ExpandedFunctionCall build() {
            return new ExpandedFunctionCall(this.mPropertiesMap);
        }
    }

    public static class ExpandedResource {
        private final Map<String, List<ExpandedFunctionCall>> mMacros;
        private final int mResourceFormatVersion;
        private final List<ExpandedRule> mRules;
        private final String mVersion;

        private ExpandedResource(List<ExpandedRule> list, Map<String, List<ExpandedFunctionCall>> map, String str, int i) {
            this.mRules = Collections.unmodifiableList(list);
            this.mMacros = Collections.unmodifiableMap(map);
            this.mVersion = str;
            this.mResourceFormatVersion = i;
        }

        public static ExpandedResourceBuilder newBuilder() {
            return new ExpandedResourceBuilder();
        }

        public Map<String, List<ExpandedFunctionCall>> getAllMacros() {
            return this.mMacros;
        }

        public List<ExpandedFunctionCall> getMacros(String str) {
            return this.mMacros.get(str);
        }

        public int getResourceFormatVersion() {
            return this.mResourceFormatVersion;
        }

        public List<ExpandedRule> getRules() {
            return this.mRules;
        }

        public String getVersion() {
            return this.mVersion;
        }

        public String toString() {
            return "Rules: " + getRules() + "  Macros: " + this.mMacros;
        }
    }

    public static class ExpandedResourceBuilder {
        private final Map<String, List<ExpandedFunctionCall>> mMacros;
        private final List<ExpandedFunctionCall> mPredicates;
        private int mResourceFormatVersion;
        private final List<ExpandedRule> mRules;
        private final List<ExpandedFunctionCall> mTags;
        private String mVersion;

        private ExpandedResourceBuilder() {
            this.mRules = new ArrayList();
            this.mTags = new ArrayList();
            this.mPredicates = new ArrayList();
            this.mMacros = new HashMap();
            this.mVersion = "";
            this.mResourceFormatVersion = 0;
        }

        public ExpandedResourceBuilder addMacro(ExpandedFunctionCall expandedFunctionCall) {
            String valueToString = Types.valueToString(expandedFunctionCall.getProperties().get(Key.INSTANCE_NAME.toString()));
            List<ExpandedFunctionCall> list = this.mMacros.get(valueToString);
            if (list == null) {
                list = new ArrayList<>();
                this.mMacros.put(valueToString, list);
            }
            list.add(expandedFunctionCall);
            return this;
        }

        public ExpandedResourceBuilder addRule(ExpandedRule expandedRule) {
            this.mRules.add(expandedRule);
            return this;
        }

        public ExpandedResource build() {
            return new ExpandedResource(this.mRules, this.mMacros, this.mVersion, this.mResourceFormatVersion);
        }

        public ExpandedResourceBuilder setResourceFormatVersion(int i) {
            this.mResourceFormatVersion = i;
            return this;
        }

        public ExpandedResourceBuilder setVersion(String str) {
            this.mVersion = str;
            return this;
        }
    }

    public static class ExpandedRule {
        private final List<String> mAddMacroRuleNames;
        private final List<ExpandedFunctionCall> mAddMacros;
        private final List<String> mAddTagRuleNames;
        private final List<ExpandedFunctionCall> mAddTags;
        private final List<ExpandedFunctionCall> mNegativePredicates;
        private final List<ExpandedFunctionCall> mPositivePredicates;
        private final List<String> mRemoveMacroRuleNames;
        private final List<ExpandedFunctionCall> mRemoveMacros;
        private final List<String> mRemoveTagRuleNames;
        private final List<ExpandedFunctionCall> mRemoveTags;

        private ExpandedRule(List<ExpandedFunctionCall> list, List<ExpandedFunctionCall> list2, List<ExpandedFunctionCall> list3, List<ExpandedFunctionCall> list4, List<ExpandedFunctionCall> list5, List<ExpandedFunctionCall> list6, List<String> list7, List<String> list8, List<String> list9, List<String> list10) {
            this.mPositivePredicates = Collections.unmodifiableList(list);
            this.mNegativePredicates = Collections.unmodifiableList(list2);
            this.mAddTags = Collections.unmodifiableList(list3);
            this.mRemoveTags = Collections.unmodifiableList(list4);
            this.mAddMacros = Collections.unmodifiableList(list5);
            this.mRemoveMacros = Collections.unmodifiableList(list6);
            this.mAddMacroRuleNames = Collections.unmodifiableList(list7);
            this.mRemoveMacroRuleNames = Collections.unmodifiableList(list8);
            this.mAddTagRuleNames = Collections.unmodifiableList(list9);
            this.mRemoveTagRuleNames = Collections.unmodifiableList(list10);
        }

        public static ExpandedRuleBuilder newBuilder() {
            return new ExpandedRuleBuilder();
        }

        public List<String> getAddMacroRuleNames() {
            return this.mAddMacroRuleNames;
        }

        public List<ExpandedFunctionCall> getAddMacros() {
            return this.mAddMacros;
        }

        public List<String> getAddTagRuleNames() {
            return this.mAddTagRuleNames;
        }

        public List<ExpandedFunctionCall> getAddTags() {
            return this.mAddTags;
        }

        public List<ExpandedFunctionCall> getNegativePredicates() {
            return this.mNegativePredicates;
        }

        public List<ExpandedFunctionCall> getPositivePredicates() {
            return this.mPositivePredicates;
        }

        public List<String> getRemoveMacroRuleNames() {
            return this.mRemoveMacroRuleNames;
        }

        public List<ExpandedFunctionCall> getRemoveMacros() {
            return this.mRemoveMacros;
        }

        public List<String> getRemoveTagRuleNames() {
            return this.mRemoveTagRuleNames;
        }

        public List<ExpandedFunctionCall> getRemoveTags() {
            return this.mRemoveTags;
        }

        public String toString() {
            return "Positive predicates: " + getPositivePredicates() + "  Negative predicates: " + getNegativePredicates() + "  Add tags: " + getAddTags() + "  Remove tags: " + getRemoveTags() + "  Add macros: " + getAddMacros() + "  Remove macros: " + getRemoveMacros();
        }
    }

    public static class ExpandedRuleBuilder {
        private final List<String> mAddMacroRuleNames;
        private final List<ExpandedFunctionCall> mAddMacros;
        private final List<String> mAddTagRuleNames;
        private final List<ExpandedFunctionCall> mAddTags;
        private final List<ExpandedFunctionCall> mNegativePredicates;
        private final List<ExpandedFunctionCall> mPositivePredicates;
        private final List<String> mRemoveMacroRuleNames;
        private final List<ExpandedFunctionCall> mRemoveMacros;
        private final List<String> mRemoveTagRuleNames;
        private final List<ExpandedFunctionCall> mRemoveTags;

        private ExpandedRuleBuilder() {
            this.mPositivePredicates = new ArrayList();
            this.mNegativePredicates = new ArrayList();
            this.mAddTags = new ArrayList();
            this.mRemoveTags = new ArrayList();
            this.mAddMacros = new ArrayList();
            this.mRemoveMacros = new ArrayList();
            this.mAddMacroRuleNames = new ArrayList();
            this.mRemoveMacroRuleNames = new ArrayList();
            this.mAddTagRuleNames = new ArrayList();
            this.mRemoveTagRuleNames = new ArrayList();
        }

        public ExpandedRuleBuilder addAddMacro(ExpandedFunctionCall expandedFunctionCall) {
            this.mAddMacros.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addAddMacroRuleName(String str) {
            this.mAddMacroRuleNames.add(str);
            return this;
        }

        public ExpandedRuleBuilder addAddTag(ExpandedFunctionCall expandedFunctionCall) {
            this.mAddTags.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addAddTagRuleName(String str) {
            this.mAddTagRuleNames.add(str);
            return this;
        }

        public ExpandedRuleBuilder addNegativePredicate(ExpandedFunctionCall expandedFunctionCall) {
            this.mNegativePredicates.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addPositivePredicate(ExpandedFunctionCall expandedFunctionCall) {
            this.mPositivePredicates.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addRemoveMacro(ExpandedFunctionCall expandedFunctionCall) {
            this.mRemoveMacros.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addRemoveMacroRuleName(String str) {
            this.mRemoveMacroRuleNames.add(str);
            return this;
        }

        public ExpandedRuleBuilder addRemoveTag(ExpandedFunctionCall expandedFunctionCall) {
            this.mRemoveTags.add(expandedFunctionCall);
            return this;
        }

        public ExpandedRuleBuilder addRemoveTagRuleName(String str) {
            this.mRemoveTagRuleNames.add(str);
            return this;
        }

        public ExpandedRule build() {
            return new ExpandedRule(this.mPositivePredicates, this.mNegativePredicates, this.mAddTags, this.mRemoveTags, this.mAddMacros, this.mRemoveMacros, this.mAddMacroRuleNames, this.mRemoveMacroRuleNames, this.mAddTagRuleNames, this.mRemoveTagRuleNames);
        }
    }

    public static class InvalidResourceException extends Exception {
        public InvalidResourceException(String str) {
            super(str);
        }
    }

    private ResourceUtil() {
    }

    private static ExpandedFunctionCall expandFunctionCall(Serving.FunctionCall functionCall, Serving.Resource resource, TypeSystem.Value[] valueArr, int i) throws InvalidResourceException {
        ExpandedFunctionCallBuilder newBuilder = ExpandedFunctionCall.newBuilder();
        for (Integer num : functionCall.getPropertyList()) {
            Serving.Property property = (Serving.Property) getWithBoundsCheck(resource.getPropertyList(), num.intValue(), "properties");
            newBuilder.addProperty((String) getWithBoundsCheck(resource.getKeyList(), property.getKey(), "keys"), (TypeSystem.Value) getWithBoundsCheck(valueArr, property.getValue(), "values"));
        }
        return newBuilder.build();
    }

    private static ExpandedRule expandRule(Serving.Rule rule, List<ExpandedFunctionCall> list, List<ExpandedFunctionCall> list2, List<ExpandedFunctionCall> list3, Serving.Resource resource) {
        ExpandedRuleBuilder newBuilder = ExpandedRule.newBuilder();
        for (Integer num : rule.getPositivePredicateList()) {
            newBuilder.addPositivePredicate(list3.get(num.intValue()));
        }
        for (Integer num2 : rule.getNegativePredicateList()) {
            newBuilder.addNegativePredicate(list3.get(num2.intValue()));
        }
        for (Integer num3 : rule.getAddTagList()) {
            newBuilder.addAddTag(list.get(num3.intValue()));
        }
        for (Integer num4 : rule.getAddTagRuleNameList()) {
            newBuilder.addAddTagRuleName(resource.getValue(num4.intValue()).getString());
        }
        for (Integer num5 : rule.getRemoveTagList()) {
            newBuilder.addRemoveTag(list.get(num5.intValue()));
        }
        for (Integer num6 : rule.getRemoveTagRuleNameList()) {
            newBuilder.addRemoveTagRuleName(resource.getValue(num6.intValue()).getString());
        }
        for (Integer num7 : rule.getAddMacroList()) {
            newBuilder.addAddMacro(list2.get(num7.intValue()));
        }
        for (Integer num8 : rule.getAddMacroRuleNameList()) {
            newBuilder.addAddMacroRuleName(resource.getValue(num8.intValue()).getString());
        }
        for (Integer num9 : rule.getRemoveMacroList()) {
            newBuilder.addRemoveMacro(list2.get(num9.intValue()));
        }
        for (Integer num10 : rule.getRemoveMacroRuleNameList()) {
            newBuilder.addRemoveMacroRuleName(resource.getValue(num10.intValue()).getString());
        }
        return newBuilder.build();
    }

    private static TypeSystem.Value expandValue(int i, Serving.Resource resource, TypeSystem.Value[] valueArr, Set<Integer> set) throws InvalidResourceException {
        String valueToString;
        if (set.contains(Integer.valueOf(i))) {
            logAndThrow("Value cycle detected.  Current value reference: " + i + "." + "  Previous value references: " + set + ".");
        }
        TypeSystem.Value value = (TypeSystem.Value) getWithBoundsCheck(resource.getValueList(), i, "values");
        if (valueArr[i] != null) {
            return valueArr[i];
        }
        TypeSystem.Value value2 = null;
        set.add(Integer.valueOf(i));
        switch (value.getType()) {
            case LIST:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue = newValueBuilderBasedOnValue(value);
                for (Integer num : getServingValue(value).getListItemList()) {
                    newValueBuilderBasedOnValue.addListItem(expandValue(num.intValue(), resource, valueArr, set));
                }
                value2 = newValueBuilderBasedOnValue.build();
                break;
            case MAP:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue2 = newValueBuilderBasedOnValue(value);
                Serving.ServingValue servingValue = getServingValue(value);
                if (servingValue.getMapKeyCount() != servingValue.getMapValueCount()) {
                    logAndThrow("Uneven map keys (" + servingValue.getMapKeyCount() + ") and map values (" + servingValue.getMapValueCount() + ")");
                }
                for (Integer num2 : servingValue.getMapKeyList()) {
                    newValueBuilderBasedOnValue2.addMapKey(expandValue(num2.intValue(), resource, valueArr, set));
                }
                for (Integer num3 : servingValue.getMapValueList()) {
                    newValueBuilderBasedOnValue2.addMapValue(expandValue(num3.intValue(), resource, valueArr, set));
                }
                value2 = newValueBuilderBasedOnValue2.build();
                break;
            case MACRO_REFERENCE:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue3 = newValueBuilderBasedOnValue(value);
                Serving.ServingValue servingValue2 = getServingValue(value);
                if (!servingValue2.hasMacroNameReference()) {
                    logAndThrow("Missing macro name reference");
                    valueToString = "";
                } else {
                    valueToString = Types.valueToString(expandValue(servingValue2.getMacroNameReference(), resource, valueArr, set));
                }
                newValueBuilderBasedOnValue3.setMacroReference(valueToString);
                value2 = newValueBuilderBasedOnValue3.build();
                break;
            case TEMPLATE:
                TypeSystem.Value.Builder newValueBuilderBasedOnValue4 = newValueBuilderBasedOnValue(value);
                for (Integer num4 : getServingValue(value).getTemplateTokenList()) {
                    newValueBuilderBasedOnValue4.addTemplateToken(expandValue(num4.intValue(), resource, valueArr, set));
                }
                value2 = newValueBuilderBasedOnValue4.build();
                break;
            case STRING:
            case FUNCTION_ID:
            case INTEGER:
            case BOOLEAN:
                value2 = value;
                break;
        }
        if (value2 == null) {
            logAndThrow("Invalid value: " + value);
        }
        valueArr[i] = value2;
        set.remove(Integer.valueOf(i));
        return value2;
    }

    public static ExpandedResource getExpandedResource(Serving.Resource resource) throws InvalidResourceException {
        TypeSystem.Value[] valueArr = new TypeSystem.Value[resource.getValueCount()];
        for (int i = 0; i < resource.getValueCount(); i++) {
            expandValue(i, resource, valueArr, new HashSet(0));
        }
        ExpandedResourceBuilder newBuilder = ExpandedResource.newBuilder();
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < resource.getTagCount(); i2++) {
            arrayList.add(expandFunctionCall(resource.getTag(i2), resource, valueArr, i2));
        }
        ArrayList arrayList2 = new ArrayList();
        for (int i3 = 0; i3 < resource.getPredicateCount(); i3++) {
            arrayList2.add(expandFunctionCall(resource.getPredicate(i3), resource, valueArr, i3));
        }
        ArrayList arrayList3 = new ArrayList();
        for (int i4 = 0; i4 < resource.getMacroCount(); i4++) {
            ExpandedFunctionCall expandFunctionCall = expandFunctionCall(resource.getMacro(i4), resource, valueArr, i4);
            newBuilder.addMacro(expandFunctionCall);
            arrayList3.add(expandFunctionCall);
        }
        for (Serving.Rule rule : resource.getRuleList()) {
            newBuilder.addRule(expandRule(rule, arrayList, arrayList3, arrayList2, resource));
        }
        newBuilder.setVersion(resource.getVersion());
        newBuilder.setResourceFormatVersion(resource.getResourceFormatVersion());
        return newBuilder.build();
    }

    private static Serving.ServingValue getServingValue(TypeSystem.Value value) throws InvalidResourceException {
        if (!value.hasExtension(Serving.ServingValue.ext)) {
            logAndThrow("Expected a ServingValue and didn't get one. Value is: " + value);
        }
        return (Serving.ServingValue) value.getExtension(Serving.ServingValue.ext);
    }

    private static <T> T getWithBoundsCheck(List<T> list, int i, String str) throws InvalidResourceException {
        if (i < 0 || i >= list.size()) {
            logAndThrow("Index out of bounds detected: " + i + " in " + str);
        }
        return list.get(i);
    }

    private static <T> T getWithBoundsCheck(T[] tArr, int i, String str) throws InvalidResourceException {
        if (i < 0 || i >= tArr.length) {
            logAndThrow("Index out of bounds detected: " + i + " in " + str);
        }
        return tArr[i];
    }

    private static void logAndThrow(String str) throws InvalidResourceException {
        Log.e(str);
        throw new InvalidResourceException(str);
    }

    public static TypeSystem.Value.Builder newValueBuilderBasedOnValue(TypeSystem.Value value) {
        TypeSystem.Value.Builder addAllEscaping = TypeSystem.Value.newBuilder().setType(value.getType()).addAllEscaping(value.getEscapingList());
        if (value.getContainsReferences()) {
            addAllEscaping.setContainsReferences(true);
        }
        return addAllEscaping;
    }
}

package com.google.tagmanager;

import android.annotation.TargetApi;
import android.util.LruCache;
import com.google.tagmanager.CacheFactory;

@TargetApi(12)
class LRUCache<K, V> implements Cache<K, V> {
    private LruCache<K, V> lruCache;

    LRUCache(int i, final CacheFactory.CacheSizeManager<K, V> cacheSizeManager) {
        this.lruCache = new LruCache<K, V>(i) {
            /* class com.google.tagmanager.LRUCache.AnonymousClass1 */

            /* access modifiers changed from: protected */
            @Override // android.util.LruCache
            public int sizeOf(K k, V v) {
                return cacheSizeManager.sizeOf(k, v);
            }
        };
    }

    @Override // com.google.tagmanager.Cache
    public V get(K k) {
        return this.lruCache.get(k);
    }

    @Override // com.google.tagmanager.Cache
    public void put(K k, V v) {
        this.lruCache.put(k, v);
    }
}

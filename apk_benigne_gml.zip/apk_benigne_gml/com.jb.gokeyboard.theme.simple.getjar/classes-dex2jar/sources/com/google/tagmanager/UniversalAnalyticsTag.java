package com.google.tagmanager;

import android.content.Context;
import com.getjar.sdk.utilities.Constants;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import com.google.analytics.tracking.android.Fields;
import com.google.analytics.tracking.android.HitTypes;
import com.google.analytics.tracking.android.Tracker;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

class UniversalAnalyticsTag extends TrackingTag {
    private static final String ACCOUNT = Key.ACCOUNT.toString();
    private static final String ANALYTICS_FIELDS = Key.ANALYTICS_FIELDS.toString();
    private static final String ANALYTICS_PASS_THROUGH = Key.ANALYTICS_PASS_THROUGH.toString();
    private static final String DEFAULT_TRACKING_ID = "_GTM_DEFAULT_TRACKER_";
    private static final String ID = FunctionType.UNIVERSAL_ANALYTICS.toString();
    private static final String TRACK_TRANSACTION = Key.TRACK_TRANSACTION.toString();
    private static final String TRANSACTION_DATALAYER_MAP = Key.TRANSACTION_DATALAYER_MAP.toString();
    private static final String TRANSACTION_ITEM_DATALAYER_MAP = Key.TRANSACTION_ITEM_DATALAYER_MAP.toString();
    private static Map<String, String> defaultItemMap;
    private static Map<String, String> defaultTransactionMap;
    private final DataLayer mDataLayer;
    private final TrackerProvider mTrackerProvider;
    private final Set<String> mTurnOffAnonymizeIpValues;

    public UniversalAnalyticsTag(Context context, DataLayer dataLayer) {
        this(context, dataLayer, new TrackerProvider(context));
    }

    @VisibleForTesting
    UniversalAnalyticsTag(Context context, DataLayer dataLayer, TrackerProvider trackerProvider) {
        super(ID, new String[0]);
        this.mDataLayer = dataLayer;
        this.mTrackerProvider = trackerProvider;
        this.mTurnOffAnonymizeIpValues = new HashSet();
        this.mTurnOffAnonymizeIpValues.add("");
        this.mTurnOffAnonymizeIpValues.add("0");
        this.mTurnOffAnonymizeIpValues.add("false");
    }

    private void addParam(Map<String, String> map, String str, String str2) {
        if (str2 != null) {
            map.put(str, str2);
        }
    }

    private boolean checkBooleanProperty(Map<String, TypeSystem.Value> map, String str) {
        TypeSystem.Value value = map.get(str);
        if (value == null) {
            return false;
        }
        return value.getBoolean();
    }

    private Map<String, String> convertToGaFields(TypeSystem.Value value) {
        Map<String, String> map;
        if (value == null || value.getType() != TypeSystem.Value.Type.MAP) {
            map = new HashMap<>();
        } else {
            Map<String, String> valueToMap = valueToMap(value);
            String str = valueToMap.get(Fields.ANONYMIZE_IP);
            if (str == null || !this.mTurnOffAnonymizeIpValues.contains(str.toLowerCase())) {
                map = valueToMap;
            } else {
                valueToMap.remove(Fields.ANONYMIZE_IP);
                return valueToMap;
            }
        }
        return map;
    }

    private String getDataLayerString(String str) {
        Object obj = this.mDataLayer.get(str);
        if (obj == null) {
            return null;
        }
        return obj.toString();
    }

    public static String getFunctionId() {
        return ID;
    }

    private Map<String, String> getTransactionFields(Map<String, TypeSystem.Value> map) {
        TypeSystem.Value value = map.get(TRANSACTION_DATALAYER_MAP);
        if (value != null) {
            return valueToMap(value);
        }
        if (defaultTransactionMap == null) {
            HashMap hashMap = new HashMap();
            hashMap.put(Constants.TRANSACTION_ID, Fields.TRANSACTION_ID);
            hashMap.put("transactionAffiliation", Fields.TRANSACTION_AFFILIATION);
            hashMap.put("transactionTax", Fields.TRANSACTION_TAX);
            hashMap.put("transactionShipping", Fields.TRANSACTION_SHIPPING);
            hashMap.put("transactionTotal", Fields.TRANSACTION_REVENUE);
            hashMap.put("transactionCurrency", Fields.CURRENCY_CODE);
            defaultTransactionMap = hashMap;
        }
        return defaultTransactionMap;
    }

    private Map<String, String> getTransactionItemFields(Map<String, TypeSystem.Value> map) {
        TypeSystem.Value value = map.get(TRANSACTION_ITEM_DATALAYER_MAP);
        if (value != null) {
            return valueToMap(value);
        }
        if (defaultItemMap == null) {
            HashMap hashMap = new HashMap();
            hashMap.put("name", Fields.ITEM_NAME);
            hashMap.put("sku", Fields.ITEM_SKU);
            hashMap.put("category", Fields.ITEM_CATEGORY);
            hashMap.put(Constants.APP_COST, Fields.ITEM_PRICE);
            hashMap.put("quantity", Fields.ITEM_QUANTITY);
            hashMap.put("currency", Fields.CURRENCY_CODE);
            defaultItemMap = hashMap;
        }
        return defaultItemMap;
    }

    private List<Map<String, String>> getTransactionItems() {
        Object obj = this.mDataLayer.get("transactionProducts");
        if (obj == null) {
            return null;
        }
        if (!(obj instanceof List)) {
            throw new IllegalArgumentException("transactionProducts should be of type List.");
        }
        for (Object obj2 : (List) obj) {
            if (!(obj2 instanceof Map)) {
                throw new IllegalArgumentException("Each element of transactionProducts should be of type Map.");
            }
        }
        return (List) obj;
    }

    private void sendTransaction(Tracker tracker, Map<String, TypeSystem.Value> map) {
        map.get(ACCOUNT).getString();
        String dataLayerString = getDataLayerString(Constants.TRANSACTION_ID);
        if (dataLayerString == null) {
            Log.e("Cannot find transactionId in data layer.");
            return;
        }
        LinkedList<Map> linkedList = new LinkedList();
        try {
            Map<String, String> convertToGaFields = convertToGaFields(map.get(ANALYTICS_FIELDS));
            convertToGaFields.put(Fields.HIT_TYPE, HitTypes.TRANSACTION);
            for (Map.Entry<String, String> entry : getTransactionFields(map).entrySet()) {
                addParam(convertToGaFields, entry.getValue(), getDataLayerString(entry.getKey()));
            }
            linkedList.add(convertToGaFields);
            List<Map<String, String>> transactionItems = getTransactionItems();
            if (transactionItems != null) {
                for (Map<String, String> map2 : transactionItems) {
                    if (map2.get("name") == null) {
                        Log.e("Unable to send transaction item hit due to missing 'name' field.");
                        return;
                    }
                    Map<String, String> convertToGaFields2 = convertToGaFields(map.get(ANALYTICS_FIELDS));
                    convertToGaFields2.put(Fields.HIT_TYPE, HitTypes.ITEM);
                    convertToGaFields2.put(Fields.TRANSACTION_ID, dataLayerString);
                    for (Map.Entry<String, String> entry2 : getTransactionItemFields(map).entrySet()) {
                        addParam(convertToGaFields2, entry2.getValue(), map2.get(entry2.getKey()));
                    }
                    linkedList.add(convertToGaFields2);
                }
            }
            for (Map map3 : linkedList) {
                tracker.send(map3);
            }
        } catch (IllegalArgumentException e) {
            Log.e("Unable to send transaction", e);
        }
    }

    private Map<String, String> valueToMap(TypeSystem.Value value) {
        if (value.getType() != TypeSystem.Value.Type.MAP) {
            return null;
        }
        HashMap hashMap = new HashMap(value.getMapKeyCount());
        for (int i = 0; i < value.getMapKeyCount(); i++) {
            hashMap.put(Types.valueToString(value.getMapKey(i)), Types.valueToString(value.getMapValue(i)));
        }
        return hashMap;
    }

    @Override // com.google.tagmanager.TrackingTag
    public void evaluateTrackingTag(Map<String, TypeSystem.Value> map) {
        Tracker tracker = this.mTrackerProvider.getTracker(DEFAULT_TRACKING_ID);
        if (checkBooleanProperty(map, ANALYTICS_PASS_THROUGH)) {
            tracker.send(convertToGaFields(map.get(ANALYTICS_FIELDS)));
        } else if (checkBooleanProperty(map, TRACK_TRANSACTION)) {
            sendTransaction(tracker, map);
        } else {
            Log.w("Ignoring unknown tag.");
        }
        this.mTrackerProvider.close(tracker);
    }
}

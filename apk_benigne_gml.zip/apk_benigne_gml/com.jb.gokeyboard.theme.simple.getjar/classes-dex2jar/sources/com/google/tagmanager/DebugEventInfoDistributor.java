package com.google.tagmanager;

import com.google.analytics.containertag.proto.MutableDebug;

class DebugEventInfoDistributor implements EventInfoDistributor {
    private String containerId;
    private String containerVersion;
    private DebugInformationHandler handler;

    public DebugEventInfoDistributor(DebugInformationHandler debugInformationHandler, String str, String str2) {
        this.handler = debugInformationHandler;
        this.containerVersion = str;
        this.containerId = str2;
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public EventInfoBuilder createDataLayerEventEvaluationEventInfo(String str) {
        return new DebugEventInfoBuilder(MutableDebug.EventInfo.EventType.DATA_LAYER_EVENT, this.containerVersion, this.containerId, str, this.handler);
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public EventInfoBuilder createMacroEvalutionEventInfo(String str) {
        return new DebugEventInfoBuilder(MutableDebug.EventInfo.EventType.MACRO_REFERENCE, this.containerVersion, this.containerId, str, this.handler);
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public boolean debugMode() {
        return true;
    }
}

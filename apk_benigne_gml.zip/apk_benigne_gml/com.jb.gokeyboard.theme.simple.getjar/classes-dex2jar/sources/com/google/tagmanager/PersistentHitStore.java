package com.google.tagmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.text.TextUtils;
import com.getjar.sdk.utilities.Utility;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.tagmanager.SimpleNetworkDispatcher;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentHitStore implements HitStore {
    /* access modifiers changed from: private */
    public static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL,'%s' INTEGER NOT NULL);", HITS_TABLE, HIT_ID, HIT_TIME, HIT_URL, HIT_FIRST_DISPATCH_TIME);
    private static final String DATABASE_FILENAME = "gtm_urls.db";
    @VisibleForTesting
    static final String HITS_TABLE = "gtm_hits";
    static final long HIT_DISPATCH_RETRY_WINDOW = 14400000;
    @VisibleForTesting
    static final String HIT_FIRST_DISPATCH_TIME = "hit_first_send_time";
    @VisibleForTesting
    static final String HIT_ID = "hit_id";
    private static final String HIT_ID_WHERE_CLAUSE = "hit_id=?";
    @VisibleForTesting
    static final String HIT_TIME = "hit_time";
    @VisibleForTesting
    static final String HIT_URL = "hit_url";
    /* access modifiers changed from: private */
    public Clock mClock;
    /* access modifiers changed from: private */
    public final Context mContext;
    /* access modifiers changed from: private */
    public final String mDatabaseName;
    private final UrlDatabaseHelper mDbHelper;
    private volatile Dispatcher mDispatcher;
    private long mLastDeleteStaleHitsTime;
    private final HitStoreStateListener mListener;

    @VisibleForTesting
    class StoreDispatchListener implements SimpleNetworkDispatcher.DispatchListener {
        StoreDispatchListener() {
        }

        @Override // com.google.tagmanager.SimpleNetworkDispatcher.DispatchListener
        public void onHitDispatched(Hit hit) {
            PersistentHitStore.this.deleteHit(hit.getHitId());
        }

        @Override // com.google.tagmanager.SimpleNetworkDispatcher.DispatchListener
        public void onHitPermanentDispatchFailure(Hit hit) {
            PersistentHitStore.this.deleteHit(hit.getHitId());
            Log.v("Permanent failure dispatching hitId: " + hit.getHitId());
        }

        @Override // com.google.tagmanager.SimpleNetworkDispatcher.DispatchListener
        public void onHitTransientDispatchFailure(Hit hit) {
            long hitFirstDispatchTime = hit.getHitFirstDispatchTime();
            if (hitFirstDispatchTime == 0) {
                PersistentHitStore.this.setHitFirstDispatchTime(hit.getHitId(), PersistentHitStore.this.mClock.currentTimeMillis());
            } else if (hitFirstDispatchTime + PersistentHitStore.HIT_DISPATCH_RETRY_WINDOW < PersistentHitStore.this.mClock.currentTimeMillis()) {
                PersistentHitStore.this.deleteHit(hit.getHitId());
                Log.v("Giving up on failed hitId: " + hit.getHitId());
            }
        }
    }

    @VisibleForTesting
    class UrlDatabaseHelper extends SQLiteOpenHelper {
        private boolean mBadDatabase;
        private long mLastDatabaseCheckTime = 0;

        UrlDatabaseHelper(Context context, String str) {
            super(context, str, (SQLiteDatabase.CursorFactory) null, 1);
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x0049  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private boolean tablePresent(java.lang.String r11, android.database.sqlite.SQLiteDatabase r12) {
            /*
                r10 = this;
                r8 = 0
                r9 = 0
                java.lang.String r1 = "SQLITE_MASTER"
                r0 = 1
                java.lang.String[] r2 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r0 = 0
                java.lang.String r3 = "name"
                r2[r0] = r3     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                java.lang.String r3 = "name=?"
                r0 = 1
                java.lang.String[] r4 = new java.lang.String[r0]     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r0 = 0
                r4[r0] = r11     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                r5 = 0
                r6 = 0
                r7 = 0
                r0 = r12
                android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x0026, all -> 0x0045 }
                boolean r0 = r1.moveToFirst()     // Catch:{ SQLiteException -> 0x0055, all -> 0x004d }
                if (r1 == 0) goto L_0x0025
                r1.close()
            L_0x0025:
                return r0
            L_0x0026:
                r0 = move-exception
                r0 = r9
            L_0x0028:
                java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0051 }
                r1.<init>()     // Catch:{ all -> 0x0051 }
                java.lang.String r2 = "Error querying for table "
                java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x0051 }
                java.lang.StringBuilder r1 = r1.append(r11)     // Catch:{ all -> 0x0051 }
                java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0051 }
                com.google.tagmanager.Log.w(r1)     // Catch:{ all -> 0x0051 }
                if (r0 == 0) goto L_0x0043
                r0.close()
            L_0x0043:
                r0 = r8
                goto L_0x0025
            L_0x0045:
                r0 = move-exception
                r2 = r0
            L_0x0047:
                if (r9 == 0) goto L_0x004c
                r9.close()
            L_0x004c:
                throw r2
            L_0x004d:
                r0 = move-exception
                r2 = r0
                r9 = r1
                goto L_0x0047
            L_0x0051:
                r1 = move-exception
                r2 = r1
                r9 = r0
                goto L_0x0047
            L_0x0055:
                r0 = move-exception
                r0 = r1
                goto L_0x0028
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.PersistentHitStore.UrlDatabaseHelper.tablePresent(java.lang.String, android.database.sqlite.SQLiteDatabase):boolean");
        }

        /* JADX INFO: finally extract failed */
        private void validateColumnsPresent(SQLiteDatabase sQLiteDatabase) {
            String[] columnNames;
            Cursor rawQuery = sQLiteDatabase.rawQuery("SELECT * FROM gtm_hits WHERE 0", null);
            HashSet hashSet = new HashSet();
            try {
                for (String str : rawQuery.getColumnNames()) {
                    hashSet.add(str);
                }
                rawQuery.close();
                if (!hashSet.remove(PersistentHitStore.HIT_ID) || !hashSet.remove(PersistentHitStore.HIT_URL) || !hashSet.remove(PersistentHitStore.HIT_TIME) || !hashSet.remove(PersistentHitStore.HIT_FIRST_DISPATCH_TIME)) {
                    throw new SQLiteException("Database column missing");
                } else if (!hashSet.isEmpty()) {
                    throw new SQLiteException("Database has extra columns");
                }
            } catch (Throwable th) {
                rawQuery.close();
                throw th;
            }
        }

        public SQLiteDatabase getWritableDatabase() {
            if (!this.mBadDatabase || this.mLastDatabaseCheckTime + 3600000 <= PersistentHitStore.this.mClock.currentTimeMillis()) {
                SQLiteDatabase sQLiteDatabase = null;
                this.mBadDatabase = true;
                this.mLastDatabaseCheckTime = PersistentHitStore.this.mClock.currentTimeMillis();
                try {
                    sQLiteDatabase = super.getWritableDatabase();
                } catch (SQLiteException e) {
                    PersistentHitStore.this.mContext.getDatabasePath(PersistentHitStore.this.mDatabaseName).delete();
                }
                if (sQLiteDatabase == null) {
                    sQLiteDatabase = super.getWritableDatabase();
                }
                this.mBadDatabase = false;
                return sQLiteDatabase;
            }
            throw new SQLiteException("Database creation failed");
        }

        /* access modifiers changed from: package-private */
        public boolean isBadDatabase() {
            return this.mBadDatabase;
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            FutureApis.setOwnerOnlyReadWrite(sQLiteDatabase.getPath());
        }

        public void onOpen(SQLiteDatabase sQLiteDatabase) {
            if (Build.VERSION.SDK_INT < 15) {
                Cursor rawQuery = sQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
                try {
                    rawQuery.moveToFirst();
                } finally {
                    rawQuery.close();
                }
            }
            if (!tablePresent(PersistentHitStore.HITS_TABLE, sQLiteDatabase)) {
                sQLiteDatabase.execSQL(PersistentHitStore.CREATE_HITS_TABLE);
            } else {
                validateColumnsPresent(sQLiteDatabase);
            }
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        }

        /* access modifiers changed from: package-private */
        public void setBadDatabase(boolean z) {
            this.mBadDatabase = z;
        }
    }

    PersistentHitStore(HitStoreStateListener hitStoreStateListener, Context context) {
        this(hitStoreStateListener, context, DATABASE_FILENAME);
    }

    @VisibleForTesting
    PersistentHitStore(HitStoreStateListener hitStoreStateListener, Context context, String str) {
        this.mContext = context.getApplicationContext();
        this.mDatabaseName = str;
        this.mListener = hitStoreStateListener;
        this.mClock = new Clock() {
            /* class com.google.tagmanager.PersistentHitStore.AnonymousClass1 */

            @Override // com.google.tagmanager.Clock
            public long currentTimeMillis() {
                return System.currentTimeMillis();
            }
        };
        this.mDbHelper = new UrlDatabaseHelper(this.mContext, this.mDatabaseName);
        this.mDispatcher = new SimpleNetworkDispatcher(new DefaultHttpClient(), this.mContext, new StoreDispatchListener());
        this.mLastDeleteStaleHitsTime = 0;
    }

    /* access modifiers changed from: private */
    public void deleteHit(long j) {
        deleteHits(new String[]{String.valueOf(j)});
    }

    private SQLiteDatabase getWritableDatabase(String str) {
        try {
            return this.mDbHelper.getWritableDatabase();
        } catch (SQLiteException e) {
            Log.w(str);
            return null;
        }
    }

    private void removeOldHitIfFull() {
        int numStoredHits = (getNumStoredHits() - 2000) + 1;
        if (numStoredHits > 0) {
            List<String> peekHitIds = peekHitIds(numStoredHits);
            Log.v("Store full, deleting " + peekHitIds.size() + " hits to make room.");
            deleteHits((String[]) peekHitIds.toArray(new String[0]));
        }
    }

    /* access modifiers changed from: private */
    public void setHitFirstDispatchTime(long j, long j2) {
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for getNumStoredHits.");
        if (writableDatabase != null) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(HIT_FIRST_DISPATCH_TIME, Long.valueOf(j2));
            try {
                writableDatabase.update(HITS_TABLE, contentValues, HIT_ID_WHERE_CLAUSE, new String[]{String.valueOf(j)});
            } catch (SQLiteException e) {
                Log.w("Error setting HIT_FIRST_DISPATCH_TIME for hitId: " + j);
                deleteHit(j);
            }
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void}
     arg types: [java.lang.String, int]
     candidates:
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Byte):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Float):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.String):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Long):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Boolean):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, byte[]):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Double):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Short):void}
      ClspMth{android.content.ContentValues.put(java.lang.String, java.lang.Integer):void} */
    private void writeHitToDatabase(long j, String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for putHit");
        if (writableDatabase != null) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(HIT_TIME, Long.valueOf(j));
            contentValues.put(HIT_URL, str);
            contentValues.put(HIT_FIRST_DISPATCH_TIME, (Integer) 0);
            try {
                writableDatabase.insert(HITS_TABLE, null, contentValues);
                this.mListener.reportStoreIsEmpty(false);
            } catch (SQLiteException e) {
                Log.w("Error storing hit");
            }
        }
    }

    @Override // com.google.tagmanager.HitStore
    public void close() {
        try {
            this.mDbHelper.getWritableDatabase().close();
            this.mDispatcher.close();
        } catch (SQLiteException e) {
            Log.w("Error opening database for close");
        }
    }

    /* access modifiers changed from: package-private */
    public void deleteHits(String[] strArr) {
        SQLiteDatabase writableDatabase;
        boolean z = false;
        if (strArr != null && strArr.length != 0 && (writableDatabase = getWritableDatabase("Error opening database for deleteHits.")) != null) {
            try {
                writableDatabase.delete(HITS_TABLE, String.format("HIT_ID in (%s)", TextUtils.join(",", Collections.nCopies(strArr.length, Utility.QUERY_START))), strArr);
                HitStoreStateListener hitStoreStateListener = this.mListener;
                if (getNumStoredHits() == 0) {
                    z = true;
                }
                hitStoreStateListener.reportStoreIsEmpty(z);
            } catch (SQLiteException e) {
                Log.w("Error deleting hits");
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int deleteStaleHits() {
        boolean z = false;
        long currentTimeMillis = this.mClock.currentTimeMillis();
        if (currentTimeMillis <= this.mLastDeleteStaleHitsTime + 86400000) {
            return 0;
        }
        this.mLastDeleteStaleHitsTime = currentTimeMillis;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for deleteStaleHits.");
        if (writableDatabase == null) {
            return 0;
        }
        int delete = writableDatabase.delete(HITS_TABLE, "HIT_TIME < ?", new String[]{Long.toString(this.mClock.currentTimeMillis() - 2592000000L)});
        HitStoreStateListener hitStoreStateListener = this.mListener;
        if (getNumStoredHits() == 0) {
            z = true;
        }
        hitStoreStateListener.reportStoreIsEmpty(z);
        return delete;
    }

    @Override // com.google.tagmanager.HitStore
    public void dispatch() {
        Log.v("GTM Dispatch running...");
        if (this.mDispatcher.okToDispatch()) {
            List<Hit> peekHits = peekHits(40);
            if (peekHits.isEmpty()) {
                Log.v("...nothing to dispatch");
                this.mListener.reportStoreIsEmpty(true);
                return;
            }
            this.mDispatcher.dispatchHits(peekHits);
            if (getNumStoredUntriedHits() > 0) {
                ServiceManagerImpl.getInstance().dispatch();
            }
        }
    }

    @VisibleForTesting
    public UrlDatabaseHelper getDbHelper() {
        return this.mDbHelper;
    }

    @Override // com.google.tagmanager.HitStore
    public Dispatcher getDispatcher() {
        return this.mDispatcher;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public UrlDatabaseHelper getHelper() {
        return this.mDbHelper;
    }

    /* access modifiers changed from: package-private */
    public int getNumStoredHits() {
        Cursor cursor = null;
        int i = 0;
        SQLiteDatabase writableDatabase = getWritableDatabase("Error opening database for getNumStoredHits.");
        if (writableDatabase != null) {
            try {
                Cursor rawQuery = writableDatabase.rawQuery("SELECT COUNT(*) from gtm_hits", null);
                if (rawQuery.moveToFirst()) {
                    i = (int) rawQuery.getLong(0);
                }
                if (rawQuery != null) {
                    rawQuery.close();
                }
            } catch (SQLiteException e) {
                Log.w("Error getting numStoredHits");
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (cursor != null) {
                    cursor.close();
                }
                throw th;
            }
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0041  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getNumStoredUntriedHits() {
        /*
            r10 = this;
            r8 = 0
            r9 = 0
            java.lang.String r0 = "Error opening database for getNumStoredHits."
            android.database.sqlite.SQLiteDatabase r0 = r10.getWritableDatabase(r0)
            if (r0 != 0) goto L_0x000b
        L_0x000a:
            return r8
        L_0x000b:
            java.lang.String r1 = "gtm_hits"
            r2 = 2
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch:{ SQLiteException -> 0x002f, all -> 0x003d }
            r3 = 0
            java.lang.String r4 = "hit_id"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x002f, all -> 0x003d }
            r3 = 1
            java.lang.String r4 = "hit_first_send_time"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x002f, all -> 0x003d }
            java.lang.String r3 = "hit_first_send_time=0"
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ SQLiteException -> 0x002f, all -> 0x003d }
            int r0 = r1.getCount()     // Catch:{ SQLiteException -> 0x004d, all -> 0x0045 }
            if (r1 == 0) goto L_0x002d
            r1.close()
        L_0x002d:
            r8 = r0
            goto L_0x000a
        L_0x002f:
            r0 = move-exception
            r0 = r9
        L_0x0031:
            java.lang.String r1 = "Error getting num untried hits"
            com.google.tagmanager.Log.w(r1)     // Catch:{ all -> 0x0049 }
            if (r0 == 0) goto L_0x0050
            r0.close()
            r0 = r8
            goto L_0x002d
        L_0x003d:
            r0 = move-exception
            r2 = r0
        L_0x003f:
            if (r9 == 0) goto L_0x0044
            r9.close()
        L_0x0044:
            throw r2
        L_0x0045:
            r0 = move-exception
            r2 = r0
            r9 = r1
            goto L_0x003f
        L_0x0049:
            r1 = move-exception
            r2 = r1
            r9 = r0
            goto L_0x003f
        L_0x004d:
            r0 = move-exception
            r0 = r1
            goto L_0x0031
        L_0x0050:
            r0 = r8
            goto L_0x002d
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.PersistentHitStore.getNumStoredUntriedHits():int");
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0081  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<java.lang.String> peekHitIds(int r12) {
        /*
            r11 = this;
            r10 = 0
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            if (r12 > 0) goto L_0x000f
            java.lang.String r0 = "Invalid maxHits specified. Skipping"
            com.google.tagmanager.Log.w(r0)
        L_0x000d:
            r0 = r9
        L_0x000e:
            return r0
        L_0x000f:
            java.lang.String r0 = "Error opening database for peekHitIds."
            android.database.sqlite.SQLiteDatabase r0 = r11.getWritableDatabase(r0)
            if (r0 == 0) goto L_0x000d
            java.lang.String r1 = "%s ASC"
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            java.lang.String r4 = "hit_id"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r7 = java.lang.String.format(r1, r2)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r8 = java.lang.Integer.toString(r12)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            java.lang.String r1 = "gtm_hits"
            r2 = 1
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            java.lang.String r4 = "hit_id"
            r2[r3] = r4     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch:{ SQLiteException -> 0x005a, all -> 0x007d }
            boolean r0 = r1.moveToFirst()     // Catch:{ SQLiteException -> 0x0087 }
            if (r0 == 0) goto L_0x0053
        L_0x0041:
            r0 = 0
            long r2 = r1.getLong(r0)     // Catch:{ SQLiteException -> 0x0087 }
            java.lang.String r0 = java.lang.String.valueOf(r2)     // Catch:{ SQLiteException -> 0x0087 }
            r9.add(r0)     // Catch:{ SQLiteException -> 0x0087 }
            boolean r0 = r1.moveToNext()     // Catch:{ SQLiteException -> 0x0087 }
            if (r0 != 0) goto L_0x0041
        L_0x0053:
            if (r1 == 0) goto L_0x000d
            r1.close()
            r0 = r9
            goto L_0x000e
        L_0x005a:
            r0 = move-exception
            r1 = r10
        L_0x005c:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0085 }
            r2.<init>()     // Catch:{ all -> 0x0085 }
            java.lang.String r3 = "Error in peekHits fetching hitIds: "
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x0085 }
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x0085 }
            java.lang.StringBuilder r0 = r2.append(r0)     // Catch:{ all -> 0x0085 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0085 }
            com.google.tagmanager.Log.w(r0)     // Catch:{ all -> 0x0085 }
            if (r1 == 0) goto L_0x000d
            r1.close()
            r0 = r9
            goto L_0x000e
        L_0x007d:
            r0 = move-exception
            r1 = r10
        L_0x007f:
            if (r1 == 0) goto L_0x0084
            r1.close()
        L_0x0084:
            throw r0
        L_0x0085:
            r0 = move-exception
            goto L_0x007f
        L_0x0087:
            r0 = move-exception
            goto L_0x005c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.PersistentHitStore.peekHitIds(int):java.util.List");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:67:0x016f, code lost:
        r2 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0175, code lost:
        r3 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0176, code lost:
        r4 = r14;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00e9  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00f2  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x016f A[ExcHandler: all (th java.lang.Throwable), Splitter:B:3:0x0016] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<com.google.tagmanager.Hit> peekHits(int r17) {
        /*
            r16 = this;
            r15 = 1
            r11 = 0
            r14 = 0
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            java.lang.String r2 = "Error opening database for peekHits"
            r0 = r16
            android.database.sqlite.SQLiteDatabase r2 = r0.getWritableDatabase(r2)
            if (r2 != 0) goto L_0x0013
        L_0x0012:
            return r13
        L_0x0013:
            java.lang.String r3 = "%s ASC"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            java.lang.String r9 = java.lang.String.format(r3, r4)     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            java.lang.String r10 = java.lang.Integer.toString(r17)     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            java.lang.String r3 = "gtm_hits"
            r4 = 3
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            r5 = 1
            java.lang.String r6 = "hit_time"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            r5 = 2
            java.lang.String r6 = "hit_first_send_time"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r14 = r2.query(r3, r4, r5, r6, r7, r8, r9, r10)     // Catch:{ SQLiteException -> 0x00ca, all -> 0x016f }
            java.util.ArrayList r12 = new java.util.ArrayList     // Catch:{ SQLiteException -> 0x0175, all -> 0x016f }
            r12.<init>()     // Catch:{ SQLiteException -> 0x0175, all -> 0x016f }
            boolean r3 = r14.moveToFirst()     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            if (r3 == 0) goto L_0x0069
        L_0x004c:
            com.google.tagmanager.Hit r3 = new com.google.tagmanager.Hit     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            r4 = 0
            long r4 = r14.getLong(r4)     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            r6 = 1
            long r6 = r14.getLong(r6)     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            r8 = 2
            long r8 = r14.getLong(r8)     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            r3.<init>(r4, r6, r8)     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            r12.add(r3)     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            boolean r3 = r14.moveToNext()     // Catch:{ SQLiteException -> 0x0165, all -> 0x00ef }
            if (r3 != 0) goto L_0x004c
        L_0x0069:
            if (r14 == 0) goto L_0x006e
            r14.close()
        L_0x006e:
            java.lang.String r3 = "%s ASC"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ SQLiteException -> 0x016d }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x016d }
            java.lang.String r9 = java.lang.String.format(r3, r4)     // Catch:{ SQLiteException -> 0x016d }
            java.lang.String r10 = java.lang.Integer.toString(r17)     // Catch:{ SQLiteException -> 0x016d }
            java.lang.String r3 = "gtm_hits"
            r4 = 2
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch:{ SQLiteException -> 0x016d }
            r5 = 0
            java.lang.String r6 = "hit_id"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x016d }
            r5 = 1
            java.lang.String r6 = "hit_url"
            r4[r5] = r6     // Catch:{ SQLiteException -> 0x016d }
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            android.database.Cursor r3 = r2.query(r3, r4, r5, r6, r7, r8, r9, r10)     // Catch:{ SQLiteException -> 0x016d }
            boolean r2 = r3.moveToFirst()     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            if (r2 == 0) goto L_0x00c2
            r4 = r11
        L_0x009e:
            r0 = r3
            android.database.sqlite.SQLiteCursor r0 = (android.database.sqlite.SQLiteCursor) r0     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            r2 = r0
            android.database.CursorWindow r2 = r2.getWindow()     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            int r2 = r2.getNumRows()     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            if (r2 <= 0) goto L_0x00f6
            java.lang.Object r2 = r12.get(r4)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            com.google.tagmanager.Hit r2 = (com.google.tagmanager.Hit) r2     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            r5 = 1
            java.lang.String r5 = r3.getString(r5)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            r2.setHitUrl(r5)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
        L_0x00ba:
            int r2 = r4 + 1
            boolean r4 = r3.moveToNext()     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            if (r4 != 0) goto L_0x0179
        L_0x00c2:
            if (r3 == 0) goto L_0x00c7
            r3.close()
        L_0x00c7:
            r13 = r12
            goto L_0x0012
        L_0x00ca:
            r3 = move-exception
            r4 = r14
        L_0x00cc:
            r2 = r13
        L_0x00cd:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x0171 }
            r5.<init>()     // Catch:{ all -> 0x0171 }
            java.lang.String r6 = "Error in peekHits fetching hitIds: "
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ all -> 0x0171 }
            java.lang.String r3 = r3.getMessage()     // Catch:{ all -> 0x0171 }
            java.lang.StringBuilder r3 = r5.append(r3)     // Catch:{ all -> 0x0171 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0171 }
            com.google.tagmanager.Log.w(r3)     // Catch:{ all -> 0x0171 }
            if (r4 == 0) goto L_0x00ec
            r4.close()
        L_0x00ec:
            r13 = r2
            goto L_0x0012
        L_0x00ef:
            r2 = move-exception
        L_0x00f0:
            if (r14 == 0) goto L_0x00f5
            r14.close()
        L_0x00f5:
            throw r2
        L_0x00f6:
            java.lang.String r5 = "HitString for hitId %d too large.  Hit will be deleted."
            r2 = 1
            java.lang.Object[] r6 = new java.lang.Object[r2]     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            r7 = 0
            java.lang.Object r2 = r12.get(r4)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            com.google.tagmanager.Hit r2 = (com.google.tagmanager.Hit) r2     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            long r8 = r2.getHitId()     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            java.lang.Long r2 = java.lang.Long.valueOf(r8)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            r6[r7] = r2     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            java.lang.String r2 = java.lang.String.format(r5, r6)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            com.google.tagmanager.Log.w(r2)     // Catch:{ SQLiteException -> 0x0114, all -> 0x016a }
            goto L_0x00ba
        L_0x0114:
            r2 = move-exception
            r14 = r3
        L_0x0116:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x015e }
            r3.<init>()     // Catch:{ all -> 0x015e }
            java.lang.String r4 = "Error in peekHits fetching hit url: "
            java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x015e }
            java.lang.String r2 = r2.getMessage()     // Catch:{ all -> 0x015e }
            java.lang.StringBuilder r2 = r3.append(r2)     // Catch:{ all -> 0x015e }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x015e }
            com.google.tagmanager.Log.w(r2)     // Catch:{ all -> 0x015e }
            java.util.ArrayList r13 = new java.util.ArrayList     // Catch:{ all -> 0x015e }
            r13.<init>()     // Catch:{ all -> 0x015e }
            java.util.Iterator r4 = r12.iterator()     // Catch:{ all -> 0x015e }
            r3 = r11
        L_0x013a:
            boolean r2 = r4.hasNext()     // Catch:{ all -> 0x015e }
            if (r2 == 0) goto L_0x0152
            java.lang.Object r2 = r4.next()     // Catch:{ all -> 0x015e }
            com.google.tagmanager.Hit r2 = (com.google.tagmanager.Hit) r2     // Catch:{ all -> 0x015e }
            java.lang.String r5 = r2.getHitUrl()     // Catch:{ all -> 0x015e }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x015e }
            if (r5 == 0) goto L_0x015a
            if (r3 == 0) goto L_0x0159
        L_0x0152:
            if (r14 == 0) goto L_0x0012
            r14.close()
            goto L_0x0012
        L_0x0159:
            r3 = r15
        L_0x015a:
            r13.add(r2)     // Catch:{ all -> 0x015e }
            goto L_0x013a
        L_0x015e:
            r2 = move-exception
        L_0x015f:
            if (r14 == 0) goto L_0x0164
            r14.close()
        L_0x0164:
            throw r2
        L_0x0165:
            r3 = move-exception
            r2 = r12
            r4 = r14
            goto L_0x00cd
        L_0x016a:
            r2 = move-exception
            r14 = r3
            goto L_0x015f
        L_0x016d:
            r2 = move-exception
            goto L_0x0116
        L_0x016f:
            r2 = move-exception
            goto L_0x00f0
        L_0x0171:
            r2 = move-exception
            r14 = r4
            goto L_0x00f0
        L_0x0175:
            r3 = move-exception
            r4 = r14
            goto L_0x00cc
        L_0x0179:
            r4 = r2
            goto L_0x009e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.PersistentHitStore.peekHits(int):java.util.List");
    }

    @Override // com.google.tagmanager.HitStore
    public void putHit(long j, String str) {
        deleteStaleHits();
        removeOldHitIfFull();
        writeHitToDatabase(j, str);
    }

    @VisibleForTesting
    public void setClock(Clock clock) {
        this.mClock = clock;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setDispatcher(Dispatcher dispatcher) {
        this.mDispatcher = dispatcher;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setLastDeleteStaleHitsTime(long j) {
        this.mLastDeleteStaleHitsTime = j;
    }
}

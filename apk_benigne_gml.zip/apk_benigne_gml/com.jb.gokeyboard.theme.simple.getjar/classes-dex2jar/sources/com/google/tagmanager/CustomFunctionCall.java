package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.HashMap;
import java.util.Map;

class CustomFunctionCall extends FunctionCallImplementation {
    private static final String ADDITIONAL_PARAMS = Key.ADDITIONAL_PARAMS.toString();
    private static final String FUNCTION_CALL_NAME = Key.FUNCTION_CALL_NAME.toString();
    private static final String ID = FunctionType.FUNCTION_CALL.toString();
    private final CustomEvaluator mFunctionCallEvaluator;

    public interface CustomEvaluator {
        Object evaluate(String str, Map<String, Object> map);
    }

    public CustomFunctionCall(CustomEvaluator customEvaluator) {
        super(ID, FUNCTION_CALL_NAME);
        this.mFunctionCallEvaluator = customEvaluator;
    }

    public static String getAdditionalParamsKey() {
        return ADDITIONAL_PARAMS;
    }

    public static String getFunctionCallNameKey() {
        return FUNCTION_CALL_NAME;
    }

    public static String getFunctionId() {
        return ID;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        String valueToString = Types.valueToString(map.get(FUNCTION_CALL_NAME));
        HashMap hashMap = new HashMap();
        TypeSystem.Value value = map.get(ADDITIONAL_PARAMS);
        if (value != null) {
            Object valueToObject = Types.valueToObject(value);
            if (!(valueToObject instanceof Map)) {
                Log.w("FunctionCallMacro: expected ADDITIONAL_PARAMS to be a map.");
                return Types.getDefaultValue();
            }
            for (Map.Entry entry : ((Map) valueToObject).entrySet()) {
                hashMap.put(entry.getKey().toString(), entry.getValue());
            }
        }
        try {
            return Types.objectToValue(this.mFunctionCallEvaluator.evaluate(valueToString, hashMap));
        } catch (Exception e) {
            Log.w("Custom macro/tag " + valueToString + " threw exception " + e.getMessage());
            return Types.getDefaultValue();
        }
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return false;
    }
}

package com.google.tagmanager;

import android.content.Context;
import android.net.Uri;
import com.google.tagmanager.DataLayer;
import java.util.Map;

class AdwordsClickReferrerListener implements DataLayer.Listener {
    private final Context context;

    public AdwordsClickReferrerListener(Context context2) {
        this.context = context2;
    }

    @Override // com.google.tagmanager.DataLayer.Listener
    public void changed(Map<Object, Object> map) {
        String queryParameter;
        Object obj;
        Object obj2 = map.get("gtm.url");
        Object obj3 = (obj2 != null || (obj = map.get("gtm")) == null || !(obj instanceof Map)) ? obj2 : ((Map) obj).get("url");
        if (obj3 != null && (obj3 instanceof String) && (queryParameter = Uri.parse((String) obj3).getQueryParameter("referrer")) != null) {
            InstallReferrerUtil.addClickReferrer(this.context, queryParameter);
        }
    }
}

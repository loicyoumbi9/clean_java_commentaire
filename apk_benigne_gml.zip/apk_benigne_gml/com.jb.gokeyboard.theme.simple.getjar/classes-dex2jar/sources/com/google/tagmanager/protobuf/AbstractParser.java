package com.google.tagmanager.protobuf;

import com.google.tagmanager.protobuf.AbstractMessageLite;
import com.google.tagmanager.protobuf.MessageLite;
import java.io.IOException;
import java.io.InputStream;

public abstract class AbstractParser<MessageType extends MessageLite> implements Parser<MessageType> {
    private static final ExtensionRegistryLite EMPTY_REGISTRY = ExtensionRegistryLite.getEmptyRegistry();

    private MessageType checkMessageInitialized(MessageType messagetype) throws InvalidProtocolBufferException {
        if (messagetype == null || messagetype.isInitialized()) {
            return messagetype;
        }
        throw newUninitializedMessageException(messagetype).asInvalidProtocolBufferException().setUnfinishedMessage(messagetype);
    }

    private UninitializedMessageException newUninitializedMessageException(MessageType messagetype) {
        return messagetype instanceof AbstractMessageLite ? messagetype.newUninitializedMessageException() : messagetype instanceof AbstractMutableMessageLite ? messagetype.newUninitializedMessageException() : new UninitializedMessageException((MessageLite) messagetype);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parseDelimitedFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseDelimitedFrom(InputStream inputStream) throws InvalidProtocolBufferException {
        return parseDelimitedFrom(inputStream, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialDelimitedFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return checkMessageInitialized(parsePartialDelimitedFrom(inputStream, extensionRegistryLite));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return parseFrom(byteString, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return checkMessageInitialized(parsePartialFrom(byteString, extensionRegistryLite));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(CodedInputStream codedInputStream) throws InvalidProtocolBufferException {
        return parseFrom(codedInputStream, EMPTY_REGISTRY);
    }

    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return checkMessageInitialized((MessageLite) parsePartialFrom(codedInputStream, extensionRegistryLite));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(InputStream inputStream) throws InvalidProtocolBufferException {
        return parseFrom(inputStream, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return checkMessageInitialized(parsePartialFrom(inputStream, extensionRegistryLite));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
        return parseFrom(bArr, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(byte[] bArr, int i, int i2) throws InvalidProtocolBufferException {
        return parseFrom(bArr, i, i2, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(byte[] bArr, int i, int i2, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return checkMessageInitialized(parsePartialFrom(bArr, i, i2, extensionRegistryLite));
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parseFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return parseFrom(bArr, 0, bArr.length, extensionRegistryLite);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialDelimitedFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialDelimitedFrom(InputStream inputStream) throws InvalidProtocolBufferException {
        return parsePartialDelimitedFrom(inputStream, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [com.google.tagmanager.protobuf.AbstractMessageLite$Builder$LimitedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        try {
            int read = inputStream.read();
            if (read == -1) {
                return null;
            }
            return parsePartialFrom((InputStream) new AbstractMessageLite.Builder.LimitedInputStream(inputStream, CodedInputStream.readRawVarint32(read, inputStream)), extensionRegistryLite);
        } catch (IOException e) {
            throw new InvalidProtocolBufferException(e.getMessage());
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return parsePartialFrom(byteString, EMPTY_REGISTRY);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0017, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001f, code lost:
        throw new java.lang.RuntimeException("Reading from a ByteString threw an IOException (should never happen).", r0);
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0017 A[ExcHandler: IOException (r0v0 'e' java.io.IOException A[CUSTOM_DECLARE]), Splitter:B:0:0x0000] */
    @Override // com.google.tagmanager.protobuf.Parser
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MessageType parsePartialFrom(com.google.tagmanager.protobuf.ByteString r4, com.google.tagmanager.protobuf.ExtensionRegistryLite r5) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
        /*
            r3 = this;
            com.google.tagmanager.protobuf.CodedInputStream r1 = r4.newCodedInput()     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            java.lang.Object r0 = r3.parsePartialFrom(r1, r5)     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            com.google.tagmanager.protobuf.MessageLite r0 = (com.google.tagmanager.protobuf.MessageLite) r0     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            r2 = 0
            r1.checkLastTagWas(r2)     // Catch:{ InvalidProtocolBufferException -> 0x000f, IOException -> 0x0017 }
            return r0
        L_0x000f:
            r1 = move-exception
            com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r1.setUnfinishedMessage(r0)     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            throw r0     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
        L_0x0015:
            r0 = move-exception
            throw r0
        L_0x0017:
            r0 = move-exception
            java.lang.RuntimeException r1 = new java.lang.RuntimeException
            java.lang.String r2 = "Reading from a ByteString threw an IOException (should never happen)."
            r1.<init>(r2, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite");
    }

    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(CodedInputStream codedInputStream) throws InvalidProtocolBufferException {
        return parsePartialFrom(codedInputStream, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(com.google.tagmanager.protobuf.ByteString, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(com.google.tagmanager.protobuf.CodedInputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(java.io.InputStream, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(InputStream inputStream) throws InvalidProtocolBufferException {
        return parsePartialFrom(inputStream, EMPTY_REGISTRY);
    }

    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        CodedInputStream newInstance = CodedInputStream.newInstance(inputStream);
        MessageType parsePartialFrom = parsePartialFrom(newInstance, extensionRegistryLite);
        try {
            newInstance.checkLastTagWas(0);
            return parsePartialFrom;
        } catch (InvalidProtocolBufferException e) {
            throw e.setUnfinishedMessage(parsePartialFrom);
        }
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(byte[] bArr) throws InvalidProtocolBufferException {
        return parsePartialFrom(bArr, 0, bArr.length, EMPTY_REGISTRY);
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(byte[] bArr, int i, int i2) throws InvalidProtocolBufferException {
        return parsePartialFrom(bArr, i, i2, EMPTY_REGISTRY);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0017, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001f, code lost:
        throw new java.lang.RuntimeException("Reading from a byte array threw an IOException (should never happen).", r0);
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0017 A[ExcHandler: IOException (r0v0 'e' java.io.IOException A[CUSTOM_DECLARE]), Splitter:B:0:0x0000] */
    @Override // com.google.tagmanager.protobuf.Parser
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MessageType parsePartialFrom(byte[] r4, int r5, int r6, com.google.tagmanager.protobuf.ExtensionRegistryLite r7) throws com.google.tagmanager.protobuf.InvalidProtocolBufferException {
        /*
            r3 = this;
            com.google.tagmanager.protobuf.CodedInputStream r1 = com.google.tagmanager.protobuf.CodedInputStream.newInstance(r4, r5, r6)     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            java.lang.Object r0 = r3.parsePartialFrom(r1, r7)     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            com.google.tagmanager.protobuf.MessageLite r0 = (com.google.tagmanager.protobuf.MessageLite) r0     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            r2 = 0
            r1.checkLastTagWas(r2)     // Catch:{ InvalidProtocolBufferException -> 0x000f, IOException -> 0x0017 }
            return r0
        L_0x000f:
            r1 = move-exception
            com.google.tagmanager.protobuf.InvalidProtocolBufferException r0 = r1.setUnfinishedMessage(r0)     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
            throw r0     // Catch:{ InvalidProtocolBufferException -> 0x0015, IOException -> 0x0017 }
        L_0x0015:
            r0 = move-exception
            throw r0
        L_0x0017:
            r0 = move-exception
            java.lang.RuntimeException r1 = new java.lang.RuntimeException
            java.lang.String r2 = "Reading from a byte array threw an IOException (should never happen)."
            r1.<init>(r2, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite");
    }

    /* JADX DEBUG: Failed to find minimal casts for resolve overloaded methods, cast all args instead
     method: MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
     arg types: [byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite]
     candidates:
      com.google.tagmanager.protobuf.AbstractParser.parsePartialFrom(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):java.lang.Object throws com.google.tagmanager.protobuf.InvalidProtocolBufferException
      MutableMD:(byte[], int, int, com.google.tagmanager.protobuf.ExtensionRegistryLite):com.google.tagmanager.protobuf.MessageLite throws com.google.tagmanager.protobuf.InvalidProtocolBufferException */
    @Override // com.google.tagmanager.protobuf.Parser
    public MessageType parsePartialFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return parsePartialFrom(bArr, 0, bArr.length, extensionRegistryLite);
    }
}

package com.google.tagmanager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.google.analytics.containertag.proto.Serving;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.tagmanager.LoadCallback;
import com.google.tagmanager.PreviewManager;
import java.io.FileNotFoundException;
import java.io.IOException;

class ResourceLoader implements Runnable {
    private static final String CTFE_URL_PREFIX = "/r?id=";
    private static final String CTFE_URL_SUFFIX = "&v=a50788154";
    private static final String PREVIOUS_CONTAINER_VERSION_QUERY_NAME = "pv";
    @VisibleForTesting
    static final String SDK_VERSION = "a50788154";
    private LoadCallback<Serving.Resource> mCallback;
    private final NetworkClientFactory mClientFactory;
    private final String mContainerId;
    private final Context mContext;
    private volatile CtfeHost mCtfeHost;
    private volatile String mCtfeUrlPathAndQuery;
    private final String mDefaultCtfeUrlPathAndQuery;
    private volatile String mPreviousVersion;

    public ResourceLoader(Context context, String str, CtfeHost ctfeHost) {
        this(context, str, new NetworkClientFactory(), ctfeHost);
    }

    @VisibleForTesting
    ResourceLoader(Context context, String str, NetworkClientFactory networkClientFactory, CtfeHost ctfeHost) {
        this.mContext = context;
        this.mClientFactory = networkClientFactory;
        this.mContainerId = str;
        this.mCtfeHost = ctfeHost;
        this.mDefaultCtfeUrlPathAndQuery = CTFE_URL_PREFIX + str;
        this.mCtfeUrlPathAndQuery = this.mDefaultCtfeUrlPathAndQuery;
        this.mPreviousVersion = null;
    }

    private void loadResource() {
        if (!okToLoad()) {
            this.mCallback.onFailure(LoadCallback.Failure.NOT_AVAILABLE);
            return;
        }
        Log.v("Start loading resource from network ...");
        String ctfeUrl = getCtfeUrl();
        NetworkClient createNetworkClient = this.mClientFactory.createNetworkClient();
        try {
            try {
                Serving.OptionalResource parseFrom = Serving.OptionalResource.parseFrom(createNetworkClient.getInputStream(ctfeUrl), ProtoExtensionRegistry.getRegistry());
                Log.v("Successfully loaded resource: " + parseFrom);
                if (!parseFrom.hasResource()) {
                    Log.v("No change for container: " + this.mContainerId);
                }
                this.mCallback.onSuccess(parseFrom.hasResource() ? parseFrom.getResource() : null);
                createNetworkClient.close();
                Log.v("Load resource from network finished.");
            } catch (IOException e) {
                Log.w("Error when parsing downloaded resources from url: " + ctfeUrl + " " + e.getMessage(), e);
                this.mCallback.onFailure(LoadCallback.Failure.SERVER_ERROR);
            }
        } catch (FileNotFoundException e2) {
            Log.w("No data is retrieved from the given url: " + ctfeUrl + ". Make sure container_id: " + this.mContainerId + " is correct.");
            this.mCallback.onFailure(LoadCallback.Failure.SERVER_ERROR);
        } catch (IOException e3) {
            Log.w("Error when loading resources from url: " + ctfeUrl + " " + e3.getMessage(), e3);
            this.mCallback.onFailure(LoadCallback.Failure.IO_ERROR);
        } finally {
            createNetworkClient.close();
        }
    }

    private boolean okToLoad() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.mContext.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            return true;
        }
        Log.v("...no network connectivity");
        return false;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public String getCtfeUrl() {
        String str = this.mCtfeHost.getCtfeServerAddress() + this.mCtfeUrlPathAndQuery + CTFE_URL_SUFFIX;
        if (this.mPreviousVersion != null && !this.mPreviousVersion.trim().equals("")) {
            str = str + "&pv=" + this.mPreviousVersion;
        }
        return PreviewManager.getInstance().getPreviewMode().equals(PreviewManager.PreviewMode.CONTAINER_DEBUG) ? str + "&gtm_debug=x" : str;
    }

    public void run() {
        if (this.mCallback == null) {
            throw new IllegalStateException("callback must be set before execute");
        }
        this.mCallback.startLoad();
        loadResource();
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setCtfeURLPathAndQuery(String str) {
        if (str == null) {
            this.mCtfeUrlPathAndQuery = this.mDefaultCtfeUrlPathAndQuery;
            return;
        }
        Log.d("Setting CTFE URL path: " + str);
        this.mCtfeUrlPathAndQuery = str;
    }

    /* access modifiers changed from: package-private */
    public void setLoadCallback(LoadCallback<Serving.Resource> loadCallback) {
        this.mCallback = loadCallback;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void setPreviousVersion(String str) {
        Log.d("Setting previous container version: " + str);
        this.mPreviousVersion = str;
    }
}

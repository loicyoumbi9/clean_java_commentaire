package com.google.tagmanager;

import android.util.Log;
import com.google.tagmanager.Logger;

class DefaultLogger implements Logger {
    private static final String LOG_TAG = "GoogleTagManager";
    private Logger.LogLevel mLogLevel = Logger.LogLevel.WARNING;

    DefaultLogger() {
    }

    @Override // com.google.tagmanager.Logger
    public void d(String str) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.DEBUG.ordinal()) {
            Log.d(LOG_TAG, str);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void d(String str, Throwable th) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.DEBUG.ordinal()) {
            Log.d(LOG_TAG, str, th);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void e(String str) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.ERROR.ordinal()) {
            Log.e(LOG_TAG, str);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void e(String str, Throwable th) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.ERROR.ordinal()) {
            Log.e(LOG_TAG, str, th);
        }
    }

    @Override // com.google.tagmanager.Logger
    public Logger.LogLevel getLogLevel() {
        return this.mLogLevel;
    }

    @Override // com.google.tagmanager.Logger
    public void i(String str) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.INFO.ordinal()) {
            Log.i(LOG_TAG, str);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void i(String str, Throwable th) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.INFO.ordinal()) {
            Log.i(LOG_TAG, str, th);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void setLogLevel(Logger.LogLevel logLevel) {
        this.mLogLevel = logLevel;
    }

    @Override // com.google.tagmanager.Logger
    public void v(String str) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.VERBOSE.ordinal()) {
            Log.v(LOG_TAG, str);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void v(String str, Throwable th) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.VERBOSE.ordinal()) {
            Log.v(LOG_TAG, str, th);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void w(String str) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.WARNING.ordinal()) {
            Log.w(LOG_TAG, str);
        }
    }

    @Override // com.google.tagmanager.Logger
    public void w(String str, Throwable th) {
        if (this.mLogLevel.ordinal() <= Logger.LogLevel.WARNING.ordinal()) {
            Log.w(LOG_TAG, str, th);
        }
    }
}

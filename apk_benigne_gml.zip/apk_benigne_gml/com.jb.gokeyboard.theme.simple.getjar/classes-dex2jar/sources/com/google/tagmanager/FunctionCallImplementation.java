package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

abstract class FunctionCallImplementation {
    private static final String FUNCTION_KEY = "function";
    private final String mFunctionId;
    private final Set<String> mRequiredKeys;

    public FunctionCallImplementation(String str, String... strArr) {
        this.mFunctionId = str;
        this.mRequiredKeys = new HashSet(strArr.length);
        for (String str2 : strArr) {
            this.mRequiredKeys.add(str2);
        }
    }

    public static String getFunctionKey() {
        return FUNCTION_KEY;
    }

    public abstract TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map);

    public String getInstanceFunctionId() {
        return this.mFunctionId;
    }

    public Set<String> getRequiredKeys() {
        return this.mRequiredKeys;
    }

    /* access modifiers changed from: package-private */
    public boolean hasRequiredKeys(Set<String> set) {
        return set.containsAll(this.mRequiredKeys);
    }

    public abstract boolean isCacheable();
}

package com.google.tagmanager;

import com.google.tagmanager.CacheFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class SimpleCache<K, V> implements Cache<K, V> {
    private final Map<K, V> mHashMap = new HashMap();
    private final int mMaxSize;
    private final CacheFactory.CacheSizeManager<K, V> mSizeManager;
    private int mTotalSize;

    SimpleCache(int i, CacheFactory.CacheSizeManager<K, V> cacheSizeManager) {
        this.mMaxSize = i;
        this.mSizeManager = cacheSizeManager;
    }

    @Override // com.google.tagmanager.Cache
    public V get(K k) {
        V v;
        synchronized (this) {
            v = this.mHashMap.get(k);
        }
        return v;
    }

    @Override // com.google.tagmanager.Cache
    public void put(K k, V v) {
        synchronized (this) {
            if (k == null || v == null) {
                throw new NullPointerException("key == null || value == null");
            }
            this.mTotalSize += this.mSizeManager.sizeOf(k, v);
            if (this.mTotalSize > this.mMaxSize) {
                Iterator<Map.Entry<K, V>> it = this.mHashMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<K, V> next = it.next();
                    this.mTotalSize -= this.mSizeManager.sizeOf(next.getKey(), next.getValue());
                    it.remove();
                    if (this.mTotalSize <= this.mMaxSize) {
                        break;
                    }
                }
            }
            this.mHashMap.put(k, v);
        }
    }
}

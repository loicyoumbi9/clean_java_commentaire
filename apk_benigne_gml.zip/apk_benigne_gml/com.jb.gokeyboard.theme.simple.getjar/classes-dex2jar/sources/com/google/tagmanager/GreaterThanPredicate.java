package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

class GreaterThanPredicate extends NumberPredicate {
    private static final String ID = FunctionType.GREATER_THAN.toString();

    public GreaterThanPredicate() {
        super(ID);
    }

    public static String getFunctionId() {
        return ID;
    }

    /* access modifiers changed from: protected */
    @Override // com.google.tagmanager.NumberPredicate
    public boolean evaluateNumber(TypedNumber typedNumber, TypedNumber typedNumber2, Map<String, TypeSystem.Value> map) {
        return typedNumber.compareTo(typedNumber2) > 0;
    }
}

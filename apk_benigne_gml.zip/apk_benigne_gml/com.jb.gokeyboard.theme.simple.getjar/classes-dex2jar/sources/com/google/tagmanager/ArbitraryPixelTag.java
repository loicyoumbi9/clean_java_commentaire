package com.google.tagmanager;

import android.content.Context;
import android.net.Uri;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

class ArbitraryPixelTag extends TrackingTag {
    private static final String ADDITIONAL_PARAMS = Key.ADDITIONAL_PARAMS.toString();
    static final String ARBITRARY_PIXEL_UNREPEATABLE = ("gtm_" + ID + "_unrepeatable");
    private static final String ID = FunctionType.ARBITRARY_PIXEL.toString();
    private static final String UNREPEATABLE = Key.UNREPEATABLE.toString();
    private static final String URL = Key.URL.toString();
    private static final Set<String> unrepeatableIds = new HashSet();
    private final Context mContext;
    private final HitSenderProvider mHitSenderProvider;

    public interface HitSenderProvider {
        HitSender get();
    }

    public ArbitraryPixelTag(final Context context) {
        this(context, new HitSenderProvider() {
            /* class com.google.tagmanager.ArbitraryPixelTag.AnonymousClass1 */

            @Override // com.google.tagmanager.ArbitraryPixelTag.HitSenderProvider
            public HitSender get() {
                return DelayedHitSender.getInstance(context);
            }
        });
    }

    @VisibleForTesting
    ArbitraryPixelTag(Context context, HitSenderProvider hitSenderProvider) {
        super(ID, URL);
        this.mHitSenderProvider = hitSenderProvider;
        this.mContext = context;
    }

    public static String getFunctionId() {
        return ID;
    }

    private boolean idProcessed(String str) {
        boolean z = true;
        synchronized (this) {
            if (!idInCache(str)) {
                if (idInSharedPreferences(str)) {
                    unrepeatableIds.add(str);
                } else {
                    z = false;
                }
            }
        }
        return z;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void clearCache() {
        unrepeatableIds.clear();
    }

    @Override // com.google.tagmanager.TrackingTag
    public void evaluateTrackingTag(Map<String, TypeSystem.Value> map) {
        String valueToString = map.get(UNREPEATABLE) != null ? Types.valueToString(map.get(UNREPEATABLE)) : null;
        if (valueToString == null || !idProcessed(valueToString)) {
            Uri.Builder buildUpon = Uri.parse(Types.valueToString(map.get(URL))).buildUpon();
            TypeSystem.Value value = map.get(ADDITIONAL_PARAMS);
            if (value != null) {
                Object valueToObject = Types.valueToObject(value);
                if (!(valueToObject instanceof List)) {
                    Log.e("ArbitraryPixel: additional params not a list: not sending partial hit: " + buildUpon.build().toString());
                    return;
                }
                for (Object obj : (List) valueToObject) {
                    if (!(obj instanceof Map)) {
                        Log.e("ArbitraryPixel: additional params contains non-map: not sending partial hit: " + buildUpon.build().toString());
                        return;
                    }
                    for (Map.Entry entry : ((Map) obj).entrySet()) {
                        buildUpon.appendQueryParameter(entry.getKey().toString(), entry.getValue().toString());
                    }
                }
            }
            String uri = buildUpon.build().toString();
            this.mHitSenderProvider.get().sendHit(uri);
            Log.v("ArbitraryPixel: url = " + uri);
            if (valueToString != null) {
                synchronized (ArbitraryPixelTag.class) {
                    try {
                        unrepeatableIds.add(valueToString);
                        SharedPreferencesUtil.saveAsync(this.mContext, ARBITRARY_PIXEL_UNREPEATABLE, valueToString, "true");
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public boolean idInCache(String str) {
        return unrepeatableIds.contains(str);
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public boolean idInSharedPreferences(String str) {
        return this.mContext.getSharedPreferences(ARBITRARY_PIXEL_UNREPEATABLE, 0).contains(str);
    }
}

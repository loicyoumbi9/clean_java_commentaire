package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

class InstallReferrerMacro extends FunctionCallImplementation {
    private static final String COMPONENT = Key.COMPONENT.toString();
    private static final String ID = FunctionType.INSTALL_REFERRER.toString();
    private final Context context;

    public InstallReferrerMacro(Context context2) {
        super(ID, new String[0]);
        this.context = context2;
    }

    public static String getFunctionId() {
        return ID;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        String installReferrer = InstallReferrerUtil.getInstallReferrer(this.context, map.get(COMPONENT) != null ? Types.valueToString(map.get(COMPONENT)) : null);
        return installReferrer != null ? Types.objectToValue(installReferrer) : Types.getDefaultValue();
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return true;
    }
}

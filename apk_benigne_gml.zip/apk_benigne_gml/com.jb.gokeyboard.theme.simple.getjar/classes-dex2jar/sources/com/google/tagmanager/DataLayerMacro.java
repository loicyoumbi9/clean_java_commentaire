package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem;
import java.util.Map;

class DataLayerMacro extends FunctionCallImplementation {
    private static final String DEFAULT_VALUE = Key.DEFAULT_VALUE.toString();
    private static final String ID = FunctionType.CUSTOM_VAR.toString();
    private static final String NAME = Key.NAME.toString();
    private final DataLayer mDataLayer;

    public DataLayerMacro(DataLayer dataLayer) {
        super(ID, NAME);
        this.mDataLayer = dataLayer;
    }

    public static String getDefaultValueKey() {
        return DEFAULT_VALUE;
    }

    public static String getFunctionId() {
        return ID;
    }

    public static String getNameKey() {
        return NAME;
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public TypeSystem.Value evaluate(Map<String, TypeSystem.Value> map) {
        Object obj = this.mDataLayer.get(Types.valueToString(map.get(NAME)));
        if (obj != null) {
            return Types.objectToValue(obj);
        }
        TypeSystem.Value value = map.get(DEFAULT_VALUE);
        return value != null ? value : Types.getDefaultValue();
    }

    @Override // com.google.tagmanager.FunctionCallImplementation
    public boolean isCacheable() {
        return false;
    }
}

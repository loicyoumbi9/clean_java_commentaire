package com.google.tagmanager;

class NoopEventInfoDistributor implements EventInfoDistributor {
    NoopEventInfoDistributor() {
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public EventInfoBuilder createDataLayerEventEvaluationEventInfo(String str) {
        return new NoopEventInfoBuilder();
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public EventInfoBuilder createMacroEvalutionEventInfo(String str) {
        return new NoopEventInfoBuilder();
    }

    @Override // com.google.tagmanager.EventInfoDistributor
    public boolean debugMode() {
        return false;
    }
}

package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem;

class NoopResolvedPropertyBuilder implements ResolvedPropertyBuilder {
    NoopResolvedPropertyBuilder() {
    }

    @Override // com.google.tagmanager.ResolvedPropertyBuilder
    public ValueBuilder createPropertyValueBuilder(TypeSystem.Value value) {
        return new NoopValueBuilder();
    }
}

package com.google.tagmanager;

import android.content.Context;
import android.content.res.AssetManager;
import com.getjar.sdk.utilities.Constants;
import com.google.analytics.containertag.proto.Serving;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.tagmanager.Container;
import com.google.tagmanager.LoadCallback;
import com.google.tagmanager.PreviewManager;
import com.google.tagmanager.proto.Resource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class ResourceStorageImpl implements Container.ResourceStorage {
    private static final String SAVED_RESOURCE_FILENAME_PREFIX = "resource_";
    private static final String SAVED_RESOURCE_SUB_DIR = "google_tagmanager";
    private LoadCallback<Resource.ResourceWithMetadata> mCallback;
    private final String mContainerId;
    private final Context mContext;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();

    ResourceStorageImpl(Context context, String str) {
        this.mContext = context;
        this.mContainerId = str;
    }

    private String stringFromInputStream(InputStream inputStream) throws IOException {
        StringWriter stringWriter = new StringWriter();
        char[] cArr = new char[1024];
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Constants.ENCODING_CHARSET));
        while (true) {
            int read = bufferedReader.read(cArr);
            if (read == -1) {
                return stringWriter.toString();
            }
            stringWriter.write(cArr, 0, read);
        }
    }

    @Override // com.google.tagmanager.Container.ResourceStorage
    public void close() {
        synchronized (this) {
            this.mExecutor.shutdown();
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public File getResourceFile() {
        return new File(this.mContext.getDir(SAVED_RESOURCE_SUB_DIR, 0), SAVED_RESOURCE_FILENAME_PREFIX + this.mContainerId);
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0084 A[SYNTHETIC, Splitter:B:25:0x0084] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x008f A[SYNTHETIC, Splitter:B:31:0x008f] */
    @Override // com.google.tagmanager.Container.ResourceStorage
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.tagmanager.ResourceUtil.ExpandedResource loadExpandedResourceFromJsonAsset(java.lang.String r6) {
        /*
            r5 = this;
            r0 = 0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "loading default container from "
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.StringBuilder r1 = r1.append(r6)
            java.lang.String r1 = r1.toString()
            com.google.tagmanager.Log.v(r1)
            android.content.Context r1 = r5.mContext
            android.content.res.AssetManager r1 = r1.getAssets()
            if (r1 != 0) goto L_0x0025
            java.lang.String r1 = "Looking for default JSON container in package, but no assets were found."
            com.google.tagmanager.Log.w(r1)
        L_0x0024:
            return r0
        L_0x0025:
            java.io.InputStream r1 = r1.open(r6)     // Catch:{ IOException -> 0x0039, JSONException -> 0x005f, all -> 0x008a }
            java.lang.String r2 = r5.stringFromInputStream(r1)     // Catch:{ IOException -> 0x009f, JSONException -> 0x009c }
            com.google.tagmanager.ResourceUtil$ExpandedResource r0 = com.google.tagmanager.JsonUtils.expandedResourceFromJsonString(r2)     // Catch:{ IOException -> 0x009f, JSONException -> 0x009c }
            if (r1 == 0) goto L_0x0024
            r1.close()     // Catch:{ IOException -> 0x0037 }
            goto L_0x0024
        L_0x0037:
            r1 = move-exception
            goto L_0x0024
        L_0x0039:
            r1 = move-exception
            r1 = r0
        L_0x003b:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0095 }
            r2.<init>()     // Catch:{ all -> 0x0095 }
            java.lang.String r3 = "No asset file: "
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x0095 }
            java.lang.StringBuilder r2 = r2.append(r6)     // Catch:{ all -> 0x0095 }
            java.lang.String r3 = " found (or errors reading it)."
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x0095 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0095 }
            com.google.tagmanager.Log.w(r2)     // Catch:{ all -> 0x0095 }
            if (r1 == 0) goto L_0x0024
            r1.close()     // Catch:{ IOException -> 0x005d }
            goto L_0x0024
        L_0x005d:
            r1 = move-exception
            goto L_0x0024
        L_0x005f:
            r1 = move-exception
            r2 = r1
            r3 = r0
        L_0x0062:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0099 }
            r1.<init>()     // Catch:{ all -> 0x0099 }
            java.lang.String r4 = "Error parsing JSON file"
            java.lang.StringBuilder r1 = r1.append(r4)     // Catch:{ all -> 0x0099 }
            java.lang.StringBuilder r1 = r1.append(r6)     // Catch:{ all -> 0x0099 }
            java.lang.String r4 = " : "
            java.lang.StringBuilder r1 = r1.append(r4)     // Catch:{ all -> 0x0099 }
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0099 }
            com.google.tagmanager.Log.w(r1)     // Catch:{ all -> 0x0099 }
            if (r3 == 0) goto L_0x0024
            r3.close()     // Catch:{ IOException -> 0x0088 }
            goto L_0x0024
        L_0x0088:
            r1 = move-exception
            goto L_0x0024
        L_0x008a:
            r1 = move-exception
            r2 = r1
            r3 = r0
        L_0x008d:
            if (r3 == 0) goto L_0x0092
            r3.close()     // Catch:{ IOException -> 0x0093 }
        L_0x0092:
            throw r2
        L_0x0093:
            r0 = move-exception
            goto L_0x0092
        L_0x0095:
            r0 = move-exception
            r2 = r0
            r3 = r1
            goto L_0x008d
        L_0x0099:
            r0 = move-exception
            r2 = r0
            goto L_0x008d
        L_0x009c:
            r2 = move-exception
            r3 = r1
            goto L_0x0062
        L_0x009f:
            r2 = move-exception
            goto L_0x003b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.tagmanager.ResourceStorageImpl.loadExpandedResourceFromJsonAsset(java.lang.String):com.google.tagmanager.ResourceUtil$ExpandedResource");
    }

    @Override // com.google.tagmanager.Container.ResourceStorage
    public Serving.Resource loadResourceFromContainerAsset(String str) {
        Log.v("Loading default container from " + str);
        AssetManager assets = this.mContext.getAssets();
        if (assets == null) {
            Log.e("No assets found in package");
            return null;
        }
        try {
            InputStream open = assets.open(str);
            try {
                Serving.Resource parseFrom = Serving.Resource.parseFrom(open, ProtoExtensionRegistry.getRegistry());
                Log.v("Parsed default container: " + parseFrom);
                try {
                    open.close();
                    return parseFrom;
                } catch (IOException e) {
                    return parseFrom;
                }
            } catch (IOException e2) {
                Log.w("Error when parsing: " + str);
                try {
                    open.close();
                    return null;
                } catch (IOException e3) {
                    return null;
                }
            } catch (Throwable th) {
                try {
                    open.close();
                } catch (IOException e4) {
                }
                throw th;
            }
        } catch (IOException e5) {
            Log.w("No asset file: " + str + " found.");
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void loadResourceFromDisk() {
        if (this.mCallback == null) {
            throw new IllegalStateException("callback must be set before execute");
        }
        this.mCallback.startLoad();
        Log.v("Start loading resource from disk ...");
        if ((PreviewManager.getInstance().getPreviewMode() == PreviewManager.PreviewMode.CONTAINER || PreviewManager.getInstance().getPreviewMode() == PreviewManager.PreviewMode.CONTAINER_DEBUG) && this.mContainerId.equals(PreviewManager.getInstance().getContainerId())) {
            this.mCallback.onFailure(LoadCallback.Failure.NOT_AVAILABLE);
            return;
        }
        try {
            FileInputStream fileInputStream = new FileInputStream(getResourceFile());
            try {
                this.mCallback.onSuccess(Resource.ResourceWithMetadata.parseFrom(fileInputStream, ProtoExtensionRegistry.getRegistry()));
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    Log.w("error closing stream for reading resource from disk");
                }
            } catch (IOException e2) {
                Log.w("error reading resource from disk");
                this.mCallback.onFailure(LoadCallback.Failure.IO_ERROR);
                try {
                    fileInputStream.close();
                } catch (IOException e3) {
                    Log.w("error closing stream for reading resource from disk");
                }
            } catch (Throwable th) {
                try {
                    fileInputStream.close();
                } catch (IOException e4) {
                    Log.w("error closing stream for reading resource from disk");
                }
                throw th;
            }
            Log.v("Load resource from disk finished.");
        } catch (FileNotFoundException e5) {
            Log.d("resource not on disk");
            this.mCallback.onFailure(LoadCallback.Failure.NOT_AVAILABLE);
        }
    }

    @Override // com.google.tagmanager.Container.ResourceStorage
    public void loadResourceFromDiskInBackground() {
        this.mExecutor.execute(new Runnable() {
            /* class com.google.tagmanager.ResourceStorageImpl.AnonymousClass1 */

            public void run() {
                ResourceStorageImpl.this.loadResourceFromDisk();
            }
        });
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public boolean saveResourceToDisk(Resource.ResourceWithMetadata resourceWithMetadata) {
        File resourceFile = getResourceFile();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(resourceFile);
            try {
                resourceWithMetadata.writeTo(fileOutputStream);
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    Log.w("error closing stream for writing resource to disk");
                }
                return true;
            } catch (IOException e2) {
                Log.w("Error writing resource to disk. Removing resource from disk.");
                resourceFile.delete();
                try {
                    fileOutputStream.close();
                    return false;
                } catch (IOException e3) {
                    Log.w("error closing stream for writing resource to disk");
                    return false;
                }
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                } catch (IOException e4) {
                    Log.w("error closing stream for writing resource to disk");
                }
                throw th;
            }
        } catch (FileNotFoundException e5) {
            Log.e("Error opening resource file for writing");
            return false;
        }
    }

    @Override // com.google.tagmanager.Container.ResourceStorage
    public void saveResourceToDiskInBackground(final Resource.ResourceWithMetadata resourceWithMetadata) {
        this.mExecutor.execute(new Runnable() {
            /* class com.google.tagmanager.ResourceStorageImpl.AnonymousClass2 */

            public void run() {
                ResourceStorageImpl.this.saveResourceToDisk(resourceWithMetadata);
            }
        });
    }

    @Override // com.google.tagmanager.Container.ResourceStorage
    public void setLoadCallback(LoadCallback<Resource.ResourceWithMetadata> loadCallback) {
        this.mCallback = loadCallback;
    }
}

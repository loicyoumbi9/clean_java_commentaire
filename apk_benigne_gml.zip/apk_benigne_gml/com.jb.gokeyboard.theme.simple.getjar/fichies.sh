#!/bin/bash
cd classes-dex2jar
a=`ls`
for file in $a
do
	if [ -d "$file" ]; then 
		if [ "$(ls -A "$file" )" != "" ]; then
		 	cat */* . >> fichiers.txt
			a=`ls`
			cd ..
			sudo ./fichies.sh	
		fi
	fi
done
a=`ls`
for file in $a
do
	if [ -d "$file" ]; then 
		if [ "$(ls -A "$file" )" == "" ]; then
		 	rm -R "$file"	
		fi
	elif [ -f "$file" ]; then
		if [  "${file##*.}" == "java" ];then
			cat "$file" >> fichiers.txt
		fi
	fi
done
sudo chmod -R 777 fichiers.txt

